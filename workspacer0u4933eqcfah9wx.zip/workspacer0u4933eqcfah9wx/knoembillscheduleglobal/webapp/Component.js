sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"sap/ui/model/json/JSONModel",
	"kno/em/billschedule/model/models"

], function (UIComponent, Device, JSONModel, models) {
	"use strict";

	return UIComponent.extend("kno.em.billschedule.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * In this method, the FLP and device models are set and the router is initialized.
		 * @public
		 * @override
		 */
		init: function () {

			// set the device model
			this.setModel(models.createDeviceModel(), "device");
			// set the FLP model
			this.setModel(models.createFLPModel(), "FLP");

			// call the base component's init function and create the App view
			UIComponent.prototype.init.apply(this, arguments);
			// create the views based on the url/hash
			this.getRouter().initialize();

			var mBillScheVis = new sap.ui.model.json.JSONModel({
				CreateVisibility: true,
				EditVisibility: false,
				CreateEnabled: true
			});
			this.setModel(mBillScheVis, "mBillScheVis");

			var mBillScheduleHeader = new sap.ui.model.json.JSONModel({
				items: []
			});
			this.setModel(mBillScheduleHeader, "mBillScheduleHeader");
			var oTextResource = this.getModel("i18n").getResourceBundle();
			var sTimeText = oTextResource.getText("TimeText");
			var sFixText = oTextResource.getText("FixText");
			var sDownText = oTextResource.getText("DownText");
			var sMonthly = oTextResource.getText("Monthly");
			var sQuarterly = oTextResource.getText("Quarterly");
			var sBiannually = oTextResource.getText("Biannually");
			var sYearly = oTextResource.getText("Yearly");
			var sSingle = oTextResource.getText("Single");
			var sYes = oTextResource.getText("Yes");
			var sNo = oTextResource.getText("No");
			var sBillDateWise = oTextResource.getText("BillDateWise");
			var sEngItemWise = oTextResource.getText("EngItemWise");
			var sAll = oTextResource.getText("All");

			var arrPlanTyp = [];
			var json1 = {
				plan: "Y003",
				planDesc: sTimeText
			};

			var json2 = {
				plan: "Y004",
				planDesc: sFixText
			};

			var json3 = {
				plan: "Y009",
				planDesc: sDownText
			};

			var json4 = {
				plan: " ",
				planDesc: " "
			};

			arrPlanTyp.push(" ");
			arrPlanTyp.push(json1);
			arrPlanTyp.push(json2);
			arrPlanTyp.push(json3);
			arrPlanTyp.push(json4);

			var mPlanTyp = new sap.ui.model.json.JSONModel({
				items: arrPlanTyp
			});
			this.setModel(mPlanTyp, "mPlanTyp");

			var mBillBlk = new sap.ui.model.json.JSONModel({
				items: []
			});
			this.setModel(mBillBlk, "mBillBlk");

			var arrPlanFreq = [];
			var json11 = {
				planFreq: "M",
				freqDesc: sMonthly
			};

			var json21 = {
				planFreq: "Q",
				freqDesc: sQuarterly
			};

			var json31 = {
				planFreq: "H",
				freqDesc: sBiannually
			};

			var json41 = {
				planFreq: "Y",
				freqDesc: sYearly
			};

			var json51 = {
				planFreq: "S",
				freqDesc: sSingle
			};

			arrPlanFreq.push(json11);
			arrPlanFreq.push(json21);
			arrPlanFreq.push(json31);
			arrPlanFreq.push(json41);
			arrPlanFreq.push(json51);

			var mPlanFreq = new sap.ui.model.json.JSONModel({
				items: arrPlanFreq
			});
			this.setModel(mPlanFreq, "mPlanFreq");

			var appGrpBy = [{
				grpCode: "01",
				grpDesc: sBillDateWise
			}, {
				grpCode: "02",
				grpDesc: sEngItemWise
			}, {
				grpCode: "03",
				grpDesc: sAll
			}];

			var mGrpBy = new sap.ui.model.json.JSONModel({
				items: appGrpBy
			});
			this.setModel(mGrpBy, "mGrpBy");

			var mBillDates = new sap.ui.model.json.JSONModel({
				items: []
			});
			this.setModel(mBillDates, "mBillDates");

			var mEngItms = new sap.ui.model.json.JSONModel({
				items: []
			});
			this.setModel(mEngItms, "mEngItms");

			var mEngNum = new sap.ui.model.json.JSONModel({
				items: []
			});
			this.setModel(mEngNum, "mEngNum");

			var arrConBill = [{
				conCode: "X",
				conDesc: sYes
			}, {
				conCode: " ",
				conDesc: sNo
			}];

			var mConBill = new sap.ui.model.json.JSONModel({
				items: arrConBill
			});
			this.setModel(mConBill, "mConBill");

			var mBisDateEdit = new sap.ui.model.json.JSONModel({
				editable: false
			});
			this.setModel(mBisDateEdit, "mBisDateEdit");

			var mBillBlock = new sap.ui.model.json.JSONModel({
				items: []
			});
			this.setModel(mBillBlock, "mBillBlock");

			var mUserProfile = new sap.ui.model.json.JSONModel({
				dateFormat: "",
				currFormat: ""

			});
			mUserProfile.setDefaultBindingMode("TwoWay");
			this.setModel(mUserProfile, "mUserProfile");

			var mBillPlanEdit = new sap.ui.model.json.JSONModel({
				items: []

			});
			mBillPlanEdit.setDefaultBindingMode("TwoWay");
			mBillPlanEdit.setSizeLimit(999999);
			this.setModel(mBillPlanEdit, "mBillPlanEdit");

			var mBillPlanCrea = new sap.ui.model.json.JSONModel({
				items: []

			});
			mBillPlanCrea.setDefaultBindingMode("TwoWay");
			mBillPlanCrea.setSizeLimit(999999);
			this.setModel(mBillPlanCrea, "mBillPlanCrea");

			var mOriginalModel = new sap.ui.model.json.JSONModel({
				items: []

			});
			// mBillPlanEdit.setDefaultBindingMode("TwoWay");
			this.setModel(mOriginalModel, "mOriginalModel");

			var mCurrencyKey = new sap.ui.model.json.JSONModel({
				currKey: ""

			});
			this.setModel(mCurrencyKey, "mCurrencyKey");

			var mDateModel = new sap.ui.model.json.JSONModel({
				sDate: "",
				eDate: ""

			});
			this.setModel(mDateModel, "mDateModel");

			var mConBillEnabled = new sap.ui.model.json.JSONModel({
				Enabled: false,
				Editable: false

			});
			this.setModel(mConBillEnabled, "mConBillEnabled");

		},

		/**
		 * The component is destroyed by UI5 automatically.
		 * In this method, the ListSelector and ErrorHandler are destroyed.
		 * @public
		 * @override
		 */
		destroy: function () {
			// call the base component's destroy function
			UIComponent.prototype.destroy.apply(this, arguments);
		},

		/**
		 * This method can be called to determine whether the sapUiSizeCompact or sapUiSizeCozy
		 * design mode class should be set, which influences the size appearance of some controls.
		 * @public
		 * @return {string} css class, either 'sapUiSizeCompact' or 'sapUiSizeCozy' - or an empty string if no css class should be set
		 */
		getContentDensityClass: function () {
			if (this._sContentDensityClass === undefined) {
				// check whether FLP has already set the content density class; do nothing in this case
				if (jQuery(document.body).hasClass("sapUiSizeCozy") || jQuery(document.body).hasClass("sapUiSizeCompact")) {
					this._sContentDensityClass = "";
				} else if (!Device.support.touch) { // apply "compact" mode if touch is not supported
					this._sContentDensityClass = "sapUiSizeCompact";
				} else {
					// "cozy" in case of touch support; default for most sap.m controls, but needed for desktop-first controls like sap.ui.table.Table
					this._sContentDensityClass = "sapUiSizeCozy";
				}
			}
			return this._sContentDensityClass;
		}

	});

});