/*global history */

//jQuery.sap.require("sap.ui.core.IconPool");
sap.ui.define([
	"kno/em/billschedule/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/GroupHeaderListItem",
	"sap/ui/Device",
	"kno/em/billschedule/model/formatter",
	"kno/em/billschedule/model/grouper",
	"kno/em/billschedule/model/GroupSortState",
	"sap/ui/core/IconPool",
	"sap/m/MessageBox"

	// "sap/m/MessagePopover",
	// "sap/m/MessageItem"
], function (BaseController, JSONModel, History, Filter, FilterOperator, GroupHeaderListItem, Device, formatter, grouper, GroupSortState,
	IconPool, MessageBo) {
	// "use strict";

	return BaseController.extend("kno.em.billschedule.controller.createbillschedule", {

		formatter: formatter,
		oController: this,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the master list controller is instantiated. It sets up the event handling for the master/detail communication and other lifecycle tasks.
		 * @public
		 */

		onExit: function () {
			this.dequeueEngagement();
			this.destroy();

		},

		// onNavBack: function () {
		// 	this.dequeueEngagement();
		// 	var sPreviousHash = History.getInstance().getPreviousHash(),
		// 		oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

		// 	if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
		// 		history.go(-1);
		// 	} else {
		// 		oCrossAppNavigator.toExternal({
		// 			target: {
		// 				shellHash: "#Shell-home"
		// 			}
		// 		});
		// 	}
		// },

		removeSpecialChars: function (strng) {
			var specialChars = "%20";
			var str = strng.split(specialChars);
			var sReturn;

			for (var j = 0; j < str.length; j++) {

				if (j === 0) {
					sReturn = str[j];
				} else {
					sReturn = sReturn + ' ' + str[j];
				}
			}

			return sReturn;
		},

		onInit: function () {

			var fnUserSettingSuccess = jQuery.proxy(function (oData, response) {
				var mUserSettings = JSON.parse(JSON.stringify(oData));
				var arrUserSettingsData = mUserSettings.results[0];
				var mUserProfile = this.getOwnerComponent().getModel("mUserProfile");
				mUserProfile.setProperty("/dateFormat", arrUserSettingsData.DATE_FORMAT);
				mUserProfile.setProperty("/currFormat", arrUserSettingsData.DEC_FORMAT);

				this.sDateFormat = arrUserSettingsData.DATE_FORMAT;
				mUserProfile.refresh();
				this.getView().setModel(mUserProfile, "mUserProfile");
				// this.loadInitialSettings();
			}, this);

			var fnUserSettingError = jQuery.proxy(function (response) {

				var mUserProfile = this.getOwnerComponent().getModel("mUserProfile");
				mUserProfile.setProperty("/dateFormat", "dd.MM.yyyy");
				mUserProfile.refresh();
				this.getView().setModel(mUserProfile, "mUserProfile");

				// this.loadInitialSettings();
			}, this);

			var oDataModl = this.getOwnerComponent().getModel("mainSrv");

			var mParams = {
				success: fnUserSettingSuccess,
				error: fnUserSettingError
			};

			oDataModl.read('/UserSettingSet', mParams);
			this.loadInitialSettings();
			this.loadHeaderDetails();

		},

		onAfterRendering: function () {

			this.setRowsNonEditable();

		},

		setRowsNonEditable: function () {
			if (this.Mode === 'E') {

				// var oItemBlockTable = this.getView().byId("idTabBillEdit");

				var sTabKey = this.getView().byId("idIconTabBar").getSelectedKey();
				var oItemBlockTable;

				switch (sTabKey) {
				case "01":
					oItemBlockTable = this.getView().byId("idTabBillEdit");
					break;

				case "02":
					oItemBlockTable = this.getView().byId("idTabBillEditAll");
					break;
				default:
				}
				oItemBlockTable.addEventDelegate({
					onAfterRendering: jQuery.proxy(function (event) {
							var sKey = this.getView().byId("idIconTabBar").getSelectedKey();
							var oTab;

							switch (sKey) {
							case "01":
								oTab = this.getView().byId("idTabBillEdit");
								break;

							case "02":
								oTab = this.getView().byId("idTabBillEditAll");
								break;
							default:
							}
							var oTabItems = oTab.getItems();
							var oCells;

							var arrBillPlanModel = this.getView().getModel("mBillPlanEdit").getData().items;

							for (var i = 0; i < arrBillPlanModel.length; i++) {

								if (arrBillPlanModel[i].tetxt === "Y605") {
									oTabItems[i].getModeControl().setEnabled(false);
									oCells = oTabItems[i].getCells();

									// if (sKey === "01") {
									// 	for (var j = 0; j < oCells.length; j++) {

									// 		if (j === 5) {
									// 			oCells[j].mAggregations.items[0].setEditable(false);
									// 		} else {
									// 			if (!oCells[j].mProperties["text"]) {
									// 				oCells[j].setEditable(false);
									// 			}
									// 		}
									// 	}
									// } else {
									// 	oCells[6].setEditable(false);
									// }
								}
							}

						},
						this)
				});

			}
		},

		dequeueEngagement: function () {

			var oDataModl = this.getOwnerComponent().getModel("mainSrv");

			var oComponentData = this.getOwnerComponent().getComponentData();

			if (oComponentData.startupParameters && jQuery.isEmptyObject(oComponentData.startupParameters) ===
				false) {

				var mBillHeader = this.getOwnerComponent().getModel("mBillScheduleHeader");
				var arrEngNum = mBillHeader.getProperty("/items");

				var sVbeln = " ";

				for (var i = 0; i < arrEngNum.length; i++) {

					if (arrEngNum[i].EngNum.length < 10) {
						for (var j = arrEngNum[i].EngNum.length; j < 10; j++) {
							arrEngNum[i].EngNum = '0' + arrEngNum[i].EngNum;
						}
					}
					sVbeln = sVbeln + "|" + arrEngNum[i].EngNum;

				}

				var fnSuccess = jQuery.proxy(function (oData, response) {
						// sap.ui.core.BusyIndicator.hide();
					},
					this);

				var fnError = jQuery.proxy(function (oData, response) {
					// sap.ui.core.BusyIndicator.hide();
				}, this);

				// sap.ui.core.BusyIndicator.show(0);
				oDataModl.callFunction('/engDequeue', {
					urlParameters: {
						ENGNUM: sVbeln
							// MODE: sMode
					},

					method: "GET",
					success: fnSuccess,
					error: fnError
				});

			}

		},

		selectTabs: function (oEvent) {

			var sKey = oEvent.getSource().getSelectedKey();
			var oTable = this.getView().byId("idCreBillSchTable");
			switch (sKey) {
			case "01":

				oTable.setMode("SingleSelectLeft");
				this.onInit();
				break;

			case "02":
				var aFilter = [];
				if (this.delItm) {
					this.delItm = [];
				}
				oTable.setMode("None");
				try {
					this.getView().byId("idBillNow").setVisible(true);
					//this.getView().byId("idWipClear").setVisible(true);

				} catch (e) {}
				this.getView().byId("idCBoxBillDateAll").setSelectedKey("");
				var mModel = this.getOwnerComponent().getModel("mBillPlanEdit");
				mModel.setProperty("/items", []);

				var mBillHeader = this.getOwnerComponent().getModel("mBillScheduleHeader");
				var arrEngNum = mBillHeader.getProperty("/items");

				var sVbeln = " ";

				for (var i = 0; i < arrEngNum.length; i++) {

					if (arrEngNum[i].EngNum.length < 10) {

						sVbeln = arrEngNum[i].EngNum;
						for (var j = sVbeln.length; j < 10; j++) {
							sVbeln = '0' + sVbeln;
						}

						aFilter.push(new sap.ui.model.Filter("vbeln", 'EQ', sVbeln));
					}

				}

				var fnSuccess = jQuery.proxy(function (oData) {

					var oResult = JSON.parse(JSON.stringify(oData));
					var mBillDates = this.getOwnerComponent().getModel("mBillDates");
					mBillDates.setProperty("/items", oResult.results);
					this.getView().setModel(mBillDates, "mBillDates");

					this.setRowsNonEditable();
				}, this);

				var fnError = jQuery.proxy(function (oData) {

				}, this);
				var oModel = this.getOwnerComponent().getModel("mainSrv");
				var mParams = {
					filters: aFilter,
					success: fnSuccess,
					error: fnError
				};
				oModel.read("/Billplan_date", mParams);
				break;
			default:
			}

			this.onAfterRendering();
		},
		//// loadHeaderDetails: function () {

		// 	var oDataModl = this.getOwnerComponent().getModel("mainSrv");
		// 	this.hasChanges = false;

		// 	var sParamMode;

		// 	var oComponentData = this.getOwnerComponent().getComponentData();
		// 	//debugger
		// 	var sImportingParam;
		// 	var arrBillHeader = [];
		// 	var mBillHeader = this.getOwnerComponent().getModel("mBillScheduleHeader");

		// 	if (oComponentData.startupParameters && jQuery.isEmptyObject(oComponentData.startupParameters) ===
		// 		false) {

		// 		var arrEngNum = oComponentData.startupParameters.EngNum;
		// 		var sVbeln = " ";
		// 		var mVbeln, arrVbeln = [];
		// 		for (var i = 0; i < arrEngNum.length; i++) {

		// 			mVbeln = {
		// 				Vbeln: arrEngNum[i]
		// 			};

		// 			arrVbeln.push(mVbeln);
		// 			if (arrEngNum[i].length < 10) {
		// 				for (var j = arrEngNum[i].length; j < 10; j++) {
		// 					arrEngNum[i] = '0' + arrEngNum[i];
		// 				}
		// 			}
		// 			sVbeln = sVbeln + "|" + arrEngNum[i];

		// 		}

		// 		var mEngNum = this.getOwnerComponent().getModel("mEngNum");
		// 		mEngNum.setProperty("/items", arrVbeln);
		// 		this.getView().setModel(mEngNum, "mEngNum");

		// 		if (this.changeToEditMode) {
		// 			sParamMode = "EDIT";
		// 		} else {
		// 			sParamMode = oComponentData.startupParameters.Mode[0];
		// 		}
		// 		var sMode;
		// 		if (sParamMode === "EDIT") {
		// 			sMode = "E";
		// 		} else {
		// 			sMode = "C";
		// 		}

		// 		var fnSuccess = jQuery.proxy(function (oData, response) {

		// 				sap.ui.core.BusyIndicator.hide();

		// 				var mBillScheduleHeader = this.getOwnerComponent().getModel("mBillScheduleHeader");

		// 				var sVblnHdr;

		// 				for (var i = 0; i < oData.results.length; i++) {

		// 					var sProj;

		// 					if (oData.results[i].PROJDESC) {

		// 						sProj = oData.results[i].PROJDESC + "(" + oData.results[i].PROJDEF1 + ")";
		// 					}

		// 					var sSelection;
		// 					var sAmnt;
		// 					if (sParamMode === "EDIT") {

		// 						sVblnHdr = oData.results[i].ENGNUM;
		// 						if (sVblnHdr.length < 10) {
		// 							for (var t = sVblnHdr.length; t < 10; t++)
		// 								sVblnHdr = "0" + sVblnHdr;
		// 						}

		// 						if (this.vbeln && this.vbeln === sVblnHdr) {
		// 							this.selectedIndx = i;
		// 							sSelection = true;

		// 							var oControl = this.getView().byId("idCBoxConBill");

		// 							if (oData.results[i].LEADENGNUM === "X") {

		// 								oControl.setEnabled(false);
		// 								oControl.setSelectedKey("X");
		// 								if (!this.LeadEngNum) {
		// 									this.LeadEngNum = oData.results[i].ENGNUM;
		// 								}

		// 							} else {
		// 								if (oData.results[i].LEADENGNUM && oData.results[i].LEADENGNUM !== "X") {
		// 									oControl.setSelectedKey("X");
		// 								}
		// 							}

		// 							if (oData.results[i].BILLNOWFLAG === "X") {
		// 								this.getView().getModel("mConBillEnabled").setProperty("/Enabled", true);
		// 							} else {
		// 								this.getView().getModel("mConBillEnabled").setProperty("/Enabled", false);
		// 							}

		// 							var isLeadPartner = oData.results[i].LeadPartner;
		// 							if (isLeadPartner === "X") {

		// 								this.getView().getModel("mConBillEnabled").setProperty("/Editable", true);
		// 								if (oData.results[i].LEADENGNUM === "X") {
		// 									oControl.setEnabled(false);
		// 								} else {
		// 									oControl.setEnabled(true);
		// 								}
		// 							} else {
		// 								this.getView().getModel("mConBillEnabled").setProperty("/Editable", false);
		// 								oControl.setEnabled(false);
		// 							}

		// 						} else {
		// 							sSelection = false;
		// 						}
		// 					} else {
		// 						if (i === 0) {
		// 							sSelection = true; // Default First Item will be Selected
		// 						} else {
		// 							sSelection = false;
		// 						}
		// 					}
		// 					sAmnt = oData.results[i].AMT;
		// 					// sAmnt = sAmnt.toString();
		// 					var mBillSchdeuleHeader = {
		// 						EngNum: oData.results[i].ENGNUM,
		// 						EngDesc: oData.results[i].ENGDESC,
		// 						ProjDesc: sProj,
		// 						ProfitCenter: oData.results[i].PRCTR,
		// 						Client: oData.results[i].NAME1 + "(" + oData.results[i].CLIENT + ")",
		// 						PayTerm: oData.results[i].ZTERM,
		// 						HdrAmnt: sAmnt,
		// 						Lead: oData.results[i].LEADENGNUM,
		// 						Selected: sSelection,
		// 						LEADENGNUM: oData.results[i].LEADENGNUM,
		// 						BILLNOWFLAG: oData.results[i].BILLNOWFLAG,
		// 						LeadPartner: oData.results[i].LeadPartner

		// 					};

		// 					arrBillHeader.push(mBillSchdeuleHeader);

		// 				}

		// 				mBillScheduleHeader.setProperty("/items", arrBillHeader);
		// 				this.getView().setModel(mBillScheduleHeader, "mBillScheduleHeader");

		// 				this.sCurrKey = oData.results[0].WAERS;

		// 				this.getOwnerComponent().getModel("mCurrencyKey").setProperty("/currKey", this.sCurrKey);
		// 				this.engSDate = new Date(oData.results[
		// 					0].VBEGDAT);
		// 				this.sDate = new Date(oData.results[0].VBEGDAT);
		// 				this.getOwnerComponent().getModel("mDateModel").setProperty(
		// 					"/sDate", oData.results[0].VBEGDAT);
		// 				this.engEDate = new Date(oData.results[0].VENDDAT);
		// 				this.eDate = new Date(oData.results[0]
		// 					.VENDDAT);
		// 				this.getOwnerComponent().getModel("mDateModel").setProperty("/eDate", oData.results[0].VENDDAT);
		// 				this.getOwnerComponent()
		// 					.getModel("mDateModel").refresh(true);

		// 			},
		// 			this);

		// 		var fnError = jQuery.proxy(function (oData, response) {
		// 			sap.ui.core.BusyIndicator.hide();
		// 		}, this);

		// 		sap.ui.core.BusyIndicator.show(0);
		// 		oDataModl.callFunction('/engDetails', {
		// 			urlParameters: {
		// 				VBELN: sVbeln,
		// 				MODE: sMode
		// 			},

		// 			method: "GET",
		// 			success: fnSuccess,
		// 			error: fnError
		// 		});

		// 	}

		// 	mBillHeader.setProperty("/items", arrBillHeader);
		// 	this.getView().setModel(mBillHeader, "mBillScheduleHeader");

		// 	this.sImportingParam = sImportingParam;

		// },

		loadHeaderDetails: function () {

			var oDataModl = this.getOwnerComponent().getModel("mainSrv");
			this.hasChanges = false;

			var sParamMode;

			var oComponentData = this.getOwnerComponent().getComponentData();
			//debugger
			var sImportingParam;
			var arrBillHeader = [];
			var mBillHeader = this.getOwnerComponent().getModel("mBillScheduleHeader");

			if (oComponentData.startupParameters && jQuery.isEmptyObject(oComponentData.startupParameters) ===
				false) {

				var arrEngNum = oComponentData.startupParameters.EngNum;
				var sVbeln = " ";
				var mVbeln, arrVbeln = [];

				// if (this.Lead) {
				// 	if (this.Lead.length < 10) {
				// 		for (var j = this.Lead.length; j < 10; j++) {
				// 			this.Lead = '0' + this.Lead;
				// 		}
				// 	}
				// }

				for (var i = 0; i < arrEngNum.length; i++) {

					mVbeln = {
						Vbeln: arrEngNum[i]
					};

					arrVbeln.push(mVbeln);
					if (arrEngNum[i].length < 10) {
						for (var j = arrEngNum[i].length; j < 10; j++) {
							arrEngNum[i] = '0' + arrEngNum[i];
						}
					}
					sVbeln = sVbeln + "|" + arrEngNum[i];

				}

				var mEngNum = this.getOwnerComponent().getModel("mEngNum");
				mEngNum.setProperty("/items", arrVbeln);
				this.getView().setModel(mEngNum, "mEngNum");

				if (this.changeToEditMode) {
					sParamMode = "EDIT";
				} else {
					sParamMode = oComponentData.startupParameters.Mode[0];
				}
				var sMode;
				if (sParamMode === "EDIT") {
					sMode = "E";
				} else {
					sMode = "C";
				}

				var fnSuccess = jQuery.proxy(function (oData, response) {

						sap.ui.core.BusyIndicator.hide();

						var mBillScheduleHeader = this.getOwnerComponent().getModel("mBillScheduleHeader");

						var sVblnHdr;

						var sLeadEngNum, isLeadEngNum;

						for (var i = 0; i < oData.results.length; i++) {

							var sProj;

							if (oData.results[i].PROJDESC) {

								sProj = oData.results[i].PROJDESC + "(" + oData.results[i].PROJDEF1 + ")";
							}

							var sSelection;
							var sAmnt;

							if (sParamMode === "EDIT") {

								sVblnHdr = oData.results[i].ENGNUM;
								if (sVblnHdr.length < 10) {
									for (var t = sVblnHdr.length; t < 10; t++)
										sVblnHdr = "0" + sVblnHdr;
								}

								if (this.vbeln && this.vbeln === sVblnHdr) {
									this.selectedIndx = i;
									sSelection = true;

									var oControl = this.getView().byId("idCBoxConBill");

									if (oData.results[i].LEADENGNUM === "X") {

										oControl.setEnabled(false);
										oControl.setSelectedKey("X");
										if (!this.LeadEngNum) {
											this.LeadEngNum = oData.results[i].ENGNUM;
										}

									} else {
										if (oData.results[i].LEADENGNUM && oData.results[i].LEADENGNUM !== "X") {
											oControl.setSelectedKey("X");
										}
									}

									if (oData.results[i].BILLNOWFLAG === "X") {
										this.getView().getModel("mConBillEnabled").setProperty("/Enabled", true);
									} else {
										this.getView().getModel("mConBillEnabled").setProperty("/Enabled", false);
									}

									var isLeadPartner = oData.results[i].LeadPartner;
									if (isLeadPartner === "X") {

										this.getView().getModel("mConBillEnabled").setProperty("/Editable", true);
										if (oData.results[i].LEADENGNUM === "X") {
											oControl.setEnabled(false);
										} else {
											oControl.setEnabled(true);
										}
									} else {
										this.getView().getModel("mConBillEnabled").setProperty("/Editable", false);
										oControl.setEnabled(false);
									}

								} else {
									sSelection = false;
								}

								isLeadEngNum = oData.results[i].LEADENGNUM;
								sLeadEngNum = oData.results[i].ENGNUM;

							} else {
								if (i === 0) {
									sSelection = true; // Default First Item will be Selected
								} else {
									sSelection = false;
								}

								if (this.Lead === oData.results[i].ENGNUM) {
									sLeadEngNum = this.Lead;
									isLeadEngNum = "X";
								} else {
									sLeadEngNum = "";
									isLeadEngNum = "";
								}

							}
							sAmnt = oData.results[i].AMT;

							var mBillSchdeuleHeader = {
								EngNum: oData.results[i].ENGNUM,
								EngDesc: oData.results[i].ENGDESC,
								ProjDesc: sProj,
								ProfitCenter: oData.results[i].PRCTR,
								Client: oData.results[i].NAME1 + "(" + oData.results[i].CLIENT + ")",
								PayTerm: oData.results[i].ZTERM,
								HdrAmnt: sAmnt,
								Lead: isLeadEngNum,
								Selected: sSelection,
								LEADENGNUM: isLeadEngNum,
								BillTyp: oData.results[i].BillTyp,
								BILLNOWFLAG: oData.results[i].BILLNOWFLAG,
								LeadPartner: oData.results[i].LeadPartner

							};

							arrBillHeader.push(mBillSchdeuleHeader);

						}

						mBillScheduleHeader.setProperty("/items", arrBillHeader);
						this.getView().setModel(mBillScheduleHeader, "mBillScheduleHeader");

						this.sCurrKey = oData.results[0].WAERS;

						this.getOwnerComponent().getModel("mCurrencyKey").setProperty("/currKey", this.sCurrKey);
						this.engSDate = new Date(oData.results[
							0].VBEGDAT);
						this.sDate = new Date(oData.results[0].VBEGDAT);
						this.getOwnerComponent().getModel("mDateModel").setProperty(
							"/sDate", oData.results[0].VBEGDAT);
						this.engEDate = new Date(oData.results[0].VENDDAT);
						this.eDate = new Date(oData.results[0]
							.VENDDAT);
						this.getOwnerComponent().getModel("mDateModel").setProperty("/eDate", oData.results[0].VENDDAT);
						this.getOwnerComponent()
							.getModel("mDateModel").refresh(true);

					},
					this);

				var fnError = jQuery.proxy(function (oData, response) {
					sap.ui.core.BusyIndicator.hide();
				}, this);

				sap.ui.core.BusyIndicator.show(0);
				oDataModl.callFunction('/engDetails', {
					urlParameters: {
						VBELN: sVbeln,
						MODE: sMode
					},

					method: "GET",
					success: fnSuccess,
					error: fnError
				});

			}

			mBillHeader.setProperty("/items", arrBillHeader);
			this.getView().setModel(mBillHeader, "mBillScheduleHeader");

			this.sImportingParam = sImportingParam;

		},
		loadInitialSettings: function () {

			var oComponentData = this.getOwnerComponent().getComponentData();

			if (oComponentData.startupParameters && jQuery.isEmptyObject(oComponentData.startupParameters) ===
				false) {

				var arrEngNum = oComponentData.startupParameters.EngNum;

				var mVisModel = this.getOwnerComponent().getModel("mBillScheVis");

				var mVisModelData = mVisModel.getData();

				var sParamMode;

				if (this.changeToEditMode) {
					sParamMode = "EDIT";
				} else {
					sParamMode = oComponentData.startupParameters.Mode[0];
				}

				switch (sParamMode) {
				case 'EDIT':

					mVisModelData.CreateVisibility = false;
					mVisModelData.EditVisibility = true;
					this.Mode = 'E';
					if (!this.vbeln) {
						this.vbeln = arrEngNum[0];
					}
					this.defaultHeaderFields();
					this.getView().byId("idBillNow").setVisible(true);
					//this.getView().byId("idWipClear").setVisible(true);
					this.handleLoadItems();

					break;

				case 'CREA':

					this.Mode = 'C';
					this.Lead = oComponentData.startupParameters.LeadNum[0];
					mVisModelData.CreateVisibility = true;
					mVisModelData.EditVisibility = false;
					this.getView().byId("idBillNow").setVisible(false);
					//this.getView().byId("idWipClear").setVisible(false);
					var sDefaultAmnt = parseFloat("0").toFixed(2);
					sDefaultAmnt = this.formatAmount(sDefaultAmnt);
					this.getView().byId("inputGT").setValue(sDefaultAmnt);
					this.sameAmount = false;
					if (arrEngNum.length > 1) {
						this.getView().byId("idComboBoxConBill").setSelectedKey("X");
					} else {
						this.getView().byId("idComboBoxConBill").setSelectedKey(" ");
					}

					var oTextResource = this.getOwnerComponent().getModel("i18n").getResourceBundle();
					var sDownText = oTextResource.getText("DownText"),
						sDefault = oTextResource.getText("Default");

					var arrPlanTyp = [];

					var sJsonPln2 = {
						plan: "X",
						planDesc: sDefault
							//"Default"
					};
					arrPlanTyp.push(sJsonPln2);
					var sJsonPln3 = {
						plan: "Y004",
						planDesc: "Fixed Value"
							//"Default"
					};
					arrPlanTyp.push(sJsonPln3);
					

					if (arrEngNum.length === 1) {

						var sJsonPln1 = {
							plan: "Y009",
							planDesc: sDownText
						};

						arrPlanTyp.push(sJsonPln1);
					}

					this.getOwnerComponent().getModel("mPlanTyp").setProperty("/items", arrPlanTyp);

					if (arrEngNum.length === 1) {
						var mVisModel = this.getOwnerComponent().getModel("mBillScheVis");
						var mVisModelData = mVisModel.getData();
						mVisModelData.CreateEnabled = false;
						this.getView().byId("idCpySameAmnt").setSelected(true);
						this.getView().byId("inputGT").setEnabled(true);
						this.sameAmount = true;
						mVisModel.refresh(true);
					}

					break;
				default:
					this.Mode = 'C';
					mVisModelData.CreateVisibility = true;
					mVisModelData.EditVisibility = false;

				}

				this.getView().setModel(mVisModel, "mBillScheVis");

				this.readBilliBlock();

				var mGrpBy = this.getOwnerComponent().getModel("mGrpBy");
				this.getView().setModel(mGrpBy, "mGrpBy");

				this.sessionExists = true;
				this.hasChanges = false;
			}
		},

		onBeforeRendering: function () {},

		onChangeBillDate: function (oEvent) {

			var sDate;
			var oTextResource = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var Unsavedmsg = oTextResource.getText("Unsavedmsg");

			if (oEvent) {
				sDate = oEvent.getSource().getSelectedKey();
			} else {
				sDate = this.getView().byId("idCBoxBillDate").getSelectedKey();
			}

			if (this.hasChanges) {
				sap.m.MessageBox.show(
					Unsavedmsg, {
						icon: sap.m.MessageBox.Icon.INFORMATION,
						title: "Warning",
						actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
						onClose: jQuery.proxy(function (oAction) {

							if (oAction === sap.m.MessageBox.Action.NO) {
								this.getView().byId("idCBoxBillDate").setSelectedItem(this.previousSelecTedDateItm);
								return;
							}

							if (oAction === sap.m.MessageBox.Action.YES) {
								this.hasChanges = false;
								var aFilter = [];

								if (this.vbeln.length < 10) {

									for (var p = this.vbeln.length; p < 10; p++) {
										this.vbeln = '0' + this.vbeln;
									}
								}

								aFilter.push(new sap.ui.model.Filter("vbeln", 'EQ', this.vbeln));
								aFilter.push(new sap.ui.model.Filter("afdat", 'EQ', sDate));
								this.aEditFilter = aFilter;
								this.readBillPlanCons(aFilter);
							}

						}, this)
					}
				);
			} else {
				var aFilter = [];

				if (this.vbeln.length < 10) {

					for (var p = this.vbeln.length; p < 10; p++) {
						this.vbeln = '0' + this.vbeln;
					}
				}

				aFilter.push(new sap.ui.model.Filter("vbeln", 'EQ', this.vbeln));
				aFilter.push(new sap.ui.model.Filter("afdat", 'EQ', sDate));
				this.aEditFilter = aFilter;
				this.readBillPlanCons(aFilter);

			}

			this.previousSelecTedDateItm = this.getView().byId("idCBoxBillDate").getItems()[0];

		},

		onChangeBillDateAll: function (oEvent) {

			var sDate;
			var oTextResource = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var Unsavedmsg = oTextResource.getText("Unsavedmsg");

			if (oEvent) {
				sDate = oEvent.getSource().getSelectedKey();
			} else {
				sDate = this.getView().byId("idCBoxBillDateAll").getSelectedKey();
			}

			var aFilter = [];

			var mBillHeader = this.getOwnerComponent().getModel("mBillScheduleHeader");
			var arrEngNum = mBillHeader.getProperty("/items");

			var sVbeln = " ";

			for (var i = 0; i < arrEngNum.length; i++) {

				if (arrEngNum[i].EngNum.length < 10) {

					sVbeln = arrEngNum[i].EngNum;
					for (var j = sVbeln.length; j < 10; j++) {
						sVbeln = '0' + sVbeln;
					}

					aFilter.push(new sap.ui.model.Filter("vbeln", 'EQ', sVbeln));
				}

			}

			aFilter.push(new sap.ui.model.Filter("afdat", 'EQ', sDate));
			this.aEditFilter = aFilter;
			this.readBillPlanCons(aFilter);

		},

		readBillPlanCons: function (aFilter) {

			var oModel = this.getOwnerComponent().getModel("mainSrv");
			sap.ui.core.BusyIndicator.show(0);

			var fnSuccess = jQuery.proxy(function (oData) {

				sap.ui.core.BusyIndicator.hide();

				var mOriginalModel = this.getOwnerComponent().getModel("mOriginalModel");
				mOriginalModel.setProperty("/items", JSON.parse(JSON.stringify(oData.results)));

				var mBillPlanEdit = this.getOwnerComponent().getModel("mBillPlanEdit");
				mBillPlanEdit.setProperty("/items", oData.results);

				var arrModelDataItems = mBillPlanEdit.getProperty("/items");

				for (var i = 0; i < arrModelDataItems.length; i++) {

					arrModelDataItems[i].posnrFc = false;
					arrModelDataItems[i].VbelnFc = false;

				}

				// mBillPlanEdit.refresh();
				this.getView().byId("idTabBillEdit").setModel(mBillPlanEdit, "mBillPlanEdit");
				this.getOwnerComponent().getModel("mBillPlanEdit").refresh();

			}, this);

			var fnError = jQuery.proxy(function (oData) {

				this.oResult = JSON.parse(JSON.stringify(oData));
				var mBillPlanEdit = this.getOwnerComponent().getModel("mBillPlanEdit");
				mBillPlanEdit.setProperty("/items", []);
				sap.ui.core.BusyIndicator.hide();

			}, this);

			var mParameters = {
				filters: aFilter,
				success: fnSuccess,
				error: fnError
			};

			oModel.read("/Billplan_cons", mParameters);

		},
		/**
		 * Event handler for navigating back.
		 * It there is a history entry or an previous app-to-app navigation we go one step back in the browser history
		 * If not, it will navigate to the shell home
		 * @public
		 */

		defaultHeaderFields: function () {

			var oGrpComboBox = this.getView().byId("idGrpBy");
			oGrpComboBox.setSelectedKey("01");
			this.previousKey = oGrpComboBox.getSelectedKey();
			this.getView().byId("elemBillDate").setVisible(true);
			this.getView().byId("elemEngItm").setVisible(false);
			this.handleLoadDates();

			// this.handleLoadItems();

		},

		readBilliBlock: function () {

			var fnSuccess = jQuery.proxy(function (oData) {

				var oResult = JSON.parse(JSON.stringify(oData));
				var mBillBlock = this.getOwnerComponent().getModel("mBillBlock");
				mBillBlock.setProperty("/items", oResult.results);
				this.getView().setModel(mBillBlock, "mBillBlock");

			}, this);

			var fnError = jQuery.proxy(function (oData) {

				this.oResult = JSON.parse(JSON.stringify(oData));

			}, this);

			var oModel = this.getOwnerComponent().getModel("mainSrv");
			var mParams = {
				// filters: aFilter,
				success: fnSuccess,
				error: fnError
			};
			oModel.read("/Billplan_BillblockValhelpSet", mParams);
		},

		handleLoadItems: function () {

			var aFilter = [];
			var oTextResource = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var Unsavedmsg = oTextResource.getText("Unsavedmsg");
			if (this.vbeln.length < 10) {

				for (var p = this.vbeln.length; p < 10; p++) {
					this.vbeln = '0' + this.vbeln;
				}
			}
			aFilter.push(new sap.ui.model.Filter("vbeln", 'EQ', this.vbeln));
			// var oBinding = this.getView().byId("idGrpByCombo").getBinding("items");
			// oBinding.filter(aFilter);

			var fnSuccess = jQuery.proxy(function (oData) {

				var oResult = JSON.parse(JSON.stringify(oData));
				var mBillDates = this.getOwnerComponent().getModel("mEngItms");
				mBillDates.setProperty("/items", oResult.results);
				this.getView().setModel(mBillDates, "mEngItms");

				var PlnTyp = [];
					var sJsonPln3 = {
						plan: "Y004",
						planDesc: "Fixed Value"
					};
					PlnTyp.push(sJsonPln3);

				var arrEngNums = this.getView().getModel("mBillScheduleHeader").getData().items;

				var leadEng;

				arrEngNums.forEach(function (oResult, index) {
					if (oResult.Lead === "X") {
						leadEng = oResult.EngNum;
					}
				}, this);

				for (var i = 0; i < oResult.results.length; i++) {
					var sJsonPln = {
						plan: oResult.results[i].feetyp,
						planDesc: oResult.results[i].feedesc
					};

					PlnTyp.push(sJsonPln);
				}

				var sDownText = oTextResource.getText("DownText");

				if (!leadEng || oResult.results[0].vbeln === leadEng) {

					var sJsonPln1 = {
						plan: "Y009",
						planDesc: sDownText
					};

					PlnTyp.push(sJsonPln1);
				}

				// var sMigratedText = oTextResource.getText("Migrated");

				// var sJsonPln2 = {
				// 	plan: "Y605",
				// 	planDesc: sMigratedText
				// };

				// PlnTyp.push(sJsonPln2);

				var arrPlnTyp = this.removeDuplicates(PlnTyp);

				var mPlanTyp = this.getOwnerComponent().getModel("mPlanTyp");
				mPlanTyp.setProperty("/items", arrPlnTyp);

				// this.sCurrKey = oResult.results[0].WAERS;

			}, this);

			var fnError = jQuery.proxy(function (oData) {

				this.oResult = JSON.parse(JSON.stringify(oData));

			}, this);

			var oModel = this.getOwnerComponent().getModel("mainSrv");
			var mParams = {
				filters: aFilter,
				success: fnSuccess,
				error: fnError
			};

			if (this.hasChanges) {
				sap.m.MessageBox.show(
					Unsavedmsg, {
						icon: sap.m.MessageBox.Icon.INFORMATION,
						title: "Warning",
						actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
						onClose: jQuery.proxy(function (oAction) {

							if (oAction === sap.m.MessageBox.Action.NO) {
								// var oGrpComboBox = this.getView().byId("idGrpByCombo");
								this.getView().byId("idGrpByCombo").setSelectedItem(this.previousSelectedPosnrItm);
								return;
							}

							if (oAction === sap.m.MessageBox.Action.YES) {
								oModel.read("/Engitem_cons", mParams);
								this.hasChanges = false;
							}

						}, this)
					}
				);
			} else {
				oModel.read("/Engitem_cons", mParams);
			}

			this.previousSelectedPosnrItm = this.getView().byId("idGrpByCombo").getSelectedItem();

		},

		handleLoadDatesgrpBy: function () {
			var aFilter = [];

			if (this.vbeln.length < 10) {

				for (var p = this.vbeln.length; p < 10; p++) {
					this.vbeln = '0' + this.vbeln;
				}
			}
			aFilter.push(new sap.ui.model.Filter("vbeln", 'EQ', this.vbeln));
			// var oBinding = this.getView().byId("idGrpByCombo").getBinding("items");
			// oBinding.filter(aFilter);

			var fnSuccess = jQuery.proxy(function (oData) {

				var oResult = JSON.parse(JSON.stringify(oData));
				var mBillDates = this.getOwnerComponent().getModel("mBillDates");
				// var oItemBlockTable = this.getView().byId("idTabBillEdit");
				// oItemBlockTable.setBusy(false);
				mBillDates.setProperty("/items", oResult.results);
				this.getView().setModel(mBillDates, "mBillDates");
				// if (oData.results.length > 0) {
				// 	this.getView().byId("idCBoxBillDate").setSelectedItem(this.getView().byId("idCBoxBillDate").getItems()[0]);
				// 	this.onChangeBillDate();
				// 	this.getView().byId("idCBoxBillDate").setSelectedKey(oData.results[0].afdat);
				// 	this.previousSelecTedDateItm = this.getView().byId("idCBoxBillDate").getItems()[0];
				// }

			}, this);

			var fnError = jQuery.proxy(function (oData) {

				this.oResult = JSON.parse(JSON.stringify(oData));
				// var oItemBlockTable = this.getView().byId("idTabBillEdit");
				// oItemBlockTable.setBusy(false);

			}, this);
			var oModel = this.getOwnerComponent().getModel("mainSrv");
			var mParams = {
				filters: aFilter,
				success: fnSuccess,
				error: fnError
			};
			oModel.read("/Billplan_date", mParams);
		},

		handleLoadDates: function () {
			var aFilter = [];

			if (this.vbeln.length < 10) {

				for (var p = this.vbeln.length; p < 10; p++) {
					this.vbeln = '0' + this.vbeln;
				}
			}
			aFilter.push(new sap.ui.model.Filter("vbeln", 'EQ', this.vbeln));

			var fnSuccess = jQuery.proxy(function (oData) {

				var oResult = JSON.parse(JSON.stringify(oData));
				var mBillDates = this.getOwnerComponent().getModel("mBillDates");
				// var oItemBlockTable = this.getView().byId("idTabBillEdit");
				// oItemBlockTable.setBusy(false);
				mBillDates.setProperty("/items", oResult.results);
				this.getView().setModel(mBillDates, "mBillDates");
				if (oData.results.length > 0) {
					this.getView().byId("idCBoxBillDate").setSelectedItem(this.getView().byId("idCBoxBillDate").getItems()[0]);
					this.onChangeBillDate();
					this.getView().byId("idCBoxBillDate").setSelectedKey(oData.results[0].afdat);
					this.previousSelecTedDateItm = this.getView().byId("idCBoxBillDate").getItems()[0];
				} else {

					this.getView().byId("idCBoxBillDate").setSelectedKey(" ");
					this.getView().byId("idCBoxBillDate").setValue(" ");
					this.previousSelecTedDateItm = [];
					this.onChangeBillDate();
				}

			}, this);

			var fnError = jQuery.proxy(function (oData) {

				this.oResult = JSON.parse(JSON.stringify(oData));
				// var oItemBlockTable = this.getView().byId("idTabBillEdit");
				// oItemBlockTable.setBusy(false);

			}, this);
			var oModel = this.getOwnerComponent().getModel("mainSrv");
			var mParams = {
				filters: aFilter,
				success: fnSuccess,
				error: fnError
			};
			oModel.read("/Billplan_date", mParams);
		},

		onChangeConBill: function (oEvent) {
			this.hasChanges = true;
		},

		onChangeGroupBy: function (oEvent) {

			// var mBisDateEdit = this.getOwnerComponent().getModel("mBisDateEdit");

			var oGrpConboDate, oGrpConboItm;
			var oTextResource = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var Unsavedmsg = oTextResource.getText("Unsavedmsg");

			this.delItm = [];

			var sKey = oEvent.getSource().getSelectedKey();
			this.compareChanges();

			var oGrpConbo;

			if (this.hasChanges) {
				sap.m.MessageBox.show(
					Unsavedmsg, {
						icon: sap.m.MessageBox.Icon.INFORMATION,
						title: "Warning",
						actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
						onClose: jQuery.proxy(function (oAction) {

							if (oAction === sap.m.MessageBox.Action.NO) {
								var oGrpComboBox = this.getView().byId("idGrpBy");
								oGrpComboBox.setSelectedKey(this.previousKey);
								return;
							}

							if (oAction === sap.m.MessageBox.Action.YES) {
								this.hasChanges = false;

								switch (sKey) {
								case "01":
									this.getView().byId("elemBillDate").setVisible(true);
									this.getView().byId("elemEngItm").setVisible(false);

									this.getView().byId("idBillNow").setVisible(true);
									//	this.getView().byId("idWipClear").setVisible(true);

									oGrpConbo = this.getView().byId("idGrpByCombo");
									oGrpConboDate = this.getView().byId("idCBoxBillDate");
									if (this.previousKey !== sKey) {
										this.onDeleteAllForGrp();
										oGrpConbo.setSelectedKey("");
										if (oGrpConboDate) {
											oGrpConboDate.setSelectedKey("");
										}
									}
									this.previousKey = sKey;
									this.handleLoadDatesgrpBy();
									// mBisDateEdit.setProperty("/editable", false);
									// oDateConbo.setSelectedKey(" ");

									break;
								case "02":
									this.getView().byId("elemBillDate").setVisible(false);
									this.getView().byId("elemEngItm").setVisible(true);
									this.getView().byId("idBillNow").setVisible(false);
									//this.getView().byId("idWipClear").setVisible(false);
									oGrpConbo = this.getView().byId("idCBoxBillDate");
									oGrpConboItm = this.getView().byId("idGrpByCombo");
									if (this.previousKey !== sKey) {
										this.onDeleteAllForGrp();
										oGrpConbo.setSelectedKey("");

										if (oGrpConboItm) {
											oGrpConboItm.setSelectedKey("");
										}
									}
									this.previousKey = sKey;
									// mBisDateEdit.setProperty("/editable", true);

									break;

								case "03":
									this.getView().byId("elemBillDate").setVisible(false);
									this.getView().byId("elemEngItm").setVisible(true);
									this.getView().byId("idGrpByCombo").setEnabled(false);
									this.getView().byId("idGrpByCombo").setSelectedKey("");
									this.getView().byId("idBillNow").setVisible(false);
									//this.getView().byId("idWipClear").setVisible(false);
									oGrpConbo = this.getView().byId("idCBoxBillDate");
									oGrpConboItm = this.getView().byId("idGrpByCombo");
									if (this.previousKey !== sKey) {
										this.onDeleteAllForGrp();
										oGrpConbo.setSelectedKey("");
										if (oGrpConboItm) {
											oGrpConboItm.setSelectedKey("");
										}
									}
									this.previousKey = sKey;
									this.readAllSchedule();
									// mBisDateEdit.setProperty("/editable", true);

									break;
								default:
								}

							}

						}, this)
					}
				);
			} else {

				switch (sKey) {
				case "01":
					this.getView().byId("elemBillDate").setVisible(true);
					this.getView().byId("elemEngItm").setVisible(false);
					this.getView().byId("idBillNow").setVisible(true);
					//this.getView().byId("idWipClear").setVisible(true);
					oGrpConbo = this.getView().byId("idGrpByCombo");
					oGrpConboDate = this.getView().byId("idCBoxBillDate");
					if (this.previousKey !== sKey) {
						this.onDeleteAllForGrp();
						oGrpConbo.setSelectedKey("");
						if (oGrpConboDate) {
							oGrpConboDate.setSelectedKey("");
						}
					}
					this.handleLoadDatesgrpBy();
					// mBisDateEdit.setProperty("/editable", false);
					// oDateConbo.setSelectedKey(" ");

					break;
				case "02":
					this.getView().byId("elemBillDate").setVisible(false);
					this.getView().byId("elemEngItm").setVisible(true);
					this.getView().byId("idGrpByCombo").setEnabled(true);
					this.getView().byId("idBillNow").setVisible(false);
					// this.getView().byId("idWipClear").setVisible(false);
					oGrpConbo = this.getView().byId("idCBoxBillDate");
					oGrpConboItm = this.getView().byId("idGrpByCombo");
					if (this.previousKey !== sKey) {
						this.onDeleteAllForGrp();
						oGrpConbo.setSelectedKey("");
						if (oGrpConboItm) {
							oGrpConboItm.setSelectedKey("");
						}
					}

					break;

				case "03":
					this.getView().byId("elemBillDate").setVisible(false);
					this.getView().byId("elemEngItm").setVisible(true);
					this.getView().byId("idGrpByCombo").setEnabled(false);
					this.getView().byId("idGrpByCombo").setSelectedKey("");
					this.getView().byId("idBillNow").setVisible(false);
					//	this.getView().byId("idWipClear").setVisible(false);
					oGrpConbo = this.getView().byId("idCBoxBillDate");
					oGrpConboItm = this.getView().byId("idGrpByCombo");
					if (this.previousKey !== sKey) {
						this.onDeleteAllForGrp();
						oGrpConbo.setSelectedKey("");
						if (oGrpConboItm) {
							oGrpConboItm.setSelectedKey("");
						}
					}
					this.previousKey = sKey;
					this.readAllSchedule();

					break;
				default:
				}

				this.previousKey = sKey;
			}

			// this.getView().setModel("mBisDateEdit");

		},

		compareChanges: function () {
			var mBillPlanEdit = this.getOwnerComponent().getModel("mBillPlanEdit");

			var arrModelDataItems = mBillPlanEdit.getProperty("/items");

			var mOriginalModel = this.getOwnerComponent().getModel("mOriginalModel");
			var arrActualModelData = mOriginalModel.getProperty("/items");

			if (arrModelDataItems.length === arrActualModelData.length) {
				for (var i = 0; i < arrModelDataItems.length; i++) {

					if (
						new Date(arrActualModelData[i].afdat).getTime() === new Date(arrModelDataItems[i].afdat).getTime() &&
						arrActualModelData[i].posnr === arrModelDataItems[i].posnr &&
						arrActualModelData[i].tetxt === arrModelDataItems[i].tetxt &&
						arrActualModelData[i].fakwr === arrModelDataItems[i].fakwr &&
						arrActualModelData[i].fksaf === arrModelDataItems[i].fksaf &&
						arrActualModelData[i].faksp === arrModelDataItems[i].faksp) {
						this.hasChanges = false;
					} else {
						this.hasChanges = true;
						break;
					}
				}
			} else {
				if (arrModelDataItems.length > 0) {
					this.hasChanges = true;
				}
			}

		},
		onNavBack: function () {
			this.dequeueEngagement();

			jQuery.sap.delayedCall(1000, this, function () {
				var sPreviousHash = History.getInstance().getPreviousHash(),
					oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

				if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
					history.go(-1);
				} else {
					oCrossAppNavigator.toExternal({
						target: {
							shellHash: "#Shell-home"
						}
					});
				}
			});

		},

		handleGenerateItems: function () {
			if (this.sameAmount) {
				this.generateItemSameAmount();
			} else {
				this.generateItemSeperateAmount();
			}
		},

		generateItemSeperateAmount: function () {
			var mBillScheduleHeader = this.getOwnerComponent().getModel("mBillScheduleHeader");
			var arrHdrData = mBillScheduleHeader.getData().items;

			// var oItemBlock = this.getView().byId("idcmItemsBlock");

			// this.onDeleteAllForGrp();

			var oDataModel = this.getView().getModel("mainSrv");
			// oDataModel.refresh(true);
			var oItemBlockTable = this.getView().byId("Table1");

			oItemBlockTable.removeSelections(true);
			sap.ui.core.BusyIndicator.show(0);
			jQuery.sap.delayedCall(1500, this, function () {
				sap.ui.core.BusyIndicator.hide();
			});

			if (oItemBlockTable) {

				var totAmnt, Vbeln;

				var sZeroAmnt = false,
					sHdrDataEng;

				for (var i = 0; i < arrHdrData.length; i++) {

					if (arrHdrData[i].BillTyp === "F" && parseFloat(arrHdrData[i].HdrAmnt) === 0) {
						sZeroAmnt = true;
						sHdrDataEng = arrHdrData[i].EngNum;
					}

					if (totAmnt) {

						try {
							var num = parseFloat(arrHdrData[i].HdrAmnt.replace(/\s/g, "").replace(",", "."));
							var sTmpAmt = num.toString();
							totAmnt = totAmnt + this.deformatAmount(sTmpAmt) + "|";
						} catch (e) {
							totAmnt = totAmnt + this.deformatAmount(arrHdrData[i].HdrAmnt) + "|";
						}

					} else {
						try {
							var num = parseFloat(arrHdrData[i].HdrAmnt.replace(/\s/g, "").replace(",", "."));
							sTmpAmt = num.toString();
							totAmnt = this.deformatAmount(sTmpAmt) + "|";
						} catch (e) {
							totAmnt = this.deformatAmount(arrHdrData[i].HdrAmnt) + "|";
						}
						//totAmnt = this.deformatAmount(arrHdrData[i].HdrAmnt) + "|";
					}

					if (Vbeln) {
						Vbeln = Vbeln + arrHdrData[i].EngNum + "|";
					} else {
						Vbeln = arrHdrData[i].EngNum + "|";
					}
				}

				var planTyp = this.getView().byId("idComboBoxPlanType").getSelectedKey();
				var planFreq = this.getView().byId("idComboBoxFreq").getSelectedKey();

				var startDate = this.sDate;
				var endDate = this.eDate;
				var conBilling = "X";
				var oTextResource = this.getOwnerComponent().getModel("i18n").getResourceBundle();
				var Mandatfldsmsg = oTextResource.getText("Mandatfldsmsg");
				var Startdatemsg = oTextResource.getText("Startdatemsg");
				var sError = oTextResource.getText("Error");
				if (!startDate || !endDate || !planFreq) {
					sap.m.MessageBox.error(Mandatfldsmsg, {
						title: sError // default
							// 			textDirection: sap.ui.core.TextDirection.Inherit // default
					});
					return;
				}

				if (startDate > endDate) {
					sap.m.MessageBox.error(Startdatemsg, {
						title: sError // default
							// 			textDirection: sap.ui.core.TextDirection.Inherit // default
					});
					return;
				}

			}

			var aFilter = [];

			aFilter.push(new sap.ui.model.Filter("StartDate", 'EQ', startDate));
			aFilter.push(new sap.ui.model.Filter("EndDate", 'EQ', endDate));
			aFilter.push(new sap.ui.model.Filter("ConBillFlag", 'EQ', conBilling));
			aFilter.push(new sap.ui.model.Filter("Freq", 'EQ', planFreq));
			aFilter.push(new sap.ui.model.Filter("Vbeln2", 'EQ', Vbeln));
			aFilter.push(new sap.ui.model.Filter("Fakwr2", 'EQ', totAmnt));
			aFilter.push(new sap.ui.model.Filter("Fkarv", 'EQ', planTyp));

			var oModel = this.getOwnerComponent().getModel("mainSrv");
			sap.ui.core.BusyIndicator.show(0);

			var fnSuccess = jQuery.proxy(function (oData) {

				sap.ui.core.BusyIndicator.hide();

				var mBillPlanCrea = this.getOwnerComponent().getModel("mBillPlanCrea");
				mBillPlanCrea.setProperty("/items", oData.results);

				var arrModelDataItems = mBillPlanCrea.getProperty("/items");

				for (var i = 0; i < arrModelDataItems.length; i++) {

					arrModelDataItems[i].posnrFc = false;
					arrModelDataItems[i].VbelnFc = false;
					if (!arrModelDataItems[i].Tetxt) {
						arrModelDataItems[i].Tetxt = "X";
					}

				}

				this.getView().byId("idTabBillEdit").setModel(mBillPlanCrea, "mBillPlanCrea");
				this.getOwnerComponent().getModel("mBillPlanCrea").refresh();

			}, this);

			var fnError = jQuery.proxy(function (oData) {

				this.oResult = JSON.parse(JSON.stringify(oData));
				sap.ui.core.BusyIndicator.hide();

			}, this);

			var mParameters = {
				filters: aFilter,
				success: fnSuccess,
				error: fnError
			};

			var Unsavedmsg = "Enagement-" + sHdrDataEng + " " +
				"contains fixed price plantype. Amount can not be Zero(0).Do you want to generate schedule?";

			//	var planTyp = this.getView().byId("idComboBoxPlanType").getSelectedKey();

			if (planTyp !== "Y009") {
				if (sZeroAmnt) {

					sap.m.MessageBox.show(
						Unsavedmsg, {
							icon: sap.m.MessageBox.Icon.INFORMATION,
							title: "Warning",
							actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
							onClose: jQuery.proxy(function (oAction) {

								if (oAction === sap.m.MessageBox.Action.NO) {
									return;
								}

								if (oAction === sap.m.MessageBox.Action.YES) {
									oModel.read("/BIllplan_gen_itemTypeSet", mParameters);
								}

							}, this)
						}
					);
				} else {
					oModel.read("/BIllplan_gen_itemTypeSet", mParameters);
				}
			} else {
				if (parseFloat(totAmnt) === 0 || !totAmnt) {

					var Typemsg = oTextResource.getText("Typemsg");
					var sError = oTextResource.getText("Error");
					sap.m.MessageBox.error(Typemsg, {
						title: sError // default
							// 			textDirection: sap.ui.core.TextDirection.Inherit // default
					});

					return;
				} else {
					oModel.read("/BIllplan_gen_itemTypeSet", mParameters);
				}
			}

		},

		generateItemSameAmount: function () {

			// var oItemBlock = this.getView().byId("idcmItemsBlock");

			var mBillScheduleHeader = this.getOwnerComponent().getModel("mBillScheduleHeader");
			var arrHdrData = mBillScheduleHeader.getData().items;

			this.onDeleteAllForGrp();

			var oDataModel = this.getView().getModel("mainSrv");
			// oDataModel.refresh(true);
			var oItemBlockTable = this.getView().byId("Table1");

			oItemBlockTable.removeSelections(true);
			sap.ui.core.BusyIndicator.show(0);
			jQuery.sap.delayedCall(1500, this, function () {
				sap.ui.core.BusyIndicator.hide();
			});

			if (oItemBlockTable) {

				var Vbeln;
				try {
					var num = parseFloat(this.getView().byId("inputGT").getValue().replace(/\s/g, "").replace(",", "."));
					var totAmnt = num.toString();
				} catch (e) {
					totAmnt = parseFloat(this.getView().byId("inputGT").getValue()).toFixed(2);
				}

				totAmnt = this.deformatAmount(totAmnt);

				var sZeroAmnt = false,
					sHdrDataEng;

				for (var i = 0; i < arrHdrData.length; i++) {

					if (arrHdrData[i].BillTyp === "F" && parseFloat(totAmnt) === 0) {
						sZeroAmnt = true;
						sHdrDataEng = arrHdrData[i].EngNum;
					}

					if (Vbeln) {
						Vbeln = Vbeln + arrHdrData[i].EngNum + "|";
					} else {
						Vbeln = arrHdrData[i].EngNum + "|";
					}
				}

				totAmnt = totAmnt + "|";

				var planTyp = this.getView().byId("idComboBoxPlanType").getSelectedKey();
				var planFreq = this.getView().byId("idComboBoxFreq").getSelectedKey();

				var startDate = this.sDate;
				var endDate = this.eDate;
				var conBilling = "X";
				var oTextResource = this.getOwnerComponent().getModel("i18n").getResourceBundle();
				var Mandatfldsmsg = oTextResource.getText("Mandatfldsmsg");
				var Startdatemsg = oTextResource.getText("Startdatemsg");
				var Typemsg = oTextResource.getText("Typemsg");
				var sError = oTextResource.getText("Error");
				if (!startDate || !endDate || !planFreq) {
					sap.m.MessageBox.error(Mandatfldsmsg, {
						title: sError // default
							// 			textDirection: sap.ui.core.TextDirection.Inherit // default
					});
					return;
				}

				if (startDate > endDate) {
					sap.m.MessageBox.error(Startdatemsg, {
						title: sError // default
							// 			textDirection: sap.ui.core.TextDirection.Inherit // default
					});
					return;
				}

				if (planTyp === "Y009") {
					// sMandMissing = true;

					if (parseFloat(totAmnt) === 0 || !totAmnt) {
						var sError = oTextResource.getText("Error");
						sap.m.MessageBox.error(Typemsg, {
							title: sError // default
								// 			textDirection: sap.ui.core.TextDirection.Inherit // default
						});

						return;
					}

				}

				var aFilter = [];

				aFilter.push(new sap.ui.model.Filter("StartDate", 'EQ', startDate));
				aFilter.push(new sap.ui.model.Filter("EndDate", 'EQ', endDate));
				aFilter.push(new sap.ui.model.Filter("ConBillFlag", 'EQ', conBilling));
				aFilter.push(new sap.ui.model.Filter("Freq", 'EQ', planFreq));
				aFilter.push(new sap.ui.model.Filter("Vbeln2", 'EQ', Vbeln));
				aFilter.push(new sap.ui.model.Filter("Fakwr2", 'EQ', totAmnt));
				aFilter.push(new sap.ui.model.Filter("Fkarv", 'EQ', planTyp));

				var oModel = this.getOwnerComponent().getModel("mainSrv");
				sap.ui.core.BusyIndicator.show(0);

				var fnSuccess = jQuery.proxy(function (oData) {

					sap.ui.core.BusyIndicator.hide();

					var mBillPlanCrea = this.getOwnerComponent().getModel("mBillPlanCrea");
					mBillPlanCrea.setProperty("/items", oData.results);

					var arrModelDataItems = mBillPlanCrea.getProperty("/items");

					for (var i = 0; i < arrModelDataItems.length; i++) {

						arrModelDataItems[i].posnrFc = false;
						arrModelDataItems[i].VbelnFc = false;

					}

					this.getView().byId("idTabBillEdit").setModel(mBillPlanCrea, "mBillPlanCrea");
					this.getOwnerComponent().getModel("mBillPlanCrea").refresh();

				}, this);

				var fnError = jQuery.proxy(function (oData) {

					this.oResult = JSON.parse(JSON.stringify(oData));
					sap.ui.core.BusyIndicator.hide();

				}, this);

				var mParameters = {
					filters: aFilter,
					success: fnSuccess,
					error: fnError
				};

				var Unsavedmsg = "Enagement-" + sHdrDataEng + " " +
					"contains fixed price plantype. Amount can not be Zero(0).Do you want to generate schedule?";

				//	var planTyp = this.getView().byId("idComboBoxPlanType").getSelectedKey();

				if (sZeroAmnt) {

					sap.m.MessageBox.show(
						Unsavedmsg, {
							icon: sap.m.MessageBox.Icon.INFORMATION,
							title: "Warning",
							actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
							onClose: jQuery.proxy(function (oAction) {

								if (oAction === sap.m.MessageBox.Action.NO) {
									return;
								}

								if (oAction === sap.m.MessageBox.Action.YES) {
									oModel.read("/BIllplan_gen_itemTypeSet", mParameters);
								}

							}, this)
						}
					);
				} else {
					oModel.read("/BIllplan_gen_itemTypeSet", mParameters);
				}

				// oModel.read("/BIllplan_gen_itemTypeSet", mParameters);

			}

		},

		saveBillSchdeule: function (oEvent) {

			var oItemBlockTable;

			var oControl = oEvent.getSource();

			switch (this.Mode) {
			case 'C':
				this.createPlan(oControl);
				// oItemBlockTable = this.getView().byId("Table1");
				break;

			case 'E':
				this.updatePlan(oControl);
				// oItemBlockTable = this.getView().byId("idTabBillEdit");
				break;
			default:
			}

		},

		handleStartDateChange: function (oEvent) {
			if (this.engSDate) {

				if ((new Date()).getTimezoneOffset() < 0) {
					var lvEngtempSdate = new Date(this.engSDate.getTime() - this.engSDate.getTimezoneOffset() * 60000);
				} else {
					var lvEngtempSdate = new Date(this.engSDate.getTime() + this.engSDate.getTimezoneOffset() * 60000);
				}
				var lvEngSdate = lvEngtempSdate.setHours(0, 0, 0, 0);
				var lvNewDate = oEvent.oSource.mProperties.dateValue.setHours(0, 0, 0, 0);
				if (this.engSDate && lvEngSdate > lvNewDate) {

					var oTextResource = this.getOwnerComponent().getModel("i18n").getResourceBundle();
					var sDateChngMsg = oTextResource.getText("pastDateMsgCre");

					sap.m.MessageBox.error(sDateChngMsg, {
						title: "Error" // default
							// 			textDirection: sap.ui.core.TextDirection.Inherit // default
					});

					var sDate = this.formatDate(this.engSDate);
					// oEvent.getSource().setValue(sDate);
					this.getView().getModel("mDateModel").setProperty("/sDate", sDate);
					this.getView().getModel("mDateModel").refresh(true);

					return;

					// if (!this.sDateChanged) {
					// 	sap.m.MessageBox.information(
					// 		"Start Date is outside of project duration", {
					// 			styleClass: "sapUiSizeCompact"
					// 		}
					// 	);
					// }

				}
			}
			this.sDateChanged = true;
			this.sDate = this.formatDate(oEvent.oSource.mProperties.dateValue);
			// this.sDate = oEvent.oSource.mProperties.dateValue; //new Date(oEvent.getSource().getValue());
		},

		handleEndDateChange: function (oEvent) {

			// if (this.engEDate && this.engEDate < oEvent.oSource.mProperties.dateValue) {

			// 	var oTextResource = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			// 	var sDateChngMsg = oTextResource.getText("futDateMsgCre");

			// 	sap.m.MessageBox.error(sDateChngMsg, {
			// 		title: "Error" // default
			// 	});

			// 	var sDate = this.formatDate(this.engEDate);

			// 	oEvent.getSource().setValue(sDate);

			// 	return;

			// }
			// this.eDateChanged = true;
			// this.eDate = oEvent.oSource.mProperties.dateValue; //new Date(oEvent.oSource.mProperties.dateValue); 
			this.eDate = this.formatDate(oEvent.oSource.mProperties.dateValue);
		},

		setFilterValue: function () {

			return this.sImportingParam;

		},

		onAddItem: function (oEvent) {

			var arrInp = this.getOwnerComponent().getModel("mBillScheduleHeader").getProperty("/items");
			var sVbeln = " ";
			if (arrInp.length === 1) {
				sVbeln = arrInp[0].EngNum;
			}

			var data = {
				fksaf_text: " ",
				payterms: " ",
				billstat: " ",
				PLANEDIT: " ",
				FAREG: " ",
				StartDate: " ",
				Vbeln: sVbeln,
				Afdat: " ",
				EndDate: " ",
				Freq: " ",
				GenItem: " ",
				ConBillFlag: " ",
				Fakwr: parseFloat("0").toFixed(2),
				Waers: this.sCurrKey,
				Fpttp: " ",
				Tetxt: " ",
				Tebez: " ",
				Faksp: " ",
				Fksaf: " ",
				Fkarv: " ",
				Zterm: " ",
				VbelnFc: true
			};

			this.getOwnerComponent().getModel("mBillPlanCrea").getProperty("/items").push(data);
			this.getOwnerComponent().getModel("mBillPlanCrea").refresh();

		},

		onDeleteAllForGrp: function (oEvent) {

			// var oItemBlockTable;

			var mModel, arrModelData;
			var oItemBlockTable;
			switch (this.Mode) {
			case 'C':
				oItemBlockTable = this.getView().byId("Table1");
				mModel = this.getOwnerComponent().getModel("mBillPlanCrea");
				arrModelData = mModel.getProperty("/items");

				break;

			case 'E':
				oItemBlockTable = this.getView().byId("idTabBillEdit");
				mModel = this.getOwnerComponent().getModel("mBillPlanEdit");
				arrModelData = mModel.getProperty("/items");
				break;
			default:
			}

			if (oItemBlockTable.getItems().length > 0) {

				var attSel = [];

				attSel = oItemBlockTable.getItems();

				var sPath, idx;

				for (var i = attSel.length - 1; i >= 0; i--) {
					sPath = attSel[i].getBindingContextPath();

					idx = parseInt(sPath.substring(sPath.lastIndexOf('/') + 1));
					arrModelData.splice(idx, 1);

				}

				mModel.setProperty("/items", arrModelData);
				mModel.refresh(true);
				oItemBlockTable.removeSelections(true);

			}

		},
		onDeleteAll: function (oEvent) {
			var oItemBlockTable;
			switch (this.Mode) {
			case 'C':
				oItemBlockTable = this.getView().byId("Table1");
				break;

			case 'E':
				oItemBlockTable = this.getView().byId("idTabBillEdit");
				break;
			default:
			}

			var sStatus;

			if (oItemBlockTable.getItems().length > 0) {

				var attSel = [];
				var sItmId;

				attSel = oItemBlockTable.getItems();

				for (var i = 0; i < attSel.length; i++) {

					sItmId = attSel[i].getId();
					// if (oItemBlockTable.getSelectedItems()[i]) {
					// var item = oItemBlockTable.getSelectedItems()[i];
					if (this.Mode === 'E') {
						sStatus = attSel[i].getModel("mainSrv").getProperty(attSel[i].getBindingContextPath() + "/fksaf");
						if (sStatus !== "C") {
							oItemBlockTable.removeItem(sItmId);
						}
					}

					//attSel[i].destroy();
					// attSel[i].getModel("mainSrv").remove(attSel[i].getBindingContextPath());
					// }
				}

				if (this.Mode === 'C') {
					var xx = attSel.length;
					for (var i = 0; i < xx; i++) {
						// sStatus = attSel[i].getModel("mainSrv").getProperty(attSel[i].getBindingContextPath() + "/fksaf");
						// if (sStatus !== "C") {
						attSel[i].destroy();
						// }

					}
				}
			}
		},

		onDeleteAddedItm: function (oEvent) {
			var oItemBlockTable;
			switch (this.Mode) {
			case 'C':
				oItemBlockTable = this.getView().byId("Table1");
				break;

			case 'E':
				oItemBlockTable = this.getView().byId("idTabBillEdit");
				break;
			default:
			}

			if (oItemBlockTable.getItems().length > 0) {

				this.oItmTemplate = oItemBlockTable.getItems()[0];

				var attSel = [];
				var sItmId;

				attSel = oItemBlockTable.getItems();

				for (var i = 0; i < attSel.length; i++) {

					sItmId = attSel[i].getId();
					// if (oItemBlockTable.getSelectedItems()[i]) {
					// var item = oItemBlockTable.getSelectedItems()[i];
					if (!attSel[i].getModel("mainSrv").getProperty(attSel[i].getBindingContextPath() + "/RefreshItem")) {
						oItemBlockTable.removeItem(sItmId);
						//attSel[i].destroy();
						// attSel[i].getModel("mainSrv").remove(attSel[i].getBindingContextPath());
					}

					// }

				}
			}
		},

		onDeleteItem: function (oEvent) {

			// var oItemBlockTable;

			var mModel, arrModelData;
			var oItemBlockTable;
			var oTextResource = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var Delitemmsg = oTextResource.getText("Delitemmsg");

			switch (this.Mode) {
			case 'C':
				oItemBlockTable = this.getView().byId("Table1");
				mModel = this.getOwnerComponent().getModel("mBillPlanCrea");
				arrModelData = mModel.getProperty("/items");

				break;

			case 'E':
				oItemBlockTable = this.getView().byId("idTabBillEdit");
				mModel = this.getOwnerComponent().getModel("mBillPlanEdit");
				arrModelData = mModel.getProperty("/items");
				if (!this.delItm) {
					this.delItm = [];
				}

				break;
			default:
			}

			if (oItemBlockTable.getSelectedItems().length > 0) {

				var attSel = [];
				var sItmId;

				attSel = oItemBlockTable.getSelectedItems();

				var sStatus, hasCompletedItm = false,
					sPath, idx;

				for (var i = attSel.length - 1; i >= 0; i--) {

					// sItmId = attSel[i].getId();

					sPath = attSel[i].getBindingContextPath();

					if (this.Mode === 'E') {

						sStatus = attSel[i].getModel("mBillPlanEdit").getProperty(sPath + "/fksaf");
					}

					if (sStatus !== "C") {

						idx = parseInt(sPath.substring(sPath.lastIndexOf('/') + 1));
						if (this.Mode === 'E') {
							this.delItm.push(arrModelData[idx]);
						}
						arrModelData.splice(idx, 1);

					} else {
						attSel[i].setSelected(false);
						hasCompletedItm = true;
					}
					// }
				};

				mModel.setProperty("/items", arrModelData);
				mModel.refresh(true);
				oItemBlockTable.removeSelections(true);

				if (hasCompletedItm) {
					sap.m.MessageBox.information(
						Delitemmsg, {
							styleClass: "sapUiSizeCompact"
						}
					);
				}
			} else {
				sap.m.MessageBox.information(
					"Select at least one item to delete", {
						styleClass: "sapUiSizeCompact"
					}
				);
			}
		},

		onAddItemEdit: function (oEvent) {

			var oItemBlockTable = this.getView().byId("idTabBillEdit");

			this.oSearchResultTable = oItemBlockTable;

			var oGrpComboBox = this.getView().byId("idGrpBy");
			var oKey = oGrpComboBox.getSelectedKey();
			var sEdit;
			var sKeyDate = "",
				sKeyItem = "";

			if (oKey === "01") {
				sEdit = false;
				var oDateConbo = this.getView().byId("idCBoxBillDate");
				sKeyDate = new Date(oDateConbo.getSelectedKey());
			} else {
				var oItmConbo = this.getView().byId("idGrpByCombo");
				sEdit = true;
				sKeyItem = oItmConbo.getSelectedKey();
			}

			// var arrInp = this.getOwnerComponent().getModel("mBillPlanEdit").getProperty("/items");
			// var sVbeln = " ";
			// if (arrInp.length === 1) {
			// 	sVbeln = arrInp[0].vbeln;
			// }

			if (oKey === "01" || oKey === "03") {
				var arrEngItems = this.getView().getModel("mEngItms").getProperty("/items");

				for (var i = 0; i < arrEngItems.length; i++) {

					sKeyItem = arrEngItems[i].posnr;
					var data = {
						matcode: "",
						PLANEDIT: "",
						RefreshItem: "",
						afdat: sKeyDate,
						faksp: "",
						fakwr: parseFloat("0").toFixed(2),
						fksaf: "",
						fplnr: "",
						fpltr: "",
						fpttp: "",
						posnr: sKeyItem,
						tebez: "",
						tetxt: "",
						vbeln: this.vbeln,
						waers: this.sCurrKey,
						zterm: "",
						payterms: "",
						editable: sEdit,
						sddocumentitem: "",
						billstat: "",
						updkz: "",
						fareg: "",
						fkarv: "",
						posnrFc: true,
						VbelnFc: false
					};

					this.getView().byId("idTabBillEdit").getModel("mBillPlanEdit").getProperty("/items").push(data);
				}

			} else {

				var data = {
					matcode: "",
					PLANEDIT: "",
					RefreshItem: "",
					afdat: sKeyDate,
					faksp: "",
					fakwr: parseFloat("0").toFixed(2),
					fksaf: "",
					fplnr: "",
					fpltr: "",
					fpttp: "",
					posnr: sKeyItem,
					tebez: "",
					tetxt: "",
					vbeln: this.vbeln,
					waers: this.sCurrKey,
					zterm: "",
					payterms: "",
					editable: sEdit,
					sddocumentitem: "",
					billstat: "",
					updkz: "",
					fareg: "",
					fkarv: "",
					posnrFc: true,
					VbelnFc: false
				};

				this.getView().byId("idTabBillEdit").getModel("mBillPlanEdit").getProperty("/items").push(data);
			}
			this.getOwnerComponent().getModel("mBillPlanEdit").refresh();

		},

		onRemoveBlockBillNow: function (oEvent) {

			var mModel, arrModelData;
			var oItemBlockTable;
			this.hasChanges = true;

			var oIconTabKey = this.getView().byId("idIconTabBar").getSelectedKey();

			switch (oIconTabKey) {
			case "01":
				oItemBlockTable = this.getView().byId("idTabBillEdit");
				break;

			case "02":
				oItemBlockTable = this.getView().byId("idTabBillEditAll");
				break;
			default:
			}

			mModel = this.getOwnerComponent().getModel("mBillPlanEdit");
			arrModelData = mModel.getProperty("/items");

			if (oItemBlockTable.getSelectedItems().length > 0) {

				var attSel = [];
				// var sItmId;

				attSel = oItemBlockTable.getSelectedItems();

				// var sStatus, hasCompletedItm = false,
				var sPath, idx;

				for (var i = attSel.length - 1; i >= 0; i--) {

					sPath = attSel[i].getBindingContextPath();

					idx = parseInt(sPath.substring(sPath.lastIndexOf('/') + 1));
					arrModelData[idx].faksp = "";

				}

				mModel.setProperty("/items", arrModelData);
				mModel.refresh(true);
				// oItemBlockTable.removeSelections(true);

			}

		},

		onRemoveBlock: function (oEvent) {

			// var oItemBlockTable;

			var mModel, arrModelData;
			var oItemBlockTable;
			this.hasChanges = true;

			var oIconTabKey = this.getView().byId("idIconTabBar").getSelectedKey();

			switch (oIconTabKey) {
			case "01":
				oItemBlockTable = this.getView().byId("idTabBillEdit");
				break;

			case "02":
				oItemBlockTable = this.getView().byId("idTabBillEditAll");
				break;
			default:
			}

			mModel = this.getOwnerComponent().getModel("mBillPlanEdit");
			arrModelData = mModel.getProperty("/items");

			if (oItemBlockTable.getSelectedItems().length > 0) {

				var attSel = [];
				var sItmId;

				attSel = oItemBlockTable.getSelectedItems();

				var sStatus, hasCompletedItm = false,
					sPath, idx;

				for (var i = attSel.length - 1; i >= 0; i--) {

					sPath = attSel[i].getBindingContextPath();

					// if (this.Mode === 'E') {

					// 	sStatus = attSel[i].getModel("mBillPlanEdit").getProperty(sPath + "/fksaf");
					// }

					// if (sStatus !== "C") {

					idx = parseInt(sPath.substring(sPath.lastIndexOf('/') + 1));
					arrModelData[idx].faksp = "";

					// } else {
					// 	attSel[i].setSelected(false);
					// 	hasCompletedItm = true;
					// }

				}

				mModel.setProperty("/items", arrModelData);
				mModel.refresh(true);
				oItemBlockTable.removeSelections(true);

				// if (hasCompletedItm) {
				// 	sap.m.MessageBox.information(
				// 		"Invoiced items can not be modified", {
				// 			styleClass: "sapUiSizeCompact"
				// 		}
				// 	);
				// }
			} else {
				sap.m.MessageBox.information(
					"Select at least one item to remove block", {
						styleClass: "sapUiSizeCompact"
					}
				);
			}

		},
		handleItemDateChange: function (oEvent) {

			if (this.engSDate) {
				if ((new Date()).getTimezoneOffset() < 0) {
					var lvEngtempSdate = new Date(this.engSDate.getTime() - this.engSDate.getTimezoneOffset() * 60000);
				} else {
					var lvEngtempSdate = new Date(this.engSDate.getTime() + this.engSDate.getTimezoneOffset() * 60000);
				}
				var lvEngSdate = lvEngtempSdate.setHours(0, 0, 0, 0);
				var lvNewDate = oEvent.oSource.mProperties.dateValue.setHours(0, 0, 0, 0);

				if (this.engSDate && lvEngSdate > lvNewDate) {

					var oTextResource = this.getOwnerComponent().getModel("i18n").getResourceBundle();
					var sDateChngMsg = oTextResource.getText("pastDateMsgCre");

					sap.m.MessageBox.error(sDateChngMsg, {
						title: "Error" // default
							//  textDirection: sap.ui.core.TextDirection.Inherit // default
					});

					var sPath = oEvent.getSource().getParent().getBindingContextPath();
					var idx = parseInt(sPath.substring(sPath.lastIndexOf('/') + 1));

					if (this.Mode === 'E') {
						var mModel = this.getOwnerComponent().getModel("mBillPlanEdit");
					} else {
						var mModel = this.getOwnerComponent().getModel("mBillPlanCrea");
					}

					var arrModelData = mModel.getProperty("/items");
					arrModelData[idx].Afdat = arrModelData[idx].Afdat;
					mModel.setProperty("/items", arrModelData);
					mModel.refresh(true);
					return;

				}
			}

			this._oSelectedItem = oEvent.getSource().getParent();
			var oDate = new Date(oEvent.oSource.mProperties.dateValue);

			var sPath = this._oSelectedItem.getBindingContextPath();
			var idx = parseInt(sPath.substring(sPath.lastIndexOf('/') + 1));

			if (this.Mode === 'E') {

				var oGrpComboBox = this.getView().byId("idGrpBy");
				var oKey = oGrpComboBox.getSelectedKey();

				if (oKey === "03") {

					if (this.calculateDateDiff(oDate)) {

						var oTextResource = this.getOwnerComponent().getModel("i18n").getResourceBundle();
						var sDateChngMsg = oTextResource.getText("pastDateMsg");

						sap.m.MessageBox.warning(sDateChngMsg, {
							title: "Warning" // default
								// 			textDirection: sap.ui.core.TextDirection.Inherit // default
						});

						// oEvent.getSource().setValue(" ");

						// return;

					}
				}

				var mModel = this.getOwnerComponent().getModel("mBillPlanEdit");
				var arrModelData = mModel.getProperty("/items");
				if (arrModelData[idx].afdat !== oDate) {
					this.hasChanges = true;

				}

				arrModelData[idx].afdat = oDate;
			} else {
				var mModel = this.getOwnerComponent().getModel("mBillPlanCrea");
				var arrModelData = mModel.getProperty("/items");
				arrModelData[idx].Afdat = oDate;
			}

			mModel.setProperty("/items", arrModelData);
			mModel.refresh(true);

		},

		updateAmount: function (oEvent) {
			this._oSelectedItem = oEvent.getSource().getParent().getParent();

			var sPath = this._oSelectedItem.getBindingContextPath();
			var mModel, arrModelData;
			var sAmnt;

			var idx = parseInt(sPath.substring(sPath.lastIndexOf('/') + 1));

			if (!oEvent.getParameter("value")) {
				sAmnt = parseFloat("0").toFixed(2);
			} else {
				sAmnt = oEvent.getParameter("value");
			}

			if (sAmnt) {
				// var newAmnt = parseFloat(sAmnt).toFixed(2);
				var newAmnt = sAmnt;

				if (this.Mode === 'E') {
					this.hasChanges = true;
					mModel = this.getOwnerComponent().getModel("mBillPlanEdit");
					arrModelData = mModel.getProperty("/items");
					arrModelData[idx].fakwr = newAmnt;
				} else {
					mModel = this.getOwnerComponent().getModel("mBillPlanCrea");
					arrModelData = mModel.getProperty("/items");
					arrModelData[idx].Fakwr = newAmnt;
				}
			}

			oEvent.getSource().setValue(newAmnt);

		},

		amountChange: function (oEvent) {

		},

		onItmNumberChange: function (oEvent) {

			// .getTable().getSelectedItem();
			this._oSelectedPlanItem = oEvent.getSource().getParent().getParent();
			var oView = this.getView();
			var oDialog = oView.byId("itmNum");
			// create dialog lazily
			if (!oDialog) {
				// create dialog via fragment factory
				// var oCtrl = sap.ui.controller("kno.em.billsrch.germany.ext.controller.ListReportActions");
				oDialog = sap.ui.xmlfragment(oView.getId(), "kno.em.billschedule.view.itemNum", this);
				// connect dialog to view (models, lifecycle)
				oView.addDependent(oDialog);
			}

			oDialog.open();

		},
		onItmPlanTypChange: function (oEvent) {

			// .getTable().getSelectedItem();
			this._oSelectedPlanItem = oEvent.getSource().getParent().getParent();
			var oView = this.getView();
			var oDialog = oView.byId("planTyp");
			// create dialog lazily
			if (!oDialog) {
				// create dialog via fragment factory
				// var oCtrl = sap.ui.controller("kno.em.billsrch.germany.ext.controller.ListReportActions");
				oDialog = sap.ui.xmlfragment(oView.getId(), "kno.em.billschedule.view.planType", this);
				// connect dialog to view (models, lifecycle)
				oView.addDependent(oDialog);
			}

			oDialog.open();

		},

		onChangeItmPlanTyp: function (oEvent) {
			var oTextResource = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var sError = oTextResource.getText("Error");
			if (this.Mode === 'E') {

				var oPlnTyp = oEvent.getSource();
				var sItemPath = oPlnTyp.getParent().getBindingContextPath();

				var sPosnr = this.getView().getModel("mBillPlanEdit").getProperty(sItemPath + "/posnr");
				var attEngItems;
				if (this.getView().getModel("mEngItms").getData()) {
					attEngItems = this.getView().getModel("mEngItms").getData().items;
				}

				var sPlanTyp;

				for (var j = 0; j < attEngItems.length; j++) {
					if (attEngItems[j].posnr === sPosnr) {
						sPlanTyp = attEngItems[j].feetyp;
						break;
					}
				}

				var sMsg;
				switch (oEvent.getSource().getSelectedKey()) {
				case "Y004":
					if (sPlanTyp === "Y003") {
						sMsg = "Plan type for Item" + " " + sPosnr + " " + "can not be changed to Fixed price.";
						oEvent.getSource().setSelectedKey("Y003");

					}

					break;
				case "Y003":

					if (sPlanTyp === "Y004") {
						sMsg = "Plan type for Item" + " " + sPosnr + " " + "can not be changed to Time & Material.";
						oEvent.getSource().setSelectedKey("Y004");
					}

					break;

				case "Y605":
					// sMsg = "Plan type for Item" + " " + sPosnr + " " + "can not be changed to Migrated plan type.";
					// oEvent.getSource().setSelectedKey(sPlanTyp);
					break;

				default:
				}

				if (sMsg) {
					sap.m.MessageBox.error(sMsg, {
						title: sError // default

					});
				} else {

					if (oEvent.getSource().getSelectedKey() === "Y003") {
						var sItemPathFakwr = oEvent.getSource().getParent().getBindingContextPath();
						this.getView().getModel("mBillPlanEdit").setProperty(sItemPathFakwr + "/fakwr", parseFloat("0").toFixed(2));
					}

				}

			}

		},

		onChangeEngItm: function (oEvent) {
			var sItm = oEvent.getSource().getSelectedKey();
			var oItemBlockTable = this.getView().byId("idTabBillEdit");
			if (oItemBlockTable) {
				var aFilter = [];

				if (this.vbeln.length < 10) {

					for (var p = this.vbeln.length; p < 10; p++) {
						this.vbeln = '0' + this.vbeln;
					}
				}

				aFilter.push(new sap.ui.model.Filter("vbeln", 'EQ', this.vbeln));
				aFilter.push(new sap.ui.model.Filter("posnr", 'EQ', sItm));

				this.aEditFilter = aFilter;
				this.readBillPlanCons(this.aEditFilter);

			}
		},

		onChangePlanTyp: function (oEvent) {

			var oPlnTyp = oEvent.getSource();
			var sPlnKey = oPlnTyp.getSelectedKey();

			if (sPlnKey === "Y003") {
				var sDefaultAmnt = parseFloat("0").toFixed(2);
				this.getView().byId("inputGT").setValue(sDefaultAmnt);
			}

		},

		onChangeTotAmnt: function (oEvent) {
			var sAmt = oEvent.getSource().getValue();
			var sPlnKey = this.getView().byId("idComboBoxPlanType").getSelectedKey();
			var oTextResource = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var Amountmsg = oTextResource.getText("Amountmsg");
			var sError = oTextResource.getText("Error");
			sAmt = this.deformatAmount(sAmt);
			if (isNaN(sAmt)) {

				var sMsg = Amountmsg + " " + sAmt;
				sap.m.MessageBox.error(sMsg, {
					title: sError // default
						// 			textDirection: sap.ui.core.TextDirection.Inherit // default
				});

				var sDefaultAmnt = parseFloat("0").toFixed(2);
				sDefaultAmnt = this.formatAmount(sDefaultAmnt);
				oEvent.getSource().setValue(sDefaultAmnt);
				return;
			};

			if (!sAmt) {
				var sDefaultAmnt = parseFloat("0").toFixed(2);
				sDefaultAmnt = this.formatAmount(sDefaultAmnt);
				oEvent.getSource().setValue(sDefaultAmnt);
			} else {
				if (sPlnKey === "Y003") {
					var sDefaultAmnt = parseFloat("0").toFixed(2);
					sDefaultAmnt = this.formatAmount(sDefaultAmnt);
					oEvent.getSource().setValue(sDefaultAmnt);
				} else {
					try {
						var num = parseFloat(sAmt.replace(/\s/g, "").replace(",", "."));
						sDefaultAmnt = num.toString();
					} catch (e) {
						sDefaultAmnt = parseFloat(sAmt).toFixed(2);
					}

					sDefaultAmnt = this.formatAmount(sDefaultAmnt);
					oEvent.getSource().setValue(sDefaultAmnt);
				}

			}

		},

		// onChangeEngItmNum: function(oEvent) {

		// 	var Dialog = this.getView().byId("itmNum");

		// 	var oPlnTyp = oEvent.getSource();

		// 	var oBindingContxt = oPlnTyp.getParent().getBindingContext("mainSrv");
		// 	var oModel = oBindingContxt.getModel();

		// 	// if (this.Mode === 'E') {
		// 	// 	oModel.setProperty(oBindingContxt.getPath() + '/tetxt', oPlnTyp.getSelectedKey());
		// 	// } else {

		// 	oModel.setProperty(oBindingContxt.getPath() + '/posnr', oPlnTyp.getSelectedKey());
		// 	// }
		// 	oPlnTyp.setSelectedItem(oEvent.mParameters.selectedItem);
		// 	oModel.refresh(true);
		// 	// oModel.updateBindings();
		// 	// Dialog.close();
		// 	// Dialog.destroy(true);
		// },

		formatAmount: function (sAmnt) {
			// var mUserProfile = this.getOwnerComponent().getModel("mUserProfile");
			// var sDecFormat = mUserProfile.getProperty("/currFormat");

			var sDecFormat = sap.ui.getCore().getConfiguration().getFormatSettings().getCustomLocaleData()["symbols-latn-decimal"];
			var oNumberFormat = sap.ui.core.format.NumberFormat.getFloatInstance({
				maxFractionDigits: 2,
				groupingEnabled: false,
				// groupingSeparator: sDecFormat === "," ? "." : ",",
				decimalSeparator: sDecFormat
			});

			return oNumberFormat.format(sAmnt);

			// return sAmnt;
		},

		createPlan: function (oControl) {

			var oDataSrv = this.getView().getModel("mainSrv");
			var oTextResource = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var Billschedulesuccess = oTextResource.getText("Billschedulesuccess");
			var Billdatemsg = oTextResource.getText("Billdatemsg");
			var selplanmsg = oTextResource.getText("selplanmsg");
			var amountzeromsg = oTextResource.getText("amountzeromsg");
			var Nosavemsg = oTextResource.getText("Nosavemsg");
			var Typemsg = oTextResource.getText("Typemsg");
			var sError = oTextResource.getText("Error");
			oDataSrv.setRefreshAfterChange(false);

			var arrEngItems = this.getView().getModel("mBillScheduleHeader").getProperty("/items");
			var sLeadEng;
			for (var i = 0; i < arrEngItems.length; i++) {
				if (arrEngItems[i].Lead === "X") {

					sLeadEng = arrEngItems[i].EngNum;
					this.vbeln = sLeadEng;
				}
			}

			// var oItemBlockTable;

			// oItemBlockTable = this.getView().byId("Table1");

			var oTabRows = this.getOwnerComponent().getModel("mBillPlanCrea").getProperty("/items"); // oItemBlockTable.getItems();
			// var oBindingContxt;
			var engNum;
			// var d = [];

			var mEngModel = this.getView().getModel("mBillScheduleHeader");

			if (mEngModel) {

				var oEngModelData = mEngModel.getData();
				if (oEngModelData) {

					var fnSuccess = jQuery.proxy(function (oData, oResponse) {

						sap.ui.core.BusyIndicator.hide();
						 if (oResponse.data.__batchResponses[0].response) {
                            Billschedulesuccess = JSON.parse(oResponse.data.__batchResponses[0].response.body).error.message.value;
                        }

						if (!this.successCount) {

							sap.m.MessageToast.show(Billschedulesuccess, {
								duration: 3000, // default
								width: "15em", // default
								my: "center bottom", // default
								at: "center bottom", // default
								of: window, // default
								offset: "0 0", // default
								collision: "fit fit", // default
								onClose: null, // default
								autoClose: true, // default
								animationTimingFunction: "ease", // default
								animationDuration: 1000, // default
								closeOnBrowserNavigation: true // default
							});
							this.successCount = 1;

							var mVisModel = this.getOwnerComponent().getModel("mBillScheVis");
							var mVisModelData = mVisModel.getData();
							mVisModelData.CreateVisibility = false;
							mVisModelData.EditVisibility = true;
							this.getView().setModel(mVisModel, "mBillScheVis");
							mVisModel.refresh();
							this.changeToEditMode = "EDIT";
							this.onInit();
						}
					}, this);
					var fnError = jQuery.proxy(function (d) {
						//debugger
						sap.ui.core.BusyIndicator.hide();
					}, this);
					var arrEngItems = oEngModelData.items;

					var aDefGrp = oDataSrv.getDeferredGroups();
					aDefGrp.push("batchCreate");
					oDataSrv.setDeferredGroups(aDefGrp);

					var mParameters = {
						groupId: "batchCreate"
					};

					var sDate, eDate;
					var itemNo, sMessage;
					var iCounter = 0;
					var arrMessages = [];

					if (arrEngItems.length > 0) {

						for (var i = 0; i < oTabRows.length; i++) {

							engNum = oTabRows[i].Vbeln;

							if (!oTabRows[i].Afdat) {

								itemNo = i + 1;
								sMessage = "Item-00" + itemNo + ":" + Billdatemsg;

								iCounter = iCounter + 1;

								var mMessageModel = {
									type: 'Error',
									title: sMessage,
									description: sMessage,
									subtitle: 'Error Details',
									counter: iCounter
								};

								arrMessages.push(mMessageModel);

							}

							// if (!oTabRows[i].Tetxt) {

							// 	itemNo = i + 1;
							// 	sMessage = "Item-00" + itemNo + ":" + selplanmsg;

							// 	iCounter = iCounter + 1;

							// 	var mMessageModelPlan = {
							// 		type: 'Error',
							// 		title: sMessage,
							// 		description: sMessage,
							// 		subtitle: 'Error Details',
							// 		counter: iCounter
							// 	};

							// 	arrMessages.push(mMessageModelPlan);

							// }

							// if (oTabRows[i].Tetxt === "Y004" || oTabRows[i].Tetxt === "Y009") {
							// 	if (oTabRows[i].Fakwr === parseFloat("0").toFixed(2) || !oTabRows[i].Fakwr) {

							// 		itemNo = i + 1;
							// 		sMessage = "Item-00" + itemNo + ":" + Typemsg;

							// 		iCounter = iCounter + 1;

							// 		var mMessageModelPlan = {
							// 			type: 'Error',
							// 			title: sMessage,
							// 			description: sMessage,
							// 			subtitle: 'Error Details',
							// 			counter: iCounter
							// 		};

							// 		arrMessages.push(mMessageModelPlan);
							// 	}

							// }

							// if (oTabRows[i].Tetxt === "Y003") {
							// 	if (oTabRows[i].Fakwr > parseFloat("0").toFixed(2)) {

							// 		itemNo = i + 1;
							// 		sMessage = "Item-00" + itemNo + ":" + amountzeromsg;

							// 		iCounter = iCounter + 1;

							// 		var mMessageModelPlan = {
							// 			type: 'Error',
							// 			title: sMessage,
							// 			description: sMessage,
							// 			subtitle: 'Error Details',
							// 			counter: iCounter
							// 		};

							// 		arrMessages.push(mMessageModelPlan);
							// 	}

							// }

							if (arrMessages.length === 0) {

								// if (!jQuery.isEmptyObject(oTabRows[i].oBindingContexts.mainSrv)) {

								if (oTabRows[i].StartDate === "" || oTabRows[i].StartDate === " ") {

									sDate = oTabRows[i].Afdat;
								} else {
									sDate = oTabRows[i].StartDate;

								}

								if (oTabRows[i].EndDate === " " || oTabRows[i].EndDate === "") {

									eDate = oTabRows[i].Afdat;
								} else {
									eDate = oTabRows[i].EndDate; //oBindingContxt.getProperty("EndDate");

								}
								var sConBillFlag = this.byId("idComboBoxConBill").getProperty("selectedKey");
								if (oTabRows[i].Tetxt === "Y009") {
									var sBillplantype = oTabRows[i].Tetxt;
								} else if (oTabRows[i].Tetxt === "Y004"){
									sBillplantype = oTabRows[i].Tetxt;
								}else if(oTabRows[i].Tetxt === "Y003"){
									sBillplantype = oTabRows[i].Tetxt;
								}else{
									sBillplantype="";
								}

								try {
									var startDate;
									startDate = this.formatDate(sDate);
									if (startDate) {
										sDate = startDate;
									}

									var endtDate;
									endtDate = this.formatDate(eDate);
									if (endtDate) {
										eDate = endtDate;
									}

								} catch (e) {}
								var mModelData = {
									Vbeln: engNum,
									// Afdat: oTabRows[i].Afdat,
									Afdat: this.formatDate(oTabRows[i].Afdat),
									Fakwr: this.deformatAmount(oTabRows[i].Fakwr),
									GenItem: oTabRows[i].GenItem,
									Tetxt: sBillplantype,
									StartDate: sDate,
									EndDate: eDate,
									ConBillFlag: sConBillFlag,
									Faksp: " ",
									// FAREG: " ",
									// Fkarv: " ",
									Fksaf: " ",
									// Fpttp: " ",
									Freq: " ",
									Tebez: " ",
									Waers: " ",
									Zterm: " "

								};

								if (sLeadEng === engNum) {
									mModelData.Conref = "X";
								} else {
									mModelData.Conref = " ";
								}

								// d.push(mModelData);
								sap.ui.core.BusyIndicator.show(0);
								oDataSrv.create("/BIllplan_gen_itemTypeSet", mModelData, mParameters);

							}
							// }

						}
						if (oTabRows.length <= 0) {
							sap.m.MessageBox.error(Nosavemsg, {
								title: sError // default
									// 			textDirection: sap.ui.core.TextDirection.Inherit // default
							});

							return;
						}
						if (arrMessages.length > 0) {
							sap.ui.core.BusyIndicator.hide();
							this.openUpDownPopover(arrMessages);
							if (this.oMessagePopover) {
								this.oMessagePopover.openBy(oControl);
							}
							return;
						}

						// }

						oDataSrv.submitChanges({
							groupId: "batchCreate",
							success: fnSuccess,
							error: fnError
						});

					}
				}
			}

		},

		updatePlan: function () {

			// //this.getView().byId("idTabBillEdit").setBusy(true);
			sap.ui.core.BusyIndicator.show(0);
			var oDataSrv = this.getView().getModel("mainSrv");
			var arrBillPlanConsData = this.getOwnerComponent().getModel("mBillPlanEdit").getProperty("/items");
			var oTextResource = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var Successmsg = oTextResource.getText("Successmsg");
			var Nosavemsg = oTextResource.getText("Nosavemsg");
			var Failuremsg = oTextResource.getText("Failuremsg");
			var sError = oTextResource.getText("Error");
			var oItemBlockTable;
			var sPlanedit;

			var oIconTabKey = this.getView().byId("idIconTabBar").getSelectedKey();
			var sConBillFlag;

			switch (oIconTabKey) {
			case "01":
				oItemBlockTable = this.getView().byId("idTabBillEdit");
				sConBillFlag = this.getView().byId("idCBoxConBill").getSelectedKey();
				break;

			case "02":
				oItemBlockTable = this.getView().byId("idTabBillEditAll");
				sConBillFlag = "X";
				break;
			default:
			}

			var oTabRows = oItemBlockTable.getItems();
			// var oBindingContxt;
			// var engNum;

			var mEngModel = this.getView().getModel("mBillScheduleHeader");

			if (mEngModel) {

				var oEngModelData = mEngModel.getData();
				if (oEngModelData) {
					var arrEngItems = oEngModelData.items;

					var aDefGrp = oDataSrv.getDeferredGroups();
					aDefGrp.push("batchCreate");
					oDataSrv.setDeferredGroups(aDefGrp);

					var fnSuccess = jQuery.proxy(function (oData, oResponse) {

						var sMessage;

						if (!oResponse.data.__batchResponses[0].response) {

							sMessage = Successmsg;
						} else {
							var oResponseBody = JSON.parse(oResponse.data.__batchResponses[0].response.body);
							sMessage = oResponseBody.error.message.value;

						}

						sap.m.MessageToast.show(sMessage, {
							duration: 3000, // default
							width: "15em", // default
							my: "center bottom", // default
							at: "center bottom", // default
							of: window, // default
							offset: "0 0", // default
							collision: "fit fit", // default
							onClose: null, // default
							autoClose: true, // default
							animationTimingFunction: "ease", // default
							animationDuration: 1000, // default
							closeOnBrowserNavigation: true // default
						});

						// this.count = 1 + this.count;
						var arrItms = [];
						this.getOwnerComponent().getModel("mBillPlanEdit").setProperty("/items", arrItms);
						this.readBillPlanCons(this.aEditFilter);
						this.delItm = [];

						//this.getView().byId("idTabBillEdit").setBusy(false);
						sap.ui.core.BusyIndicator.hide();
						if (this.hasChanges) {
							var sConBillFlag = this.getView().byId("idCBoxConBill").getSelectedKey();
							if (sConBillFlag === "X") {
								this.hasChanges = false;
								this.loadHeaderDetails();
							} else {

								this.hasChanges = false;
								this.loadHeaderDetails();
								if (this.itemChanged) {
									this.vbeln = this.LeadEngNum;
									this.loadInitialSettings();
									this.itemChanged = false;
								}

							}

						}

					}, this);
					var fnError = jQuery.proxy(function (d) {
						var message = Failuremsg;
						sap.m.MessageToast.show(message, {
							duration: 30000, // default
							width: "15em", // default
							my: "center bottom", // default
							at: "center bottom", // default
							of: window, // default
							offset: "0 0", // default
							collision: "fit fit", // default
							onClose: null, // default
							autoClose: true, // default
							animationTimingFunction: "ease", // default
							animationDuration: 1000, // default
							closeOnBrowserNavigation: true // default
						});
						sap.ui.core.BusyIndicator.hide();
					}, this);

					var mParameters = {
						groupId: "batchCreate"
					};

					var delItems = [];

					// var sDate, eDate;

					// var engNum;

					if (arrEngItems.length > 0) {

						var processingItems = [];
						processingItems.push(oTabRows);

						if (this.validateItems(arrBillPlanConsData)) {
							// return;
						} else {
							// for (var j = 0; j < arrEngItems.length; j++) {

							// engNum = arrEngItems[j].EngNum;

							oTabRows = arrBillPlanConsData;

							if (oTabRows.length === 0) {

								if (!this.delItm || (this.delItm && this.delItm.length === 0)) {
									sap.ui.core.BusyIndicator.hide();

									sap.m.MessageBox.error(Nosavemsg, {
										title: sError // default
											// 			textDirection: sap.ui.core.TextDirection.Inherit // default
									});

									return;
								}

							}

							if (this.delItm && this.delItm.length > 0) {

								delItems = this.delItm;

								for (var i = 0; i < delItems.length; i++) {

									sPlanedit = delItems[i].PLANEDIT;

									var mModelData = {

										PLANEDIT: sPlanedit,
										RefreshItem: "",
										// afdat: delItems[i].afdat,
										afdat: this.formatDate(delItems[i].afdat),
										faksp: delItems[i].faksp,
										fakwr: this.deformatAmount(delItems[i].fakwr),
										fksaf: delItems[i].fksaf,
										fplnr: delItems[i].fplnr,
										fpltr: delItems[i].fpltr,
										posnr: delItems[i].posnr,
										tebez: delItems[i].tebez,
										tetxt: delItems[i].tetxt,
										vbeln: this.vbeln,
										waers: delItems[i].waers,
										zterm: delItems[i].zterm,
										updkz: "D"

									};

									oDataSrv.create("/Billplan_cons", mModelData, mParameters);

								}
							}

							// Insert Items and create the payload for Post

							for (var i = 0; i < oTabRows.length; i++) {
								sPlanedit = oTabRows[i].PLANEDIT;

								var sCurrKey;

								var sVbeln;

								sVbeln = oTabRows[i].vbeln;

								if (sVbeln.length < 10) {
									for (var t = sVbeln.length; t < 10; t++)
										sVbeln = "0" + sVbeln;
								} else {
									sVbeln = oTabRows[i].vbeln;
								}

								if (oTabRows[i].waers) {
									sCurrKey = oTabRows[i].waers;
								} else {
									sCurrKey = this.sCurrKey;
								}

								var mModelDataIns = {
									PLANEDIT: sPlanedit,
									RefreshItem: "",
									// afdat: oTabRows[i].afdat,
									afdat: this.formatDate(oTabRows[i].afdat),
									faksp: oTabRows[i].faksp,
									fakwr: this.deformatAmount(oTabRows[i].fakwr),
									fksaf: oTabRows[i].fksaf,
									fplnr: oTabRows[i].fplnr,
									fpltr: oTabRows[i].fpltr,
									posnr: oTabRows[i].posnr,
									tebez: oTabRows[i].tebez,
									tetxt: oTabRows[i].tetxt,
									vbeln: sVbeln,
									waers: sCurrKey,
									zterm: oTabRows[i].zterm,
									updkz: "I",
									ConBillFlag: sConBillFlag
								};

								oDataSrv.create("/Billplan_cons", mModelDataIns, mParameters);
							}

							// }

							if (oTabRows.length > 0 || delItems.length > 0) {
								oDataSrv.submitChanges({
									groupId: "batchCreate",
									success: fnSuccess,
									error: fnError
								});
							} else {
								sap.ui.core.BusyIndicator.hide();
							}

							this.count = 1;

							// oDataSrv.attachRequestCompleted(function(oEvent) {
							// 	if (oEvent.mParameters.url === "Billplan_cons" && oEvent.mParameters.method === "POST") {

							// 		if (this.count === 1) {}

							// 	};

							// 	jQuery.sap.delayedCall(2000, this, function() {

							// 	});

							// }, this);
						}

						// oDataSrv.submitChanges(mParameters);

					}
				}
			}

		},

		openUpDownPopover: function (arrMsg) {
			if (!this.oMessageTemplate) {
				this.oMessageTemplate = new sap.m.MessagePopoverItem({
					type: '{type}',
					title: '{title}',
					description: '{description}',
					subtitle: '{subtitle}',
					counter: '{counter}'

				});
			}

			if (!this.oMessagePopover) {
				this.oMessagePopover = new sap.m.MessagePopover({
					items: {
						path: '/',
						template: this.oMessageTemplate
					}
				});
			}

			var oModel = new JSONModel();
			oModel.setData(arrMsg);

			var viewModel = new JSONModel();
			viewModel.setData({
				messagesLength: arrMsg.length + ''
			});

			this.getView().setModel(viewModel);

			this.oMessagePopover.setModel(oModel);

		},

		onOKPressed: function (oEvent) {

			var Dialog = this.getView().byId("planTyp");

			var oPlnTyp = this.getView().byId("idComboBoxItmPlanType");

			var oBindingContxt = this._oSelectedPlanItem.getBindingContext("mainSrv");
			var oModel = oBindingContxt.getModel();
			oModel.setProperty(oBindingContxt.getPath() + '/Tetxt', oPlnTyp.getSelectedKey());
			oModel.refresh(true);
			oModel.updateBindings();
			Dialog.close();

		},

		onBillBlkCancelPressed: function (oEvent) {

			// var Dialog = this.getView().byId("planTyp");
			this.getView().byId("billBlckChng").close();

		},

		onCancelPlnTypPressed: function (oEvent) {

			var Dialog = this.getView().byId("planTyp");
			Dialog.close();

		},

		// onChangeItmBillBlk: function(oEvent) {

		// 	// 			var Dialog = this.getView().byId("billBlckChng");

		// 	var oPlnTyp = oEvent.getSource();

		// 	var oBindingContxt = oPlnTyp.getParent().getBindingContext("mainSrv");
		// 	var oModel = oBindingContxt.getModel();

		// 	if (this.Mode === 'E') {
		// 		// oModel.setProperty(oBindingContxt.getPath() + '/tebez', oPlnTyp.getSelectedItem().getText());
		// 		if (oModel.getProperty(oBindingContxt.getPath() + '/faksp') !== oPlnTyp.getSelectedKey()) {
		// this.hasChanges = true;

		// 		}
		// 		oModel.setProperty(oBindingContxt.getPath() + '/faksp', oPlnTyp.getSelectedKey());
		// 	} else {
		// 		// oModel.setProperty(oBindingContxt.getPath() + '/Tebez', oPlnTyp.getSelectedItem().getText());
		// 		oModel.setProperty(oBindingContxt.getPath() + '/Faksp', oPlnTyp.getSelectedKey());
		// 	}

		// 	oPlnTyp.setSelectedItem(oEvent.mParameters.selectedItem);

		// 	oModel.refresh(true);
		// 	// 			oModel.updateBindings();
		// 	// 			Dialog.close();
		// 	// 			Dialog.destroy(true);

		// },

		handleClearWip: function (oEvent) {

			// //this.getView().byId("idTabBillEdit").setBusy(true);
			sap.ui.core.BusyIndicator.show(0);
			var oDataSrv = this.getView().getModel("mainSrv");
			var arrBillPlanConsData = this.getOwnerComponent().getModel("mBillPlanEdit").getProperty("/items");
			var oTextResource = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var Successmsg = oTextResource.getText("Successmsg");
			var Failuremsg = oTextResource.getText("Failuremsg");
			var sError = oTextResource.getText("Error");
			var sNoSave = oTextResource.getText("NothingBill");
			var oItemBlockTable;
			var sPlanedit;

			var oIconTabKey = this.getView().byId("idIconTabBar").getSelectedKey();
			var sConBillFlag;

			switch (oIconTabKey) {
			case "01":
				oItemBlockTable = this.getView().byId("idTabBillEdit");
				sConBillFlag = this.getView().byId("idCBoxConBill").getSelectedKey();
				break;

			case "02":
				oItemBlockTable = this.getView().byId("idTabBillEditAll");
				sConBillFlag = "X";
				break;
			default:
			}

			var oTabRows = oItemBlockTable.getItems();
			// var oBindingContxt;
			// var engNum;

			var mEngModel = this.getView().getModel("mBillScheduleHeader");

			if (mEngModel) {

				var oEngModelData = mEngModel.getData();
				if (oEngModelData) {
					var arrEngItems = oEngModelData.items;

					var aDefGrp = oDataSrv.getDeferredGroups();
					aDefGrp.push("batchCreate");
					oDataSrv.setDeferredGroups(aDefGrp);

					var fnSuccess = jQuery.proxy(function (oData, oResponse) {

						var sMessage;

						if (!oResponse.data.__batchResponses[0].response) {

							sMessage = Successmsg;
						} else {
							var oResponseBody = JSON.parse(oResponse.data.__batchResponses[0].response.body);
							sMessage = oResponseBody.error.message.value;

						}

						sap.m.MessageToast.show(sMessage, {
							duration: 3000, // default
							width: "15em", // default
							my: "center bottom", // default
							at: "center bottom", // default
							of: window, // default
							offset: "0 0", // default
							collision: "fit fit", // default
							onClose: null, // default
							autoClose: true, // default
							animationTimingFunction: "ease", // default
							animationDuration: 1000, // default
							closeOnBrowserNavigation: true // default
						});

						// this.count = 1 + this.count;
						var arrItms = [];
						this.getOwnerComponent().getModel("mBillPlanEdit").setProperty("/items", arrItms);
						this.readBillPlanCons(this.aEditFilter);
						this.delItm = [];

						//this.getView().byId("idTabBillEdit").setBusy(false);
						sap.ui.core.BusyIndicator.hide();

						if (this.hasChanges) {
							var sConBillFlag = this.getView().byId("idCBoxConBill").getSelectedKey();
							if (sConBillFlag === "X") {
								this.hasChanges = false;
								this.loadHeaderDetails();
							} else {

								this.hasChanges = false;
								this.loadHeaderDetails();
								if (this.itemChanged) {
									this.vbeln = this.LeadEngNum;
									this.loadInitialSettings();
									this.itemChanged = false;
								}

							}

						}

					}, this);
					var fnError = jQuery.proxy(function (d) {
						var message = Failuremsg;
						sap.m.MessageToast.show(message, {
							duration: 30000, // default
							width: "15em", // default
							my: "center bottom", // default
							at: "center bottom", // default
							of: window, // default
							offset: "0 0", // default
							collision: "fit fit", // default
							onClose: null, // default
							autoClose: true, // default
							animationTimingFunction: "ease", // default
							animationDuration: 1000, // default
							closeOnBrowserNavigation: true // default
						});
						sap.ui.core.BusyIndicator.hide();
					}, this);

					var mParameters = {
						groupId: "batchCreate"
					};

					var delItems = [];

					// var sDate, eDate;

					// var engNum;

					if (arrEngItems.length > 0) {

						var processingItems = [];
						processingItems.push(oTabRows);

						if (this.validateItems(arrBillPlanConsData)) {
							// return;
						} else {
							// for (var j = 0; j < arrEngItems.length; j++) {

							// engNum = arrEngItems[j].EngNum;

							oTabRows = arrBillPlanConsData;

							if (oTabRows.length === 0) {

								if (!this.delItm || (this.delItm && this.delItm.length === 0)) {
									sap.ui.core.BusyIndicator.hide();

									sap.m.MessageBox.error(sNoSave, {
										title: sError // default
											// 			textDirection: sap.ui.core.TextDirection.Inherit // default
									});

									return;
								}

							}

							if (this.delItm && this.delItm.length > 0) {

								delItems = this.delItm;

								for (var i = 0; i < delItems.length; i++) {

									sPlanedit = delItems[i].PLANEDIT;

									var mModelData = {

										PLANEDIT: sPlanedit,
										RefreshItem: "",
										// afdat: delItems[i].afdat,
										afdat: this.formatDate(delItems[i].afdat),
										faksp: delItems[i].faksp,
										fakwr: delItems[i].fakwr,
										fksaf: delItems[i].fksaf,
										fplnr: delItems[i].fplnr,
										fpltr: delItems[i].fpltr,
										posnr: delItems[i].posnr,
										tebez: delItems[i].tebez,
										tetxt: delItems[i].tetxt,
										vbeln: this.vbeln,
										waers: delItems[i].waers,
										zterm: delItems[i].zterm,
										updkz: "D"

									};

									oDataSrv.create("/Billplan_cons", mModelData, mParameters);

								}
							}

							// Insert Items and create the payload for Post
							// oTabRows = arrBillPlanConsData;

							for (var i = 0; i < oTabRows.length; i++) {
								sPlanedit = oTabRows[i].PLANEDIT;

								var sCurrKey;

								if (oTabRows[i].waers) {
									sCurrKey = oTabRows[i].waers;
								} else {
									sCurrKey = this.sCurrKey;
								}

								var sVbeln;

								sVbeln = oTabRows[i].vbeln;

								if (sVbeln.length < 10) {
									for (var t = sVbeln.length; t < 10; t++)
										sVbeln = "0" + sVbeln;
								} else {
									sVbeln = oTabRows[i].vbeln;
								}

								var mModelDataIns = {
									PLANEDIT: sPlanedit,
									RefreshItem: "",
									// afdat: oTabRows[i].afdat,
									afdat: this.formatDate(oTabRows[i].afdat),
									faksp: oTabRows[i].faksp,
									fakwr: oTabRows[i].fakwr,
									fksaf: oTabRows[i].fksaf,
									fplnr: oTabRows[i].fplnr,
									fpltr: oTabRows[i].fpltr,
									posnr: oTabRows[i].posnr,
									tebez: oTabRows[i].tebez,
									tetxt: oTabRows[i].tetxt,
									vbeln: sVbeln,
									waers: sCurrKey,
									zterm: oTabRows[i].zterm,
									updkz: "W",
									ConBillFlag: sConBillFlag
								};

								oDataSrv.create("/Billplan_cons", mModelDataIns, mParameters);
							}

							// }

							if (oTabRows.length > 0 || delItems.length > 0) {
								oDataSrv.submitChanges({
									groupId: "batchCreate",
									success: fnSuccess,
									error: fnError
								});
							} else {
								sap.ui.core.BusyIndicator.hide();
							}

							this.count = 1;

						}

					}
				}
			}

		},

		handleBillNow: function (oEvent) {

			// //this.getView().byId("idTabBillEdit").setBusy(true);
			sap.ui.core.BusyIndicator.show(0);
			var oDataSrv = this.getView().getModel("mainSrv");
			var arrBillPlanConsData = [];
			//arrBillPlanConsData = this.getOwnerComponent().getModel("mBillPlanEdit").getProperty("/items");
			var oTextResource = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var Successmsg = oTextResource.getText("Successmsg");
			var Failuremsg = oTextResource.getText("Failuremsg");
			var sError = oTextResource.getText("Error");
			var sNoSave = oTextResource.getText("NothingBill");
			var oItemBlockTable;
			var sPlanedit;

			var oIconTabKey = this.getView().byId("idIconTabBar").getSelectedKey();
			var sConBillFlag;

			switch (oIconTabKey) {
			case "01":
				oItemBlockTable = this.getView().byId("idTabBillEdit");
				this.onRemoveBlockBillNow();
				sConBillFlag = this.getView().byId("idCBoxConBill").getSelectedKey();
				break;

			case "02":
				oItemBlockTable = this.getView().byId("idTabBillEditAll");
				sConBillFlag = "X";
				this.onRemoveBlockBillNow();
				break;
			default:
			}

			// var arrSelectedItems = oItemBlockTable.getSelectedItems();

			var mModel = this.getView().getModel("mBillPlanEdit");
			var oSelectedContext = oItemBlockTable.getSelectedContexts();

			for (var i = 0; i < oSelectedContext.length; i++) {
				arrBillPlanConsData.push(mModel.getProperty(oSelectedContext[i].getPath()));
			}

			var oTabRows = oItemBlockTable.getItems();
			// var oBindingContxt;
			// var engNum;

			var mEngModel = this.getView().getModel("mBillScheduleHeader");

			if (mEngModel) {

				var oEngModelData = mEngModel.getData();
				if (oEngModelData) {
					var arrEngItems = oEngModelData.items;

					var aDefGrp = oDataSrv.getDeferredGroups();
					aDefGrp.push("batchCreate");
					oDataSrv.setDeferredGroups(aDefGrp);

					var fnSuccess = jQuery.proxy(function (oData, oResponse) {
						var sMessage;

						if (!oResponse.data.__batchResponses[0].response) {

							if ((oData.__batchResponses[0].__changeResponses[0].data.Success) == "X") {
								sMessage = oData.__batchResponses[0].__changeResponses[0].data.Message;
								if (!sMessage) {
									sMessage = Successmsg;
								}
								//sMessage = oData.__batchResponses[0].__changeResponses[0].data.Message;
							}
							//							sMessage = Successmsg;
						} else {
							var oResponseBody = JSON.parse(oResponse.data.__batchResponses[0].response.body);
							sMessage = oResponseBody.error.message.value;
							if (!sMessage) {
								sMessage = Failuremsg;
							}
							var sErrortype = JSON.parse(oResponse.data.__batchResponses[0].response.body).error.innererror.errordetails[0].severity;
							if (sErrortype == "error") {
								sap.ui.core.BusyIndicator.hide();
								sap.m.MessageToast.show(sMessage, {
									duration: 3000, // default
									width: "15em", // default
									my: "center bottom", // default
									at: "center bottom", // default
									of: window, // default
									offset: "0 0", // default
									collision: "fit fit", // default
									onClose: null, // default
									autoClose: true, // default
									animationTimingFunction: "ease", // default
									animationDuration: 1000, // default
									closeOnBrowserNavigation: true // default
								});
								return;
							}
						}

						sap.m.MessageToast.show(sMessage, {
							duration: 10000, // default
							width: "15em", // default
							my: "center bottom", // default
							at: "center bottom", // default
							of: window, // default
							offset: "0 0", // default
							collision: "fit fit", // default
							onClose: null, // default
							autoClose: true, // default
							animationTimingFunction: "ease", // default
							animationDuration: 1000, // default
							closeOnBrowserNavigation: true // default
						});

						// this.count = 1 + this.count;
						var arrItms = [];
						this.getOwnerComponent().getModel("mBillPlanEdit").setProperty("/items", arrItms);
						this.readBillPlanCons(this.aEditFilter);
						this.delItm = [];

						//this.getView().byId("idTabBillEdit").setBusy(false);
						sap.ui.core.BusyIndicator.hide();

						if (this.hasChanges) {
							var sConBillFlag = this.getView().byId("idCBoxConBill").getSelectedKey();
							if (sConBillFlag === "X") {
								this.hasChanges = false;
								this.loadHeaderDetails();
							} else {

								this.hasChanges = false;
								this.loadHeaderDetails();
								if (this.itemChanged) {
									this.vbeln = this.LeadEngNum;
									this.loadInitialSettings();
									this.itemChanged = false;
								}

							}

						}

					}, this);
					var fnError = jQuery.proxy(function (d) {
						var message = Failuremsg;
						sap.m.MessageToast.show(message, {
							duration: 30000, // default
							width: "15em", // default
							my: "center bottom", // default
							at: "center bottom", // default
							of: window, // default
							offset: "0 0", // default
							collision: "fit fit", // default
							onClose: null, // default
							autoClose: true, // default
							animationTimingFunction: "ease", // default
							animationDuration: 1000, // default
							closeOnBrowserNavigation: true // default
						});
						sap.ui.core.BusyIndicator.hide();
					}, this);

					var mParameters = {
						groupId: "batchCreate"
					};

					var delItems = [];

					// var sDate, eDate;

					// var engNum;

					if (arrEngItems.length > 0) {

						var processingItems = [];
						processingItems.push(oTabRows);

						if (this.validateItems(arrBillPlanConsData)) {
							// return;
						} else {
							// for (var j = 0; j < arrEngItems.length; j++) {

							// engNum = arrEngItems[j].EngNum;

							oTabRows = arrBillPlanConsData;

							if (oTabRows.length === 0) {

								if (!this.delItm || (this.delItm && this.delItm.length === 0)) {
									sap.ui.core.BusyIndicator.hide();

									sap.m.MessageBox.error(sNoSave, {
										title: sError // default
											// 			textDirection: sap.ui.core.TextDirection.Inherit // default
									});

									return;
								}

							}

							if (this.delItm && this.delItm.length > 0) {

								delItems = this.delItm;

								for (var i = 0; i < delItems.length; i++) {

									sPlanedit = delItems[i].PLANEDIT;

									var mModelData = {

										PLANEDIT: sPlanedit,
										RefreshItem: "",
										// afdat: delItems[i].afdat,
										afdat: this.formatDate(delItems[i].afdat),
										faksp: delItems[i].faksp,
										fakwr: this.deformatAmount(delItems[i].fakwr),
										fksaf: delItems[i].fksaf,
										fplnr: delItems[i].fplnr,
										fpltr: delItems[i].fpltr,
										posnr: delItems[i].posnr,
										tebez: delItems[i].tebez,
										tetxt: delItems[i].tetxt,
										vbeln: this.vbeln,
										waers: delItems[i].waers,
										zterm: delItems[i].zterm,
										updkz: "D"

									};

									oDataSrv.create("/Billplan_cons", mModelData, mParameters);

								}
							}

							// Insert Items and create the payload for Post
							// oTabRows = arrBillPlanConsData;

							for (var i = 0; i < oTabRows.length; i++) {
								sPlanedit = oTabRows[i].PLANEDIT;

								var sCurrKey;

								if (oTabRows[i].waers) {
									sCurrKey = oTabRows[i].waers;
								} else {
									sCurrKey = this.sCurrKey;
								}

								var sVbeln;

								sVbeln = oTabRows[i].vbeln;

								if (sVbeln.length < 10) {
									for (var t = sVbeln.length; t < 10; t++)
										sVbeln = "0" + sVbeln;
								} else {
									sVbeln = oTabRows[i].vbeln;
								}
								var mModelDataIns = {
									PLANEDIT: sPlanedit,
									RefreshItem: "",
									// afdat: oTabRows[i].afdat,
									afdat: this.formatDate(oTabRows[i].afdat),
									faksp: oTabRows[i].faksp,
									fakwr: this.deformatAmount(oTabRows[i].fakwr),
									fksaf: oTabRows[i].fksaf,
									fplnr: oTabRows[i].fplnr,
									fpltr: oTabRows[i].fpltr,
									posnr: oTabRows[i].posnr,
									tebez: oTabRows[i].tebez,
									tetxt: oTabRows[i].tetxt,
									vbeln: sVbeln,
									waers: sCurrKey,
									zterm: oTabRows[i].zterm,
									updkz: "B",
									ConBillFlag: sConBillFlag
								};

								oDataSrv.create("/Billplan_cons", mModelDataIns, mParameters);
							}

							// }

							if (oTabRows.length > 0 || delItems.length > 0) {
								oDataSrv.submitChanges({
									groupId: "batchCreate",
									success: fnSuccess,
									error: fnError
								});
							} else {
								sap.ui.core.BusyIndicator.hide();
							}

							this.count = 1;

						}

					}
				}
			}

		},

		readAllSchedule: function () {
			var aFilter = [];

			if (this.vbeln.length < 10) {

				for (var p = this.vbeln.length; p < 10; p++) {
					this.vbeln = '0' + this.vbeln;
				}
			}

			aFilter.push(new sap.ui.model.Filter("vbeln", 'EQ', this.vbeln));

			this.aEditFilter = aFilter;
			this.readBillPlanCons(this.aEditFilter);
		},

		validateItems: function (values) {

			var items = values;

			var sDate, sItemNum, sPlnTyp, sAmnt;
			var sMandMissing = false;
			var oTextResource = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var Mandatfldsmsg = oTextResource.getText("Mandatfldsmsg");
			var Typemsg = oTextResource.getText("Typemsg");
			var sError = oTextResource.getText("Error");
			for (var i = 0; i < items.length; i++) {

				sDate = items[i].afdat;
				sItemNum = items[i].posnr;
				sPlnTyp = items[i].tetxt;
				sAmnt = items[i].fakwr;

				if (!sDate || !sItemNum || !sPlnTyp) {
					// sMandMissing = true;

					sap.m.MessageBox.error(Mandatfldsmsg, {
						title: sError // default
							// 			textDirection: sap.ui.core.TextDirection.Inherit // default
					});

					//this.getView().byId("idTabBillEdit").setBusy(false);
					sap.ui.core.BusyIndicator.hide();

					sMandMissing = true;

					return sMandMissing;

				}

				if (sPlnTyp === "Y004" || sPlnTyp === "Y009") {
					// sMandMissing = true;

					if (sAmnt === "0.00" || !sAmnt) {

						sap.m.MessageBox.error(Typemsg, {
							title: sError // default
								// 			textDirection: sap.ui.core.TextDirection.Inherit // default
						});

						//this.getView().byId("idTabBillEdit").setBusy(false);
						sap.ui.core.BusyIndicator.hide();

						sMandMissing = true;

						return sMandMissing;
					}

				}

				if (sPlnTyp === "Y003") {
					// sMandMissing = true;

					if (sAmnt > 0) {

						sap.m.MessageBox.error("For time & material payment type, amount must be zero ", {
							title: sError // default
								// 			textDirection: sap.ui.core.TextDirection.Inherit // default
						});

						//this.getView().byId("idTabBillEdit").setBusy(false);
						sap.ui.core.BusyIndicator.hide();

						sMandMissing = true;

						return sMandMissing;
					}

				}

			};

			return sMandMissing;
		},

		// updateBillBlock: function(oEvent) {

		// 	var oItem = oEvent.getSource().getParent();
		// 	var sPath = oItem.getBindingContextPath();
		// 	var oModel = this.getOwnerComponent().getModel("mainSrv");
		// 	var sOldVal = oModel.getProperty(sPath + '/faksp');
		// 	if (!this.originalVal) {
		// 		this.originalVal = sOldVal;
		// 	}

		// 	if (this.originalVal === oEvent.getParameter("newValue") || oEvent.getParameter("newValue") === "") {
		// 		oModel.setProperty(sPath + '/faksp', oEvent.getParameter("newValue"));
		// 	} else {

		// 		// oModel.setProperty(sPath + '/faksp', "");

		// 		sap.m.MessageBox.error("Please provide correct Billing Block", {
		// 			title: "Error", // default
		// 			textDirection: sap.ui.core.TextDirection.Inherit // default
		// 		});

		// 		oEvent.getSource().setValue(this.originalVal);

		// 	}
		// },

		formatDate: function (sDate) {
			// var mUserProfile = this.getOwnerComponent().getModel("mUserProfile");
			// var sDateFormat = mUserProfile.getProperty("/dateFormat");

			// var oLocale = sap.ui.getCore().getConfiguration().getLocale();

			// var oParamFormat = {
			// 	pattern: sDateFormat,
			// 	UTC: false
			// };

			// var oFormat = sap.ca.ui.model.format.DateFormat.getDateInstance(oParamFormat, oLocale);

			// var rDate = new Date(sDate.getTime() + (new Date()).getTimezoneOffset() * 60000);
			// return oFormat.format(rDate);

			var rDate;

			if ((new Date()).getTimezoneOffset() < 0) {

				rDate = new Date(sDate.getTime() - sDate.getTimezoneOffset() * 60000);
			} else {
				rDate = new Date(sDate.getTime() + sDate.getTimezoneOffset() * 60000);
			}

			return rDate;
		},

		calculateDateDiff: function (selectedDate) {

			var sDate = new Date();
			var sCurrDate = new Date(sDate.getFullYear(), sDate.getMonth(), sDate.getDate());

			if (selectedDate < sCurrDate) {
				return true;
			} else {
				return false;
			}

		},

		onItmBlkChange: function (oEvent) {

			// .getTable().getSelectedItem();
			// this._oSelectedPlanItem = oEvent.getSource().getParent().getParent();
			var oView = this.getView();
			var oDialog = oView.byId("billBlckChng");
			// create dialog lazily
			if (!oDialog) {
				// create dialog via fragment factory
				// var oCtrl = sap.ui.controller("kno.em.billsrch.germany.ext.controller.ListReportActions");
				oDialog = sap.ui.xmlfragment(oView.getId(), "kno.em.billschedule.view.changeBillBlk", this);
				// connect dialog to view (models, lifecycle)
				oView.addDependent(oDialog);
			}

			this._oSelectedBlkItem = oEvent.getSource().getParent().getParent();

			oDialog.open();

		},

		onCopyAmntSelected: function (oEvent) {
			var mVisModel = this.getOwnerComponent().getModel("mBillScheVis");
			var mVisModelData = mVisModel.getData();

			if (oEvent.getSource().getSelected()) {
				mVisModelData.CreateEnabled = false;
				this.getView().byId("inputGT").setEnabled(true);
				this.sameAmount = true;
			} else {
				mVisModelData.CreateEnabled = true;
				this.getView().byId("inputGT").setEnabled(false);
				this.sameAmount = false;
			}

			mVisModel.refresh(true);

		},

		onChangeHdrAmnt: function (oEvent) {

			var sVal = oEvent.getSource().getValue();
			try {
				var num = parseFloat(sVal.replace(/\s/g, "").replace(",", "."));
				var sAmount = num.toString();
			} catch (e) {
				sAmount = parseFloat(sVal).toFixed(2);
			}
			sAmount = this.formatAmount(sAmount);
			oEvent.getSource().setValue(sAmount);
			var sIndx = oEvent.getSource().getParent().getBindingContextPath().split("/")[2];
			var oModel = this.getView().getModel("mBillScheduleHeader").getData().items[sIndx];
			oModel.HdrAmnt = sAmount;

		},

		getSelectedItem: function (oEvent) {

			if (this.Mode === 'E') {

				var arrPlanTyp = this.getOwnerComponent().getModel("mPlanTyp").getProperty("/items");

				var sLeadIndx;

				arrPlanTyp.forEach(function (oResult, index) {
					if (oResult.plan === "Y009") {
						sLeadIndx = index;
					}
				}, this);

				this.itemChanged = true;

				var oTable = oEvent.getSource();
				var mBillScheduleHeader = this.getView().getModel("mBillScheduleHeader");
				var sProp = oTable.getSelectedItem().getBindingContextPath() + "/EngNum";

				if (this.hasChanges) {

					var oTextResource = this.getOwnerComponent().getModel("i18n").getResourceBundle();
					var Unsavedmsg = oTextResource.getText("Unsavedmsg");

					sap.m.MessageBox.show(
						Unsavedmsg, {
							icon: sap.m.MessageBox.Icon.INFORMATION,
							title: "Warning",
							actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
							onClose: jQuery.proxy(function (oAction) {

								if (oAction === sap.m.MessageBox.Action.NO) {

									var selItm = oTable.getItems()[this.selectedIndx];
									oTable.setSelectedItem(selItm);
									var sPath = oTable.getSelectedItem().getBindingContextPath();
									this.selectedIndx = sPath.split("/")[sPath.split("/").length - 1];

								}

								if (oAction === sap.m.MessageBox.Action.YES) {
									this.vbeln = this.getView().getModel("mBillScheduleHeader").getProperty(sProp);
									this.hasChanges = false;
									this.loadInitialSettings();
									this.getView().byId("idCBoxConBill").setSelectedKey(null);
									var sPath = oTable.getSelectedItem().getBindingContextPath();
									this.selectedIndx = sPath.split("/")[sPath.split("/").length - 1];
									sPath = oTable.getSelectedItem().getBindingContextPath() + "/LEADENGNUM";
									var sLeadNum = this.getView().getModel("mBillScheduleHeader").getProperty(sPath);
									var oControl = this.getView().byId("idCBoxConBill");
									if (sLeadNum) {
										oControl.setSelectedKey("X");
									} else {
										oControl.setSelectedKey(" ");
									}

									sPath = oTable.getSelectedItem().getBindingContextPath() + "/Lead";
									var isLead = this.getView().getModel("mBillScheduleHeader").getProperty(sPath);
									if (isLead === "X") {
										oControl.setEnabled(false);
									} else {
										oControl.setEnabled(true);
										if (sLeadIndx) {
											arrPlanTyp.splice(sLeadIndx);
											this.getOwnerComponent().getModel("mPlanTyp").setProperty("/items", arrPlanTyp);
											this.getOwnerComponent().getModel("mPlanTyp").refresh(true);
										}
									}

								}

							}, this)
						}
					);
				} else {

					this.vbeln = this.getView().getModel("mBillScheduleHeader").getProperty(sProp);
					this.hasChanges = false;
					this.loadInitialSettings();
					var sPath = oTable.getSelectedItem().getBindingContextPath();
					this.selectedIndx = sPath.split("/")[sPath.split("/").length - 1];
					var sPath = oTable.getSelectedItem().getBindingContextPath() + "/LEADENGNUM";
					var sLeadNum = this.getView().getModel("mBillScheduleHeader").getProperty(sPath);
					var oControl = this.getView().byId("idCBoxConBill");
					if (sLeadNum) {
						oControl.setSelectedKey("X");
					} else {
						oControl.setSelectedKey(" ");
					}

					sPath = oTable.getSelectedItem().getBindingContextPath() + "/Lead";
					var isLead = this.getView().getModel("mBillScheduleHeader").getProperty(sPath);
					if (isLead === "X") {
						oControl.setEnabled(false);
					} else {
						oControl.setEnabled(true);
						if (sLeadIndx) {
							arrPlanTyp.splice(sLeadIndx);
							this.getOwnerComponent().getModel("mPlanTyp").setProperty("/items", arrPlanTyp);
							this.getOwnerComponent().getModel("mPlanTyp").refresh(true);
						}
					}

				}

				var sPath = oTable.getSelectedItem().getBindingContextPath() + "/BILLNOWFLAG";
				var isLeadPartner = this.getView().getModel("mBillScheduleHeader").getProperty(sPath);

				if (isLeadPartner === "X") {
					this.getView().getModel("mConBillEnabled").setProperty("/Enabled", true);
				} else {
					this.getView().getModel("mConBillEnabled").setProperty("/Enabled", false);
				}

				sPath = oTable.getSelectedItem().getBindingContextPath() + "/LeadPartner";
				isLeadPartner = this.getView().getModel("mBillScheduleHeader").getProperty(sPath);
				if (isLeadPartner === "X") {
					this.getView().getModel("mConBillEnabled").setProperty("/Editable", true);
					sPath = oTable.getSelectedItem().getBindingContextPath() + "/Lead";
					var oControl = this.getView().byId("idCBoxConBill");
					if (isLead === "X") {
						oControl.setEnabled(false);
					} else {
						oControl.setEnabled(true);
					}
				} else {
					var oControl = this.getView().byId("idCBoxConBill");
					this.getView().getModel("mConBillEnabled").setProperty("/Editable", false);
					oControl.setEnabled(false);
				}

				this.getView().getModel("mConBillEnabled").refresh(true);

			}

		},

		onItemLeadSelected: function (oEvent) {
			this.vbeln = this.getView().getModel("mBillScheduleHeader").getProperty(oEvent.getSource().getParent().getBindingContextPath() +
				"/EngNum");

			if (this.Mode === 'C') {

				var arrHeaderDet = this.getView().getModel("mBillScheduleHeader").getProperty("/items");
				var j;
				for (var i = 0; i < arrHeaderDet.length; i++) {

					if (this.vbeln === arrHeaderDet[i].EngNum) {
						arrHeaderDet[i].Lead = "X";
						arrHeaderDet[i].Selected = true;
					} else {
						arrHeaderDet[i].Lead = "";
						arrHeaderDet[i].Selected = false;

					}

					this.getView().getModel("mBillScheduleHeader").setProperty("/items", arrHeaderDet);
					this.getView().getModel("mBillScheduleHeader").refresh(true);

				}

			}
		},

		deformatAmount: function (sMaount) {
			var sGrpFormat = sap.ui.getCore().getConfiguration().getFormatSettings().getCustomLocaleData()["symbols-latn-group"];
			var sDecFormat = sap.ui.getCore().getConfiguration().getFormatSettings().getCustomLocaleData()["symbols-latn-decimal"];
			var sArrAmnt = sMaount.split(sGrpFormat);
			var sArrDec = sMaount.split(sDecFormat);
			var sNewAmnt;

			if (sArrAmnt.length > 1 && sArrDec.length > 1) {
				for (var x = 0; x < sArrAmnt.length; x++) {
					if (x === 0) {
						sNewAmnt = sArrAmnt[x];
					} else {
						sNewAmnt = sNewAmnt + sArrAmnt[x];
					}
				}
			} else {
				sNewAmnt = sMaount;
			}

			var sAmntNew = sNewAmnt.split(sDecFormat);

			if (sAmntNew.length > 1) {

				var deformtAmnt = sAmntNew[0] + "." + sAmntNew[1];
				return deformtAmnt;
			} else {
				return sNewAmnt;
			}

		},

		removeDuplicates: function (arr) {

			arr.sort(function (a, b) {
				return (a.plan > b.plan) ? 1 : ((b.plan > a.plan) ? -1 : 0);
			});
			for (var i = 1; i < arr.length;) {
				if (arr[i - 1].plan == arr[i].plan) {
					arr.splice(i, 1);
				} else {
					i++;
				}
			}
			return arr;

		},

		onResetStatus: function (oEvent) {

			var mModel, arrModelData;
			var oItemBlockTable;
			this.hasChanges = true;
			var oTextResource = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var sMsgText = oTextResource.getText("ResetMsg");
			var sResetOpenMsg = oTextResource.getText("ResetOpenMsg");
			var oIconTabKey = this.getView().byId("idIconTabBar").getSelectedKey();

			switch (oIconTabKey) {
			case "01":
				oItemBlockTable = this.getView().byId("idTabBillEdit");
				break;

			case "02":
				oItemBlockTable = this.getView().byId("idTabBillEditAll");
				break;
			default:
			}

			mModel = this.getOwnerComponent().getModel("mBillPlanEdit");
			arrModelData = mModel.getProperty("/items");

			if (oItemBlockTable.getSelectedItems().length > 0) {

				var attSel = [];
				var sItmId;

				attSel = oItemBlockTable.getSelectedItems();

				var sStatus, hasCompletedItm = false,
					sPath, idx;

				for (var i = attSel.length - 1; i >= 0; i--) {

					sPath = attSel[i].getBindingContextPath();

					idx = parseInt(sPath.substring(sPath.lastIndexOf('/') + 1));

					if (arrModelData[idx].Is_Rejected != "Yes") {
						sap.m.MessageBox.information(
							sResetOpenMsg, {
								styleClass: "sapUiSizeCompact"
							}
						);
						return;
					}
					arrModelData[idx].fksaf = "A";

				}

				mModel.setProperty("/items", arrModelData);
				mModel.refresh(true);
				oItemBlockTable.removeSelections(true);

			} else {
				sap.m.MessageBox.information(
					sMsgText, {
						styleClass: "sapUiSizeCompact"
					}
				);
			}

		},

	});

});