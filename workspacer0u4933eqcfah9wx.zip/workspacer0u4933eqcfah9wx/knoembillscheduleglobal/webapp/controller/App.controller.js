sap.ui.define([
	"kno/em/billschedule/controller/BaseController",
	"sap/ui/model/json/JSONModel"
], function(BaseController, JSONModel) {
	"use strict";

	return BaseController.extend("kno.em.billschedule.controller.App", {});

});