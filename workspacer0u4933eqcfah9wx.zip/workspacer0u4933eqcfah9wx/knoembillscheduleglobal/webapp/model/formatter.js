jQuery.sap.require("sap.ui.core.format.NumberFormat");
sap.ui.define([], function () {
	"use strict";

	return {
		/**
		 * Rounds the currency value to 2 digits
		 *
		 * @public
		 * @param {string} sValue value to be formatted
		 * @returns {string} formatted currency value with 2 digits
		 */

		currencyValue: function (sValue) {
			if (!sValue) {
				return "";
			}

			return parseFloat(sValue).toFixed(2);
		},

		formatAmount: function (sAmnt) {
			
			// var mUserProfile = this.getOwnerComponent().getModel("mUserProfile");
			// var sDecFormat = mUserProfile.getProperty("/currFormat");

			var sDecFormat = sap.ui.getCore().getConfiguration().getFormatSettings().getCustomLocaleData()["symbols-latn-decimal"];
			var oNumberFormat = sap.ui.core.format.NumberFormat.getFloatInstance({
				maxFractionDigits: 2,
				groupingEnabled: true,
				groupingSeparator: sDecFormat === "," ? "." : ",",
				decimalSeparator: sDecFormat
			});

			return oNumberFormat.format(sAmnt);
		},
		formatDate: function (sDate) {

			if (sDate) {
				sDate = new Date(sDate);
				var mUserProfile = this.getOwnerComponent().getModel("mUserProfile");
				var sDateFormat = mUserProfile.getProperty("/dateFormat");

				var oLocale = sap.ui.getCore().getConfiguration().getLocale();

				var oParamFormat = {
					pattern: sDateFormat,
					UTC: false
				};

				var oFormat = sap.ca.ui.model.format.DateFormat.getDateInstance(oParamFormat, oLocale);
				var rDate;

				if ((new Date()).getTimezoneOffset() < 0) {
					rDate = new Date(sDate.getTime() - sDate.getTimezoneOffset() * 60000);
				} else {
					rDate = new Date(sDate.getTime() + sDate.getTimezoneOffset() * 60000);
				}
				return oFormat.format(rDate);

			} else {
				return sDate;

			}

			// return sDate;
		},

		formatDateItem: function (sDate) {

			if (sDate) {
				var mUserProfile = this.getOwnerComponent().getModel("mUserProfile");
				var sDateFormat = mUserProfile.getProperty("/dateFormat");

				var oLocale = sap.ui.getCore().getConfiguration().getLocale();

				var oParamFormat = {
					pattern: sDateFormat,
					UTC: false
				};

				// var oFormat = sap.ca.ui.model.format.DateFormat.getDateInstance(oParamFormat, oLocale);
				// var rDate = new Date(sDate.getTime() - (new Date()).getTimezoneOffset() * 60000);
				// return oFormat.format(sDate);

				var oFormat = sap.ca.ui.model.format.DateFormat.getDateInstance(oParamFormat, oLocale);
				var rDate;

				if ((new Date()).getTimezoneOffset() < 0) {

					rDate = new Date(sDate.getTime() - sDate.getTimezoneOffset() * 60000);
				} else {
					rDate = new Date(sDate.getTime() + sDate.getTimezoneOffset() * 60000);
				}
				return oFormat.format(rDate);

			} else {
				return sDate;
			}

			// return sDate;
		},

		formatEdit: function (sVal1, sVal2, sVal3) {

			if (sVal3 && sVal3 === "Y605") {
				return false;
			} else {
				if (sVal2 === "C") {
					return false;
				} else {
					if (sVal1) {
						return true;
					} else {
						return false;
					}
				}
			}
		},

		editValue: function (sVal2) {
			if (sVal2 === "C") {
				return false;
			} else {

				return true;

			}
		},

		editValueFakwr: function (sVal2, sval1) {
			if (sVal2 === "C") {
				return false;
			} else {
				if (sval1 === "Y003" || sval1 === "Y605") {
					return false;
				} else {
					return true;
				}

			}
		},

		editableCheck: function (sVal1, sval2) {
			if (sval2 === "Y605") {

				return false;

			} else {
				return sVal1;
			}
		},

		formatKey: function (oKey) {
			var sVal = " ";
			if (oKey) {
				sVal = oKey;
			} else {
				sVal = "NA";
			}

			return sVal;
		},

		selectedItm: function (oKey) {
			var oModel = this.getOwnerComponent().getModel("mPlanTyp");
			debugger;
		},

		formatCurr: function (sCurr) {
			var sCurrKey;
			if (!sCurr) {
				sCurrKey = this.getOwnerComponent().getModel("mCurrencyKey").getProperty("/currKey");
			} else {
				sCurrKey = sCurr;
			}
			return sCurrKey;
		},

		formatStat: function (sVal1, sVal2) {
			try {
				var oTextResource = this.getOwnerComponent().getModel("i18n").getResourceBundle();
				var sOpenStat = oTextResource.getText("OpenStat");
			} catch (e) {}
			if (sVal1) {
				if (sVal1 === "A") {
					return sOpenStat;
				} else {
					return sVal1 + "(" + sVal2 + ")";
				}
			} else {

				if (sVal2) {
					var sVal = sVal2;
				} else {
					sVal = "";
				}
				return sVal;

			}
		},

		formatItenNum: function (sVal1, sVal2) {
			var sItm;
			if (sVal1 && sVal2) {
				sItm = sVal1 + " / " + parseInt(sVal2, 10);
			} else {
				if (!sVal1 && !sVal2) {
					sItm = "";
				}
			}

			return sItm;
		},

		formatEnabled: function (sVal) {
			return !sVal;
		},

		isLead: function (sVal) {

			if (sVal === "X") {
				return true;
			} else {
				return false;
			}
		},

		showRadio: function (sVal) {
			var sMode;
			if (sVal) {
				sMode = "None";
			} else {
				sMode = "SingleSelectLeft";
			}

			return sMode;
		},

		formatPosnr: function (sVal) {
			var arrEngItems = this.getModel("mEngItms").getData().items;
			var sArktx;

			for (var i = 0; i < arrEngItems.length; i++) {
				// arrEngItems.forEach(function (oEngItem, index) {
				if (arrEngItems[i].posnr === sVal) {
					sArktx = arrEngItems[i].arktx;
					return sArktx;
					// break;
				}

				// }, this);
			}
		},

		formatTetxt: function (sVal) {
			var arrPlanTyp = this.getModel("mPlanTyp").getData().items;
			var sPlanTyp;
			arrPlanTyp.forEach(function (oPlanTyp, index) {
				if (oPlanTyp.plan === sVal) {
					sPlanTyp = oPlanTyp.planDesc;
					// break;
				}
			}, this);
			return sPlanTyp;
		}

	};

});