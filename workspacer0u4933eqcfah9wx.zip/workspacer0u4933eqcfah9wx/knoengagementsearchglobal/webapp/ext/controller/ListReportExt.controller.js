sap.ui.controller("kno.em.engsrch.germany.ext.controller.ListReportExt", {

	onBeforeRendering: function () {

		/*	this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm4button").setVisible(false);
			this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm5button").setVisible(false);
			this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm6button").setVisible(false);
			this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm8button").setVisible(false);
			this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm9button").setVisible(false);
			this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm10button").setVisible(false);
			this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm11button").setVisible(false);*/
			
			//check

		this.getView().byId(
			"kno.em.engsrch.germany::sap.suite.ui.generic.template.ListReport.view.ListReport::xknoxem_d_di_c_y_engsrch_cosm--listReport").setProperty(
			"useExportToExcel", true);

		if (this.getOwnerComponent().getProperty("appComponent").getComponentData() && this.getOwnerComponent().getProperty("appComponent").getComponentData()
			.startupParameters && jQuery.isEmptyObject(this.getOwnerComponent().getProperty("appComponent").getComponentData().startupParameters) ===
			false) {
			var sParam = this.getOwnerComponent().getProperty("appComponent").getComponentData().startupParameters.ZACTION[0];

			switch (sParam) {
			case "ZSCHEDULE":

				this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm4button").setVisible(true);
				this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm5button").setVisible(true);
				this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm6button").setVisible(true);
				this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm8button").setVisible(true);
				this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm9button").setVisible(true);
				break;

				/*// cas/*e "ZTEXT":
					this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm6button").setVisible(true);
					break;*/

			default:
			}

		}

	},
	
	

	onTableRebind: function (oControlEvent) {
		if (this.getOwnerComponent().getProperty("appComponent").getComponentData() && this.getOwnerComponent().getProperty("appComponent").getComponentData()
			.startupParameters && jQuery.isEmptyObject(this.getOwnerComponent().getProperty("appComponent").getComponentData().startupParameters) ===
			false) {
			var sParam = this.getOwnerComponent().getProperty("appComponent").getComponentData().startupParameters.ZACTION[0];
			//	var oTable = this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm1button").getParent().getParent().getTable();
			//var oContext = oTable.getBinding("items");
			var TabFilters = oControlEvent.getParameter("bindingParams").filters;
			var authFilter = [];
			var initialFilter = [];
			var aFilter = [];
			var billToPartyFilter = [];
			var shiptoCountryFilter = [];
			var currencyFilter = [];
			var salesOrgFilter = [];
			switch (sParam) {
			case "ZSCHEDULE":

				aFilter.push(new sap.ui.model.Filter("StatusCode", 'EQ', "E0006"),
					new sap.ui.model.Filter("StatusCode", 'EQ', "E0007"));
				if (this.isSplitRev) {
					billToPartyFilter.push(new sap.ui.model.Filter("BillToParty", 'EQ', this.BILLTOPARTY));
					shiptoCountryFilter.push(new sap.ui.model.Filter("ShiptoCountry", 'EQ', this.SHIPTOCOUNTRY));
					currencyFilter.push(new sap.ui.model.Filter("currency", 'EQ', this.CURRENCY));
					salesOrgFilter.push(new sap.ui.model.Filter("SalesOrg", 'EQ', this.SALESORG));
					if (TabFilters && TabFilters.length > 0) {
						if (TabFilters[0].aFilters[0].sPath) {
							var intfilter = [];

							intfilter.push(new sap.ui.model.Filter(TabFilters[0].aFilters, false));
							TabFilters[0].aFilters = intfilter;
						}
						TabFilters[0].bAnd = true;

						TabFilters[0].aFilters.push(new sap.ui.model.Filter(billToPartyFilter, false));
						TabFilters[0].aFilters.push(new sap.ui.model.Filter(shiptoCountryFilter, false));
						TabFilters[0].aFilters.push(new sap.ui.model.Filter(currencyFilter, false));
						TabFilters[0].aFilters.push(new sap.ui.model.Filter(salesOrgFilter, false));

					} else {
						initialFilter.push(new sap.ui.model.Filter(billToPartyFilter, false));
						initialFilter.push(new sap.ui.model.Filter(shiptoCountryFilter, false));
						initialFilter.push(new sap.ui.model.Filter(currencyFilter, false));
						initialFilter.push(new sap.ui.model.Filter(salesOrgFilter, false));
					}

				} else {
					this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm4button").setVisible(true);
					this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm5button").setVisible(true);
					this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm6button").setVisible(true);
					this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm8button").setVisible(true);
					this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm9button").setVisible(true);
				}
				break;

			default:
			}

			authFilter.push(new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
				new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
				new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
				new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
				new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
				new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
				new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
				new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
				new sap.ui.model.Filter("zz_opp_function", 'EQ', "XXXX"),
				new sap.ui.model.Filter("zz_opp_function", 'EQ', "XXXX"),
				new sap.ui.model.Filter("zz_opp_function", 'EQ', "XXXX"),
				new sap.ui.model.Filter("zz_opp_function", 'EQ', "XXXX"),
				new sap.ui.model.Filter("zz_opp_function", 'EQ', "XXXX"),
				new sap.ui.model.Filter("DelegUserID", 'EQ', "XXXX"),
				//	new sap.ui.model.Filter("PartDelegUserID", 'EQ', "XXXX"),
				new sap.ui.model.Filter("ZUUSRID", 'EQ', "XXXX"),
				new sap.ui.model.Filter("PartnerUId", 'EQ', "XXXX"),
				new sap.ui.model.Filter("ManagerUId", 'EQ', "XXXX"));

			if (TabFilters && TabFilters.length > 0) {

				if (TabFilters[0].aFilters[0].sPath) {
					var intfilter = [];

					intfilter.push(new sap.ui.model.Filter(TabFilters[0].aFilters, false));
					TabFilters[0].aFilters = intfilter;
				}
				if (!this.isSplitRev) {
					TabFilters[0].aFilters.push(new sap.ui.model.Filter(authFilter, false));
				}
				TabFilters[0].aFilters.push(new sap.ui.model.Filter(aFilter, false));
				TabFilters[0].bAnd = true;

			} else {
				if (!this.isSplitRev) {
					initialFilter.push(new sap.ui.model.Filter(authFilter, false));
				}
				initialFilter.push(new sap.ui.model.Filter(aFilter, false));
				TabFilters.push(new sap.ui.model.Filter(initialFilter, true));
			}

		} else if (this.getOwnerComponent().getProperty("appComponent").getComponentData()) {
			//	var oTable = this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm1button").getParent().getParent().getTable();
			// var oContext = oTable.getBinding("items");
			var TabFilters = oControlEvent.getParameter("bindingParams").filters;
			var authFilter = [];

			authFilter.push(new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
				new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
				new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
				new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
				new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
				new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
				new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
				new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
				new sap.ui.model.Filter("zz_opp_function", 'EQ', "XXXX"),
				new sap.ui.model.Filter("zz_opp_function", 'EQ', "XXXX"),
				new sap.ui.model.Filter("zz_opp_function", 'EQ', "XXXX"),
				new sap.ui.model.Filter("zz_opp_function", 'EQ', "XXXX"),
				new sap.ui.model.Filter("zz_opp_function", 'EQ', "XXXX"),
				new sap.ui.model.Filter("DelegUserID", 'EQ', "XXXX"),
				//	new sap.ui.model.Filter("PartDelegUserID", 'EQ', "XXXX"),
				new sap.ui.model.Filter("ZUUSRID", 'EQ', "XXXX"),
				new sap.ui.model.Filter("PartnerUId", 'EQ', "XXXX"),
				new sap.ui.model.Filter("ManagerUId", 'EQ', "XXXX"));

			if (TabFilters && TabFilters.length > 0) {

				if (TabFilters[0].aFilters[0].sPath) {
					var intfilter = [];

					intfilter.push(new sap.ui.model.Filter(TabFilters[0].aFilters, false));
					TabFilters[0].aFilters = intfilter;
				}

				TabFilters[0].aFilters.push(new sap.ui.model.Filter(authFilter, false));
				//	TabFilters[0].aFilters.push(new sap.ui.model.Filter(aFilter, false));
				TabFilters[0].bAnd = true;

			} else {
				var initialFilter = [];
				initialFilter.push(new sap.ui.model.Filter(authFilter, false));
				//	initialFilter.push(new sap.ui.model.Filter(aFilter, false));
				TabFilters.push(new sap.ui.model.Filter(initialFilter, true));
			}
			//	oContext.filter(aFilter, sap.ui.model.FilterType.Application);

		}

	},

	onBatchComplete: function (oResponse) {
		if (this.getOwnerComponent().getProperty("appComponent").getComponentData() && this.getOwnerComponent().getProperty("appComponent").getComponentData()
			.startupParameters && jQuery.isEmptyObject(this.getOwnerComponent().getProperty("appComponent").getComponentData().startupParameters) ===
			false) {
			var sParam = this.getOwnerComponent().getProperty("appComponent").getComponentData().startupParameters.ZACTION[0];
			var oTable = this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm1button").getParent().getParent().getTable();
			var oContext = oTable.getBinding("items");
			var aFilter = [];
			switch (sParam) {
			case "ZSCHEDULE":

				aFilter.push(new sap.ui.model.Filter("StatusCode", 'EQ', "E0006"),
					new sap.ui.model.Filter("StatusCode", 'EQ', "E0007"));
				if (this.isSplitRev) {
					aFilter.push(new sap.ui.model.Filter("BillToParty", 'EQ', this.BILLTOPARTY));
					aFilter.push(new sap.ui.model.Filter("ShiptoCountry", 'EQ', this.SHIPTOCOUNTRY));
					aFilter.push(new sap.ui.model.Filter("currency", 'EQ', this.CURRENCY));
					aFilter.push(new sap.ui.model.Filter("SalesOrg", 'EQ', this.SALESORG));
				}
				this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm4button").setVisible(true);
				this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm5button").setVisible(true);
				this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm6button").setVisible(true);
				this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm8button").setVisible(true);
				this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm9button").setVisible(true);

				break;

			default:
			}

			if (oContext.aApplicationFilters && oContext.aApplicationFilters.length > 0) {
				for (var j = 0; j < oContext.aApplicationFilters.length; j++) {
					if (oContext.aApplicationFilters[j].aFilters && oContext.aApplicationFilters[j].aFilters.length > 0) {
						for (var i = 0; i < oContext.aApplicationFilters[j].aFilters.length; i++) {
							if (oContext.aApplicationFilters[j].aFilters[i].aFilters && oContext.aApplicationFilters[j].aFilters[i].aFilters.length > 0) {
								for (var k = 0; k < oContext.aApplicationFilters[j].aFilters[i].aFilters.length; k++) {
									aFilter.push(oContext.aApplicationFilters[j].aFilters[i].aFilters[k]);
								}
							} else {
								aFilter.push(oContext.aApplicationFilters[j].aFilters[i]);
							}
						}
					}
				}
			}

			aFilter.push(new sap.ui.model.Filter({
				filters: [
					// new sap.ui.model.Filter("EngManager", 'EQ', "XXXX"),
					// new sap.ui.model.Filter("EngPartner", 'EQ', "XXXX"),
					new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
					new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
					new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
					new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
					new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
					new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
					new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
					new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
					new sap.ui.model.Filter("zz_opp_function", 'EQ', "XXXX"),
					new sap.ui.model.Filter("zz_opp_function", 'EQ', "XXXX"),
					new sap.ui.model.Filter("zz_opp_function", 'EQ', "XXXX"),
					new sap.ui.model.Filter("zz_opp_function", 'EQ', "XXXX"),
					new sap.ui.model.Filter("zz_opp_function", 'EQ', "XXXX"),
					new sap.ui.model.Filter("DelegUserID", 'EQ', "XXXX"),
					//	new sap.ui.model.Filter("PartDelegUserID", 'EQ', "XXXX"),
					new sap.ui.model.Filter("ZUUSRID", 'EQ', "XXXX"),
					new sap.ui.model.Filter("PartnerUId", 'EQ', "XXXX"),
					new sap.ui.model.Filter("ManagerUId", 'EQ', "XXXX")
				],
				and: false
			}));

			oContext.filter(aFilter, sap.ui.model.FilterType.Application);

		} else if (this.getOwnerComponent().getProperty("appComponent").getComponentData()) {
			var oTable = this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm1button").getParent().getParent().getTable();
			var oContext = oTable.getBinding("items");
			var aFilter = [];
			if (oContext.aApplicationFilters && oContext.aApplicationFilters.length > 0) {
				for (var j = 0; j < oContext.aApplicationFilters.length; j++) {
					if (oContext.aApplicationFilters[j].aFilters && oContext.aApplicationFilters[j].aFilters.length > 0) {
						for (var i = 0; i < oContext.aApplicationFilters[j].aFilters.length; i++) {
							if (oContext.aApplicationFilters[j].aFilters[i].aFilters && oContext.aApplicationFilters[j].aFilters[i].aFilters.length > 0) {
								for (var k = 0; k < oContext.aApplicationFilters[j].aFilters[i].aFilters.length; k++) {
									aFilter.push(oContext.aApplicationFilters[j].aFilters[i].aFilters[k]);
								}
							}
						}
					}
				}
			}

			aFilter.push(new sap.ui.model.Filter({
				filters: [
					// new sap.ui.model.Filter("EngManager", 'EQ', "XXXX"),
					// new sap.ui.model.Filter("EngPartner", 'EQ', "XXXX"),
					new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
					new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
					new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
					new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
					new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
					new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
					new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
					new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
					new sap.ui.model.Filter("zz_opp_function", 'EQ', "XXXX"),
					new sap.ui.model.Filter("zz_opp_function", 'EQ', "XXXX"),
					new sap.ui.model.Filter("zz_opp_function", 'EQ', "XXXX"),
					new sap.ui.model.Filter("zz_opp_function", 'EQ', "XXXX"),
					new sap.ui.model.Filter("zz_opp_function", 'EQ', "XXXX"),
					new sap.ui.model.Filter("DelegUserID", 'EQ', "XXXX"),
					//	new sap.ui.model.Filter("PartDelegUserID", 'EQ', "XXXX"),
					new sap.ui.model.Filter("ZUUSRID", 'EQ', "XXXX"),
					new sap.ui.model.Filter("PartnerUId", 'EQ', "XXXX"),
					new sap.ui.model.Filter("ManagerUId", 'EQ', "XXXX")
				],
				and: false
			}));

			oContext.filter(aFilter, sap.ui.model.FilterType.Application);

		}

	},
	onAfterRendering: function () {

		//	this.getView().getModel().attachEventOnce("batchRequestSent", this.onBatchComplete, this); //By PP

		if (this.getOwnerComponent().getProperty("appComponent").getComponentData() && this.getOwnerComponent().getProperty("appComponent").getComponentData()
			.startupParameters && jQuery.isEmptyObject(this.getOwnerComponent().getProperty("appComponent").getComponentData().startupParameters) ===
			false) {
			var sParam = this.getOwnerComponent().getProperty("appComponent").getComponentData().startupParameters.ZACTION[0];

		}
		var oList = this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm1button").getParent().getParent();

		var oGoButtonid = $("button[id*='btnGo']")[0].id;

		var oGoButton = this.getView().byId(oGoButtonid);
		var oTable;
		oGoButton.addEventDelegate({
			ontap: function () {
				if (!this.isSplitRev) {
					var oDelFavBtn = this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm3button");
					if (oDelFavBtn) {
						oDelFavBtn.setVisible(false);
					}

					var oDelFavBtn = this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm1button");
					if (oDelFavBtn) {
						oDelFavBtn.setVisible(true);
					}

					var oDelFavBtn = this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm2button");
					if (oDelFavBtn) {
						oDelFavBtn.setVisible(true);
					}

					oTable = oDelFavBtn.getParent().getParent().getTable();
					if (oTable.getBinding("items")) {
						oTable.getBinding("items").createFilterParams("");
						oTable.getBinding("items").aFilters = [];
						oTable.getBinding("items").sFilterParams = "";
					}

					if (sParam === "ZSCHEDULE") {
						//	this.getView().getModel().attachEventOnce("batchRequestSent", this.onBatchComplete, this); //By PP
						oTable.setMode("SingleSelectLeft");
						var oButton = this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm10button");
						oButton.setVisible(true);
						//			this.isSplitRev = false;
					}
				}
			}
		}, this);

		var oSearchButtonid = $("button[id*='Share']");
		if (oSearchButtonid[0] && oSearchButtonid[0].id) {
			this.getView().byId(oSearchButtonid[0].id).setVisible(false);
		}

		var that = this;

		var oMySmartFilterTab = this.getView().byId("listReport");
		that = this;
		//Adding css dynamically 
		if(oMySmartFilterTab){
			
				oMySmartFilterTab.getParent().addStyleClass("knoEngagementearchGlobal");
				//oMySmartFilterTab.addStyleClass("knoEngagementearchGlobalReport");
			
		}
		oMySmartFilterTab.attachEvent("beforeRebindTable", that.onTableRebind, that);

		$(document).keyup(function (e) {
			if (e.keyCode === 13) {
				if (sParam === "ZSCHEDULE") {
					//	that.getView().getModel().attachEventOnce("batchRequestSent", that.onBatchComplete, that); //By PP
					oTable.setMode("SingleSelectLeft");
					var oButton = that.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm10button");
					oButton.setVisible(true);
					//			this.isSplitRev = false;
				}
			}
		});

		if (sParam === "ZSCHEDULE") {

			if (!oTable) {
				oTable = this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm1button").getParent().getParent().getTable();
			}
			oTable.setMode("SingleSelectLeft");
			var oButton = this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm10button");
			oButton.setVisible(true);
			//		this.isSplitRev = false;

		}

		var sBtnBasicSearchId =
			"kno.em.engsrch.germany::sap.suite.ui.generic.template.ListReport.view.ListReport::xknoxem_d_di_c_y_engsrch_cosm--listReportFilter-btnBasicSearch";
		var oBtnBasicSearch = this.getView().byId(sBtnBasicSearchId);
		if (oBtnBasicSearch) {
			oBtnBasicSearch.addEventDelegate({
				ontap: function () {
					var oDelFavBtn = this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm3button");
					if (oDelFavBtn) {
						oDelFavBtn.setVisible(false);
					}

					var oDelFavBtn = this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm1button");
					if (oDelFavBtn) {
						oDelFavBtn.setVisible(true);
					}

					var oDelFavBtn = this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm2button");
					if (oDelFavBtn) {
						oDelFavBtn.setVisible(true);
					}

					oTable = oDelFavBtn.getParent().getParent().getTable();
					if (oTable.getBinding("items")) {
						oTable.getBinding("items").createFilterParams("");
						oTable.getBinding("items").aFilters = [];
						oTable.getBinding("items").sFilterParams = "";
					}

					if (sParam === "ZSCHEDULE") {
						//		this.getView().getModel().attachEventOnce("batchRequestSent", this.onBatchComplete, this); //By PP
						oTable.setMode("SingleSelectLeft");
						var oButton = this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm10button");
						oButton.setVisible(true);
						this.isSplitRev = false;
					}
				}
			}, this);

		}
	},

	onClickActionxknoxem_d_di_c_y_engsrch_cosm1: function (oEvent) {

		var oDelFavBtn = this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm3button");
		if (oDelFavBtn) {
			oDelFavBtn.setVisible(true);
		}

		// var oTable = oEvent.getSource().getParent().getParent().getTable();
		var oTable = oEvent.getSource().getParent().getParent();
		var oFilter = new sap.ui.model.Filter({
			filters: [new sap.ui.model.Filter("FAV", sap.ui.model.FilterOperator.EQ, "X")]
		});

		//	oTable.removeAllItems();
		// Invoke standard method to bind the list.
		oTable.getParent().rebindTable();
		oTable.getBinding("items").createFilterParams("");
		oTable.getBinding("items").aFilters = [];
		oTable.getBinding("items").sFilterParams = "";
		oTable.getBinding("items").aApplicationFilters = [];
		oTable.getBinding("items").filter([oFilter]);

		var oDelFavBtn = this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm1button");
		if (oDelFavBtn) {
			oDelFavBtn.setVisible(false);
		}

		var oDelFavBtn = this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm2button");
		if (oDelFavBtn) {
			oDelFavBtn.setVisible(false);
		}

		// Clear Filter after Favorite

		// this.getView().getModel().refresh(true);

	},
	onClickActionxknoxem_d_di_c_y_engsrch_cosm2: function (oEvent) {
		// var oSelectedItems = oEvent.getSource().getParent().getParent().getTable().getSelectedItems();
		var oSelectedItems = oEvent.getSource().getParent().getParent().getSelectedItems();
		var oBindingContext;
		var sVbeln = " ";
		var oDataModl;
		var arrVbeln = [];
		var sMessages;
		var oTextResource = this.getView().getModel("i18n").getResourceBundle();
		var sSuccMessage = oTextResource.getText("FAVSUCC");
		for (var sCount = 0; sCount < oSelectedItems.length; sCount++) {
			oBindingContext = new sap.ui.model.Context(oSelectedItems[sCount].getModel(), oSelectedItems[sCount].getBindingContext().getPath());
			// sVbeln = oBindingContext.getProperty("EngNum");

			sVbeln = sVbeln + "|" + oBindingContext.getProperty("EngNum");
			arrVbeln.push(oBindingContext.getProperty("EngNum"));

		}

		// var that = oEvent.getSource().getParent().getParent().getTable();
		var that = oEvent.getSource().getParent().getParent();
		

		var fnSuccess = jQuery.proxy(function (oData, response) {

			var arrVbelnAdded = [];
			var arrVbelnNotAdded = [];
			var sVbelnNotAdded;
			if (oData.results && oData.results.length > 0 && oData.results.length === arrVbeln.length) {
				sMessages = sSuccMessage;
			} else {
				for (var sCountRes = 0; sCountRes < oData.results.length; sCountRes++) {
					arrVbelnAdded.push(oData.results[sCountRes].vbeln);
				}
				// var arrVbelnNotAdded = arrVbeln.filter(function (n) {
				// 	return !this.has(n);
				// }, new Set(arrVbelnAdded);

				for (var i = 0; i < arrVbelnNotAdded.length; i++) {
					if (i === 0) {
						sVbelnNotAdded = arrVbelnNotAdded[i];
					} else {
						sVbelnNotAdded = sVbelnNotAdded + "," + arrVbelnNotAdded[i];
					}
				}

				sMessages = "Engagement(s)" + " " + sVbelnNotAdded + " " + "already added to favorites";
			}
			sap.m.MessageToast.show(sMessages, {
				duration: 5000, // default
				width: "15em", // default
				my: "center bottom",
				at: "center bottom",
				of: window, // default
				offset: "0 0", // default
				collision: "fit fit", // default
				autoClose: true, // default
				animationTimingFunction: "ease", // default
				animationDuration: 1000, // default
				closeOnBrowserNavigation: true // default
			});

			this.removeSelections();
		}, that);

		oDataModl = this.getOwnerComponent().getModel();
		oDataModl.callFunction('/maintFav', {
			urlParameters: {
				ACTION: "MODI",
				VBELN: sVbeln

			},
			method: "GET",
			success: fnSuccess
		});
	},
	onClickActionxknoxem_d_di_c_y_engsrch_cosm3: function (oEvent) {

		var oDelFavBtn = this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm1button");
		if (oDelFavBtn) {
			oDelFavBtn.setVisible(false);
		}

		var oDelFavBtn = this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm2button");
		if (oDelFavBtn) {
			oDelFavBtn.setVisible(false);
		}

		// var oSelectedItems = oEvent.getSource().getParent().getParent().getTable().getSelectedItems();
		var oSelectedItems = oEvent.getSource().getParent().getParent().getSelectedItems();
		
		var oBindingContext;
		var sVbeln = " ";
		var oDataModl;
		var oTextResource = this.getView().getModel("i18n").getResourceBundle();
		var sDelMessage = oTextResource.getText("FAVDEL");
		for (var sCount = 0; sCount < oSelectedItems.length; sCount++) {
			oBindingContext = new sap.ui.model.Context(oSelectedItems[sCount].getModel(), oSelectedItems[sCount].getBindingContext().getPath());
			// sVbeln = oBindingContext.getProperty("EngNum");

			sVbeln = sVbeln + "|" + oBindingContext.getProperty("EngNum");

		}

		// var that = oEvent.getSource().getParent().getParent().getTable();
		var that = oEvent.getSource().getParent().getParent();

		var fnSuccess = jQuery.proxy(function (oData, response) {

			if (oData.results && oData.results.length > 0) {
				var sMessage = sDelMessage;
				sap.m.MessageToast.show(sMessage, {
					duration: 5000, // default
					width: "15em", // default
					my: "center bottom",
					at: "center bottom",
					of: window, // default
					offset: "0 0", // default
					collision: "fit fit", // default
					autoClose: true, // default
					animationTimingFunction: "ease", // default
					animationDuration: 1000, // default
					closeOnBrowserNavigation: true // default
				});
			}

			this.removeSelections();

			// var selectedItems = this.getSelectedItems();

			// for (var sCount = 0; sCount < oSelectedItems.length; sCount++) {
			// 	this.removeItem(oSelectedItems[sCount]);
			// }

			var oTable = this;
			var oFilter = new sap.ui.model.Filter({
				filters: [new sap.ui.model.Filter("FAV", sap.ui.model.FilterOperator.EQ, "X")]
			});

			//	oTable.removeAllItems();
			// Invoke standard method to bind the list.
			oTable.getParent().rebindTable();
			oTable.getBinding("items").createFilterParams("");
			oTable.getBinding("items").aFilters = [];
			oTable.getBinding("items").sFilterParams = "";
			oTable.getBinding("items").aApplicationFilters = [];
			oTable.getBinding("items").filter([oFilter]);

		}, that);

		oDataModl = this.getOwnerComponent().getModel();
		oDataModl.callFunction('/maintFav', {
			urlParameters: {
				ACTION: "DELE",
				VBELN: sVbeln
			},
			method: "GET",
			success: fnSuccess
		});

	},
	// onClickActionxknoxem_d_di_c_y_engsrch_cosm4: function(oEvent) {

	// 	var oSelectedItems = this.oSelectedItems = oEvent.getSource().getParent().getParent().getTable().getSelectedItems();
	// 	// var oBindingContext;
	// 	// var sVbeln = " ";
	// 	// var oDataModl, fnSuccess;

	// 	// for (var sCount = 0; sCount < oSelectedItems.length; sCount++) {
	// 	// 	oBindingContext = new sap.ui.model.Context(oSelectedItems[sCount].getModel(), oSelectedItems[sCount].getBindingContext().getPath());
	// 	// 	// sVbeln = oBindingContext.getProperty("EngNum");

	// 	// 	sVbeln = sVbeln + "|" + oBindingContext.getProperty("EngNum");

	// 	// }

	// 	// var fnSuccess = jQuery.proxy(function(oData, response) {

	// 	// 	if (oData.results && oData.results.length > 0) {

	// 	// 	} else {
	// 	var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service

	// 	var arrParams = [];

	// 	// var oSelectedItems = this.oSelectedItems;
	// 	var oBindingContext;
	// 	var arrVbeln = [];
	// 	var arrClient = [];
	// 	var arrEngDesc = [];
	// 	var arrEngSta = [];
	// 	var arrProfitCenter = [];
	// 	var oDataModl;

	// 	for (var sCount = 0; sCount < oSelectedItems.length; sCount++) {
	// 		oBindingContext = new sap.ui.model.Context(oSelectedItems[sCount].getModel(), oSelectedItems[sCount].getBindingContext().getPath());
	// 		// sVbeln = oBindingContext.getProperty("EngNum");

	// 		arrVbeln.push(oBindingContext.getProperty("EngNum"));
	// 		arrClient.push(oBindingContext.getProperty("Client"));
	// 		arrEngDesc.push(oBindingContext.getProperty("EngDesc"));
	// 		arrProfitCenter.push(oBindingContext.getProperty("ProfitCenter"));
	// 		arrEngSta.push(oBindingContext.getProperty("EngSta"));

	// 	}

	// 	var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
	// 		target: {
	// 			semanticObject: "ZBillSchedule",
	// 			action: "zmanage"
	// 		},
	// 		params: {
	// 			EngNum: arrVbeln,
	// 			Client: arrClient,
	// 			EngDesc: arrEngDesc,
	// 			ProfitCenter: arrProfitCenter,
	// 			EngSta: arrEngSta,
	// 			Mode: "CREA"

	// 		}

	// 	}));

	// 	oCrossAppNavigator.toExternal({
	// 		target: {
	// 			shellHash: hash
	// 		}
	// 	});

	// 	// 	}

	// 	// }, this);

	// 	// var oDataModl = this.getOwnerComponent().getModel();
	// 	// oDataModl.callFunction('/engValidate', {
	// 	// 	urlParameters: {
	// 	// 		ACTION: "C",
	// 	// 		VBELN: sVbeln
	// 	// 	},
	// 	// 	method: "GET",
	// 	// 	success: fnSuccess
	// 	// });

	// },

	onClickActionxknoxem_d_di_c_y_engsrch_cosm4: function (oEvent) {

		var oSelectedItems = this.oSelectedItems = oEvent.getSource().getParent().getParent().getSelectedItems();
		var oBindingContext;
		var sVbeln = " ";
		var oDataModl, fnSuccess;
		var sOrder;

		for (var sCount = 0; sCount < oSelectedItems.length; sCount++) {
			oBindingContext = new sap.ui.model.Context(oSelectedItems[sCount].getModel(), oSelectedItems[sCount].getBindingContext().getPath());
			// sVbeln = oBindingContext.getProperty("EngNum");

			sOrder = oBindingContext.getProperty("EngNum");

			if (sOrder.length < 10) {

				for (var i = sOrder.length; i < 10; i++) {

					sOrder = '0' + sOrder;
				}
			}

			sVbeln = sVbeln + "|" + sOrder;

		}

		this.oButton = oEvent.getSource();

		fnSuccess = jQuery.proxy(function (oData, response) {

			var arrMessages = [];
			var iCounter;
			var oControl = this.oButton;

			if (oData.results && oData.results.length > 0) {
				for (var i = 0; i < oData.results.length; i++) {

					if (oData.results[i].MESSAGE) {

						var mMessageModel = {
							type: 'Error',
							title: oData.results[i].MESSAGE,
							// description: oData.results[i].MESSAGE,
							subtitle: 'Error Details',
							counter: iCounter
						};

						arrMessages.push(mMessageModel);
					}
				}

				if (arrMessages.length > 0) {
					this.openUpDownPopover(arrMessages);
					if (this.oMessagePopover) {
						this.oMessagePopover.openBy(oControl);
					}
					// return;
				} else {

					var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service

					var arrParams = [];

					// var oSelectedItems = this.oSelectedItems;
					var oBindingContext;
					var arrVbeln = [];
					var arrClient = [];
					var arrEngDesc = [];
					var arrEngSta = [];
					var arrProfitCenter = [];
					var oDataModl;

					for (var sCount = 0; sCount < oSelectedItems.length; sCount++) {
						oBindingContext = new sap.ui.model.Context(oSelectedItems[sCount].getModel(), oSelectedItems[sCount].getBindingContext().getPath());
						// sVbeln = oBindingContext.getProperty("EngNum");

						arrVbeln.push(oBindingContext.getProperty("EngNum"));
						arrClient.push(oBindingContext.getProperty("Client"));
						arrEngDesc.push(oBindingContext.getProperty("EngDesc"));
						arrProfitCenter.push(oBindingContext.getProperty("ProfitCenter"));
						arrEngSta.push(oBindingContext.getProperty("EngSta"));

					}

					if (!this.EngNum) {
						var oTable = this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm4button").getParent().getParent().getTable();
						var oSelectedItem = oTable.getSelectedItem();
						var oBindingContext = new sap.ui.model.Context(oSelectedItem.getModel(), oSelectedItem.getBindingContext().getPath());
						this.EngNum = oBindingContext.getProperty("EngNum");
					}

					var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
						target: {
							semanticObject: "ZBillSchedule",
							action: "zmanage"
						},
						params: {
							EngNum: arrVbeln,
							Client: arrClient,
							EngDesc: arrEngDesc,
							LeadNum: this.EngNum,
							ProfitCenter: arrProfitCenter,
							EngSta: arrEngSta,
							Mode: "CREA"

						}

					}));

					oCrossAppNavigator.toExternal({
						target: {
							shellHash: hash
						}
					});

				}

			}

		}, this);

		if (!this.EngNum) {

			this.EngNum = sVbeln;
		}
		var oDataModl = this.getOwnerComponent().getModel();
		oDataModl.callFunction('/engValidation', {
			urlParameters: {
				ACTION: "C",
				VBELN: sVbeln,
				LEADENG: this.EngNum
			},
			method: "GET",
			success: fnSuccess
		});

	},
	onClickActionxknoxem_d_di_c_y_engsrch_cosm5: function (oEvent) {

		//var oSelectedItems = this.oSelectedItems = oEvent.getSource().getParent().getParent().getTable().getSelectedItems();
		var oSelectedItems = this.oSelectedItems = oEvent.getSource().getParent().getParent().getSelectedItems();
		var oBindingContext;
		var sVbeln = " ";
		var oDataModl, fnSuccess;
		var sOrder;

		for (var sCount = 0; sCount < oSelectedItems.length; sCount++) {
			oBindingContext = new sap.ui.model.Context(oSelectedItems[sCount].getModel(), oSelectedItems[sCount].getBindingContext().getPath());
			// sVbeln = oBindingContext.getProperty("EngNum");

			sOrder = oBindingContext.getProperty("EngNum");

			if (sOrder.length < 10) {

				for (var i = sOrder.length; i < 10; i++) {

					sOrder = '0' + sOrder;
				}
			}

			sVbeln = sVbeln + "|" + sOrder;

		}

		this.oButton = oEvent.getSource();

		fnSuccess = jQuery.proxy(function (oData, response) {

			var arrMessages = [];
			var iCounter;
			var oControl = this.oButton;

			if (oData.results && oData.results.length > 0) {
				for (var i = 0; i < oData.results.length; i++) {

					if (oData.results[i].MESSAGE) {
						var mMessageModel = {
							type: 'Error',
							title: oData.results[i].MESSAGE,
							// description: oData.results[i].MESSAGE,
							subtitle: 'Error Details',
							counter: iCounter
						};

						arrMessages.push(mMessageModel);
					}

				}

				if (arrMessages.length > 0) {
					this.openUpDownPopover(arrMessages);
					if (this.oMessagePopover) {
						this.oMessagePopover.openBy(oControl);
					}
					// return;
				} else {
					var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service

					var arrParams = [];

					// var oSelectedItems = this.oSelectedItems;
					var oBindingContext;
					var arrVbeln = [];
					var arrClient = [];
					var arrEngDesc = [];
					var arrEngSta = [];
					var arrProfitCenter = [];
					var oDataModl;

					for (var sCount = 0; sCount < oSelectedItems.length; sCount++) {
						oBindingContext = new sap.ui.model.Context(oSelectedItems[sCount].getModel(), oSelectedItems[sCount].getBindingContext().getPath());
						// sVbeln = oBindingContext.getProperty("EngNum");

						arrVbeln.push(oBindingContext.getProperty("EngNum"));
						arrClient.push(oBindingContext.getProperty("Client"));
						arrEngDesc.push(oBindingContext.getProperty("EngDesc"));
						arrProfitCenter.push(oBindingContext.getProperty("ProfitCenter"));
						arrEngSta.push(oBindingContext.getProperty("EngSta"));

					}

					var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
						target: {
							semanticObject: "ZBillSchedule",
							action: "zmanage"
						},
						params: {
							EngNum: arrVbeln,
							Client: arrClient,
							EngDesc: arrEngDesc,
							ProfitCenter: arrProfitCenter,
							EngSta: arrEngSta,
							Mode: "EDIT"

						}

					}));

					oCrossAppNavigator.toExternal({
						target: {
							shellHash: hash
						}
					});

				}

			}

		}, this);

		var oDataModl = this.getOwnerComponent().getModel();
		oDataModl.callFunction('/engValidation', {
			urlParameters: {
				ACTION: "U",
				VBELN: sVbeln,
				LEADENG: sVbeln
			},
			method: "GET",
			success: fnSuccess
		});

		// var eventBus = sap.ui.getCore().getEventBus();

		// eventBus.publish("nav", "to", {

		// 	id: "Detail",

		// 	data: {

		// 	}

		// });

		// var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service

		// var arrParams = [];

		// var oSelectedItems = oEvent.getSource().getParent().getParent().getTable().getSelectedItems();
		// var oBindingContext;
		// var arrVbeln = [];
		// var arrClient = [];
		// var arrEngDesc = [];
		// var arrEngSta = [];
		// var arrProfitCenter = [];
		// var oDataModl;

		// for (var sCount = 0; sCount < oSelectedItems.length; sCount++) {
		// 	oBindingContext = new sap.ui.model.Context(oSelectedItems[sCount].getModel(), oSelectedItems[sCount].getBindingContext().getPath());
		// 	// sVbeln = oBindingContext.getProperty("EngNum");

		// 	arrVbeln.push(oBindingContext.getProperty("EngNum"));
		// 	arrClient.push(oBindingContext.getProperty("Client"));
		// 	arrEngDesc.push(oBindingContext.getProperty("EngDesc"));
		// 	arrProfitCenter.push(oBindingContext.getProperty("ProfitCenter"));
		// 	arrEngSta.push(oBindingContext.getProperty("EngSta"));

		// }

		// var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
		// 	target: {
		// 		semanticObject: "ZBillSchedule",
		// 		action: "zmanage"
		// 	},
		// 	params: {
		// 		EngNum: arrVbeln,
		// 		Client: arrClient,
		// 		EngDesc: arrEngDesc,
		// 		ProfitCenter: arrProfitCenter,
		// 		EngSta: arrEngSta,
		// 		Mode: "EDIT"

		// 	}

		// }));

		// oCrossAppNavigator.toExternal({
		// 	target: {
		// 		shellHash: hash
		// 	}
		// });

	},
	openUpDownPopover: function (arrMsg) {
		if (!this.oMessageTemplate) {
			this.oMessageTemplate = new sap.m.MessagePopoverItem({
				type: '{type}',
				title: '{title}',
				description: '{description}',
				subtitle: '{subtitle}',
				counter: '{counter}'

			});
		}

		if (!this.oMessagePopover) {
			this.oMessagePopover = new sap.m.MessagePopover({
				items: {
					path: '/',
					template: this.oMessageTemplate
				}
			});
		}

		var oModel = new sap.ui.model.json.JSONModel();
		oModel.setData(arrMsg);

		// var viewModel = new sap.ui.model.json.JSONModel();
		// viewModel.setData({
		// 	messagesLength: arrMsg.length + ''
		// });

		// this.getView().setModel(viewModel);

		this.oMessagePopover.setModel(oModel);

	},
	onClickActionxknoxem_d_di_c_y_engsrch_cosm6: function (oEvent) {
		// var oSelectedItems = oEvent.getSource().getParent().getParent().getTable().getSelectedItems();
		var oSelectedItems = oEvent.getSource().getParent().getParent().getSelectedItems();
		var oTextResource = this.getView().getModel("i18n").getResourceBundle();
		var sErrTxt = oTextResource.getText("TXT1");
		var iCounter;
		var arrMessages = [];
		this.oButton = oEvent.getSource();
		var oControl = this.oButton;
		if (oSelectedItems.length > 1) {
			var mMessageModel = {
				type: 'Error',
				title: sErrTxt,
				subtitle: 'Error Details',
				counter: iCounter
			};
			arrMessages.push(mMessageModel);
			this.openUpDownPopover(arrMessages);
			if (this.oMessagePopover) {
				this.oMessagePopover.openBy(oControl);
			}
			return;
		} else {
			var oBindingContext = new sap.ui.model.Context(oSelectedItems[0].getModel(), oSelectedItems[0].getBindingContext().getPath());
			var sVbeln = oBindingContext.getProperty("EngNum");
			var fnSuccess = jQuery.proxy(function (oData, response) {
					if (oData.SUCCESS) {
						/*	if (sCancelbillno) {
								this.displayErrorMessage(sErrTxt);
							} else {*/
						if (sVbeln !== '') {

							var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service

							var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
								target: {
									semanticObject: "ZTextMaintain",
									action: "zmanage"
								},
								// params: {
								// 	DocId: oData.VBELN,
								// 	DocType: oData.DocType,
								// 	Client: oData.Cname,
								// 	Partner: oData.Ename,
								// 	Demo: oData.DemoDm,
								// 	ParamDisp: oData.ParamDisp
								// }

							}));
							var sStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
							//to add data in the storage 
							sStorage.put("TextKey", oData);

							oCrossAppNavigator.toExternal({
								target: {
									shellHash: hash
								}
							});
						} else {
							mMessageModel = {
								type: 'Error',
								title: oData.MESSAGE,
								subtitle: 'Error Details',
								counter: iCounter
							};
							arrMessages.push(mMessageModel);
							this.openUpDownPopover(arrMessages);
							if (this.oMessagePopover) {
								this.oMessagePopover.openBy(oControl);
							}
							//this.displayErrorMessage(sErrVal);
						}
						// }
					} else {
						mMessageModel = {
							type: 'Error',
							title: oData.MESSAGE,
							subtitle: 'Error Details',
							counter: iCounter
						};
						arrMessages.push(mMessageModel);
						this.openUpDownPopover(arrMessages);
						if (this.oMessagePopover) {
							this.oMessagePopover.openBy(oControl);
						}
						//this.displayErrorMessage(oData.MESSAGE);
					}
				},
				this);
			var oDataModl = this.getOwnerComponent().getModel();
			if (sVbeln.length < 10) {

				for (var i = sVbeln.length; i < 10; i++) {

					sVbeln = '0' + sVbeln;
				}
			}
			oDataModl.callFunction('/fnTextMaint', {
				urlParameters: {
					ACTION: "CRET",
					VBELN: sVbeln
				},
				method: "GET",
				success: fnSuccess
			});
		}
	},
	onClickActionxknoxem_d_di_c_y_engsrch_cosm7: function (oEvent) {

		var oList = oEvent.getSource().getParent().getParent();
		var oRowBinding = oList._getRowBinding();
		var sUrl = oRowBinding.getDownloadUrl("xlsx");
		// sUrl = this._adjustUrlToVisibleColumns(sUrl);
		sUrl = oList._removeExpandParameter(sUrl);
		// check for length of URL -> URLs longer than 2048 chars aren't supported in some browsers (e.g. Internet Explorer)
		if (sUrl && sUrl.length > 2048 && sap.ui.Device.browser.msie) {
			// thrown info to user!
			sap.m.MessageBox.error(sap.ui.getCore().getLibraryResourceBundle("sap.ui.comp").getText("DOWNLOAD_TOO_COMPLEX_TEXT"));
			return;
		}
		window.open(sUrl);

	},
	onClickActionxknoxem_d_di_c_y_engsrch_cosm8: function (oEvent) {
		// var oSelectedItems = oEvent.getSource().getParent().getParent().getTable().getSelectedItems();
		var oSelectedItems = oEvent.getSource().getParent().getParent().getSelectedItems();
		
		if (oSelectedItems.length > 1) {
			var oTextResource = this.getView().getModel("i18n").getResourceBundle();
			var sErrTxt = oTextResource.getText("WIPERROR");
			var iCounter;
			var arrMessages = [];
			this.oButton = oEvent.getSource();
			var oControl = this.oButton;

			var mMessageModel = {
				type: 'Error',
				title: sErrTxt,
				subtitle: 'Error Details',
				counter: iCounter
			};
			arrMessages.push(mMessageModel);
			this.openUpDownPopover(arrMessages);
			if (this.oMessagePopover) {
				this.oMessagePopover.openBy(oControl);
			}
			return;
		} else {
			var oBindingContext = new sap.ui.model.Context(oSelectedItems[0].getModel(), oSelectedItems[0].getBindingContext().getPath());
			var sVbeln = oBindingContext.getProperty("EngNum");
			this.wipBilling(oEvent, "WIPP", sVbeln);
		}
	},

	wipBilling: function (oEvent, sMode, sVbeln) {

		sap.ui.core.BusyIndicator.show(0);
		if (sVbeln) {
			var fnSuccess = jQuery.proxy(function (oData, response) {
				this.displayMessage(oData.MESSAGE);
				sap.ui.core.BusyIndicator.hide();
			}, this);

			var fnError = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide();
			}, this);

			var oDataModl = this.getOwnerComponent().getModel();
			oDataModl.callFunction('/wipBilling', {
				urlParameters: {
					ENGNUM: sVbeln,
					ACTION: sMode

				},
				method: "GET",
				success: fnSuccess,
				error: fnError
			});

		}
	},
	onClickActionxknoxem_d_di_c_y_engsrch_cosm9: function (oEvent) {
		// var oSelectedItems = oEvent.getSource().getParent().getParent().getTable().getSelectedItems();
		var oSelectedItems = oEvent.getSource().getParent().getParent().getSelectedItems();
		if (oSelectedItems.length > 1) {
			var oTextResource = this.getView().getModel("i18n").getResourceBundle();
			var sErrTxt = oTextResource.getText("WIPERROR");
			var iCounter;
			var arrMessages = [];
			this.oButton = oEvent.getSource();
			var oControl = this.oButton;

			var mMessageModel = {
				type: 'Error',
				title: sErrTxt,
				subtitle: 'Error Details',
				counter: iCounter
			};
			arrMessages.push(mMessageModel);
			this.openUpDownPopover(arrMessages);
			if (this.oMessagePopover) {
				this.oMessagePopover.openBy(oControl);
			}
			return;
		} else {
			var oBindingContext = new sap.ui.model.Context(oSelectedItems[0].getModel(), oSelectedItems[0].getBindingContext().getPath());
			var sVbeln = oBindingContext.getProperty("EngNum");
			var that = this;
			var dialog = new sap.m.Dialog({
				title: "Confirmation",
				type: "Message",
				content: new sap.m.Text({
					text: "Do you want to process Total Write Off for the Selected Engagement?"
				}),
				beginButton: new sap.m.Button({
					text: "Yes",
					press: function () {
						that.wipBilling(oEvent, "WIPT", sVbeln);
						dialog.close();
					}
				}),
				endButton: new sap.m.Button({
					text: "No",
					press: function () {
						dialog.close();
					}
				}),
				afterClose: function () {
					dialog.destroy();
				}
			});
			dialog.open();
		}
	},

	displayMessage: function (sMessage) {

			sap.m.MessageToast.show(sMessage, {
				duration: 5000, // default
				width: "15em", // default
				my: "center bottom",
				at: "center bottom",
				of: window, // default
				offset: "0 0", // default
				collision: "fit fit", // default
				autoClose: true, // default
				animationTimingFunction: "ease", // default
				animationDuration: 1000, // default
				closeOnBrowserNavigation: true // default
			});
		}
		// onClickActionxknoxem_d_di_c_y_engsrch_cosm10: function (oEvent) {
		// 	var oSelectedItems = oEvent.getSource().getParent().getParent().getTable().getSelectedItems();
		// 	if (oSelectedItems.length > 1) {
		// 		var oTextResource = this.getView().getModel("i18n").getResourceBundle();
		// 		var sErrTxt = oTextResource.getText("TXT1");
		// 		var iCounter;
		// 		var arrMessages = [];
		// 		this.oButton = oEvent.getSource();
		// 		var oControl = this.oButton;

	// 		var mMessageModel = {
	// 			type: 'Error',
	// 			title: sErrTxt,
	// 			subtitle: 'Error Details',
	// 			counter: iCounter
	// 		};
	// 		arrMessages.push(mMessageModel);
	// 		this.openUpDownPopover(arrMessages);
	// 		if (this.oMessagePopover) {
	// 			this.oMessagePopover.openBy(oControl);
	// 		}
	// 		return;
	// 	} else {
	// 		var oBindingContext = new sap.ui.model.Context(oSelectedItems[0].getModel(), oSelectedItems[0].getBindingContext().getPath());
	// 		var sVbeln = oBindingContext.getProperty("EngNum");
	// 		var fnSuccess = jQuery.proxy(function (oData, response) {
	// 				if (oData.SUCCESS) {
	// 					/*	if (sCancelbillno) {
	// 							this.displayErrorMessage(sErrTxt);
	// 						} else {*/
	// 					if (sVbeln !== '') {

	// 						var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service

	// 						var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
	// 							target: {
	// 								semanticObject: "ZTextMaintain",
	// 								action: "zmanage"
	// 							},
	// 							params: {
	// 								DocId: oData.VBELN,
	// 								DocType: oData.DocType,
	// 								Client: oData.Cname,
	// 								Partner: oData.Ename,
	// 								Demo: oData.DemoDm,
	// 								ParamDisp: oData.ParamDisp
	// 							}

	// 						}));

	// 						oCrossAppNavigator.toExternal({
	// 							target: {
	// 								shellHash: hash
	// 							}
	// 						});
	// 					} else {
	// 						//this.displayErrorMessage(sErrVal);
	// 					}
	// 					// }
	// 				} else {

	// 					//this.displayErrorMessage(oData.MESSAGE);
	// 				}
	// 			},
	// 			this);
	// 		var oDataModl = this.getOwnerComponent().getModel();
	// 		if (sVbeln.length < 10) {

	// 			for (var i = sVbeln.length; i < 10; i++) {

	// 				sVbeln = '0' + sVbeln;
	// 			}
	// 		}
	// 		oDataModl.callFunction('/fnTextMaint', {
	// 			urlParameters: {
	// 				ACTION: "CRET",
	// 				VBELN: sVbeln
	// 			},
	// 			method: "GET",
	// 			success: fnSuccess
	// 		});
	// 	}
	// }
	,
	onClickActionxknoxem_d_di_c_y_engsrch_cosm10: function (oEvent) {

		// var sParam = this.getOwnerComponent().getProperty("appComponent").getComponentData().startupParameters.ZACTION[0];
		var sParam ="ZSCHEDULE";
		// var oTable = this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm10button").getParent().getParent().getTable();
		 var oTable = this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm10button").getParent().getParent();
    	 //var oTable=oEvent.getSource().getParent().getParent().getSelectedItems();
		var oButton = this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm10button");
		var oSelectedItem = oTable.getSelectedItem();
		// var oSelectedItem=oTable;
		this.EngNum = undefined;

		switch (sParam) {
		case "ZSCHEDULE":

			var oBindingContext = new sap.ui.model.Context(oSelectedItem.getModel(), oSelectedItem.getBindingContext().getPath());
			// sVbeln = oBindingContext.getProperty("EngNum");

			this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm11button").setVisible(true);

			this.EngNum = oBindingContext.getProperty("EngNum");
			this.isSplitRev = false;

			var oDataModl = this.getOwnerComponent().getModel();
			this.oButton = oEvent.getSource();
			var fnSuccess = jQuery.proxy(function (oData, response) {

				var arrMessages = [];
				var iCounter;
				var oControl = this.oButton;

				if (oData.results && oData.results.length > 0) {
					for (var i = 0; i < oData.results.length; i++) {
						//Throw Message
						if (oData.results[i].MESSAGE) {
							var mMessageModel = {
								type: 'Error',
								title: oData.results[i].MESSAGE,
								// description: oData.results[i].MESSAGE,
								subtitle: 'Error Details',
								counter: iCounter
							};

							arrMessages.push(mMessageModel);

							if (arrMessages.length > 0) {
								this.openUpDownPopover(arrMessages);
								if (this.oMessagePopover) {
									this.oMessagePopover.openBy(oControl);
								}
								return;
							}
						} else {
							//End 
							oTable.setMode("MultiSelect");
							//Begin of change for RfC 3000005904 on 19/3/2019
							oTable.setGrowing(false);
							oTable.setGrowingScrollToLoad(false);
							oTable.setFixedLayout(true);
							//End of change for RfC 3000005904 on 19/3/2019

							oButton.setVisible(false);
							this.isSplitRev = true;
							//	this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm11button").setVisible(true);
							this.SALESORG = oData.results[i].SALESORG;
							this.BILLTOPARTY = oData.results[i].BILLTOPARTY;
							this.SHIPTOCOUNTRY = oData.results[i].SHIPTOCOUNTRY;
							this.CURRENCY = oData.results[i].CURRENCY;

							oTable = this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm1button").getParent().getParent();
							var oContext = oTable.getBinding("items");
							var aFilter = [];
							aFilter.push(new sap.ui.model.Filter("StatusCode", 'EQ', "E0006"),
								new sap.ui.model.Filter("StatusCode", 'EQ', "E0007"),
								new sap.ui.model.Filter("StatusCode", 'EQ', this.EngNum));
							if (this.isSplitRev) {
								aFilter.push(new sap.ui.model.Filter("BillToParty", 'EQ', this.BILLTOPARTY));
								aFilter.push(new sap.ui.model.Filter("ShiptoCountry", 'EQ', this.SHIPTOCOUNTRY));
								aFilter.push(new sap.ui.model.Filter("currency", 'EQ', this.CURRENCY));
								aFilter.push(new sap.ui.model.Filter("SalesOrg", 'EQ', this.SALESORG));

								//Hide buttons
								this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm1button").setVisible(false);
								this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm2button").setVisible(false);
								this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm3button").setVisible(false);
								this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm4button").setVisible(true);
								this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm5button").setVisible(false);
								this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm6button").setVisible(false);
								this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm7button").setVisible(false);
								this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm8button").setVisible(false);
								this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm9button").setVisible(false);
								this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm10button").setVisible(false);

							}

							// if (oContext.aApplicationFilters && oContext.aApplicationFilters.length > 0) {
							// 	for (var j = 0; j < oContext.aApplicationFilters.length; j++) {
							// 		if (oContext.aApplicationFilters[j].aFilters && oContext.aApplicationFilters[j].aFilters.length > 0) {
							// 			for (var m = 0; m < oContext.aApplicationFilters[j].aFilters.length; m++) {
							// 				if (oContext.aApplicationFilters[j].aFilters[m].aFilters && oContext.aApplicationFilters[j].aFilters[m].aFilters.length > 0) {
							// 					for (var k = 0; k < oContext.aApplicationFilters[j].aFilters[m].aFilters.length; k++) {
							// 						aFilter.push(oContext.aApplicationFilters[j].aFilters[m].aFilters[k]);
							// 					}
							// 				} else {
							// 					aFilter.push(oContext.aApplicationFilters[j].aFilters[m]);
							// 				}
							// 			}
							// 		}
							// 	}
							// }
							if (!this.isSplitRev) {
								aFilter.push(new sap.ui.model.Filter({
									filters: [
										// new sap.ui.model.Filter("EngManager", 'EQ', "XXXX"),
										// new sap.ui.model.Filter("EngPartner", 'EQ', "XXXX"),
										new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
										new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
										new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
										new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
										new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
										new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
										new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
										new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
										new sap.ui.model.Filter("zz_opp_function", 'EQ', "XXXX"),
										new sap.ui.model.Filter("zz_opp_function", 'EQ', "XXXX"),
										new sap.ui.model.Filter("zz_opp_function", 'EQ', "XXXX"),
										new sap.ui.model.Filter("zz_opp_function", 'EQ', "XXXX"),
										new sap.ui.model.Filter("zz_opp_function", 'EQ', "XXXX"),
										new sap.ui.model.Filter("DelegUserID", 'EQ', "XXXX"),
										//	new sap.ui.model.Filter("PartDelegUserID", 'EQ', "XXXX"),
										new sap.ui.model.Filter("ZUUSRID", 'EQ', "XXXX"),
										new sap.ui.model.Filter("PartnerUId", 'EQ', "XXXX"),
										new sap.ui.model.Filter("ManagerUId", 'EQ', "XXXX")
									],
									and: false
								}, true));
							}
							oContext.filter(aFilter, sap.ui.model.FilterType.Application);

						}

					}
				}
			}, this);

			oDataModl.callFunction('/engValidation', {
				urlParameters: {
					ACTION: "C",
					VBELN: this.EngNum,
					LEADENG: this.EngNum
				},
				method: "GET",
				success: fnSuccess
			});
			// var oContext = oTable.getBinding("items");
			// var aFilter = [];
			// aFilter.push(new sap.ui.model.Filter("StatusCode", 'EQ', "E0006"));

			// if (oContext.aApplicationFilters && oContext.aApplicationFilters.length > 0) {
			// 	for (var j = 0; j < oContext.aApplicationFilters.length; j++) {
			// 		if (oContext.aApplicationFilters[j].aFilters && oContext.aApplicationFilters[j].aFilters.length > 0) {
			// 			for (var i = 0; i < oContext.aApplicationFilters[j].aFilters.length; i++) {
			// 				if (oContext.aApplicationFilters[j].aFilters[i].aFilters && oContext.aApplicationFilters[j].aFilters[i].aFilters.length > 0) {
			// 					for (var k = 0; k < oContext.aApplicationFilters[j].aFilters[i].aFilters.length; k++) {
			// 						aFilter.push(oContext.aApplicationFilters[j].aFilters[i].aFilters[k]);
			// 					}
			// 				} else {
			// 					aFilter.push(oContext.aApplicationFilters[j].aFilters[i]);
			// 				}
			// 			}
			// 		}
			// 	}
			// }

			// aFilter.push(new sap.ui.model.Filter({
			// 	filters: [
			// 		// new sap.ui.model.Filter("EngManager", 'EQ', "XXXX"),
			// 		// new sap.ui.model.Filter("EngPartner", 'EQ', "XXXX"),
			// 		new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
			// 		new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
			// 		new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
			// 		new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
			// 		new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
			// 		new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
			// 		new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
			// 		new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
			// 		new sap.ui.model.Filter("zz_opp_function", 'EQ', "XXXX"),
			// 		new sap.ui.model.Filter("zz_opp_function", 'EQ', "XXXX"),
			// 		new sap.ui.model.Filter("zz_opp_function", 'EQ', "XXXX"),
			// 		new sap.ui.model.Filter("zz_opp_function", 'EQ', "XXXX"),
			// 		new sap.ui.model.Filter("zz_opp_function", 'EQ', "XXXX"),
			// 		new sap.ui.model.Filter("DelegUserID", 'EQ', "XXXX"),
			// 		new sap.ui.model.Filter("PartDelegUserID", 'EQ', "XXXX"),
			//		new sap.ui.model.Filter("ZUUSRID", 'EQ', "XXXX"),
			// 		new sap.ui.model.Filter("PartnerUId", 'EQ', "XXXX"),
			// 		new sap.ui.model.Filter("ManagerUId", 'EQ', "XXXX")
			// 	],
			// 	and: false
			// }, true));

			// oContext.filter(aFilter, sap.ui.model.FilterType.Application);

			break;

		default:
		}

	},
	onClickActionxknoxem_d_di_c_y_engsrch_cosm11: function (oEvent) {

		// this.onBeforeRendering();
		this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm1button").setVisible(true);
		this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm2button").setVisible(true);
		this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm3button").setVisible(true);
		this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm4button").setVisible(false);
		this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm5button").setVisible(true);
		this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm6button").setVisible(true);
		this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm7button").setVisible(true);
		this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm8button").setVisible(true);
		this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm9button").setVisible(true);
		this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm10button").setVisible(true);
		this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm11button").setVisible(false);

		this.isSplitRev = false;
		var oGoButtonid = $("button[id*='btnGo']")[0].id;
		var oGoButton = this.getView().byId(oGoButtonid);
		oGoButton.fireTap({});
		oGoButton.firePress({});
		var oTable = this.getView().byId("Actionxknoxem_d_di_c_y_engsrch_cosm11button").getParent().getParent().getTable();
		oTable.setMode("SingleSelectLeft");
		oTable.removeSelections();
	},
	onClickActionxknoxem_d_di_c_y_engsrch_cosm12: function (oEvent) {}
});