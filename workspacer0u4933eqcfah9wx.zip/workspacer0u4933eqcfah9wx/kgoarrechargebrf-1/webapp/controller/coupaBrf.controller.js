sap.ui.define([
	"KGO/kgoarrecharge_brf/controller/BaseController",
	"sap/ui/core/mvc/Controller",
	'sap/ui/core/UIComponent', /*Added by Satabdi on 26-Nov-2019*/
	'sap/ui/core/Fragment', /*Added by Satabdi on 26-Nov-2019*/
	"sap/m/MessageToast",
	'sap/ui/core/routing/History',
	"KGO/kgoarrecharge_brf/formatter/formatter",
	"KGO/kgoarrecharge_brf/util/DataManagerBrf",
	"KGO/kgoarrecharge_brf/util/UIGlobal", /*Added on 21-APR-2020*/
	'sap/ui/core/Popup',
	"sap/m/MessageBox",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/Filter"
], function (BaseController, Controller, UIComponent, Fragment, MessageToast, History, formatter, DataManagerBrf, UIGlobal, Popup,
	MessageBox,
	FilterOperator,
	Filter) { /*Added by Satabdi on 26-Nov-2019*/
	"use strict";

	return BaseController.extend("KGO.kgoarrecharge_brf.controller.coupaBrf", {
		onInit: function () {
			var oRouter = UIComponent.getRouterFor(this);
			oRouter.attachRouteMatched(this.onRouteMatched, this);
			oRouter.attachRouteMatched(this.onRouteMatchCheckBox, this);

		},
		onRouteMatched: function (oEvent) {
			if (oEvent.getParameter("name") === "TargetcoupaBrf") {
				//only invoke if a pernr has been selected
				this.firstInitialData();
				/*Start of change on 21-APR-2020*/
				var sBR = oEvent.getParameters().arguments.No;
				var bIsOpenTask = UIGlobal.getFromOpenTask();
				if (sBR && (sBR.indexOf("BR") >= 0) && bIsOpenTask === true) {
					this.handleOpenTaskEdit(sBR);
				}
				/*End of change on 21-APR-2020*/
				/*Start of change for new Comp Code 9921 by developer Satabdi Das*/
				this.compCoCursorDisable();
				/*End of change for new Comp Code 9921 by developer Satabdi Das*/
			}
		},
		//starts changes by prashant for ltt reviw
		onRouteMatchCheckBox: function (oEvent) {

			this.brfMFSearchHelp();
			this.brfMFLocationService();
			var oBrfModel = this.getView().getModel("oBrfModel");
			var oTblBRF = this.getView().byId('tableid');

			//var checkDispBtn = this.getView().getModel("oBrfModel").getProperty("/oDisplayBtnPress");
			for (var i = 0; i < oTblBRF.getItems().length; i++) {

				if (oTblBRF.getBindingInfo("items").binding.oList[i].RequestingMf && oTblBRF.getBindingInfo("items").binding.oList[i].RequestingMf !=
					"N/A") {
					for (var k = 0; k < oTblBRF.getAggregation("items")[i].getCells().length; k++) {
						if (k == 7) {
							oTblBRF.getAggregation("items")[i].getCells()[k].setProperty("visible", true);
							if (oTblBRF.getBindingInfo("items").binding.oList[i].Ltt === "X") {
								oTblBRF.getAggregation("items")[i].getCells()[k].setProperty("selected", true);
							}
						}
						if (k == 9) {
							if (oTblBRF.getBindingInfo("items").binding.oList[i].CnFlag !== "X") {
								oTblBRF.getAggregation("items")[i].getCells()[k].setProperty("enabled", false);
								oTblBRF.getAggregation("items")[i].getCells()[k].setProperty("visible", false);
							} else {
								oTblBRF.getAggregation("items")[i].getCells()[k].setProperty("enabled", true);
								oTblBRF.getAggregation("items")[i].getCells()[k].setProperty("visible", true);
							}
						}
						/*Start of Reissuance of Invoice by developer Satabdi Das on 14-Dec-2020 */
						if (k === 10) {
							if (oTblBRF.getBindingInfo("items").binding.oList[i].RiFlag !== "X") {
								oTblBRF.getAggregation("items")[i].getCells()[k].setProperty("enabled", false);
								oTblBRF.getAggregation("items")[i].getCells()[k].setProperty("visible", false);
							} else {
								oTblBRF.getAggregation("items")[i].getCells()[k].setProperty("enabled", true);
								oTblBRF.getAggregation("items")[i].getCells()[k].setProperty("visible", true);
							}
						}
						/*End of Reissuance of Invoice by developer Satabdi Das on 14-Dec-2020 */
					}
				} else {
					oTblBRF.getAggregation("items")[i].getCells()[7].setProperty("visible", false);
					oTblBRF.getAggregation("items")[i].getCells()[9].setProperty("visible", false);
					oTblBRF.getAggregation("items")[i].getCells()[10].setProperty("visible", false); //added for Reissuance visible by Satabdi Das on  14-Dec-2020

				}

			}

		},
		/*Start of change for new Comp Code 9921 by developer Satabdi Das*/
		compCoCursorDisable: function () {

			var oCompCo = this.getView().byId("CompCo");
			oCompCo.addEventDelegate({
				onAfterRendering: function () {
					var oYear = this.$().find('.sapMInputBaseInner');
					var oID = oYear[0].id;
					$('#' + oID).attr("disabled", "disabled");
				}
			}, oCompCo);

		},
		disableAllDatepickerMF: function () {
			var createBrfFragment = this.getView().createId("createBrfFragment");

			var LastDateSrv = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "LastDateSrv"));
			LastDateSrv.addEventDelegate({
				onAfterRendering: function () {
					var oYear = this.$().find('.sapMInputBaseInner');
					var oID = oYear[0].id;
					$('#' + oID).attr("disabled", "disabled");
				}
			}, LastDateSrv);

			var oDocumentDateMF = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "DocumentDateMF"));
			oDocumentDateMF.addEventDelegate({
				onAfterRendering: function () {
					var oYear = this.$().find('.sapMInputBaseInner');
					var oID = oYear[0].id;
					$('#' + oID).attr("disabled", "disabled");
				}
			}, oDocumentDateMF);
			var oDatePickerDocPost = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "PostingDateMF"));
			oDatePickerDocPost.addEventDelegate({
				onAfterRendering: function () {
					var oYear = this.$().find('.sapMInputBaseInner');
					var oID = oYear[0].id;
					$('#' + oID).attr("disabled", "disabled");
				}
			}, oDatePickerDocPost);

			var oServicePeriodStartMF = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "ServicePeriodStartMF"));
			oServicePeriodStartMF.addEventDelegate({
				onAfterRendering: function () {
					var oYear = this.$().find('.sapMInputBaseInner');
					var oID = oYear[0].id;
					$('#' + oID).attr("disabled", "disabled");
				}
			}, oServicePeriodStartMF);

			var oServicePeriodEndMF = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "ServicePeriodEndMF"));
			oServicePeriodEndMF.addEventDelegate({
				onAfterRendering: function () {
					var oYear = this.$().find('.sapMInputBaseInner');
					var oID = oYear[0].id;
					$('#' + oID).attr("disabled", "disabled");
				}
			}, oServicePeriodEndMF);

			/*Start of change on 25-May-2020*/

			var oNatureField = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "Nature"));
			oNatureField.addEventDelegate({
				onAfterRendering: function () {
					var oYear = this.$().find('.sapMInputBaseInner');
					var oID = oYear[0].id;
					$('#' + oID).attr("disabled", "disabled");
				}
			}, oNatureField);

			/*End of change on 25-May-2020*/

			var oMFCurrency = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "MFCurr"));
			oMFCurrency.addEventDelegate({
				onAfterRendering: function () {
					var oYear = this.$().find('.sapMInputBaseInner');
					var oID = oYear[0].id;
					$('#' + oID).attr("disabled", "disabled");
				}
			}, oMFCurrency);

			/*Start of change by Satabdi Das on 05-March-2021 for SCTASK1838272*/

			var oRestGL = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "GL9921CR"));
			oRestGL.addEventDelegate({
				onAfterRendering: function () {
					var oYear = this.$().find('.sapMInputBaseInner');
					var oID = oYear[0].id;
					$('#' + oID).attr("disabled", "disabled");
				}
			}, oRestGL);

			/*End of change by Satabdi Das on 05-March-2021 for SCTASK1838272*/

			/*Start of change for new doc type field by developer Satabdi Das on 15-Sep-2020 */

			var oMFDocType = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "MFDocType"));
			oMFDocType.addEventDelegate({
				onAfterRendering: function () {
					var oYear = this.$().find('.sapMInputBaseInner');
					var oID = oYear[0].id;
					$('#' + oID).attr("disabled", "disabled");
				}
			}, oMFDocType);

			/*End of change for new doc type field by developer Satabdi Das on 15-Sep-2020 */

			var oTaxPointDate = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "TaxPointDate"));
			oTaxPointDate.addEventDelegate({
				onAfterRendering: function () {
					var oYear = this.$().find('.sapMInputBaseInner');
					var oID = oYear[0].id;
					$('#' + oID).attr("disabled", "disabled");
				}
			}, oTaxPointDate);

			var oDocumentDate = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "DocumentDate"));
			oDocumentDate.addEventDelegate({
				onAfterRendering: function () {
					var oYear = this.$().find('.sapMInputBaseInner');
					var oID = oYear[0].id;
					$('#' + oID).attr("disabled", "disabled");
				}
			}, oDocumentDate);

			var oPostingDate = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "PostingDate"));
			oPostingDate.addEventDelegate({
				onAfterRendering: function () {
					var oYear = this.$().find('.sapMInputBaseInner');
					var oID = oYear[0].id;
					$('#' + oID).attr("disabled", "disabled");
				}
			}, oPostingDate);

			var oServicePeriodStart = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "ServicePeriodStart"));
			oServicePeriodStart.addEventDelegate({
				onAfterRendering: function () {
					var oYear = this.$().find('.sapMInputBaseInner');
					var oID = oYear[0].id;
					$('#' + oID).attr("disabled", "disabled");
				}
			}, oServicePeriodStart);

			var oServicePeriodEnd = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "ServicePeriodEnd"));
			oServicePeriodEnd.addEventDelegate({
				onAfterRendering: function () {
					var oYear = this.$().find('.sapMInputBaseInner');
					var oID = oYear[0].id;
					$('#' + oID).attr("disabled", "disabled");
				}
			}, oServicePeriodEnd);

			var oQdropDown = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "comboIdTableFirst"));
			oQdropDown.addEventDelegate({
				onAfterRendering: function () {
					var oQdropDown = this.$().find('.sapMInputBaseInner');
					var oID = oQdropDown[0].id;
					$('#' + oID).attr("disabled", "disabled");
				}
			}, oQdropDown);

		},
		/*End of change for new Comp Code 9921 by developer Satabdi Das*/

		/*Start of change on 21-APR-2020*/
		handleOpenTaskEdit: function (oEvent) {
			var that = this;

			var oBrfModel = this.getView().getModel("oBrfModel");
			// var bWithRef = oBrfModel.getProperty("/oVisibleSet/withRRF");
			var editBRFText = this.getView().getModel("i18n").getProperty("editBRFText");
			oBrfModel.setProperty("/setDashBoardTextForBRF", editBRFText);
			var title = this.getView().getModel("i18n").getProperty("title");
			var fisYr = this.getView().getModel("i18n").getProperty("fiscalyear");
			var year;
			var sHeading;
			this.getModel("oBrfModel").setProperty("/oVisibleSet/attachVisible", true);
			this.getView().getModel("oBrfModel").setProperty("/brfHeaderSet/BrfNo", oEvent);
			this.currencyDropDown();
			this.DocTypeDropDown(); /*Added on 15-Sep-2020 by Satabdi Das*/
			if (this.getView().getModel("oBrfModel").getProperty("/brfHeaderSet").BrfNo) {
				var BrfNo = this.getView().getModel("oBrfModel").getProperty("/brfHeaderSet").BrfNo;
				//start change
				var fnSuccess = jQuery.proxy(function (d) {
					if (d.results.length !== 0) {
						var arrAnswer = [];
						sap.ui.core.BusyIndicator.hide(0);
						var bFlag; /*Added on 06-MAY-2020*/
						if (d.results[0].RrfNo !== "" && d.results[0].RrfNo !== undefined) {
							this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/withRRF", true); /*Added by Satabdi Das on 28-Oct-2020 for defect 63391*/
							this.getModel("oBrfModel").setProperty("/oVisibleSet/buttonVis", false);
							oBrfModel.setProperty("/oVisibleSet/addIcon", false);
							oBrfModel.setProperty("/oVisibleSet/AddDisplIcon", false);
							this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/fieldEditable", false);
							if (d.results[0].RrfNo.indexOf("PO") >= 0) {
								this.getView().getModel("oBrfModel").setProperty("/PORef", true);
							} else {
								this.getView().getModel("oBrfModel").setProperty("/PORef", false);
							}

						} else {
							this.getModel("oBrfModel").setProperty("/oVisibleSet/buttonVis", true);
							this.getView().getModel("oBrfModel").setProperty("/PORef", false);
							this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/withRRF", false); /*Added by Satabdi Das on 28-Oct-2020 for defect 63391*/
						}
						if (d.results[0].Display === "X") {
							this.getModel("oBrfModel").setProperty("/Display", true);
							this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/editable", false);
							this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/vatEditDisplay", false);
							this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/vatEditDisplay", false);
							this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/fieldEditable", false);
							oBrfModel.setProperty("/oVisibleSet/sendToContrl", false);
							oBrfModel.setProperty("/oVisibleSet/sendToSupp", false);
							oBrfModel.setProperty("/oVisibleSet/sendToVat", false);
							oBrfModel.setProperty("/oVisibleSet/sendToAR", false);
							oBrfModel.setProperty("/oVisibleSet/sendToAprrv", false);

							if (this.getModel("oBrfModel").getProperty("/oVisibleSet").buttonVis === false) {
								oBrfModel.setProperty("/oVisibleSet/addIcon", false);
								oBrfModel.setProperty("/oVisibleSet/AddDisplIcon", false);
								oBrfModel.setProperty("/oVisibleSet/SuppForwardIcon", false); /*Added by Satabdi Das for defect 63391 on 28-Oct-2020*/
								oBrfModel.setProperty("/oVisibleSet/SuppDisplayFwdIcon", true); /*Added by Satabdi Das for defect 63391 on 28-Oct-2020*/

							} else {
								oBrfModel.setProperty("/oVisibleSet/SuppForwardIcon", false); /*Added by Satabdi Das for defect 63391 on 28-Oct-2020*/
								oBrfModel.setProperty("/oVisibleSet/SuppDisplayFwdIcon", false); /*Added by Satabdi Das for defect 63391 on 28-Oct-2020*/
								if (this.getView().getModel("oBrfModel").getProperty("/oDisplayBtnPress") === "true") {

									oBrfModel.setProperty("/oVisibleSet/addIcon", false);
									oBrfModel.setProperty("/oVisibleSet/AddDisplIcon", true);
									oBrfModel.setProperty("/oVisibleSet/enableAddMF", false);
									oBrfModel.setProperty("/oVisibleSet/enableAddGF", false);
								} else {
									oBrfModel.setProperty("/oVisibleSet/addIcon", true);
									oBrfModel.setProperty("/oVisibleSet/AddDisplIcon", false);
									oBrfModel.setProperty("/oVisibleSet/enableAddMF", true);
									oBrfModel.setProperty("/oVisibleSet/enableAddGF", true);
								}
							}

						} else {
							if ((this.getView().getModel("oBrfModel").getProperty("/oDisplayBtnPress") === "false") || !this.getView().getModel(
									"oBrfModel").getProperty("/oDisplayBtnPress")) {
								this.getModel("oBrfModel").setProperty("/Display", false);
								this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/editable", true);
								oBrfModel.setProperty("/oVisibleSet/sendToContrl", true);
								oBrfModel.setProperty("/oVisibleSet/sendToSupp", true);
								oBrfModel.setProperty("/oVisibleSet/sendToVat", true);
								oBrfModel.setProperty("/oVisibleSet/sendToAR", true);
								oBrfModel.setProperty("/oVisibleSet/sendToAprrv", true);
								oBrfModel.setProperty("/oVisibleSet/forwardIcon", true);
								oBrfModel.setProperty("/oVisibleSet/displayFwdIcon", false);

								this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/fieldEditable", false);

								if (this.getModel("oBrfModel").getProperty("/oVisibleSet").buttonVis === false) {
									oBrfModel.setProperty("/oVisibleSet/addIcon", false);
									oBrfModel.setProperty("/oVisibleSet/AddDisplIcon", false);
									oBrfModel.setProperty("/oVisibleSet/SuppForwardIcon", true); /*Added by Satabdi Das for defect 63391 on 28-Oct-2020*/
									oBrfModel.setProperty("/oVisibleSet/SuppDisplayFwdIcon", false); /*Added by Satabdi Das for defect 63391 on 28-Oct-2020*/
								} else {
									oBrfModel.setProperty("/oVisibleSet/addIcon", true);
									oBrfModel.setProperty("/oVisibleSet/AddDisplIcon", false);
									oBrfModel.setProperty("/oVisibleSet/SuppForwardIcon", false); /*Added by Satabdi Das for defect 63391 on 28-Oct-2020*/
									oBrfModel.setProperty("/oVisibleSet/SuppDisplayFwdIcon", false); /*Added by Satabdi Das for defect 63391 on 28-Oct-2020*/
								}

								/*Start of change on 06-MAY-2020*/
								// for (var i = 0; i < d.results[0].BRFItemSet.results.length; i++) {
								// 	if (d.results[0].BRFItemSet.results[i].LineStatus === "CONTROLLER" || d.results[0].BRFItemSet.results[i].LineStatus ===
								// 		"SUPPLIER") {
								// 		bFlag = true;
								// 	}
								// }
								// if (bFlag === true) {
								// 	oBrfModel.setProperty("/oVisibleSet/enableAddMF", true);
								// 	oBrfModel.setProperty("/oVisibleSet/enableAddGF", true);
								// 	oBrfModel.setProperty("/oVisibleSet/buttonVis", true);
								// } else if (bFlag === undefined) {
								// 	oBrfModel.setProperty("/oVisibleSet/enableAddMF", false);
								// 	oBrfModel.setProperty("/oVisibleSet/enableAddGF", false);
								// 	oBrfModel.setProperty("/oVisibleSet/buttonVis", false);
								// }
								/*End of change on 06-MAY-2020*/
							} else {
								this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/editable", false);
								oBrfModel.setProperty("/oVisibleSet/sendToContrl", false);
								oBrfModel.setProperty("/oVisibleSet/sendToSupp", false);
								oBrfModel.setProperty("/oVisibleSet/sendToVat", false);
								oBrfModel.setProperty("/oVisibleSet/sendToAR", false);
								oBrfModel.setProperty("/oVisibleSet/sendToAprrv", false);
								oBrfModel.setProperty("/oVisibleSet/enableAddMF", false);
								oBrfModel.setProperty("/oVisibleSet/enableAddGF", false);
								oBrfModel.setProperty("/oVisibleSet/forwardIcon", false);
								oBrfModel.setProperty("/oVisibleSet/displayFwdIcon", true);
								this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/fieldEditable", false);

								if (this.getModel("oBrfModel").getProperty("/oVisibleSet").buttonVis === false) {
									oBrfModel.setProperty("/oVisibleSet/addIcon", false);
									oBrfModel.setProperty("/oVisibleSet/AddDisplIcon", false);
									oBrfModel.setProperty("/oVisibleSet/SuppForwardIcon", false); /*Added by Satabdi Das for defect 63391 on 28-Oct-2020*/
									oBrfModel.setProperty("/oVisibleSet/SuppDisplayFwdIcon", true); /*Added by Satabdi Das for defect 63391 on 28-Oct-2020*/
								} else {
									oBrfModel.setProperty("/oVisibleSet/addIcon", false);
									oBrfModel.setProperty("/oVisibleSet/AddDisplIcon", true);
									oBrfModel.setProperty("/oVisibleSet/SuppForwardIcon", false); /*Added by Satabdi Das for defect 63391 on 28-Oct-2020*/
									oBrfModel.setProperty("/oVisibleSet/SuppDisplayFwdIcon", false); /*Added by Satabdi Das for defect 63391 on 28-Oct-2020*/
								}

							}
						}
						for (var i = 0; i < d.results.length; i++) {
							var obj = {};
							var oLineItemArr = [];
							obj.BrfNo = d.results[i].BrfNo;
							obj.RrfNo = d.results[i].RrfNo;
							obj.BrfType = d.results[i].BrfType;
							obj.ContrlName = d.results[i].ContrlName;
							obj.ContrlEmail = d.results[i].ContrlEmail;
							obj.BrfCreationDate = d.results[i].BrfCreationDate;
							obj.BrfCreatedBy = d.results[i].BrfCreatedBy;
							obj.BrfCreatorName = d.results[i].BrfCreatorName; /* Added by Satabdi Das on 15-Jan-2021 for defect 63786*/
							obj.Gjahr = d.results[i].Gjahr;
							obj.SchDate = d.results[i].SchDate;
							obj.InvoiceAmount = d.results[i].InvoiceAmount;
							obj.GrossAmtLocal = d.results[i].GrossAmtLocal;
							obj.CurrencyLocal = d.results[i].CurrencyLocal;
							obj.NetAmount = d.results[i].NetAmount;
							obj.DocCurrency = d.results[i].DocCurrency;
							obj.SapDocYear = d.results[i].SapDocYear;
							obj.SapDocNum = d.results[i].SapDocNum;
							obj.BukrsUrn = d.results[i].BukrsUrn;
							obj.Urn = d.results[i].Urn;
							obj.Flag = d.results[i].Flag; /*Added on 01-Apr-2021*/
							obj.Message = d.results[i].Message; /*Added on 01-Apr-2021*/
							obj.CompanyCode = d.results[i].CompanyCode; /*Added for new Comp Code 9921 by Satabdi Das*/
							obj.ToDisplay = d.results[i].ToDisplay;
							obj.Display = d.results[i].Display;
							oLineItemArr = d.results[i].BRFItemSet;
							arrAnswer = d.results[i].BRF_AnswerSet;
							this.getView().getModel("oBrfModel").setProperty("/brfHeaderSet", obj);
							this.getView().getModel("oBrfModel").setProperty("/brfTableSet", oLineItemArr.results);
							this.getView().getModel("oBrfModel").setProperty("/questionSetSubmit", arrAnswer.results);
						}
						if (obj.BrfNo) {
							oBrfModel.setProperty("/oVisibleSet/vendorInvoiceField", false);
						} else {
							oBrfModel.setProperty("/oVisibleSet/vendorInvoiceField", true);
						}

						//SCTASK Transfer owner
						if (obj.ToDisplay === "X" && (oBrfModel.getProperty("/oDisplayBtnPress") === "false")) {
							this.getView().byId("trfOwnerId").setProperty("enabled", true);
							oBrfModel.setProperty("/oVisibleSet/contrlNameEdit", false);
						} else {
							this.getView().byId("trfOwnerId").setProperty("enabled", false);
							oBrfModel.setProperty("/oVisibleSet/contrlNameEdit", false);
						}

						year = this.getView().getModel("oBrfModel").getProperty("/brfHeaderSet").Gjahr;
						sHeading = title + " " + BrfNo + " " + fisYr + " " + year;
						this.getView().getModel("oBrfModel").setProperty("/setHeading", sHeading);
						var fragId = this.getView().createId("searchRRFNo");
						var SearchId = sap.ui.core.Fragment.byId(fragId, "localBRFSearch");
						if (SearchId) {
							SearchId.setValue("");
							var aFilter = [];
							aFilter.push(new Filter("BrfNo", FilterOperator.Contains, ""));
							var frag = this.getView().createId("searchRRFNo");
							var table = sap.ui.core.Fragment.byId(frag, "tableBRFSerch");
							var oBinding = table.getBinding("items");
							oBinding.filter(aFilter, "Application");
							this._oSearchCoordinatorForRRF.close();
						}

						if (obj.Flag === "X") {
							var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
							MessageBox.error(
								obj.Message, {
									styleClass: bCompact ? "sapUiSizeCompact" : "",
									actions: [MessageBox.Action.OK],
									onClose: function (oAction) {
										if (oAction === "OK") {
											UIGlobal.setFromOpenTask(false);
											var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
											oCrossAppNavigator.toExternal({
												target: {
													semanticObject: "#"
												}
											});
										}

									}
								}
							);
						}

						/*Start of change by developer Satabdi Das on 14-Oct-2020*/
						/* Invoking the functions after dashboard table's data binding */
						this.firstInitialData();
						this.onRouteMatchCheckBox();
						/*End of change by developer Satabdi Das on 14-Oct-2020*/
					}
				}, this);

				var fnError = jQuery.proxy(function (d) {
						var r = JSON.parse(JSON.stringify(d));
						sap.ui.core.BusyIndicator.hide();
						MessageToast.show(r.message, {
							autoClose: true,
							width: "20rem"

						});

					}, this

				);

				var sPath = "/BRFHeaderSet";
				var aFilter = [];

				var oFilterSerach;
				/*Start of change by developer Satabdi Das on 25-May-2021 for HTTP Error*/
				if (BrfNo) {
					BrfNo = formatter.formatValueToString(BrfNo); /*Change added by developer Satabdi Das on 25-May-2021 for HTTP Error*/
				}
				/*End of change by developer Satabdi Das on 25-May-2021 for HTTP Error*/
				oFilterSerach = new sap.ui.model.Filter("BrfNo", sap.ui.model.FilterOperator.EQ, BrfNo);
				aFilter.push(oFilterSerach);

				// var sParams = {};
				// var oObject = {};
				// oObject.Filter = aFilter;
				// oObject.Params = sParams;
				// oObject.successCallback = fnSuccess;
				// oObject.errorCallback = fnError;
				// oObject.sPath = sPath;
				// DataManagerBrf.getRRFHeaderSetvalueBRF(oObject);
				/*R&D---start*/
				var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_BRF_SRV/", {
					json: true
				});
				oModel1.read("/BRFHeaderSet", {
					filters: aFilter,
					urlParameters: {
						"$expand": "BRFItemSet,BRF_AnswerSet"
					},
					success: fnSuccess,
					error: fnError
				});
				/*R&D---end*/

				//end changes
			}
		},
		/*End of change on 21-APR-2020*/
		firstInitialData: function () {
			var oBrfModel = this.getView().getModel("oBrfModel");
			var oLineTbl = this.getView().byId('tableid');
			var brfHeaderData = this.getModel("oBrfModel").getData().brfHeaderSet;
			var displyPress = oBrfModel.getProperty("/oDisplayBtnPress");
			if (brfHeaderData.ToDisplay === "X" && displyPress != "true") {
				this.getView().byId("trfOwnerId").setProperty("enabled", true);
			} else {
				this.getView().byId("trfOwnerId").setProperty("enabled", false);
			}
			for (var i = 0; i < oLineTbl.getItems().length; i++) {
				var EditDisplay = oLineTbl.getBindingInfo("items").binding.oList[i].EditDisplay;

				if (EditDisplay === "X") {
					var x = oLineTbl.getAggregation("items")[i];
					x.getMultiSelectControl().setEnabled(false);
				} else if (displyPress === "true") {
					x = oLineTbl.getAggregation("items")[i];
					x.getMultiSelectControl().setEnabled(false);
				}
			}
			this.brfHistoryTab(); /*Added by developer Satabdi Das for defect 63361*/
		},
		onCoupaBack: function (oEvent) {
			var that = this;
			var oRouter = UIComponent.getRouterFor(this);
			var checkDispBtn = this.getView().getModel("oBrfModel").getProperty("/oDisplayBtnPress");

			/*Start of change on 21-APR-2020*/
			var bIsOpenTask = UIGlobal.getFromOpenTask();
			if (bIsOpenTask === false) {
				/*End of change on 21-APR-2020*/
				if (checkDispBtn === "false" || (!checkDispBtn)) {

					var bDisplay = this.getView().getModel("oBrfModel").getProperty("/Display");
					var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
					var oHistory = History.getInstance();
					var sPreviousHash = oHistory.getPreviousHash();
					if (bDisplay === false) {
						MessageBox.warning(
							this.getView().getModel("i18n").getProperty("BackWarning"), {
								actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
								styleClass: bCompact ? "sapUiSizeCompact" : "",
								onClose: function (sAction) {
									if (sAction === "OK") {
										that.handleBrfConcurrentLock();
										oRouter.navTo("TargetBrfHomeView", {}, true);

									}
									var oLineTbl = that.getView().byId("tableid");

									oLineTbl.removeSelections(true);
								}
							}, this);

					} else {
						// unlock items on back 
						if (checkDispBtn === "false") {
							MessageBox.warning(
								this.getView().getModel("i18n").getProperty("BackWarning"), {
									actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
									styleClass: bCompact ? "sapUiSizeCompact" : "",
									onClose: function (sAction) {
										if (sAction === "OK") {
											that.handleBrfConcurrentLock();
											oRouter.navTo("TargetBrfHomeView", {}, true);

										}
										var oLineTbl = that.getView().byId("tableid");

										oLineTbl.removeSelections(true);
									}
								}, this);
						} else {
							oRouter.navTo("TargetBrfHomeView", {}, true);
							var oLineTbl = that.getView().byId("tableid");
							oLineTbl.removeSelections(true);
						}

					}
				} else {
					oRouter.navTo("TargetBrfHomeView", {}, true);
					var oLineTbl = that.getView().byId("tableid");

					for (var i = 0; i < oLineTbl.getItems().length; i++) {
						//	var EditDisplay = oLineTbl.getBindingInfo("items").binding.oList[i].EditDisplay;

						if (oLineTbl) {
							var x = oLineTbl.getAggregation("items")[i];
							x.getMultiSelectControl().setEnabled(true);
						}
					}
					oLineTbl.removeSelections(true);
				}
				/*Start of change on 21-APR-2020*/
			} else if (bIsOpenTask === true) {
				MessageBox.warning(
					this.getView().getModel("i18n").getProperty("BackWarning"), {
						actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
						styleClass: bCompact ? "sapUiSizeCompact" : "",
						onClose: function (sAction) {
							if (sAction === "OK") {
								that.handleBrfConcurrentLock();
								UIGlobal.setFromOpenTask(false);
								var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
								oCrossAppNavigator.toExternal({
									target: {
										semanticObject: "#"
									}
								});
							}
							var oLineTbl = that.getView().byId("tableid");
							oLineTbl.removeSelections(true);
						}
					}, this);
			}
			/*End of change on 21-APR-2020*/
		},
		handlePressOpenMenu: function (oEvent) {
			var oButton = oEvent.getSource();
			var createMenu = this.getView().createId("createMenu");
			if (!this._oMenu) {
				this._oMenu = sap.ui.xmlfragment(createMenu, "KGO.kgoarrecharge_brf.view.menuItem", this);
				this.getView().addDependent(this._oMenu);
				this._oMenu.open(this._bKeyboard, oButton, Popup.Dock.BeginTop, Popup.Dock.BeginBottom, oButton);
			} else {
				this._oMenu.open(this._bKeyboard, oButton, Popup.Dock.BeginTop, Popup.Dock.BeginBottom, oButton);
			}
		},
		handlePressLinkAddBrfMF: function (oEvent) {

			var oModelAttachmentsLastForBF = this.getView().getModel("oBrfModel").getProperty("/FileNameBRFSet");
			if (oModelAttachmentsLastForBF) {
				this.getView().getModel("oBrfModel").setProperty("/FileNameBRFSet", null);

			}
			var oBrfModel = this.getView().getModel("oBrfModel");
			var frgText = this.getView().getModel("i18n").getProperty("AddLineItemText");
			oBrfModel.setProperty("/fraggmentText", frgText);
			oBrfModel.setProperty("/linetText", "INVOICE");
			var bDisplay = this.getView().getModel("oBrfModel").getProperty("/Display");
			if (bDisplay === false) {
				var oHeder = oBrfModel.getProperty("/brfHeaderSet");
				oBrfModel.setProperty("/oVisibleSet/attchmentExpnded", false);
				oBrfModel.setProperty("/oVisibleSet/EditAPUrnforNP", true);
				if (oHeder.BrfType && oHeder.ContrlName && oHeder.ContrlEmail) {
					var createBrfFragment = this.getView().createId("createBrfFragment");
					oBrfModel.setSizeLimit(500); /*Added by Satabdi Das on 23-Dec-2020*/
					if (!this._ofragmentBrf) {
						this._ofragmentBrf = sap.ui.xmlfragment(createBrfFragment, "KGO.kgoarrecharge_brf.view.createLineItemForBrf", this);
						this.getView().addDependent(this._ofragmentBrf);
					}

					oBrfModel.setProperty("/oVisibleSet/lineItemVisibleForGF", false);
					oBrfModel.setProperty("/oVisibleSet/lineItemVisibleForMF", true);
					oBrfModel.setProperty("/entityEdit", true); /*Added for defect 63290*/
					this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "addLineItemOkId")).setVisible(true);
					this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "idselectokForedit")).setVisible(false);
					oBrfModel.setProperty("/oVisibleSet/editMode", true);
					oBrfModel.setProperty("/oVisibleSet/amountFieldEditableForCN", true);
					oBrfModel.setProperty("/oVisibleSet/creditNoteAmount", true);
					oBrfModel.setProperty("/oVisibleSet/remaingAmount", true);
					oBrfModel.setProperty("/oVisibleSet/fieldEditable", false); /*Change added on 06-MAY-2020*/
					oBrfModel.setProperty("/oVisibleSet/editReqMF", true);
					oBrfModel.setProperty("/oVisibleSet/editable", true);
					oBrfModel.setProperty("/oVisibleSet/vatEditDisplay", true);
					oBrfModel.setProperty("/oVisibleSet/TaxPointDateEditDisplay", true);
					oBrfModel.setProperty("/LastDateSrv", false); /*Added on 25-May-2020*/
					oBrfModel.setProperty("/DateMandatory", false);
					oBrfModel.setProperty("/CodeMandat", false); /*Added for defect 63418*/
					oBrfModel.setProperty("/CurrencySet", "USD");
					oBrfModel.setProperty("/lineItemBRFSet", {});
					oBrfModel.setProperty("/selectedKeyCreditGl", ""); /*Added for GL account clear on 23-Apr-2021*/
					oBrfModel.setProperty("/SelcKeySetBRF", "");
					oBrfModel.setProperty("/SelcKeyForLocServ", "");
					oBrfModel.setProperty("/oVisibleSet/creditNoteField", false);
					oBrfModel.setProperty("/oVisibleSet/RI", false);
					oBrfModel.setProperty("/oVisibleSet/amountfieldVisible", true);
					oBrfModel.setProperty("/oVisibleSet/creditNoteTypeFieldVisible", false);
					oBrfModel.setProperty("/oVisibleSet/nonCreditNoteText", true);
					oBrfModel.setProperty("/oVisibleSet/postDate", true);
					oBrfModel.setProperty("/oVisibleSet/postDateEdit", true);
					oBrfModel.setProperty("/oVisibleSet/countryComboBox", true);
					oBrfModel.setProperty("/oVisibleSet/editContyCod", false);
					oBrfModel.setProperty("/oVisibleSet/questionPnVisibleBRF", false);
					oBrfModel.setProperty("/oVisibleSet/serviceRenderBox", false);
					oBrfModel.setProperty("/questionSet", []);
					oBrfModel.setProperty("/firstQuestionSet", []);

					if (oHeder.BrfNo) {
						oBrfModel.setProperty("/oVisibleSet/attachVisible", true);
						oBrfModel.setProperty("/oVisibleSet/attchEnable", true);
						oBrfModel.setProperty("/oVisibleSet/attchmentExpnded", false);

					} else {
						oBrfModel.setProperty("/oVisibleSet/attachVisible", false);
					}

					this.byId(sap.ui.core.Fragment.createId("createBrfFragment", "checkboxVatId")).setProperty("enabled", false); //added by prashant
					this.byId(sap.ui.core.Fragment.createId("createBrfFragment", "checkboxVatId")).setProperty("selected", false);
					/*Start of chnage for new comp code 9921 by developer Satabdi Das on 18-Aug-2020*/
					var sCompCode = oHeder.CompanyCode;
					oBrfModel.setProperty("/lineItemBRFSet/CompanyCode", sCompCode);

					/*End of change for new comp code 9921 by developer Satabdi Das on 18-Aug-2020*/
					this.getModel("oBrfModel").setProperty("/oVisibleSet/LastDateSrv", false);
					this.getModel("oBrfModel").setProperty("/oVisibleSet/CRGL160100", false);
					oBrfModel.setProperty("/WhTFldsMandat", false);
					/*Start of change for new doc type field by developer Satabdi Das on 14-Sep-2020*/
					if (sCompCode && sCompCode === "9921") {
						this.getModel("oBrfModel").setProperty("/Bukrs9901", false);
						this.getModel("oBrfModel").setProperty("/Bukrs9921", true);
						this.getView().getModel("oBrfModel").setProperty("/DocumentType", "");
						oBrfModel.setProperty("/oVisibleSet/documentTypeEditCN", true);
						oBrfModel.setProperty("/oVisibleSet/documentTypeNoNCN", true);
						oBrfModel.setProperty("/oVisibleSet/creditNoteDocumentVisible", false);

						this.DocTypeDropDown();
					} else {
						this.getModel("oBrfModel").setProperty("/Bukrs9921", false);
						this.getModel("oBrfModel").setProperty("/Bukrs9901", true);
						oBrfModel.setProperty("/oVisibleSet/creditNoteDocumentVisible", false);
						oBrfModel.setProperty("/oVisibleSet/documentTypeNoNCN", false);

					}
					/*End of change for new doc type field by developer Satabdi Das on 14-Sep-2020*/
					// this.brfMFSearchHelp();
					// this.brfMFLocationService();
					// this.currencyDropDown();
					if (!oBrfModel.getProperty("BRF_MF")) {
						this.brfMFSearchHelp();
					}
					if (!oBrfModel.getProperty("BRF_MFLocServ")) {
						this.brfMFLocationService();
					}

					if (!oHeder.RrfNo) {
						oBrfModel.setProperty("/oVisibleSet/apUrnForMf", false);
						oBrfModel.setProperty("/oVisibleSet/withoutRef", true);
					}

					var oNatureFieldC = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "RequestingMf"));
					jQuery.sap.delayedCall(1000, this, function () {
						if (oNatureFieldC) {
							var objNature = oNatureFieldC.getDomRef();
							if (objNature) {
								objNature.firstElementChild.firstChild.setAttribute("readonly", true);
								//objNature.children[1].setAttribute("readonly", true);
							}
						}
					});
					this.disableAllDatepickerMF(); // after UI Upgrade 
					// var servRenderUS = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "servRenderUS"));
					// servRenderUS.addEventDelegate({
					// 	onAfterRendering: function () {
					// 		var serviceRenderUS = this.$().find('.sapMInputBaseInner');
					// 		var oID = serviceRenderUS[0].id;
					// 		$('#' + oID).attr("disabled", "disabled");
					// 	}
					// }, servRenderUS);

					this._ofragmentBrf.open();
					var oQdropDown = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "comboIdTable"));
					oQdropDown.addEventDelegate({
						onAfterRendering: function () {
							var oQdropDown = this.$().find('.sapMInputBaseInner');
							var oID = oQdropDown[0].id;
							$('#' + oID).attr("disabled", "disabled");
						}
					}, oQdropDown);

					/*var oDatePicker1 = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "LastDateSrv"));
													jQuery.sap.delayedCall(1000, this, function () {
														if (oDatePicker1) {
															var objDate1 = oDatePicker1.getDomRef();
															if (objDate1) {
																objDate1.firstElementChild.firstChild.setAttribute("readonly", true);
															//	objDate1.children[1].setAttribute("readonly", true);
															}
														}
													});
													var oDatePickerDoc = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "DocumentDateMF"));
													jQuery.sap.delayedCall(1000, this, function () {
														if (oDatePickerDoc) {
															var objDate1 = oDatePickerDoc.getDomRef();
															if (objDate1) {
																objDate1.firstElementChild.firstChild.setAttribute("readonly", true);
																//	objDate1.children[1].setAttribute("readonly", true);
															}
														}
													});
					
														var oDatePickerDocPost = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "PostingDateMF"));
													jQuery.sap.delayedCall(1000, this, function () {
														if (oDatePickerDocPost) {
															var objDate1 = oDatePickerDocPost.getDomRef();
															if (objDate1) {
																objDate1.firstElementChild.firstChild.setAttribute("readonly", true);
																//objDate1.children[1].setAttribute("readonly", true);
															}
														}
													});
					
					
													var oDatePicker4 = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "ServicePeriodStartMF"));
													jQuery.sap.delayedCall(1000, this, function () {
														if (oDatePicker4) {
															var objDate4 = oDatePicker4.getDomRef();
															if (objDate4) {
																objDate4.firstElementChild.firstChild.setAttribute("readonly", true);
																//objDate4.children[1].setAttribute("readonly", true);
															}
														}
													});
					
													var oDatePicker5 = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "ServicePeriodEndMF"));
													jQuery.sap.delayedCall(1000, this, function () {
														if (oDatePicker5) {
															var objDate5 = oDatePicker5.getDomRef();
															if (objDate5) {
																objDate5.firstElementChild.firstChild.setAttribute("readonly", true);
																//	objDate5.children[1].setAttribute("readonly", true);
															}
														}
													});
					
													var oNatureField = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "Nature"));
													jQuery.sap.delayedCall(1000, this, function () {
														if (oNatureField) {
															var objNature = oNatureField.getDomRef();
															if (objNature) {
																objNature.firstElementChild.firstChild.setAttribute("readonly", true);
																//objNature.children[1].setAttribute("readonly", true);
															}
														}
													});
					
													var oMFCurrency = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "MFCurr"));
													jQuery.sap.delayedCall(1000, this, function () {
														if (oMFCurrency) {
															var objMFCurr = oMFCurrency.getDomRef();
															if (objMFCurr) {
																objMFCurr.firstElementChild.firstChild.setAttribute("readonly", true);
																//objMFCurr.children[1].setAttribute("readonly", true);
															}
														}
													});
					
													var oRestGL = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "GL9921CR"));
													jQuery.sap.delayedCall(1000, this, function () {
														if (oRestGL) {
															var objRestGL = oRestGL.getDomRef();
															if (objRestGL) {
																objRestGL.firstElementChild.firstChild.setAttribute("readonly", true);
																//	objRestGL.children[1].setAttribute("readonly", true);
																// objRestGL.children[2].setAttribute("readonly", true);
															}
														}
													});
					
													var oMFDocType = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "MFDocType"));
													jQuery.sap.delayedCall(1000, this, function () {
														if (oMFDocType) {
															var objMFDoc = oMFDocType.getDomRef();
															if (objMFDoc) {
																objMFDoc.firstElementChild.firstChild.setAttribute("readonly", true);
																//objMFDoc.children[1].setAttribute("readonly", true);
																//objMFDoc.children[2].setAttribute("readonly", true);
															}
														}
													});
					
														var oTaxPointDate = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "TaxPointDate"));
													jQuery.sap.delayedCall(1000, this, function () {
														if (oTaxPointDate) {
															var objTaxDate = oTaxPointDate.getDomRef();
															if (objTaxDate) {
																objTaxDate.firstElementChild.firstChild.setAttribute("readonly", true);
																//objTaxDate.children[1].setAttribute("readonly", true);
															}
														}
													});
					
													*/
					var oNatureField = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "Nature"));
					jQuery.sap.delayedCall(1000, this, function () {
						if (oNatureField) {
							var objNature = oNatureField.getDomRef();
							if (objNature) {
								objNature.firstElementChild.firstChild.setAttribute("readonly", true);
							}
						}
					});

				} else {

					MessageBox.alert("Please enter mandatory fields.");

				}
			}
		},
		handlePressLinkGlobalBudget: function () {

			var oModelAttachmentsLastForBF = this.getView().getModel("oBrfModel").getProperty("/FileNameBRFSet");
			if (oModelAttachmentsLastForBF) {
				this.getView().getModel("oBrfModel").setProperty("/FileNameBRFSet", null);
			}
			var oBrfModel = this.getView().getModel("oBrfModel");
			var frgText = this.getView().getModel("i18n").getProperty("AddLineItemText");
			oBrfModel.setProperty("/fraggmentText", frgText);
			oBrfModel.setProperty("/linetText", "INVOICE");
			var bDisplay = this.getView().getModel("oBrfModel").getProperty("/Display");
			var oHeder = this.getView().getModel("oBrfModel").getProperty("/brfHeaderSet");
			if (bDisplay === false) {
				this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/attchmentExpnded", false);
				if (oHeder.BrfType && oHeder.ContrlName && oHeder.ContrlEmail) {
					var createBrfFragment = this.getView().createId("createBrfFragment");

					if (!this._ofragmentBrf) {
						this._ofragmentBrf = sap.ui.xmlfragment(createBrfFragment, "KGO.kgoarrecharge_brf.view.createLineItemForBrf", this);
						this.getView().addDependent(this._ofragmentBrf);

					}
					this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/lineItemVisibleForGF", true);
					this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/lineItemVisibleForMF", false);
					this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "addLineItemOkId")).setVisible(true);
					this.getModel("oBrfModel").setProperty("/oVisibleSet/editMode", true);
					this.getModel("oBrfModel").setProperty("/oVisibleSet/editable", true);
					oBrfModel.setProperty("/oVisibleSet/amountFieldEditableForCN", true);
					oBrfModel.setProperty("/oVisibleSet/creditNoteAmount", true);
					oBrfModel.setProperty("/oVisibleSet/vatEditDisplay", true);
					oBrfModel.setProperty("/oVisibleSet/fieldEditable", false); /*Changed on 06-MAY-2020*/
					oBrfModel.setProperty("/oVisibleSet/editReqMF", true);
					oBrfModel.setProperty("/oVisibleSet/reqFnName", true);
					oBrfModel.setProperty("/oVisibleSet/LastDateSrv", false);
					oBrfModel.setProperty("/SelcKeyForLocServ", "NMT");
					this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "idselectokForedit")).setVisible(false);
					oBrfModel.setProperty("/CurrencySet", "USD");
					oBrfModel.setProperty("/lineItemBRFSet", {});
					oBrfModel.setProperty("/oVisibleSet/creditNoteField", false);
					oBrfModel.setProperty("/oVisibleSet/RI", false);
					oBrfModel.setProperty("/oVisibleSet/amountfieldVisible", true);
					oBrfModel.setProperty("/oVisibleSet/creditNoteTypeFieldVisible", false);
					oBrfModel.setProperty("/oVisibleSet/nonCreditNoteText", true);
					oBrfModel.setProperty("/oVisibleSet/remaingAmount", false);
					oBrfModel.setProperty("/oVisibleSet/questionPnVisibleBRF", false);
					oBrfModel.setProperty("/oVisibleSet/serviceRenderBox", false);

					if (oHeder.BrfNo) {
						oBrfModel.setProperty("/oVisibleSet/attachVisible", true);
						oBrfModel.setProperty("/oVisibleSet/attchEnable", true);
						oBrfModel.setProperty("/oVisibleSet/attchmentExpnded", false);
						oBrfModel.setProperty("/oVisibleSet/countryComboBox", false);
						oBrfModel.setProperty("/oVisibleSet/editContyCod", false);

					} else {
						oBrfModel.setProperty("/oVisibleSet/attachVisible", false);
					}

					/*Start of chnage for new comp code 9921 by developer Satabdi Das on 18-Aug-2020*/
					var sCompCode = oHeder.CompanyCode;

					oBrfModel.setProperty("/lineItemBRFSet/CompanyCode", sCompCode);
					/*End of change for new comp code 9921 by developer Satabdi Das on 18-Aug-2020*/
					this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/LocationOfTheServicesReq", "NMT");
					this.getView().getModel("oBrfModel").setProperty("/entityEdit", true);
					this.getModel("oBrfModel").setProperty("/oVisibleSet/GL160100", false);
					this.getModel("oBrfModel").setProperty("/oVisibleSet/CRGL160100", false);
					/*Start of change by developer Satabdi Das on 17-Sep-2020*/
					if (sCompCode && sCompCode === "9921") {
						this.getModel("oBrfModel").setProperty("/Bukrs9901", false);
						this.getModel("oBrfModel").setProperty("/Bukrs9921", true);
						this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/SalesTaxCode", "UO");
						oBrfModel.setProperty("/DocumentType", "JC");
						oBrfModel.setProperty("/oVisibleSet/documentTypeEditCN", true);
						oBrfModel.setProperty("/oVisibleSet/documentTypeNoNCN", true);
						oBrfModel.setProperty("/oVisibleSet/creditNoteDocumentVisible", false);
						oBrfModel.setProperty("/oVisibleSet/documentGf9921", true);
						oBrfModel.setProperty("/oVisibleSet/documentGf9901", false);
						var _dDocument9921Field = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "documentGF9921"));
						jQuery.sap.delayedCall(1000, this, function () {
							if (_dDocument9921Field) {
								var dDocument = _dDocument9921Field.getDomRef();
								if (dDocument) {
									dDocument.firstElementChild.firstChild.setAttribute("readonly", true);
									//	dDocument.children[1].setAttribute("readonly", true);
								}
							}
						});
					} else {
						this.getModel("oBrfModel").setProperty("/Bukrs9901", true);
						this.getModel("oBrfModel").setProperty("/Bukrs9921", false);
						this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/SalesTaxCode", "N0");
						oBrfModel.setProperty("/lineItemBRFSet/DocumentType", "SA");
						oBrfModel.setProperty("/oVisibleSet/creditNoteDocumentVisible", false);
						oBrfModel.setProperty("/oVisibleSet/documentGf9921", false);
						oBrfModel.setProperty("/oVisibleSet/documentGf9901", true);
					}
					/*End of change by developer Satabdi Das on 17-Sep-2020*/
					// this.currencyDropDown();
					if (!oHeder.RrfNo) {
						oBrfModel.setProperty("/oVisibleSet/assigmentUrn", false);
						oBrfModel.setProperty("/oVisibleSet/withoutRef", true);

					}
					this._ofragmentBrf.open();
					var oDatePicker2 = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "DocumentDate"));
					jQuery.sap.delayedCall(1000, this, function () {
						if (oDatePicker2) {
							var objDate2 = oDatePicker2.getDomRef();
							if (objDate2) {
								objDate2.firstElementChild.firstChild.setAttribute("readonly", true);
								//objDate2.children[1].setAttribute("readonly", true);
							}
						}
					});
					var oDatePicker3 = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "PostingDate"));
					jQuery.sap.delayedCall(1000, this, function () {
						if (oDatePicker3) {
							var objDate3 = oDatePicker3.getDomRef();
							if (objDate3) {
								objDate3.firstElementChild.firstChild.setAttribute("readonly", true);
								//objDate3.children[1].setAttribute("readonly", true);
							}
						}
					});
					var oDatePicker4 = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "ServicePeriodStart"));
					jQuery.sap.delayedCall(1000, this, function () {
						if (oDatePicker4) {
							var objDate4 = oDatePicker4.getDomRef();
							if (objDate4) {
								objDate4.firstElementChild.firstChild.setAttribute("readonly", true);
								//objDate4.children[1].setAttribute("readonly", true);
							}
						}
					});
					var oDatePicker5 = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "ServicePeriodEnd"));
					jQuery.sap.delayedCall(1000, this, function () {
						if (oDatePicker5) {
							var objDate5 = oDatePicker5.getDomRef();
							if (objDate5) {
								objDate5.firstElementChild.firstChild.setAttribute("readonly", true);
								//objDate5.children[1].setAttribute("readonly", true);
							}
						}
					});
					var oDatePicker6 = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "ServicePeriodStartCR"));
					jQuery.sap.delayedCall(1000, this, function () {
						if (oDatePicker6) {
							var objDate6 = oDatePicker6.getDomRef();
							if (objDate6) {
								objDate6.firstElementChild.firstChild.setAttribute("readonly", true);
								//	objDate6.children[1].setAttribute("readonly", true);
							}
						}
					});
					var oDatePicker7 = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "ServicePeriodEndCR"));
					jQuery.sap.delayedCall(1000, this, function () {
						if (oDatePicker7) {
							var objDate7 = oDatePicker7.getDomRef();
							if (objDate7) {
								objDate7.firstElementChild.firstChild.setAttribute("readonly", true);
								//	objDate7.children[1].setAttribute("readonly", true);
							}
						}
					});
					var oGFCurrency = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "CurrGF"));
					jQuery.sap.delayedCall(1000, this, function () {
						if (oGFCurrency) {
							var objGFCurr = oGFCurrency.getDomRef();
							if (objGFCurr) {
								objGFCurr.firstElementChild.firstChild.setAttribute("readonly", true);
								//	objGFCurr.children[1].setAttribute("readonly", true);
							}
						}
					});
				} else {
					MessageBox.alert("Please enter mandatory fields.");
				}
			}
		},
		handlePressLinkClose: function (oEvent) {
			var oBrfModel = this.getView().getModel("oBrfModel");
			var btniId = oEvent.getParameter("id").split("--")[2]; /*Change added for INC01499658 ON 22-APR-2021*/
			var sCompCode = oBrfModel.getProperty("/brfHeaderSet").CompanyCode;
			if (this.oStorePath) {
				var z = this.oStorePath.split("/")[2];
				z = parseInt(z);
			}
			if (btniId !== "lineItemCancel") {
				this.oStoreData.DocumentType = oBrfModel.getProperty("/DocumentType");
			}
			var longTextAtcancel = oBrfModel.getProperty("/longTextSetCancel");
			var oLttCheckbox = this.byId(sap.ui.core.Fragment.createId("createBrfFragment", "checkboxVatId")).getProperty("selected");
			var displyPress = oBrfModel.getProperty("/oDisplayBtnPress");
			var bManual = oBrfModel.getProperty("/oVisibleSet/withoutRef"); /*Aded for Defect 63418*/
			var oLineData = oBrfModel.getProperty("/lineItemBRFSet");
			var bReqFlag = oBrfModel.getData().lineItemBRFSet.EditReqMf;
			var sBR = oBrfModel.getData().brfHeaderSet.BrfNo;
			var oLineTbl = this.getView().byId('tableid');
			var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
			var that = this;
			if (this.documentdate) {
				oLineData.DocumentDate = this.documentdate;
				this.documentdate = "";
			}
			if (this.Postingdate) {
				oLineData.PostingDate = this.Postingdate;
				this.Postingdate = "";
			}

			//setting amount 
			if (this.oPressCNflag === true && btniId === "lineItemCancel") {
				oLineData.RechargeAmountDebit = oBrfModel.getProperty("/oReSetDataOfCN").oRechargeAmountDebitCNline;
				oLineData.RechargeAmountCredit = oBrfModel.getProperty("/oReSetDataOfCN").oRechargeAmountCreditCNline;
				oLineData.AddlDescAbove = oBrfModel.getProperty("/oReSetDataOfCN").AddlDescAboveCN;
				oLineData.AdlDescription = oBrfModel.getProperty("/oReSetDataOfCN").oAdlDescriptionCNLine;
				oLineData.DetailsDescriptionOfServic = oBrfModel.getProperty("/oReSetDataOfCN").oDetailsDescriptionOfServicCNLINE;
				oLineData.DocumentDate = oBrfModel.getProperty("/oReSetDataOfCN").DocumDate;
				oLineData.PostingDate = oBrfModel.getProperty("/oReSetDataOfCN").PostDate;
				oLineData.LongText = oBrfModel.getProperty("/oReSetDataOfCN").LongTextCreditNote;
				//oBrfModel.setProperty("/lineItemBRFSet/LongText", longTextAtcancel);
				this.oPressCNflag = false;
			} else {
				this.oPressCNflag = false;
			}

			for (var i = 0; i < oLineTbl.getItems().length; i++) {
				var EditDisplay = oLineTbl.getBindingInfo("items").binding.oList[i].EditDisplay;
				if (EditDisplay === "X") {
					var x = oLineTbl.getAggregation("items")[i];
					x.getMultiSelectControl().setEnabled(false);
				} else if (displyPress === "true") {
					x = oLineTbl.getAggregation("items")[i];
					x.getMultiSelectControl().setEnabled(false);
				}

			}

			if ((btniId === "idselectokForedit" && displyPress !== "true")) {
				if (oLineData.GlobalCc !== "N/A") {
					if (oLineData.DebitGl && (oLineData.DebitGl === "160100" || oLineData.DebitGl === "320150") && (oLineData.ExpenseGl === "" ||
							oLineData.AccrTrackNo === "" || oLineData.ExpenseGl === undefined || oLineData.AccrTrackNo === undefined)) {
						MessageBox.error(
							that.getView().getModel("i18n").getProperty("AccruMandt"), {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}
						);
						return;
					}
					if (oLineData.CreditGl && (oLineData.CreditGl === "160100" || oLineData.CreditGl === "320150") && (oLineData.ExpenseGlCredit ===
							"" || oLineData.AccrTrackNoCredit === "" || oLineData.ExpenseGlCredit === undefined ||
							oLineData.AccrTrackNoCredit === undefined)) {
						MessageBox.error(
							that.getView().getModel("i18n").getProperty("AccruMandt"), {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}
						);
						return;
					}
				}
				if (oLineData.RequestingMf !== "N/A") {
					/*Start of defect 63419*/
					// if (oLineData.LocationOfTheServicesReq === "US" && !oLineData.LocOfRenderingUs) {
					// 	var sServRender = this.getView().getModel("i18n").getProperty("locationServRender");
					// 	MessageBox.alert(sServRender);
					// 	return;
					// }

					if ((oLineData.RequestingMf === "US" || oLineData.RequestingMf === "NL") && (oLineData.MfCostCenter === undefined || oLineData.MfCostCenter ===
							"")) {
						var sMsg = this.getView().getModel("i18n").getProperty("projectcodeMandat");
						MessageBox.alert(sMsg);
						return;
					}

					/*End of defect 63418*/
					if (oLineData.WhtCode && oLineData.WhtCode !== "" && oLineData.WhtCode !== "N/A") {
						if (oLineData.LineItemTotal === "" || oLineData.LineItemTotal === undefined || oLineData.DebitGl === "" || oLineData.DebitGl ===
							undefined || oLineData.ProfitCenterDebit === "" || oLineData.ProfitCenterDebit === undefined) { /*changed by Satabdi Das for defect 63464*/
							var sMsg = this.getView().getModel("i18n").getProperty("whTMandtMsg");
							MessageBox.alert(sMsg);
							return;
						}

					}
					if (oLineData.NatureOfService && oLineData.NatureOfService !== "" && oLineData.NatureOfService === "Adhoc/One-Off") {
						if (oLineData.LastDateSrv === "" || oLineData.LastDateSrv === undefined || oLineData.LastDateSrv === "00000000") {
							var sMsg = this.getView().getModel("i18n").getProperty("lastDateMandat");
							MessageBox.alert(sMsg);
							return;
						}

					}
					if (oLineData.CreditGl && (oLineData.CreditGl === "160100" || oLineData.CreditGl === "320150") && (oLineData.ExpenseGlCredit ===
							"" || oLineData.AccrTrackNo === "" || oLineData.ExpenseGlCredit === undefined ||
							oLineData.AccrTrackNo === undefined)) {
						/*Start of change by Satabdi Das on 05-March-2021 for SCTASK1838272*/
						if (sCompCode !== "9921") {
							MessageBox.error(
								that.getView().getModel("i18n").getProperty("AccruMandt"), {
									styleClass: bCompact ? "sapUiSizeCompact" : ""
								}
							);
							return;
						} else if (sCompCode === "9921") {
							MessageBox.error(
								that.getView().getModel("i18n").getProperty("AccruMandt_9921"), {
									styleClass: bCompact ? "sapUiSizeCompact" : ""
								}
							);
							return;
						}
						/*End of change by Satabdi Das on 05-March-2021 for SCTASK1838272*/
					}

					/*Start of change by developer Satabdi Das for defect 63391 on 21-Jan-2021*/
					if (oLineData.AttenBrf === "" || oLineData.AttenBrf === undefined || oLineData.AttenBrfEmail === "" || oLineData.AttenBrfEmail ===
						undefined) {
						var sMsg = this.getView().getModel("i18n").getProperty("MandtFldAlert");
						MessageBox.alert(sMsg);
						return;
					}
					/*End of change by developer Satabdi Das for defect 63391 on 21-Jan-2021*/
				}

				if ((parseFloat(oLineData.RechargeAmountDebit) === parseFloat(oLineData.RechargeAmountCredit)) || (oLineData.RechargeAmountDebit ===
						"" && oLineData.RechargeAmountCredit === "") || (oLineData.RechargeAmountDebit ===
						undefined && oLineData.RechargeAmountCredit === undefined)) {

					var questionTable = oBrfModel.getProperty("/questionSet");
					var _firstQuestionData = oBrfModel.getProperty("/firstQuestionSet");
					if (questionTable && questionTable.length > 0) {
						var messageFlag = false;
						var submitSet = oBrfModel.getProperty("/questionSetSubmit");
						for (var i = 0; i < questionTable.length; i++) {
							for (var j = 0; j < submitSet.length; j++) {
								if (submitSet[j].RequestingMf === oBrfModel.getProperty("/questionSet")[i].RequestingMf && submitSet[j].MemberFirm ===
									oBrfModel.getProperty("/questionSet")[i].MemberFirm && submitSet[j].ProcessGrp === oBrfModel.getProperty(
										"/questionSet")[i].ProcessGrp) {
									if (!oBrfModel.getProperty("/questionSet")[i].Answer || oBrfModel.getProperty("/questionSet")[i].Answer === " ") {
										messageFlag = true;
										break;
									}

									if (oBrfModel.getProperty("/questionSet")[i].Answer === "Other" && !oBrfModel.getProperty("/questionSet")[i].AnswerDesc) {
										var messageFlag = true;
										break;
									}
									if (submitSet[j].Question === oBrfModel.getProperty("/questionSet")[i].Question && submitSet[j].TransactionType === oBrfModel
										.getProperty("/questionSet")[i].TransactionType) {
										oBrfModel.getProperty("/questionSetSubmit")[j].Answer = oBrfModel.getProperty("/questionSet")[i].Answer;
										oBrfModel.getProperty("/questionSetSubmit")[j].AnswerDesc = oBrfModel.getProperty("/questionSet")[i].AnswerDesc;

									}
								}
							}
						}
					}

					if (_firstQuestionData && _firstQuestionData.length > 0) {
						for (var k = 0; k < submitSet.length; k++) {
							if (submitSet[k].RequestingMf === _firstQuestionData[0].RequestingMf && submitSet[k].MemberFirm === _firstQuestionData[0].MemberFirm &&
								submitSet[k].ProcessGrp === _firstQuestionData[0].ProcessGrp && submitSet[k].LineType === _firstQuestionData[0].LineType &&
								submitSet[k].TransactionType === _firstQuestionData[0].TransactionType) {
								if (submitSet[k].Question === _firstQuestionData[0].Question) {
									oBrfModel.getProperty("/questionSetSubmit")[k].Answer = _firstQuestionData[0].Answer;
								}

							}

						}
					}

					if (messageFlag === true) {
						var questionnaDetailMissing2 = this.getModel("i18n").getProperty("questionnaDetailMissing2");
						MessageBox.alert(questionnaDetailMissing2);
						return true;
					}

					this._ofragmentBrf.close();

				} else if ((oLineData.RechargeAmountDebit) && !oLineData.RechargeAmountCredit) {
					MessageBox.alert("Credit amount is missing.");
					return;
				} else if ((oLineData.RechargeAmountCredit) && !oLineData.RechargeAmountDebit) {
					MessageBox.alert("Debit amount is missing.");
				} else {
					MessageBox.alert("Debit and credit amount should be equal.");
				}

				this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/vatEditDisplay", true);
				this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/attchmentExpnded", false);
			} else if (btniId === "lineItemCancel") {
				if (oLineData.RequestingMf !== "N/A" && displyPress !== "true") { /*Change added by Satabdi Das on 08-Sep-2020*/
					if (sBR && (bReqFlag && bReqFlag === true)) {
						if (oLineData.WhtCode && oLineData.WhtCode !== "" && oLineData.WhtCode !== "N/A") {
							if (oLineData.LineItemTotal === "" || oLineData.LineItemTotal === undefined || oLineData.DebitGl === "" || oLineData.DebitGl ===
								undefined || oLineData.ProfitCenterDebit === "" || oLineData.ProfitCenterDebit === undefined) { /*changed by Satabdi Das for defect 63464*/
								var sMsg = this.getView().getModel("i18n").getProperty("whTMandtMsg");
								MessageBox.alert(sMsg);
								return;
							}
						}
					}
				}
				this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/vatEditDisplay", true);
				this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/attchmentExpnded", false);

				/*Start of change by developer Satabdi Das on 05-Jan-2021*/
				if (oBrfModel.getProperty("/oReSetDataOfRI") && (oLineData.LineType === "INVOICE" && this.oPressRIflag === true) && (oLineData.BrfNo !==
						"")) {

					oLineData.FiDocNo = oBrfModel.getProperty("/oReSetDataOfRI").FiDocNoRI;
					oLineData.InvoiceStatus = oBrfModel.getProperty("/oReSetDataOfRI").InvoiceStatusRI;
					oLineData.LineStatus = oBrfModel.getProperty("/oReSetDataOfRI").LineStatusRI;
					/*Start for defect 63833 on 14-Jan-2021*/
					oLineData.NatureOfService = oBrfModel.getProperty("/oReSetDataOfRI").NatureOfServiceRI;
					oLineData.LastDateSrv = oBrfModel.getProperty("/oReSetDataOfRI").LastDateSrvRI;
					this.oPressRIflag = false;
					/*End for defect 63833 on 14-Jan-2021*/
				} else {
					this.oPressRIflag = false;
				}

				/*End of change by developer Satabdi Das on 05-Jan-2021*/

				if (this._ofragmentBrf.isOpen()) {

					//questionnaire changes by prashant kumar 20.04.2020 
					var questionTable = oBrfModel.getProperty("/questionSet");
					var _firstQuestionData = oBrfModel.getProperty("/firstQuestionSet");
					if (questionTable && questionTable.length > 0) {
						var messageFlag = false;
						var submitSet = oBrfModel.getProperty("/questionSetSubmit");
						for (var i = 0; i < questionTable.length; i++) {
							for (var j = 0; j < submitSet.length; j++) {
								if (submitSet[j].RequestingMf === oBrfModel.getProperty("/questionSet")[i].RequestingMf && submitSet[j].MemberFirm ===
									oBrfModel.getProperty("/questionSet")[i].MemberFirm && submitSet[j].ProcessGrp === oBrfModel.getProperty(
										"/questionSet")[i].ProcessGrp) {

									if (!oBrfModel.getProperty("/questionSet")[i].Answer || oBrfModel.getProperty("/questionSet")[i].Answer === " ") {
										messageFlag = true;
										break;
									}

									if (oBrfModel.getProperty("/questionSet")[i].Answer === "Other" && !oBrfModel.getProperty("/questionSet")[i].AnswerDesc) {
										messageFlag = true;
										break;
									}
									if (submitSet[j].Question === oBrfModel.getProperty("/questionSet")[i].Question && submitSet[j].TransactionType === oBrfModel
										.getProperty("/questionSet")[i].TransactionType) {
										oBrfModel.getProperty("/questionSetSubmit")[j].Answer = oBrfModel.getProperty("/questionSet")[i].Answer;
										oBrfModel.getProperty("/questionSetSubmit")[j].AnswerDesc = oBrfModel.getProperty("/questionSet")[i].AnswerDesc;

									}
								}
							}
						}
					}

					if (_firstQuestionData && _firstQuestionData.length > 0) {
						for (var k = 0; k < submitSet.length; k++) {
							if (submitSet[k].RequestingMf === _firstQuestionData[0].RequestingMf && submitSet[k].MemberFirm === _firstQuestionData[0].MemberFirm &&
								submitSet[k].ProcessGrp === _firstQuestionData[0].ProcessGrp && submitSet[k].LineType === _firstQuestionData[0].LineType &&
								submitSet[k].TransactionType === _firstQuestionData[0].TransactionType) {
								if (submitSet[k].Question === _firstQuestionData[0].Question) {
									oBrfModel.getProperty("/questionSetSubmit")[k].Answer = _firstQuestionData[0].Answer;
								}

							}

						}
					}
					/*QA Defect - 64291 - 1st Nov 2021 - displyPress === "false" && btniId !== "lineItemCancel" added*/
					if (messageFlag === true && displyPress === "false" && btniId !== "lineItemCancel") {
						var questionnaDetailMissing2 = this.getModel("i18n").getProperty("questionnaDetailMissing2");
						MessageBox.alert(questionnaDetailMissing2);
						return true;
					}

					this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet", {});
					this._ofragmentBrf.close();

				}
			}

			for (var j = 0; j < oLineTbl.getItems().length; j++) {
				if (oLineTbl.getBindingInfo("items").binding.oList[j].RequestingMf && oLineTbl.getBindingInfo("items").binding.oList[j].RequestingMf !==
					"N/A") {

					var oValidateValue = oLineTbl.getBindingInfo("items").binding.oList[j];
					oLineTbl.getAggregation("items")[j].getCells()[7].setProperty("visible", true);
					if (oLineTbl.getBindingInfo("items").binding.oList[j].Ltt === "X") {
						oLineTbl.getAggregation("items")[j].getCells()[7].setProperty("selected", true);
					} else {
						oLineTbl.getAggregation("items")[j].getCells()[7].setProperty("selected", false);
					}

					if (oValidateValue.CnFlag === "X" && oValidateValue.LineStatus === "POSTED") {
						oLineTbl.getAggregation("items")[j].getCells()[9].setProperty("visible", true);
					} else {
						oLineTbl.getAggregation("items")[j].getCells()[9].setProperty("visible", false);
						// oLineTbl.getAggregation("items")[j].getCells()[10].setProperty("visible", false);
					}
					if (oValidateValue.RiFlag === "X") {
						oLineTbl.getAggregation("items")[j].getCells()[10].setProperty("visible", true);
						oLineTbl.getAggregation("items")[j].getCells()[10].setProperty("enabled", true);
					} else if (oValidateValue.RiFlag === "") {
						oLineTbl.getAggregation("items")[j].getCells()[10].setProperty("visible", false);
					}

				} else {
					oLineTbl.getAggregation("items")[j].getCells()[7].setProperty("visible", false);
					oLineTbl.getAggregation("items")[j].getCells()[9].setProperty("visible", false);

				}
			}

		},
		onSelectingDocumentDate: function (oEvent) {
			var documentdate;
			if (oEvent.getParameter("value").split(" ").length === 3) {
				var month = oEvent.getParameter("value").split(" ")[1];
				var year = oEvent.getParameter("value").split(" ")[2];
				var day = oEvent.getParameter("value").split(" ")[0];
				switch (month) {
				case "January":
					month = "01";
					break;
				case "February":
					month = "02";
					break;
				case "March":
					month = "03";
					break;
				case "April":
					month = "04";
					break;
				case "May":
					month = "05";
					break;
				case "June":
					month = "06";
					break;
				case "July":
					month = "07";
					break;
				case "August":
					month = "08";
					break;
				case "September":
					month = "09";
					break;
				case "October":
					month = "10";
					break;
				case "November":
					month = "11";
					break;
				case "December":
					month = "12";
					break;
				}
				this.documentdate = year + month + day;
			} else {
				this.documentdate = oEvent.getParameter("value");
			}
		},
		onSelectingPostingDate: function (oEvent) {
			var Postingdate;
			if (oEvent.getParameter("value").split(" ").length === 3) {
				var month = oEvent.getParameter("value").split(" ")[1];
				var year = oEvent.getParameter("value").split(" ")[2];
				var day = oEvent.getParameter("value").split(" ")[0];
				switch (month) {
				case "January":
					month = "01";
					break;
				case "February":
					month = "02";
					break;
				case "March":
					month = "03";
					break;
				case "April":
					month = "04";
					break;
				case "May":
					month = "05";
					break;
				case "June":
					month = "06";
					break;
				case "July":
					month = "07";
					break;
				case "August":
					month = "08";
					break;
				case "September":
					month = "09";
					break;
				case "October":
					month = "10";
					break;
				case "November":
					month = "11";
					break;
				case "December":
					month = "12";
					break;
				}
				this.Postingdate = year + month + day;
			} else {
				Postingdate = oEvent.getParameter("value");
			}
		},
		onEnterProcessofBrf: function (oEvent) {
			var format = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/;
			if (format.test(oEvent.getParameter("value"))) {
				var specialMsg = this.getModel("i18n").getProperty("specialchMsg");
				MessageBox.error(specialMsg);
				return true;
			} else {
				return false;
			}
		},
		onSubmitBrf: function (oEvent) {
			var oBrfModel = this.getView().getModel("oBrfModel");
			var checkDispBtn = this.getView().getModel("oBrfModel").getProperty("/oDisplayBtnPress");
			var that = this;
			if (checkDispBtn === "false" || (!checkDispBtn)) {
				//var bDisplay = this.getView().getModel("oBrfModel").getProperty("/Display");
				var bDisplay = false; //added for submit for credit note
				var brfHederData = this.getView().getModel("oBrfModel").getProperty("/brfHeaderSet");
				if (bDisplay === false) {
					if (brfHederData.BrfType && brfHederData.CompanyCode && brfHederData.ContrlName && brfHederData.ContrlEmail) {
						var action = "SUBMIT";

						sap.ui.core.BusyIndicator.show(0);
						/*Validation start for header amount */
						if (brfHederData.InvoiceAmount === "") {
							brfHederData.InvoiceAmount = "0.00";
						}
						if (brfHederData.NetAmount === "") {
							brfHederData.NetAmount = "0.00";
						}
						/*Validation end for header amount */

						var oPayLoad = {
							CompanyCode: brfHederData.CompanyCode,
							BrfType: brfHederData.BrfType,
							BrfCreatedBy: brfHederData.BrfCreatedBy,
							BrfCreatorName: brfHederData.BrfCreatorName,
							/* Added by Satabdi Das on 15-Jan-2021 for defect 63786*/
							BrfNo: brfHederData.BrfNo,
							BrfStatus: brfHederData.BrfStatus,
							Action: action,
							CntrlApprName: brfHederData.CntrlApprName,
							VatApprName: brfHederData.VatApprName,
							ArApprName: brfHederData.ArApprName,
							BrfDesc: brfHederData.BrfDesc,
							BrfCreationDate: brfHederData.BrfCreationDate,
							OfcBillNo: brfHederData.OfcBillNo,
							OfcInvoicNo: brfHederData.OfcInvoicNo,
							InvoicDate: brfHederData.InvoicDate,
							ContrlName: brfHederData.ContrlName,
							ContrlEmail: brfHederData.ContrlEmail,
							Gjahr: brfHederData.Gjahr,
							RrfNo: brfHederData.RrfNo,
							InvoiceAmount: brfHederData.InvoiceAmount,
							SchDate: brfHederData.SchDate,
							/*GrossAmtLocal: brfHederData.GrossAmtLocal,
							CurrencyLocal: brfHederData.CurrencyLocal,*/
							NetAmount: brfHederData.NetAmount,
							DocCurrency: brfHederData.DocCurrency,
							SapDocYear: brfHederData.SapDocYear,
							SapDocNum: brfHederData.SapDocNum,
							BukrsUrn: brfHederData.BukrsUrn,
							Manual: brfHederData.Manual,
							Urn: brfHederData.Urn,

							/*Added for new Comp Code 9921 by Satabdi Das*/
							BRFItemSet: [],
							BRF_AnswerSet: []

						};
						var that = this;
						var fnSuccess = jQuery.proxy(function (d) {
							oBrfModel.setProperty("/brfHeaderSet/BrfNo", d.BrfNo);
							sap.ui.core.BusyIndicator.hide(0);
							if (d.Flag) {
								var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
								MessageBox.error(
									d.Message, {
										styleClass: bCompact ? "sapUiSizeCompact" : ""
									}
								);
							} else {
								MessageBox.show(
									d.Message, {
										icon: MessageBox.Icon.SUCCESS,
										title: "Success",
										actions: [MessageBox.Action.OK],
										onClose: function (oAction) {
											if (oAction === "OK") {
												sap.ui.core.BusyIndicator.show(0);
												that.handlePressEditBRF();
											}

											// var oRouter = UIComponent.getRouterFor(that);
											// oRouter.navTo("TargetBrfHomeView");

										}
									}
								);
								this.getModel("oBrfModel").setProperty("/lineItemBRFSet/RequestingMf", ""); /*Chnage added on 09-Jan-2020*/
								/*Start of chnage for defect 63096 on 31-Jan-2020*/
								var oTable = that.getView().byId("tableid");
								oTable.removeSelections(true);
								/*End of chnage for defect 63096 on 31-Jan-2020*/
							}
						}, this);
						var fnError = jQuery.proxy(function (d) {
							sap.ui.core.BusyIndicator.hide(0);
							var r = JSON.parse(JSON.stringify(d));
							sap.ui.core.BusyIndicator.hide();
							MessageToast.show(r.message, {
								autoClose: true,
								width: "20rem"
							});
						}, this);
						var objectOne = {};
						var arr = [];
						var TableData = [];
						var arrAnsware = [];
						var _answre = [];
						var LineNO;
						objectOne.successCallback = fnSuccess;
						objectOne.errorCallback = fnError;
						arr = this.getView().getModel("oBrfModel").getProperty("/brfTableSet");
						//questionnaire changes brf prashant kumar 16.03.2021
						arrAnsware = this.getModel("oBrfModel").getProperty("/questionSetSubmit");
						for (var t = 0; t < arrAnsware.length; t++) {
							var objAns = {};
							objAns.GlobalCc = brfHederData.GlobalCc;
							objAns.MemberFirm = arrAnsware[t].MemberFirm;
							objAns.Question = arrAnsware[t].Question;
							objAns.RequestingMf = arrAnsware[t].RequestingMf;
							objAns.Answer = arrAnsware[t].Answer;
							objAns.InternalExternal = arrAnsware[t].InternalExternal;
							objAns.AnswerDesc = arrAnsware[t].AnswerDesc;
							objAns.LineType = arrAnsware[t].LineType;
							objAns.TransactionType = arrAnsware[t].TransactionType;
							objAns.ProcessGrp = arrAnsware[t].ProcessGrp;
							objAns.CompanyCode = brfHederData.CompanyCode;
							objAns.BrfNo = brfHederData.BrfNo;
							_answre.push(objAns);

						}
						oPayLoad.BRF_AnswerSet = _answre;

						//validation for LineItem  start
						var msg = this.getView().getModel("i18n").getProperty("NoLineItemAlert");
						var sMsg2 = this.getView().getModel("i18n").getProperty("SaveMandtAlert"); /*Added by Satabdi Das on 17-Sep-2020*/
						if (!arr) {
							sap.ui.core.BusyIndicator.hide(0);
							var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
							MessageBox.alert(
								msg, {
									styleClass: bCompact ? "sapUiSizeCompact" : ""
								}

							);
							return;
						}
						// else if (arr.length === 0) {
						// 	sap.ui.core.BusyIndicator.hide();
						// 	var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
						// 	MessageBox.alert(
						// 		msg, {
						// 			styleClass: bCompact ? "sapUiSizeCompact" : ""
						// 		}
						// 	);
						// 	return;
						// }  
						else if (brfHederData.BrfNo) {
							if (arr.length > 0) {
								for (var i = 0; i < arr.length; i++) {
									/*Start of defect 63367*/
									if (arr[i].ServicePeriodStart === "00000000") {
										arr[i].ServicePeriodStart = "";
									}
									if (arr[i].ServicePeriodEnd === "00000000") {
										arr[i].ServicePeriodEnd = "";
									}
									if (arr[i].ServicePeriodStartCredit === "00000000") {
										arr[i].ServicePeriodStartCredit = "";
									}
									if (arr[i].ServicePeriodEndCredit === "00000000") {
										arr[i].ServicePeriodEndCredit = "";
									}
									/*End of defect 63367*/

									if ((arr[i].RequestingMf != "N/A") && (arr[i].GlobalCc === "N/A") && (arr[i].LineStatus)) {
										if (!arr[i].RechargeAmountDebit || !arr[i].RechargeAmountCredit || !arr[i].CreditGl || (!arr[i].DetailsDescriptionOfServic &&
												!arr[i].LongText) ||
											!arr[i].ServicePeriodStart || !arr[i].ServicePeriodEnd ||
											arr[i].ServicePeriodStart === "" || arr[i].ServicePeriodEnd === "" ||
											!arr[i].LocationOfTheServicesReq || arr[i].LocationOfTheServicesReq === "" || !arr[i].NatureOfService || arr[i].NatureOfService ===
											"" || !arr[i].VatSapCode || arr[i].VatSapCode === "" || !arr[i].AdlDescription ||
											arr[i].AdlDescription === "" || !arr[i].AttenBrf || arr[i].AttenBrf ===
											"" || !arr[i].AttenBrfEmail || arr[i].AttenBrfEmail === "") { /*Added for defect 63391 on 21-Jan-2021*/
											LineNO = i + 1;
											sap.ui.core.BusyIndicator.hide();
											MessageBox.alert(sMsg2 + LineNO);
											return;
										}

										/*Start of change for new doc type field by developer Satabdi Das on 15-Sep-2020*/
										if (arr[i].CompanyCode === "9921") {
											if (!arr[i].DocumentType || arr[i].DocumentType === "") {
												LineNO = i + 1;
												sap.ui.core.BusyIndicator.hide();
												MessageBox.alert(sMsg2 + LineNO);
												return;
											}
										}
										/*End of change for new doc type field by developer Satabdi Das on 15-Sep-2020*/

									} else if ((arr[i].RequestingMf === "N/A") && (arr[i].GlobalCc != "N/A") && (arr[i].LineStatus)) {
										if (!arr[i].RechargeAmountDebit || !arr[i].RechargeAmountCredit || !arr[i].CreditGl || !arr[i].DebitGl || !arr[i].ServicePeriodStart ||
											!arr[i].ServicePeriodEnd || !arr[i].ServicePeriodStartCredit || !arr[i].ServicePeriodEndCredit ||
											arr[i].ServicePeriodStart === "" || arr[i].ServicePeriodEnd === "" || arr[i].ServicePeriodStartCredit === "" || arr[i].ServicePeriodEndCredit ===
											"" || !arr[i].LocationOfTheServicesReq || arr[i].LocationOfTheServicesReq === "" || !arr[i].AdlDescription ||
											arr[i].AdlDescription === "") { /*Added for defect 63367*/ /*Added for defect 63737 on 17-Nov-2020*/
											LineNO = i + 1;
											sap.ui.core.BusyIndicator.hide();
											MessageBox.alert(sMsg2 + LineNO);
											return;
										}
									}

								}
							}
						}
						if (arr) {
							for (var i in arr) {
								if (arr[i].RechargeAmountDebit === "") {
									arr[i].RechargeAmountDebit = "0.00";
								}
								if (arr[i].RechargeAmountCredit === "") {
									arr[i].RechargeAmountCredit = "0.00";
								}
								/*Start of change for INC01533653 by developer Satabdi Das on 28-May-2021*/
								if (arr[i].LineItemTotal === "") {
									arr[i].LineItemTotal = "0.00";
								}
								/*End of change for INC01533653 by developer Satabdi Das on 28-May-2021*/
								if (arr[i].RequestingMf === "N/A" && arr[i].LocationOfTheServicesReq === "") {
									arr[i].LocationOfTheServicesReq = "NMT";
								}
								var fields = Object.keys(arr[i]);
								var obj = {};
								for (var j = 0; j < fields.length; j++) {
									if (fields[j] !== "__metadata") {
										obj[fields[j]] = arr[i][fields[j]];
									}
								}
								TableData.push(obj);
							}
							// oPayLoad.BRFItemSet = arr;
							oPayLoad.BRFItemSet = TableData;
							DataManagerBrf.CreateBRFData(oPayLoad, objectOne);
						}
					} else {
						MessageBox.information("Please enter mandatory field.");
					}
				}
			}
		},
		handlePressbtnOkForBrf: function (oEvent) {
			var oBrfModel = this.getView().getModel("oBrfModel");
			var bDisplay = oBrfModel.getProperty("/Display");
			var bManual = oBrfModel.getProperty("/oVisibleSet/withoutRef"); /*Aded for Defect 63418*/
			var LineTEXt = oBrfModel.getProperty("/linetText");
			var questionMess = false;
			var dupiLicateFlag = false;
			var sCompCode = oBrfModel.getProperty("/brfHeaderSet").CompanyCode;
			var format = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/;

			if (bDisplay === false || LineTEXt === "CREDITNOTE") {
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				var that = this;
				var oLineItemData = this.getView().getModel("oBrfModel").getProperty("/lineItemBRFSet");
				oLineItemData.LineType = LineTEXt;
				var oBRFNo = this.getView().getModel("oBrfModel").getProperty("/brfHeaderSet").BrfNo;
				var questionTable = oBrfModel.getProperty("/questionSet");
				var _qfirstQuestionData = oBrfModel.getProperty("/firstQuestionSet");
				var sCurrency = this.getView().getModel("oBrfModel").getProperty("/CurrencySet");
				oLineItemData.Curr1 = sCurrency;
				this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/attchmentExpnded", false);
				var selectedCountry = this.getView().getModel("oBrfModel").getProperty("/SelcKeySetBRF");
				oLineItemData.Curr1 = sCurrency;
				//special character validationcheck
				var oTblBRF = this.getView().byId("tableid");
				if (oLineItemData.ProcessGrp) {
					if (format.test(oLineItemData.ProcessGrp)) {
						var specialMsg = this.getModel("i18n").getProperty("specialchMsg");
						MessageBox.error(specialMsg);
						return true;
					}
				}

				if (!oLineItemData.GlobalCc && oLineItemData.RequestingMf === "N/A") {
					this.getView().getModel("oBrfModel").setProperty("/SelcKeySetBRF", "");
				}

				if (!oLineItemData.GlobalCc && oLineItemData.RequestingMf) {
					oLineItemData.GlobalCc = "N/A";
					oLineItemData.CcShortDesc = "";

				}
				if (!oLineItemData.RequestingMf && oLineItemData.GlobalCc) {
					oLineItemData.RequestingMf = "N/A";
					oLineItemData.MemberFirm = "";
					if (oLineItemData.CompanyCode === "9921") {
						oLineItemData.DocumentType = oBrfModel.getProperty("/DocumentType");

					}

				}
				/*Stsrt of defect 63418*/
				if (bManual === true && oLineItemData.RequestingMf !== "N/A") {
					if (oLineItemData.NatureOfService === "" || oLineItemData.NatureOfService === undefined || oLineItemData.LocationOfTheServicesReq ===
						"" || oLineItemData.LocationOfTheServicesReq === undefined) {
						var sMsg = this.getView().getModel("i18n").getProperty("MandtFldAlert");
						MessageBox.alert(sMsg);
						return;
					}
					if ((oLineItemData.RequestingMf === "US" || oLineItemData.RequestingMf === "NL") && (oLineItemData.MfCostCenter ===
							"" || oLineItemData.MfCostCenter === undefined)) {
						var sMsg = this.getView().getModel("i18n").getProperty("projectcodeMandat");
						MessageBox.alert(sMsg);
						return;
					}

				}
				/*End of defect 63418*/
				if (oLineItemData.RequestingMf !== "N/A") {
					if (oLineItemData.WhtCode && oLineItemData.WhtCode !== "" && oLineItemData.WhtCode !== "N/A") {
						if (oLineItemData.LineItemTotal === "" || oLineItemData.LineItemTotal === undefined || oLineItemData.DebitGl === "" ||
							oLineItemData.DebitGl === undefined || oLineItemData.ProfitCenterDebit === "" || oLineItemData.ProfitCenterDebit === undefined) { /*changed by Satabdi Das for defect 63464*/
							var sMsg = this.getView().getModel("i18n").getProperty("whTMandtMsg");
							MessageBox.alert(sMsg);
							return;
						}

					}
					if (oLineItemData.NatureOfService && oLineItemData.NatureOfService !== "" && oLineItemData.NatureOfService === "Adhoc/One-Off") {
						if (oLineItemData.LastDateSrv === "" || oLineItemData.LastDateSrv === undefined || oLineItemData.LastDateSrv === "00000000") {
							var sMsg = this.getView().getModel("i18n").getProperty("lastDateMandat");
							MessageBox.alert(sMsg);
							return;
						}

					}
					if (oLineItemData.CreditGl && (oLineItemData.CreditGl === "160100" || oLineItemData.CreditGl === "320150") && (oLineItemData.ExpenseGlCredit ===
							"" || oLineItemData.AccrTrackNo === "" || oLineItemData.ExpenseGlCredit === undefined ||
							oLineItemData.AccrTrackNo === undefined)) {
						/*Start of change by Satabdi Das on 05-March-2021 for SCTASK1838272*/
						if (sCompCode !== "9921") {
							MessageBox.error(
								that.getView().getModel("i18n").getProperty("AccruMandt"), {
									styleClass: bCompact ? "sapUiSizeCompact" : ""
								}
							);
							return;
						} else if (sCompCode === "9921") {
							MessageBox.error(
								that.getView().getModel("i18n").getProperty("AccruMandt_9921"), {
									styleClass: bCompact ? "sapUiSizeCompact" : ""
								}
							);
							return;
						}
						/*End of change by Satabdi Das on 05-March-2021 for SCTASK1838272*/
					}
					/*QA Defect - 64290 - Short Desc , Detail Desc Mabndatory Issue - 1st Nov 2021 */
					if (oLineItemData.AdlDescription === "" || oLineItemData.AdlDescription === undefined ||
						oLineItemData.LongText === "" || oLineItemData.LongText === undefined ||
						oLineItemData.ServicePeriodStart === "" || oLineItemData.ServicePeriodStart === undefined ||
						oLineItemData.ServicePeriodEnd === "" || oLineItemData.ServicePeriodEnd === undefined) {
						var sMsg = this.getView().getModel("i18n").getProperty("MandtFldAlert");
						MessageBox.alert(sMsg);
						return;
					}
					/*QA Defect - 64290 - Short Desc , Detail Desc Mabndatory Issue - 1st Nov 2021 */

					/*Start of change by developer Satabdi Das for defect 63391 on 21-Jan-2021*/
					if (oLineItemData.AttenBrf === "" || oLineItemData.AttenBrf === undefined || oLineItemData.AttenBrfEmail === "" || oLineItemData.AttenBrfEmail ===
						undefined) {
						var sMsg = this.getView().getModel("i18n").getProperty("MandtFldAlert");
						MessageBox.alert(sMsg);
						oBrfModel.setProperty("/SelcKeySetBRF", oLineItemData.RequestingMf);
						return;
					}
					/*End of change by developer Satabdi Das for defect 63391 on 21-Jan-2021*/

					//Location of Service Render 
					// if (oLineItemData.LocationOfTheServicesReq === "US" && !oLineItemData.LocOfRenderingUs) {
					// 	var sServRender = this.getView().getModel("i18n").getProperty("locationServRender");
					// 	MessageBox.alert(sServRender);
					// 	return;
					// }

				}
				if (oLineItemData.GlobalCc !== "N/A") {
					if (oLineItemData.DebitGl && (oLineItemData.DebitGl === "160100" || oLineItemData.DebitGl === "320150") && (oLineItemData.ExpenseGl ===
							"" || oLineItemData.AccrTrackNo === "" || oLineItemData.ExpenseGl === undefined ||
							oLineItemData.AccrTrackNo === undefined)) {
						MessageBox.error(
							that.getView().getModel("i18n").getProperty("AccruMandt"), {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}
						);
						return;
					}
					if (oLineItemData.CreditGl && (oLineItemData.CreditGl === "160100" || oLineItemData.CreditGl === "320150") && (oLineItemData.ExpenseGlCredit ===
							"" || oLineItemData.AccrTrackNoCredit === "" || oLineItemData.ExpenseGlCredit ===
							undefined || oLineItemData.AccrTrackNoCredit === undefined)) {
						MessageBox.error(
							that.getView().getModel("i18n").getProperty("AccruMandt"), {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}
						);
						return;

					}
					/*QA Defect - 64290 - Short Desc , Detail Desc Mabndatory Issue - 1st Nov 2021 */
					if (oLineItemData.AdlDescription === "" || oLineItemData.AdlDescription === undefined || oLineItemData.ServicePeriodStart === "" ||
						oLineItemData.ServicePeriodStart === undefined ||
						oLineItemData.ServicePeriodEnd === "" || oLineItemData.ServicePeriodEnd === undefined) {
						var sMsg = this.getView().getModel("i18n").getProperty("MandtFldAlert");
						MessageBox.alert(sMsg);
						return;
					}
					/*QA Defect - 64290 - Short Desc , Detail Desc Mabndatory Issue - 1st Nov 2021 */

				}

				//questionnaire changes
				if (oLineItemData.ProcessGrp && questionTable.length > 0 && _qfirstQuestionData.length > 0) {
					oBrfModel.getProperty("/firstQuestionSet")[0].ProcessGrp = oLineItemData.ProcessGrp;
					for (var i = 0; i < questionTable.length; i++) {
						oBrfModel.getProperty("/questionSet")[i].ProcessGrp = oLineItemData.ProcessGrp;
						if ((!oBrfModel.getProperty("/questionSet")[i].Answer || oBrfModel.getProperty("/questionSet")[i].Answer === " ") || (!
								_qfirstQuestionData[0].Answer || _qfirstQuestionData[0].Answer === " ")) {
							questionMess = true;
							break;
						} else if (oBrfModel.getProperty("/questionSet")[i].Answer === "Other" && !oBrfModel.getProperty("/questionSet")[i].AnswerDesc) {
							var otherDetails = true;
							break;
						}
					}
				}

				if (questionMess === true) {
					var questionnaDetailMissing = this.getModel("i18n").getProperty("questionnaDetailMissing");
					MessageBox.alert(questionnaDetailMissing);
					return true;
				} else if (otherDetails === true) {
					var questionnaDetailMissing2 = this.getModel("i18n").getProperty("questionnaDetailMissing2");
					MessageBox.alert(questionnaDetailMissing2);
					return true;
				}

				if (oLineItemData.RequestingMf === "N/A" && oLineItemData.GlobalCc === "N/A") {
					var sMsg = this.getView().getModel("i18n").getProperty("MandtFldAlert");
					MessageBox.alert(sMsg);
					return;
				} else if (((oLineItemData.RequestingMf !== "N/A") && (oLineItemData.GlobalCc === "N/A")) && (oLineItemData.ProcessGrp)) {
					//duplicate changes for mf line added by prashanr 12.05.2021
					for (var k = 0; k < oTblBRF.getItems().length; k++) {
						var oTableData = oTblBRF.getBindingInfo("items").binding.oList[k];
						if (oTableData.RequestingMf === oLineItemData.RequestingMf && oTableData.MemberFirm === oLineItemData.MemberFirm && oTableData.ProcessGrp ===
							oLineItemData.ProcessGrp) {
							dupiLicateFlag = true;
							break;
						}

					}

					if (dupiLicateFlag === true) {
						var duplicateMessage = this.getView().getModel("i18n").getProperty("duplicateFieldMesg");
						MessageBox.alert(duplicateMessage + oLineItemData.RequestingMf + " " + "Member Firm : " + oLineItemData.MemberFirm +
							" and Processing Group: " + oLineItemData.ProcessGrp + "  already exists.");
						return true;
					}
					//setting question in submit table 17.03.2020
					if (questionTable.length > 0 && _qfirstQuestionData.length > 0) { /*Added for 63937*/
						oBrfModel.getProperty("/questionSetSubmit").push(_qfirstQuestionData[0]);
						oBrfModel.setProperty("/firstQuestionSet", []);
						if (oBrfModel.getProperty("/questionSet").length > 0) {
							for (var i = 0; i < oBrfModel.getProperty("/questionSet").length; i++) {
								// if (mModelSummary.getProperty("/questionSet")[i].AnswerOther) {
								// 	mModelSummary.getProperty("/questionSet")[i].Answer = mModelSummary.getProperty("/questionSet")[i].AnswerOther;
								// }
								oBrfModel.getProperty("/questionSetSubmit").push(oBrfModel.getProperty("/questionSet")[i]);
							}

							oBrfModel.setProperty("/questionSet", []);
						}
					}

					this.getView().getModel("oBrfModel").getProperty("/brfTableSet").push(oLineItemData);
					this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet", {});
					for (var i = 0; i < oTblBRF.getItems().length; i++) {
						if (oTblBRF.getBindingInfo("items").binding.oList[i].CnFlag === "X") {

							oTblBRF.getAggregation("items")[i].getCells()[9].setProperty("enabled", true);
							//oTblBRF.getAggregation("items")[i].getCells()[9].setProperty("visible", false);

						} else {
							oTblBRF.getAggregation("items")[i].getCells()[9].setProperty("visible", false);
						}
						/*Start of change by developer Satabdi Das on 06-Jan-2021*/
						if (oTblBRF.getBindingInfo("items").binding.oList[i].RiFlag !== "X") {
							oTblBRF.getAggregation("items")[i].getCells()[10].setProperty("enabled", false);
							oTblBRF.getAggregation("items")[i].getCells()[10].setProperty("visible", false);
						} else if (oTblBRF.getBindingInfo("items").binding.oList[i].RiFlag === "X") {
							oTblBRF.getAggregation("items")[i].getCells()[10].setProperty("enabled", true);
							oTblBRF.getAggregation("items")[i].getCells()[10].setProperty("visible", true);
						}
						/*End of change by developer Satabdi Das on 06-Jan-2021*/
					}

					this._ofragmentBrf.close();

					this.getView().getModel("oBrfModel").refresh();

				} else if (((oLineItemData.RequestingMf === "N/A") && (oLineItemData.GlobalCc !== "N/A")) && (oLineItemData.Ltext)) {
					this._ofragmentBrf.close();
					this.getView().getModel("oBrfModel").getProperty("/brfTableSet").push(oLineItemData);
					this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet", {});

					for (var i = 0; i < oTblBRF.getItems().length; i++) {
						if (oTblBRF.getBindingInfo("items").binding.oList[i].GlobalCc && oTblBRF.getBindingInfo("items").binding.oList[i].GlobalCc !=
							"N/A") {
							oTblBRF.getAggregation("items")[i].getCells()[7].setProperty("visible", false);
							oTblBRF.getAggregation("items")[i].getCells()[9].setProperty("visible", false);

						}
					}
				} else {
					var sMsg = this.getView().getModel("i18n").getProperty("MandtFldAlert");
					MessageBox.alert(sMsg);
					oBrfModel.setProperty("/SelcKeySetBRF", oLineItemData.RequestingMf);
					return;

				}

			}
		},

		handleLineItemEditForBrf: function (oEvent) {
			var oBrfModel = this.getView().getModel("oBrfModel");
			var oStorePath;
			var oStoreData;
			var oPath = oEvent.getSource().getBindingContext("oBrfModel").sPath;
			this.oStorePath = oPath;
			var sBrfTableRowData = oEvent.getSource().getBindingContext("oBrfModel").getObject();
			this.oStoreData = sBrfTableRowData;
			var oModelAttachmentsLastForBF = this.getView().getModel("oBrfModel").getProperty("/FileNameBRFSet");
			var sRrfNo = this.getView().getModel("oBrfModel").getProperty("/brfHeaderSet/RrfNo");
			if (oModelAttachmentsLastForBF) {
				this.getView().getModel("oBrfModel").setProperty("/FileNameBRFSet", null);
			}
			oBrfModel.setProperty("/oVisibleSet/creditNoteField", false);
			oBrfModel.setProperty("/oVisibleSet/editReqMF", false);
			oBrfModel.setProperty("/oVisibleSet/amountfieldVisible", true);
			oBrfModel.setProperty("/oVisibleSet/RI", false); //added for Reissuance of Invoice by Satabdi Das on  14-Dec-2020
			var oHdr = this.getView().getModel("oBrfModel").getProperty("/brfHeaderSet");
			/*oBrfModel.setProperty("/lineItemBRFSet/LongText", sBrfTableRowData.LongText);*/
			oBrfModel.setProperty("/longTextSetCancel", sBrfTableRowData.LongText);
			var checkDispBtn = this.getView().getModel("oBrfModel").getProperty("/oDisplayBtnPress");
			oBrfModel.setProperty("/DocumentType", sBrfTableRowData.DocumentType);
			oBrfModel.setProperty("/oVisibleSet/attchmentExpnded", false);
			var createBrfFragment = this.getView().createId("createBrfFragment");
			oBrfModel.setSizeLimit(500);
			if (!this._ofragmentBrf) {
				this._ofragmentBrf = sap.ui.xmlfragment(createBrfFragment, "KGO.kgoarrecharge_brf.view.createLineItemForBrf", this);
				this.getView().addDependent(this._ofragmentBrf);
			}
			/*Start of change for new doc type field by developer Satabdi Das on 14-Sep-2020*/
			if (sBrfTableRowData.CompanyCode === "9921") {
				oBrfModel.setProperty("/Bukrs9921", true);
				oBrfModel.setProperty("/Bukrs9901", false);
			} else {
				oBrfModel.setProperty("/Bukrs9921", false);
				oBrfModel.setProperty("/Bukrs9901", true);
			}
			//SCTASK2249365
			if (sBrfTableRowData.TaxpointDate === "00000000") {
				sBrfTableRowData.TaxpointDate = "";
			}
			if (sBrfTableRowData.LineStatus === "CFTEAM") {
				oBrfModel.setProperty("/oVisibleSet/vatEditDisplay", false);
			}
			var oQdropDown = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "comboIdTable"));
			oQdropDown.addEventDelegate({
				onAfterRendering: function () {
					var oQdropDown = this.$().find('.sapMInputBaseInner');
					var oID = oQdropDown[0].id;
					$('#' + oID).attr("disabled", "disabled");
				}
			}, oQdropDown);

			var oQdropDown = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "comboIdTableFirst"));
			oQdropDown.addEventDelegate({
				onAfterRendering: function () {
					var oQdropDown = this.$().find('.sapMInputBaseInner');
					var oID = oQdropDown[0].id;
					$('#' + oID).attr("disabled", "disabled");
				}
			}, oQdropDown);
			/*End of change for new doc type field by developer Satabdi Das on 14-Sep-2020 */

			if (checkDispBtn === "true") {
				var frgText = this.getView().getModel("i18n").getProperty("DisplayLitem");
				oBrfModel.setProperty("/fraggmentText", frgText);
				oBrfModel.setProperty("/oVisibleSet/TaxPointDateEditDisplay", false);
				this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/vatEditDisplay", false);
				this.getModel("oBrfModel").setProperty("/LastDateSrv", false); /*Added on 26-May-2020*/
				this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/EditAPUrnforNP", false); /*Added for defect 63363*/
				this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/amountFieldEditableForCN", false); /*Added for defect 63363*/
				this.byId(sap.ui.core.Fragment.createId("createBrfFragment", "checkboxVatId")).setProperty("enabled", false);

				if (sBrfTableRowData.LineStatus) {
					oBrfModel.setProperty("/oVisibleSet/postDate", true);
					oBrfModel.setProperty("/oVisibleSet/postDateEdit", false);
				} else {
					oBrfModel.setProperty("/oVisibleSet/postDate", false);
					oBrfModel.setProperty("/oVisibleSet/postDateEdit", false);
				}

			}

			//for the credit note changes
			if (sBrfTableRowData.LineType === "CREDITNOTE") {
				oBrfModel.setProperty("/oVisibleSet/nonCreditNoteText", false);
				oBrfModel.setProperty("/oVisibleSet/creditNoteTypeFieldEdit", false);
				oBrfModel.setProperty("/oVisibleSet/documentTypeNoNCN", false);
				oBrfModel.setProperty("/oVisibleSet/creditNoteTypeFieldVisible", true);
				oBrfModel.setProperty("/oVisibleSet/documentTypeEditCN", true);
				oBrfModel.setProperty("/oVisibleSet/creditNoteDocumentVisible", true);
				oBrfModel.setProperty("/oVisibleSet/documentTypeEditCN", false);
				oBrfModel.setProperty("/oVisibleSet/amountFieldEditableForCN", true);
				oBrfModel.setProperty("/oVisibleSet/creditNoteAmount", true);
				oBrfModel.setProperty("/oVisibleSet/attachVisible", true);
				oBrfModel.setProperty("/oVisibleSet/remaingAmount", false);
				oBrfModel.setProperty("/oVisibleSet/attchEnable", true);
				oBrfModel.setProperty("/oVisibleSet/postDate", true);
				if (sBrfTableRowData.CompanyCode === "9901") {
					oBrfModel.setProperty("/oVisibleSet/documentTypeNoNCN", false);
					oBrfModel.setProperty("/oVisibleSet/documentTypeEditCN", false);
					oBrfModel.setProperty("/oVisibleSet/creditNoteDocumentVisible", true);
				}
				if (sBrfTableRowData.CompanyCode === "9921") {
					oBrfModel.setProperty("/oVisibleSet/documentTypeNoNCN", false);
					oBrfModel.setProperty("/oVisibleSet/documentTypeEditCN", false);
					oBrfModel.setProperty("/oVisibleSet/creditNoteDocumentVisible", true);

				}

			} else {

				oBrfModel.setProperty("/oVisibleSet/attachVisible", true);
				oBrfModel.setProperty("/oVisibleSet/remaingAmount", true);
				oBrfModel.setProperty("/oVisibleSet/nonCreditNoteText", true);
				oBrfModel.setProperty("/oVisibleSet/creditNoteTypeFieldVisible", false);
				if (sBrfTableRowData.LineType === "REISSUANCE") {
					oBrfModel.setProperty("/oVisibleSet/remaingAmount", false);
				}

				if (sBrfTableRowData.CompanyCode === "9901") {
					oBrfModel.setProperty("/oVisibleSet/documentTypeNoNCN", false);
					oBrfModel.setProperty("/oVisibleSet/documentTypeEditCN", false);
					oBrfModel.setProperty("/oVisibleSet/creditNoteDocumentVisible", false);

				}
				if (sBrfTableRowData.CompanyCode === "9921") {
					oBrfModel.setProperty("/oVisibleSet/documentTypeNoNCN", true);
					oBrfModel.setProperty("/oVisibleSet/documentTypeEditCN", false);
					oBrfModel.setProperty("/oVisibleSet/creditNoteDocumentVisible", false);
					if (sRrfNo && (sBrfTableRowData.LineStatus === "SUPPLIER" || sBrfTableRowData.LineStatus === "CONTROLLER" || !sBrfTableRowData.LineStatus)) {
						oBrfModel.setProperty("/oVisibleSet/documentTypeEditCN", true);
					}

				}
			}

			//CREDIT NOTe document type 14.12.2020

			if ((checkDispBtn === "false") || (!checkDispBtn)) {
				var frgText = this.getView().getModel("i18n").getProperty("EditLineItem");
				oBrfModel.setProperty("/fraggmentText", frgText);
				oBrfModel.setProperty("/oLineStatus", sBrfTableRowData.LineStatus);

				this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/attchmentExpnded", false);
				if (sBrfTableRowData.EditReqMf === true) {
					this.getModel("oBrfModel").setProperty("/oVisibleSet/editReqMF", false);
				} else {
					this.getModel("oBrfModel").setProperty("/oVisibleSet/editMode", true);
				}

				if ((sBrfTableRowData.EditDisplay === "X") || (oHdr.Display === "X")) {
					this.getModel("oBrfModel").setProperty("/oVisibleSet/editMode", false);
					oBrfModel.setProperty("/oVisibleSet/editable", false);
					oBrfModel.setProperty("/entityEdit", false); /*Added for defect 63290*/
					oBrfModel.setProperty("/oVisibleSet/fieldEditable", false);
					oBrfModel.setProperty("/oVisibleSet/vatEditDisplay", false);
					oBrfModel.setProperty("/oVisibleSet/attchEnable", false);
					oBrfModel.setProperty("/oVisibleSet/postDate", false);
					oBrfModel.setProperty("/LastDateSrv", false); /*Added on 26-May-2020*/
					oBrfModel.setProperty("/oVisibleSet/EditAPUrnforNP", false); /*Added for defect 63363*/
					this.byId(sap.ui.core.Fragment.createId("createBrfFragment", "checkboxVatId")).setProperty("enabled", false);
					oBrfModel.setProperty("/oVisibleSet/amountFieldEditableForCN", false);
					oBrfModel.setProperty("/oVisibleSet/creditNoteAmount", false);
					if (sBrfTableRowData.LineStatus === "POSTED") {
						oBrfModel.setProperty("/oVisibleSet/postDate", true);
						oBrfModel.setProperty("/oVisibleSet/postDateEdit", false);
						oBrfModel.setProperty("/oVisibleSet/TaxPointDateEditDisplay", false);
					}
					if (!sBrfTableRowData.LineStatus) {
						oBrfModel.setProperty("/oVisibleSet/amountFieldEditableForCN", true);
						oBrfModel.setProperty("/oVisibleSet/creditNoteAmount", true);
						this.getModel("oBrfModel").setProperty("/oVisibleSet/postDate", false);

					}

				}
				if ((sBrfTableRowData.EditDisplay !== "X") && (oHdr.Display !== "X")) {
					switch (sBrfTableRowData.LineStatus) {
					case "SUPPLIER":
						this.getModel("oBrfModel").setProperty("/oVisibleSet/editMode", false);
						this.getModel("oBrfModel").setProperty("/oVisibleSet/postDate", false);
						this.getModel("oBrfModel").setProperty("/oVisibleSet/editable", true);
						this.getModel("oBrfModel").setProperty("/oVisibleSet/amountFieldEditableForCN", true);
						oBrfModel.setProperty("/oVisibleSet/creditNoteAmount", true);
						this.getView().getModel("oBrfModel").setProperty("/entityEdit", true); /*Added for defect 63290*/
						this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/fieldEditable", true);
						this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/vatEditDisplay", true);
						oBrfModel.setProperty("/oVisibleSet/TaxPointDateEditDisplay", true);
						this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/attchEnable", true);
						oBrfModel.setProperty("/oVisibleSet/documentTypeEditCN", true);
						this.byId(sap.ui.core.Fragment.createId("createBrfFragment", "checkboxVatId")).setProperty("enabled", false);

						//credit note changed for point 4 31.12.2020
						if (sBrfTableRowData.LineType === "CREDITNOTE") {
							oBrfModel.setProperty("/oVisibleSet/editable", false);
							oBrfModel.setProperty("/entityEdit", false);
							oBrfModel.setProperty("/oVisibleSet/fieldEditable", false);
							oBrfModel.setProperty("/oVisibleSet/vatEditDisplay", false);
							oBrfModel.setProperty("/oVisibleSet/TaxPointDateEditDisplay", false);

							if (sBrfTableRowData.CompanyCode === "9921") {
								oBrfModel.setProperty("/oVisibleSet/documentTypeEditCN", false);
							}
						}

						//end of changed 31.12.2020
						/*Start of change on 26-May-2020*/
						var sNatureFld = sBrfTableRowData.NatureOfService;
						if (sNatureFld && sNatureFld !== "") {
							if (sNatureFld === "Adhoc/One-Off") {
								this.getModel("oBrfModel").setProperty("/LastDateSrv", true);
							} else if (sNatureFld === "Continuous") {
								this.getModel("oBrfModel").setProperty("/LastDateSrv", false);
							}
						} else {
							this.getModel("oBrfModel").setProperty("/LastDateSrv", false);
						}
						/*End of change on 26-May-2020*/
						/*Start of defect 63363*/
						if ((sRrfNo && sRrfNo !== "" && sRrfNo.indexOf("NP") >= 0) || !oHdr.RrfNo) {
							this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/EditAPUrnforNP", true);
							if (sBrfTableRowData.LineType === "CREDITNOTE") {
								oBrfModel.setProperty("/oVisibleSet/EditAPUrnforNP", false);
							}
						} else {
							this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/EditAPUrnforNP", false);
						}
						/*End of defect 63363*/

						break;
					case "CONTROLLER":
						this.getModel("oBrfModel").setProperty("/oVisibleSet/editMode", false);
						this.getModel("oBrfModel").setProperty("/oVisibleSet/editable", true);
						this.getModel("oBrfModel").setProperty("/oVisibleSet/postDate", true);
						this.getModel("oBrfModel").setProperty("/oVisibleSet/postDateEdit", true);
						oBrfModel.setProperty("/oVisibleSet/documentTypeEditCN", true);
						oBrfModel.setProperty("/oVisibleSet/amountFieldEditableForCN", true);
						oBrfModel.setProperty("/oVisibleSet/creditNoteAmount", true);
						oBrfModel.setProperty("/entityEdit", true); /*Added for defect 63290*/
						oBrfModel.setProperty("/oVisibleSet/vatEditDisplay", true);
						oBrfModel.setProperty("/oVisibleSet/TaxPointDateEditDisplay", true);
						oBrfModel.setProperty("/oVisibleSet/fieldEditable", false);
						oBrfModel.setProperty("/oVisibleSet/attchEnable", true);
						oBrfModel.setProperty("/entityEdit", true);
						this.byId(sap.ui.core.Fragment.createId("createBrfFragment", "checkboxVatId")).setProperty("enabled", false);

						if (sBrfTableRowData.LineType === "CREDITNOTE") {
							oBrfModel.setProperty("/oVisibleSet/editable", false);
							oBrfModel.setProperty("/entityEdit", false);
							oBrfModel.setProperty("/oVisibleSet/vatEditDisplay", false);
							oBrfModel.setProperty("/oVisibleSet/TaxPointDateEditDisplay", false);
							oBrfModel.setProperty("/entityEdit", false);
							if (sBrfTableRowData.CompanyCode === "9921") {
								oBrfModel.setProperty("/oVisibleSet/documentTypeEditCN", false);
							}
						}

						/*Start of change on 26-May-2020*/
						var sNatureFld = sBrfTableRowData.NatureOfService;
						if (sNatureFld && sNatureFld !== "") {
							if (sNatureFld === "Adhoc/One-Off") {
								this.getModel("oBrfModel").setProperty("/LastDateSrv", true);
							} else if (sNatureFld === "Continuous") {
								this.getModel("oBrfModel").setProperty("/LastDateSrv", false);
							}
						} else {
							this.getModel("oBrfModel").setProperty("/LastDateSrv", false);
						}
						/*End of change on 26-May-2020*/
						/*Start of defect 63363*/
						if ((sRrfNo && sRrfNo !== "" && sRrfNo.indexOf("NP") >= 0) || !oHdr.RrfNo) {
							this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/EditAPUrnforNP", true);
							if (sBrfTableRowData.LineType === "CREDITNOTE") {
								oBrfModel.setProperty("/oVisibleSet/EditAPUrnforNP", false);
							}
						} else {
							this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/EditAPUrnforNP", false);
						}
						/*End of defect 63363*/

						break;
					case "VAT":
						oBrfModel.setProperty("/oVisibleSet/vatEditDisplay", true);
						oBrfModel.setProperty("/oVisibleSet/editMode", false);
						oBrfModel.setProperty("/oVisibleSet/editable", false);
						oBrfModel.setProperty("/oVisibleSet/amountFieldEditableForCN", false);
						oBrfModel.setProperty("/oVisibleSet/creditNoteAmount", false);
						oBrfModel.setProperty("/entityEdit", false); /*Added for defect 63290*/
						oBrfModel.setProperty("/oVisibleSet/fieldEditable", false);
						oBrfModel.setProperty("/oVisibleSet/attchEnable", false);
						oBrfModel.setProperty("/LastDateSrv", false); /*Added on 26-May-2020*/
						oBrfModel.setProperty("/oVisibleSet/EditAPUrnforNP", false); /*Added for defect 63363*/
						oBrfModel.setProperty("/oVisibleSet/documentTypeEditCN", false);
						oBrfModel.setProperty("/oVisibleSet/postDate", true);
						this.getModel("oBrfModel").setProperty("/oVisibleSet/postDateEdit", false);
						this.byId(sap.ui.core.Fragment.createId("createBrfFragment", "checkboxVatId")).setProperty("enabled", true);
						if (sBrfTableRowData.LineType === "CREDITNOTE") {
							oBrfModel.setProperty("/oVisibleSet/TaxPointDateEditDisplay", false);
							oBrfModel.setProperty("/oVisibleSet/vatEditDisplay", false);
						}
						if (sBrfTableRowData.LineType === "REISSUANCE") {
							oBrfModel.setProperty("/oVisibleSet/TaxPointDateEditDisplay", true);
						}

						break;
					case "VAT(LTT)":
						this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/vatEditDisplay", false);
						oBrfModel.setProperty("/oVisibleSet/TaxPointDateEditDisplay", false);
						this.getModel("oBrfModel").setProperty("/oVisibleSet/editMode", false);
						this.getModel("oBrfModel").setProperty("/oVisibleSet/amountFieldEditableForCN", false);
						oBrfModel.setProperty("/oVisibleSet/creditNoteAmount", false);
						oBrfModel.setProperty("/oVisibleSet/documentTypeEditCN", false);
						oBrfModel.setProperty("/oVisibleSet/postDate", true);
						this.getModel("oBrfModel").setProperty("/oVisibleSet/postDateEdit", false);
						this.getModel("oBrfModel").setProperty("/oVisibleSet/editable", false);
						this.getView().getModel("oBrfModel").setProperty("/entityEdit", false); /*Added for defect 63290*/
						this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/fieldEditable", false);
						this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/attchEnable", false);
						this.getModel("oBrfModel").setProperty("/LastDateSrv", false); /*Added on 26-May-2020*/
						this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/EditAPUrnforNP", false); /*Added for defect 63363*/
						this.byId(sap.ui.core.Fragment.createId("createBrfFragment", "checkboxVatId")).setProperty("enabled", false);
						break;
					case "AR":
						this.getModel("oBrfModel").setProperty("/oVisibleSet/editMode", false);
						this.getModel("oBrfModel").setProperty("/oVisibleSet/editable", false);
						this.getModel("oBrfModel").setProperty("/oVisibleSet/amountFieldEditableForCN", false);
						oBrfModel.setProperty("/oVisibleSet/creditNoteAmount", false);
						oBrfModel.setProperty("/oVisibleSet/documentTypeEditCN", false);
						oBrfModel.setProperty("/oVisibleSet/postDate", true);
						this.getModel("oBrfModel").setProperty("/oVisibleSet/postDateEdit", false);
						this.getView().getModel("oBrfModel").setProperty("/entityEdit", false); /*Added for defect 63290*/
						this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/fieldEditable", false);
						this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/vatEditDisplay", false);
						oBrfModel.setProperty("/oVisibleSet/TaxPointDateEditDisplay", false);
						this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/attchEnable", false);
						this.getModel("oBrfModel").setProperty("/LastDateSrv", false); /*Added on 26-May-2020*/
						this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/EditAPUrnforNP", false); /*Added for defect 63363*/
						this.byId(sap.ui.core.Fragment.createId("createBrfFragment", "checkboxVatId")).setProperty("enabled", false);
						break;
					case "AR(POST)":
						this.getModel("oBrfModel").setProperty("/oVisibleSet/editMode", false);
						this.getModel("oBrfModel").setProperty("/oVisibleSet/editable", false);
						this.getModel("oBrfModel").setProperty("/oVisibleSet/amountFieldEditableForCN", false);
						oBrfModel.setProperty("/oVisibleSet/creditNoteAmount", false);
						oBrfModel.setProperty("/oVisibleSet/postDate", true);
						oBrfModel.setProperty("/oVisibleSet/postDateEdit", true);
						oBrfModel.setProperty("/oVisibleSet/documentTypeEditCN", false);
						this.getView().getModel("oBrfModel").setProperty("/entityEdit", false); /*Added for defect 63290*/
						this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/fieldEditable", false);
						this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/vatEditDisplay", false);
						oBrfModel.setProperty("/oVisibleSet/TaxPointDateEditDisplay", true);
						this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/attchEnable", false);
						this.getModel("oBrfModel").setProperty("/LastDateSrv", false); /*Added on 26-May-2020*/
						this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/EditAPUrnforNP", false); /*Added for defect 63363*/
						this.byId(sap.ui.core.Fragment.createId("createBrfFragment", "checkboxVatId")).setProperty("enabled", false);
						if (sBrfTableRowData.LineType === "CREDITNOTE") {
							oBrfModel.setProperty("/oVisibleSet/TaxPointDateEditDisplay", false);
						}
						if (sBrfTableRowData.LineType === "REISSUANCE") {
							oBrfModel.setProperty("/oVisibleSet/TaxPointDateEditDisplay", true);
						}

						break;
					case "LTT":
						this.getModel("oBrfModel").setProperty("/oVisibleSet/editMode", false);
						this.getModel("oBrfModel").setProperty("/oVisibleSet/editable", false);
						this.getModel("oBrfModel").setProperty("/oVisibleSet/amountFieldEditableForCN", false);
						oBrfModel.setProperty("/oVisibleSet/creditNoteAmount", false);
						oBrfModel.setProperty("/oVisibleSet/postDate", true);
						oBrfModel.setProperty("/oVisibleSet/postDateEdit", false);
						oBrfModel.setProperty("/oVisibleSet/documentTypeEditCN", false);
						this.getView().getModel("oBrfModel").setProperty("/entityEdit", false); /*Added for defect 63290*/
						this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/fieldEditable", false);
						this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/vatEditDisplay", false);
						this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/attchEnable", false);
						this.getModel("oBrfModel").setProperty("/LastDateSrv", false); /*Added on 26-May-2020*/
						this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/EditAPUrnforNP", false); /*Added for defect 63363*/
						this.byId(sap.ui.core.Fragment.createId("createBrfFragment", "checkboxVatId")).setProperty("enabled", false);
						break;
					case "LTT1":
						this.getModel("oBrfModel").setProperty("/oVisibleSet/editMode", false);
						this.getModel("oBrfModel").setProperty("/oVisibleSet/editable", false);
						this.getModel("oBrfModel").setProperty("/oVisibleSet/amountFieldEditableForCN", false);
						oBrfModel.setProperty("/oVisibleSet/creditNoteAmount", false);
						oBrfModel.setProperty("/oVisibleSet/postDate", true);
						oBrfModel.setProperty("/oVisibleSet/postDateEdit", false);
						oBrfModel.setProperty("/oVisibleSet/documentTypeEditCN", false);
						this.getView().getModel("oBrfModel").setProperty("/entityEdit", false); /*Added for defect 63290*/
						this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/fieldEditable", false);
						this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/vatEditDisplay", false);
						oBrfModel.setProperty("/oVisibleSet/TaxPointDateEditDisplay", false);
						this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/attchEnable", true);
						this.getModel("oBrfModel").setProperty("/LastDateSrv", false); /*Added on 26-May-2020*/
						this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/EditAPUrnforNP", false); /*Added for defect 63363*/
						this.byId(sap.ui.core.Fragment.createId("createBrfFragment", "checkboxVatId")).setProperty("enabled", false);
						break;
					case "LTT2":
						this.getModel("oBrfModel").setProperty("/oVisibleSet/editMode", false);
						this.getModel("oBrfModel").setProperty("/oVisibleSet/editable", false);
						this.getModel("oBrfModel").setProperty("/oVisibleSet/amountFieldEditableForCN", false);
						oBrfModel.setProperty("/oVisibleSet/creditNoteAmount", false);
						oBrfModel.setProperty("/oVisibleSet/postDate", true);
						oBrfModel.setProperty("/oVisibleSet/postDateEdit", false);
						oBrfModel.setProperty("/oVisibleSet/documentTypeEditCN", false);
						this.getView().getModel("oBrfModel").setProperty("/entityEdit", false); /*Added for defect 63290*/
						this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/fieldEditable", false);
						this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/vatEditDisplay", false);
						oBrfModel.setProperty("/oVisibleSet/TaxPointDateEditDisplay", false);
						this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/attchEnable", true);
						this.getModel("oBrfModel").setProperty("/LastDateSrv", false); /*Added on 26-May-2020*/
						this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/EditAPUrnforNP", false); /*Added for defect 63363*/
						this.byId(sap.ui.core.Fragment.createId("createBrfFragment", "checkboxVatId")).setProperty("enabled", false);
						break;
					case "LTT3":
						this.getModel("oBrfModel").setProperty("/oVisibleSet/editMode", false);
						this.getModel("oBrfModel").setProperty("/oVisibleSet/editable", false);
						this.getModel("oBrfModel").setProperty("/oVisibleSet/amountFieldEditableForCN", false);
						oBrfModel.setProperty("/oVisibleSet/creditNoteAmount", false);
						oBrfModel.setProperty("/oVisibleSet/postDate", true);
						oBrfModel.setProperty("/oVisibleSet/postDateEdit", false);
						oBrfModel.setProperty("/oVisibleSet/documentTypeEditCN", false);
						this.getView().getModel("oBrfModel").setProperty("/entityEdit", false); /*Added for defect 63290*/
						this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/fieldEditable", false);
						this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/vatEditDisplay", false);
						oBrfModel.setProperty("/oVisibleSet/TaxPointDateEditDisplay", false);
						this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/attchEnable", true);
						this.getModel("oBrfModel").setProperty("/LastDateSrv", false); /*Added on 26-May-2020*/
						this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/EditAPUrnforNP", false); /*Added for defect 63363*/
						this.byId(sap.ui.core.Fragment.createId("createBrfFragment", "checkboxVatId")).setProperty("enabled", false);
						break;
					case "AR(PARK)":
						this.getModel("oBrfModel").setProperty("/oVisibleSet/editMode", false);
						this.getModel("oBrfModel").setProperty("/oVisibleSet/editable", false);
						this.getModel("oBrfModel").setProperty("/oVisibleSet/amountFieldEditableForCN", false);
						oBrfModel.setProperty("/oVisibleSet/creditNoteAmount", false);
						oBrfModel.setProperty("/oVisibleSet/postDate", true);
						oBrfModel.setProperty("/oVisibleSet/postDateEdit", true);
						oBrfModel.setProperty("/oVisibleSet/documentTypeEditCN", false);
						this.getView().getModel("oBrfModel").setProperty("/entityEdit", false); /*Added for defect 63290*/
						this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/fieldEditable", false);
						this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/vatEditDisplay", true);
						oBrfModel.setProperty("/oVisibleSet/TaxPointDateEditDisplay", true);
						this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/attchEnable", false);
						this.getModel("oBrfModel").setProperty("/LastDateSrv", false); /*Added on 26-May-2020*/
						this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/EditAPUrnforNP", false); /*Added for defect 63363*/
						this.byId(sap.ui.core.Fragment.createId("createBrfFragment", "checkboxVatId")).setProperty("enabled", false);
						if (sBrfTableRowData.LineType === "CREDITNOTE") {
							oBrfModel.setProperty("/oVisibleSet/TaxPointDateEditDisplay", false);
						}
						if (sBrfTableRowData.LineType === "REISSUANCE") {
							oBrfModel.setProperty("/oVisibleSet/TaxPointDateEditDisplay", true);
						}
						break;
					case "Approved":
						this.getModel("oBrfModel").setProperty("/oVisibleSet/editMode", false);
						this.getModel("oBrfModel").setProperty("/oVisibleSet/editable", false);
						this.getModel("oBrfModel").setProperty("/oVisibleSet/amountFieldEditableForCN", false);
						oBrfModel.setProperty("/oVisibleSet/creditNoteAmount", false);
						oBrfModel.setProperty("/oVisibleSet/postDate", false);
						oBrfModel.setProperty("/oVisibleSet/documentTypeEditCN", false);
						this.getView().getModel("oBrfModel").setProperty("/entityEdit", false); /*Added for defect 63290*/
						this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/vatEditDisplay", false);
						oBrfModel.setProperty("/oVisibleSet/TaxPointDateEditDisplay", false);
						this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/fieldEditable", false);
						this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/attchEnable", false);
						this.getModel("oBrfModel").setProperty("/LastDateSrv", false); /*Added on 26-May-2020*/
						this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/EditAPUrnforNP", false); /*Added for defect 63363*/
						this.byId(sap.ui.core.Fragment.createId("createBrfFragment", "checkboxVatId")).setProperty("enabled", false);
						break;
					case "PARKED":
						this.getModel("oBrfModel").setProperty("/oVisibleSet/editMode", false);
						this.getModel("oBrfModel").setProperty("/oVisibleSet/editable", false);
						this.getModel("oBrfModel").setProperty("/oVisibleSet/amountFieldEditableForCN", false);
						oBrfModel.setProperty("/oVisibleSet/creditNoteAmount", false);
						oBrfModel.setProperty("/oVisibleSet/postDate", true);
						oBrfModel.setProperty("/oVisibleSet/postDateEdit", true);
						oBrfModel.setProperty("/oVisibleSet/documentTypeEditCN", false);
						this.getView().getModel("oBrfModel").setProperty("/entityEdit", false); /*Added for defect 63290*/
						this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/vatEditDisplay", false);
						oBrfModel.setProperty("/oVisibleSet/TaxPointDateEditDisplay", true);
						this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/fieldEditable", false);
						this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/attchEnable", false);
						this.getModel("oBrfModel").setProperty("/LastDateSrv", false); /*Added on 26-May-2020*/
						this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/EditAPUrnforNP", false); /*Added for defect 63363*/
						this.byId(sap.ui.core.Fragment.createId("createBrfFragment", "checkboxVatId")).setProperty("enabled", false);
						if (sBrfTableRowData.LineType === "CREDITNOTE") {
							oBrfModel.setProperty("/oVisibleSet/TaxPointDateEditDisplay", false);
						}
						if (sBrfTableRowData.LineType === "REISSUANCE") {
							oBrfModel.setProperty("/oVisibleSet/TaxPointDateEditDisplay", true);
						}
						break;
					case "PARKED(LTT)":
						this.getModel("oBrfModel").setProperty("/oVisibleSet/editMode", false);
						this.getModel("oBrfModel").setProperty("/oVisibleSet/editable", false);
						this.getModel("oBrfModel").setProperty("/oVisibleSet/amountFieldEditableForCN", false);
						oBrfModel.setProperty("/oVisibleSet/creditNoteAmount", false);
						oBrfModel.setProperty("/oVisibleSet/postDate", true);
						oBrfModel.setProperty("/oVisibleSet/postDateEdit", false);
						oBrfModel.setProperty("/oVisibleSet/documentTypeEditCN", false);
						this.getView().getModel("oBrfModel").setProperty("/entityEdit", false); /*Added for defect 63290*/
						this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/vatEditDisplay", false);
						oBrfModel.setProperty("/oVisibleSet/TaxPointDateEditDisplay", false);
						this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/fieldEditable", false);
						this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/attchEnable", false);
						this.getModel("oBrfModel").setProperty("/LastDateSrv", false); /*Added on 26-May-2020*/
						this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/EditAPUrnforNP", false); /*Added for defect 63363*/
						this.byId(sap.ui.core.Fragment.createId("createBrfFragment", "checkboxVatId")).setProperty("enabled", false);
						break;
					case "POSTED":
						oBrfModel.setProperty("/oVisibleSet/editMode", false);
						oBrfModel.setProperty("/oVisibleSet/editable", false);
						oBrfModel.setProperty("/oVisibleSet/postDate", true);
						oBrfModel.setProperty("/oVisibleSet/postDateEdit", false);
						oBrfModel.setProperty("/oVisibleSet/documentTypeEditCN", false);
						oBrfModel.setProperty("/oVisibleSet/amountFieldEditableForCN", false);
						oBrfModel.setProperty("/oVisibleSet/creditNoteAmount", false);
						oBrfModel.setProperty("/entityEdit", false); /*Added for defect 63290*/
						oBrfModel.setProperty("/oVisibleSet/vatEditDisplay", false);
						oBrfModel.setProperty("/oVisibleSet/TaxPointDateEditDisplay", false);
						oBrfModel.setProperty("/oVisibleSet/fieldEditable", false);
						oBrfModel.setProperty("/oVisibleSet/attchEnable", false);
						oBrfModel.setProperty("/LastDateSrv", false); /*Added on 26-May-2020*/
						this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/EditAPUrnforNP", false); /*Added for defect 63363*/
						this.byId(sap.ui.core.Fragment.createId("createBrfFragment", "checkboxVatId")).setProperty("enabled", false);
						break;

					}
				}
				/*Star of change for Defect 63290*/
				if (sRrfNo !== "") {

					if ((!sBrfTableRowData.LineStatus) && (sBrfTableRowData.RrfLineStatus)) {
						oBrfModel.setProperty("/oVisibleSet/creditNoteAmount", true);
						oBrfModel.setProperty("/entityEdit", true);
						/*Change Start by Satabdi Das on 10-Feb-2021*/
						oBrfModel.setProperty("/oVisibleSet/amountFieldEditableForCN", true);

						/*Change end by Satabdi Das on 10-Feb-2021*/
					}

				}
				/*End of change for defect 63290*/
				/*Start of defect 63363*/
				if (sBrfTableRowData.LineStatus === "") {
					oBrfModel.setProperty("/oVisibleSet/postDate", true);
					oBrfModel.setProperty("/oVisibleSet/postDateEdit", true);
					if ((sRrfNo && sRrfNo !== "" && sRrfNo.indexOf("NP") >= 0) || !oHdr.RrfNo) {
						this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/EditAPUrnforNP", true);
						if (sBrfTableRowData.LineType === "CREDITNOTE") {
							oBrfModel.setProperty("/oVisibleSet/EditAPUrnforNP", false);
						}
					} else {
						this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/EditAPUrnforNP", false);
					}
				}
				/*End of defect 63363*/

			}

			//var createBrfFragment = this.getView().createId("createBrfFragment");

			if (sBrfTableRowData.RequestingMf === "N/A") {
				oBrfModel.setProperty("/oVisibleSet/lineItemVisibleForGF", true);
				oBrfModel.setProperty("/oVisibleSet/lineItemVisibleForMF", false);
				oBrfModel.setProperty("/oVisibleSet/countryComboBox", false);
				oBrfModel.setProperty("/oVisibleSet/editContyCod", false);
				oBrfModel.setProperty("/oVisibleSet/questionPnVisibleBRF", false);
				oBrfModel.setProperty("/oVisibleSet/serviceRenderBox", false);

				if (!oHdr.RrfNo) {
					oBrfModel.setProperty("/oVisibleSet/assigmentUrn", false);
					oBrfModel.setProperty("/oVisibleSet/withoutRef", true);

				}
				if (sBrfTableRowData.CompanyCode === "9921") {
					oBrfModel.setProperty("/oVisibleSet/documentGf9921", true);
					oBrfModel.setProperty("/oVisibleSet/documentGf9901", false);
					var _dDocument9921Field = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "documentGF9921"));
					jQuery.sap.delayedCall(1000, this, function () {
						if (_dDocument9921Field) {
							var dDocument = _dDocument9921Field.getDomRef();
							if (dDocument) {
								dDocument.firstElementChild.firstChild.setAttribute("readonly", true);
								//	dDocument.children[1].setAttribute("readonly", true);
							}
						}
					});

				} else {
					oBrfModel.setProperty("/oVisibleSet/documentGf9921", false);
					oBrfModel.setProperty("/oVisibleSet/documentGf9901", true);
				}

				// if (sBrfTableRowData.LocationOfTheServicesReq === "") {
				// 	this.getView().getModel("oBrfModel").setProperty("/SelcKeyForLocServ", "OTH");
				// 	sBrfTableRowData.LocationOfTheServicesReq = "OTH";
				// } else {
				// 	oBrfModel.setProperty("/SelcKeyForLocServ", sBrfTableRowData.LocationOfTheServicesReq);
				// }
				oBrfModel.setProperty("/SelcKeyForLocServ", "NMT");
				sBrfTableRowData.LocationOfTheServicesReq = "NMT";
				if (sBrfTableRowData.DebitGl && (sBrfTableRowData.DebitGl === "160100" || sBrfTableRowData.DebitGl === "320150")) {
					this.getModel("oBrfModel").setProperty("/oVisibleSet/GL160100", true);
				} else if (sBrfTableRowData.DebitGl !== "160100" || sBrfTableRowData.DebitGl !== "320150") { /*Changed for defect 63348*/
					this.getModel("oBrfModel").setProperty("/oVisibleSet/GL160100", false);
				}

				if (sBrfTableRowData.CreditGl && (sBrfTableRowData.CreditGl === "160100" || sBrfTableRowData.CreditGl === "320150")) {
					this.getModel("oBrfModel").setProperty("/oVisibleSet/CRGL160100", true);
				} else if (sBrfTableRowData.CreditGl !== "160100" || sBrfTableRowData.CreditGl !== "320150") { /*Changed for defect 63348*/
					this.getModel("oBrfModel").setProperty("/oVisibleSet/CRGL160100", false);
				}

			}
			if (sBrfTableRowData.GlobalCc === "N/A") {

				//Questionnaire changes 15.03.2021
				var oAnswer = this.getModel("oBrfModel").getProperty("/questionSetSubmit");
				var oAnswerShow = [];
				var _fFirstLineData = [];
				for (var t = 0; t < oAnswer.length; t++) {
					if ((oAnswer[t].RequestingMf === sBrfTableRowData.RequestingMf) && (oAnswer[t].MemberFirm === sBrfTableRowData.MemberFirm) && (
							oAnswer[t].ProcessGrp === sBrfTableRowData.ProcessGrp) && (oAnswer[t].LineType === sBrfTableRowData.LineType) &&
						(oAnswer[t].TransactionType === sBrfTableRowData.TransactionType)) {
						var object = {};
						object.LineNo = oAnswer[t].LineNo;
						object.CompanyCode = oAnswer[t].CompanyCode;
						object.Mandatory = oAnswer[t].Mandatory;
						object.MemberFirm = oAnswer[t].MemberFirm;
						object.Question = oAnswer[t].Question;
						object.AnswerDesc = oAnswer[t].AnswerDesc;
						object.Answer = oAnswer[t].Answer;
						object.InternalExternal = oAnswer[t].InternalExternal;
						object.LineType = oAnswer[t].LineType;
						object.TransactionType = oAnswer[t].TransactionType;
						object.RequestingMf = oAnswer[t].RequestingMf;
						object.ProcessGrp = sBrfTableRowData.ProcessGrp;
						if (object.Question === "Nature of Supplier") {
							_fFirstLineData.push(object);
						} else {
							oAnswerShow.push(object);
						}
					}
				}
				oBrfModel.setProperty("/questionSet", oAnswerShow);
				oBrfModel.setProperty("/firstQuestionSet", _fFirstLineData);
				var firstQtable = sap.ui.core.Fragment.byId(createBrfFragment, "QuestionTableFirst");
				if (_fFirstLineData.length > 0) {
					if (sBrfTableRowData.LineStatus !== "CONTROLLER") {
						firstQtable.getAggregation("items")[0].getCells()[2].setProperty("editable", false);
						if (!sBrfTableRowData.LineStatus) {
							firstQtable.getAggregation("items")[0].getCells()[2].setProperty("editable", true);
						}
					} else {
						firstQtable.getAggregation("items")[0].getCells()[2].setProperty("editable", true);
						if (checkDispBtn === "true") {
							firstQtable.getAggregation("items")[0].getCells()[2].setProperty("editable", false);
						}

					}
				}

				if (sBrfTableRowData.LocationOfTheServicesReq === "US") {
					oBrfModel.setProperty("/oVisibleSet/serviceRenderBox", true);
				} else {
					oBrfModel.setProperty("/oVisibleSet/serviceRenderBox", false);
				}
				var tbl = sap.ui.core.Fragment.byId(createBrfFragment, "QuestionTable2");
				if (oAnswerShow.length > 0) {
					oBrfModel.setProperty("/oVisibleSet/questionPnVisibleBRF", true);
					for (var j = 0; j < oAnswerShow.length; j++) {
						if (oAnswerShow[j].Answer === "N/A") {
							tbl.getAggregation("items")[j].getCells()[3].setProperty("visible", false);
							if (sBrfTableRowData.LineStatus !== "CONTROLLER") {
								tbl.getAggregation("items")[j].getCells()[2].setProperty("editable", false);
								if (!sBrfTableRowData.LineStatus) {
									tbl.getAggregation("items")[j].getCells()[2].setProperty("editable", true);
									if (oBrfModel.getProperty("/firstQuestionSet")[0].Answer === "Service from external supplier") {

										if (oAnswerShow[j].InternalExternal === "EXTERNAL") {
											tbl.getAggregation("items")[j].getCells()[2].setProperty("editable", true);
										}
										if (oAnswerShow[j].InternalExternal === "INTERNAL") {
											tbl.getAggregation("items")[j].getCells()[2].setProperty("editable", false);
										}
									}

									if (oBrfModel.getProperty("/firstQuestionSet")[0].Answer === "Service from KPMGI") {

										if (oAnswerShow[j].InternalExternal === "INTERNAL") {
											tbl.getAggregation("items")[j].getCells()[2].setProperty("editable", true);
										}

										if (oAnswerShow[j].InternalExternal === "EXTERNAL") {
											tbl.getAggregation("items")[j].getCells()[2].setProperty("editable", false);
										}

									}

								}
							} else {
								tbl.getAggregation("items")[j].getCells()[2].setProperty("editable", true);
								if (oBrfModel.getProperty("/firstQuestionSet")[0].Answer === "Service from external supplier") {

									if (oAnswerShow[j].InternalExternal === "EXTERNAL") {
										tbl.getAggregation("items")[j].getCells()[2].setProperty("editable", true);
									}
									if (oAnswerShow[j].InternalExternal === "INTERNAL") {
										tbl.getAggregation("items")[j].getCells()[2].setProperty("editable", false);
									}
								}

								if (oBrfModel.getProperty("/firstQuestionSet")[0].Answer === "Service from KPMGI") {

									if (oAnswerShow[j].InternalExternal === "INTERNAL") {
										tbl.getAggregation("items")[j].getCells()[2].setProperty("editable", true);
									}

									if (oAnswerShow[j].InternalExternal === "EXTERNAL") {
										tbl.getAggregation("items")[j].getCells()[2].setProperty("editable", false);
									}

								}

								if (checkDispBtn === "true") {
									tbl.getAggregation("items")[j].getCells()[2].setProperty("editable", false);
								}

							}
						} else {
							tbl.getAggregation("items")[j].getCells()[3].setProperty("visible", true);
							if ((sBrfTableRowData.LineStatus === "CONTROLLER") || (!sBrfTableRowData.LineStatus && sBrfTableRowData.LineType === "INVOICE")) {
								tbl.getAggregation("items")[j].getCells()[3].setProperty("editable", true);
								tbl.getAggregation("items")[j].getCells()[2].setProperty("editable", true);
								if (checkDispBtn === "true") {
									tbl.getAggregation("items")[j].getCells()[3].setProperty("editable", false);
									tbl.getAggregation("items")[j].getCells()[2].setProperty("editable", false);
								}
							} else {
								tbl.getAggregation("items")[j].getCells()[3].setProperty("editable", false);
								tbl.getAggregation("items")[j].getCells()[2].setProperty("editable", false);
							}
						}
					}
				} else {
					oBrfModel.setProperty("/oVisibleSet/questionPnVisibleBRF", false);
				}

				if ((sBrfTableRowData.LineType === "CREDITNOTE" && !sBrfTableRowData.LineStatus) || (sBrfTableRowData.LineType === "REISSUANCE" &&
						!sBrfTableRowData.LineStatus)) {
					oBrfModel.setProperty("/oVisibleSet/questionPnVisibleBRF", false);
					oBrfModel.setProperty("/oVisibleSet/postDate", true);
					oBrfModel.setProperty("/oVisibleSet/postDateEdit", true);
				}

				//end of questionnaire chnges

				oBrfModel.setProperty("/oVisibleSet/countryComboBox", false);
				oBrfModel.setProperty("/oVisibleSet/editContyCod", true);
				if (!oHdr.RrfNo) {
					oBrfModel.setProperty("/oVisibleSet/apUrnForMf", false);
					oBrfModel.setProperty("/oVisibleSet/withoutRef", true);
				}

				if (sBrfTableRowData.CnType === "Full") {
					oBrfModel.setProperty("/oVisibleSet/creditNoteAmount", false);
				}
				if (sBrfTableRowData.WhtCode && sBrfTableRowData.WhtCode !== "" && sBrfTableRowData.WhtCode !== "N/A") {
					oBrfModel.setProperty("/WhTFldsMandat", true);
					/*Start*/
					// var sWhTAmt = sBrfTableRowData.LineItemTotal;
					// if (!sWhTAmt || sWhTAmt === "" || sWhTAmt === "0.00") {
					// 	var nDebitAmt = Number(sBrfTableRowData.RechargeAmountDebit);
					// 	var nWht = Number(sBrfTableRowData.WhtCode);
					// 	if (nDebitAmt && nDebitAmt !== "" && nDebitAmt !== "0.00") {
					// 		var nWhtAmt = ((nDebitAmt * 100) / (100 - nWht)) - nDebitAmt;
					// 		var sWhtAmt = formatter.ValueExportFormatter(nWhtAmt, 2);
					// 		sBrfTableRowData.LineItemTotal = sWhtAmt;
					// 	}
					// }
					/*End*/

				} else if (!sBrfTableRowData.WhtCode || sBrfTableRowData.WhtCode === "" || sBrfTableRowData.WhtCode === "N/A") {
					oBrfModel.setProperty("/WhTFldsMandat", false);
				}
				oBrfModel.setProperty("/oVisibleSet/lineItemVisibleForGF", false);
				oBrfModel.setProperty("/oVisibleSet/lineItemVisibleForMF", true);
				oBrfModel.setProperty("/SelcKeyForLocServ", sBrfTableRowData.LocationOfTheServicesReq);
				/*Start of defect 63418*/
				var bManual = oBrfModel.getProperty("/oVisibleSet/withoutRef");
				if ((sBrfTableRowData.RequestingMf === "US" || sBrfTableRowData.RequestingMf === "NL")) {
					oBrfModel.setProperty("/CodeMandat", true);
				} else {
					oBrfModel.setProperty("/CodeMandat", false);
				}
				/*End of defect 63418*/

				if (sBrfTableRowData.NatureOfService && sBrfTableRowData.NatureOfService !== "" && sBrfTableRowData.NatureOfService ===
					"Adhoc/One-Off") {
					oBrfModel.setProperty("/DateMandatory", true);
					oBrfModel.setProperty("/LastDateSrv", true);
				} else {
					oBrfModel.setProperty("/DateMandatory", false);
					oBrfModel.setProperty("/LastDateSrv", false);
				}
				if (sBrfTableRowData.CreditGl && (sBrfTableRowData.CreditGl === "160100" || sBrfTableRowData.CreditGl === "320150")) {
					this.getModel("oBrfModel").setProperty("/oVisibleSet/CRGL160100", true);
				} else if (sBrfTableRowData.CreditGl !== "160100" || sBrfTableRowData.CreditGl !== "320150") { /*Changed for defect 63348*/
					this.getModel("oBrfModel").setProperty("/oVisibleSet/CRGL160100", false);
				}
				oBrfModel.setProperty("/DocumentType", sBrfTableRowData.DocumentType);
				oBrfModel.setProperty("/SelcKeyForLocServ", sBrfTableRowData.LocationOfTheServicesReq);
			}
			this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "idselectokForedit")).setVisible(true);
			this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "addLineItemOkId")).setVisible(false);
			oBrfModel.setProperty("/lineItemBRFSet", sBrfTableRowData);
			oBrfModel.setProperty("/lineItemBRFSet/LongText", sBrfTableRowData.LongText);
			oBrfModel.setProperty("/SelcKeySetBRF", sBrfTableRowData.RequestingMf);
			// var x= this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "RequestingMf")).getItems();

			this.getView().getModel("oBrfModel").setProperty("/CurrencySet", sBrfTableRowData.Curr1);
			/*Start of change on 09-APR-2020*/
			if (sBrfTableRowData.SalesTaxCode === "" && sBrfTableRowData.CompanyCode !== "9921") {
				oBrfModel.setProperty("/lineItemBRFSet/SalesTaxCode", "N0");
			} else if (sBrfTableRowData.SalesTaxCode === "" && sBrfTableRowData.CompanyCode === "9921") {
				oBrfModel.setProperty("/lineItemBRFSet/SalesTaxCode", "UO");
			} else {
				oBrfModel.setProperty("/lineItemBRFSet/SalesTaxCode", sBrfTableRowData.SalesTaxCode);
			}

			/*End of change on 09-APR-2020*/

			this.getView().getModel("oBrfModel").refresh();

			//changes for attachment of credit note line items
			var brfNO = this.getView().getModel("oBrfModel").getProperty("/brfHeaderSet").BrfNo;

			if (brfNO) {
				if (sBrfTableRowData.LineType === "INVOICE" || sBrfTableRowData.LineStatus) {
					this.fetchAttachmentList();
				}

			}

			if ((sBrfTableRowData.LineType === "INVOICE") && (sBrfTableRowData.BrfNo) && (!sBrfTableRowData.LineStatus)) {
				oBrfModel.setProperty("/oVisibleSet/attchEnable", true);
			} else {
				if ((!sBrfTableRowData.LineType === "INVOICE" && !sBrfTableRowData.LineStatus) || !brfNO) {
					oBrfModel.setProperty("/oVisibleSet/attchEnable", false);
				} else {
					if ((sBrfTableRowData.LineType === "CREDITNOTE" || sBrfTableRowData.LineType === "REISSUANCE") && (!sBrfTableRowData.LineStatus)) {
						oBrfModel.setProperty("/oVisibleSet/attchEnable", false);
					}
				}
			}

			//LTT changes added by prashant 24.09.2020
			if (sBrfTableRowData.Ltt === "X") {
				this.byId(sap.ui.core.Fragment.createId("createBrfFragment", "checkboxVatId")).setProperty("selected", true);
			} else {
				this.byId(sap.ui.core.Fragment.createId("createBrfFragment", "checkboxVatId")).setProperty("selected", false);
			}

			var oTaxPointDate = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "TaxPointDate"));
			jQuery.sap.delayedCall(1000, this, function () {
				if (oTaxPointDate) {
					var objTaxDate = oTaxPointDate.getDomRef();
					if (objTaxDate) {
						objTaxDate.firstElementChild.firstChild.setAttribute("readonly", true);
						//	objTaxDate.children[1].setAttribute("readonly", true);
					}
				}
			});

			var creditNoteDoType = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "creditNoteDoType"));
			jQuery.sap.delayedCall(500, this, function () {
				if (creditNoteDoType) {
					var creditNoteDoType1 = creditNoteDoType.getDomRef();
					if (creditNoteDoType1) {
						creditNoteDoType1.firstElementChild.firstChild.setAttribute("readonly", true);
						//objNature.children[1].setAttribute("readonly", true);
					}
				}
			}, creditNoteDoType);
			// var servRenderUS = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "servRenderUS"));
			// servRenderUS.addEventDelegate({
			// 	onAfterRendering: function () {
			// 		var serviceRenderUS = this.$().find('.sapMInputBaseInner');
			// 		var oID = serviceRenderUS[0].id;
			// 		$('#' + oID).attr("disabled", "disabled");
			// 	}
			// }, servRenderUS);

			this._ofragmentBrf.open();

			/*Start of change by Satabdi Das on 06-March-2020*/

			/*	var oDatePicker1 = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "LastDateSrv"));
				jQuery.sap.delayedCall(1000, this, function () {
					if (oDatePicker1) {
						var objDate1 = oDatePicker1.getDomRef();
						if (objDate1) {
							objDate1.firstElementChild.firstChild.setAttribute("readonly", true);
						//	objDate1.children[1].setAttribute("readonly", true);
						}
					}
				});*/
			var oNatureField = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "Nature"));
			jQuery.sap.delayedCall(500, this, function () {
				if (oNatureField) {
					var objNature = oNatureField.getDomRef();
					if (objNature) {
						objNature.firstElementChild.firstChild.setAttribute("readonly", true);
						//objNature.children[1].setAttribute("readonly", true);
					}
				}
			}, oNatureField);

			this.disableAllDatepickerMF(); // after UI Upgrade 

			/*var LastDateSrv = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "LastDateSrv"));
			LastDateSrv.addEventDelegate({
				onAfterRendering: function () {
					var oYear = this.$().find('.sapMInputBaseInner');
					var oID = oYear[0].id;
					$('#' + oID).attr("disabled", "disabled");
				}
			}, LastDateSrv);

			var oDatePickerDoc = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "DocumentDateMF"));
			jQuery.sap.delayedCall(1000, this, function () {
				if (oDatePickerDoc) {
					var objDate1 = oDatePickerDoc.getDomRef();
					if (objDate1) {
						objDate1.firstElementChild.firstChild.setAttribute("readonly", true);
						//objDate1.children[1].setAttribute("readonly", true);
					}
				}
			});
			var oDatePickerDocPost = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "PostingDateMF"));
			jQuery.sap.delayedCall(1000, this, function () {
				if (oDatePickerDocPost) {
					var objDate1 = oDatePickerDocPost.getDomRef();
					if (objDate1) {
						objDate1.firstElementChild.firstChild.setAttribute("readonly", true);
						//objDate1.children[1].setAttribute("readonly", true);
					}
				}
			});
			var oDatePicker2 = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "DocumentDate"));
			jQuery.sap.delayedCall(1000, this, function () {
				if (oDatePicker2) {
					var objDate2 = oDatePicker2.getDomRef();
					if (objDate2) {
						objDate2.firstElementChild.firstChild.setAttribute("readonly", true);
						//	objDate2.children[1].setAttribute("readonly", true);
					}
				}
			});
			var oDatePicker3 = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "PostingDate"));
			jQuery.sap.delayedCall(1000, this, function () {
				if (oDatePicker3) {
					var objDate3 = oDatePicker3.getDomRef();
					if (objDate3) {
						objDate3.firstElementChild.firstChild.setAttribute("readonly", true);
						//objDate3.children[1].setAttribute("readonly", true);
					}
				}
			});
			var oDatePicker4 = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "ServicePeriodStart"));
			jQuery.sap.delayedCall(1000, this, function () {
				if (oDatePicker4) {
					var objDate4 = oDatePicker4.getDomRef();
					if (objDate4) {
						objDate4.firstElementChild.firstChild.setAttribute("readonly", true);
						//objDate4.children[1].setAttribute("readonly", true);
					}
				}
			});
			var oDatePicker5 = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "ServicePeriodEnd"));
			jQuery.sap.delayedCall(1000, this, function () {
				if (oDatePicker5) {
					var objDate5 = oDatePicker5.getDomRef();
					if (objDate5) {
						objDate5.firstElementChild.firstChild.setAttribute("readonly", true);
						//objDate5.children[1].setAttribute("readonly", true);
					}
				}
			});
			var oDatePicker6 = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "ServicePeriodStartMF"));
			jQuery.sap.delayedCall(1000, this, function () {
				if (oDatePicker6) {
					var objDate6 = oDatePicker6.getDomRef();
					if (objDate6) {
						objDate6.firstElementChild.firstChild.setAttribute("readonly", true);
						//	objDate6.children[1].setAttribute("readonly", true);
					}
				}
			});
			var oDatePicker7 = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "ServicePeriodEndMF"));
			jQuery.sap.delayedCall(1000, this, function () {
				if (oDatePicker7) {
					var objDate7 = oDatePicker7.getDomRef();
					if (objDate7) {
						objDate7.firstElementChild.firstChild.setAttribute("readonly", true);
						//	objDate7.children[1].setAttribute("readonly", true);
					}
				}
			});
			var oDatePicker8 = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "ServicePeriodStartCR"));
			jQuery.sap.delayedCall(1000, this, function () {
				if (oDatePicker8) {
					var objDate8 = oDatePicker8.getDomRef();
					if (objDate8) {
						objDate8.firstElementChild.firstChild.setAttribute("readonly", true);
						//	objDate8.children[1].setAttribute("readonly", true);
					}
				}
			});
			var oDatePicker9 = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "ServicePeriodEndCR"));
			jQuery.sap.delayedCall(1000, this, function () {
				if (oDatePicker9) {
					var objDate9 = oDatePicker9.getDomRef();
					if (objDate9) {
						objDate9.firstElementChild.firstChild.setAttribute("readonly", true);
						//	objDate9.children[1].setAttribute("readonly", true);
					}
				}
			});
			
			var oNatureField = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "Nature"));
			jQuery.sap.delayedCall(1000, this, function () {
				if (oNatureField) {
					var objNature = oNatureField.getDomRef();
					if (objNature) {
						objNature.firstElementChild.firstChild.setAttribute("readonly", true);
						//	objNature.children[1].setAttribute("readonly", true);
					}
				}
			});

		
			var oGFCurrency = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "CurrGF"));
			jQuery.sap.delayedCall(1000, this, function () {
				if (oGFCurrency) {
					var objGFCurr = oGFCurrency.getDomRef();
					if (objGFCurr) {
						objGFCurr.firstElementChild.firstChild.setAttribute("readonly", true);
						//	objGFCurr.children[1].setAttribute("readonly", true);
					}
				}
			});
			var oMFCurrency = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "MFCurr"));
			jQuery.sap.delayedCall(1000, this, function () {
				if (oMFCurrency) {
					var objMFCurr = oMFCurrency.getDomRef();
					if (objMFCurr) {
						objMFCurr.firstElementChild.firstChild.setAttribute("readonly", true);
						//objMFCurr.children[1].setAttribute("readonly", true);
					}
				}
			});

		
			var oMFDocType = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "MFDocType"));
			jQuery.sap.delayedCall(1000, this, function () {
				if (oMFDocType) {
					var objMFDoc = oMFDocType.getDomRef();
					if (objMFDoc) {
						objMFDoc.firstElementChild.firstChild.setAttribute("readonly", true);
						objMFDoc.children[1].setAttribute("readonly", true);
						//	objMFDoc.children[2].setAttribute("readonly", true);
					}
				}
			});
			
			jQuery.sap.delayedCall(1000, this, function () {
				var documentType = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "creditNoteDoType"));
				if (documentType) {
					var objVal = documentType.getDomRef();
					if (objVal) {
						objVal.firstElementChild.firstChild.setAttribute("readonly", true);
						//objVal.children[1].setAttribute("readonly", true);
					}
				}
			});

			
			var oRestGL = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "GL9921CR"));
			jQuery.sap.delayedCall(1000, this, function () {
				if (oRestGL) {
					var objRestGL = oRestGL.getDomRef();
					if (objRestGL) {
						objRestGL.firstElementChild.firstChild.setAttribute("readonly", true);
						//	objRestGL.children[1].setAttribute("readonly", true);
						// objRestGL.children[2].setAttribute("readonly", true);
					}
				}
			});
		

			var oTaxPointDate = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "TaxPointDate"));
			jQuery.sap.delayedCall(1000, this, function () {
				if (oTaxPointDate) {
					var objTaxDate = oTaxPointDate.getDomRef();
					if (objTaxDate) {
						objTaxDate.firstElementChild.firstChild.setAttribute("readonly", true);
						//objTaxDate.children[1].setAttribute("readonly", true);
					}
				}
			});*/

		},
		onPressCreditNote: function (oEvent) {
			var oBrfModel = this.getView().getModel("oBrfModel");
			var checkDispBtn = this.getView().getModel("oBrfModel").getProperty("/oDisplayBtnPress");
			if (checkDispBtn === "false" || !checkDispBtn) {
				var oModelAttachmentsLastForBF = oBrfModel.getProperty("/FileNameBRFSet");
				if (oModelAttachmentsLastForBF) {
					this.getView().getModel("oBrfModel").setProperty("/FileNameBRFSet", null);
				}
				var oHdr = this.getView().getModel("oBrfModel").getProperty("/brfHeaderSet");
				var sBrfTableRowData = oEvent.getSource().getBindingContext("oBrfModel").getObject();
				sBrfTableRowData.CnType = "";
				var oKeepingDataForCreditLine = {};
				oKeepingDataForCreditLine.LttCN = sBrfTableRowData.Ltt;
				oKeepingDataForCreditLine.LongTextCreditNote = sBrfTableRowData.LongText;
				oKeepingDataForCreditLine.AddlDescAboveCN = sBrfTableRowData.AddlDescAbove;
				oKeepingDataForCreditLine.DocumDate = sBrfTableRowData.DocumentDate;
				oKeepingDataForCreditLine.PostDate = sBrfTableRowData.PostingDate;
				oKeepingDataForCreditLine.oAdlDescriptionCNLine = sBrfTableRowData.AdlDescription;
				oKeepingDataForCreditLine.oDetailsDescriptionOfServicCNLINE = sBrfTableRowData.DetailsDescriptionOfServic;
				oKeepingDataForCreditLine.oRechargeAmountDebitCNline = sBrfTableRowData.RechargeAmountDebit;
				oKeepingDataForCreditLine.oRechargeAmountCreditCNline = sBrfTableRowData.RechargeAmountCredit;
				oKeepingDataForCreditLine.DocumentTypeline = sBrfTableRowData.DocumentType;
				// oKeepingDataForCreditLine.LocOfRenderingUs = sBrfTableRowData.LocOfRenderingUs;
				oKeepingDataForCreditLine.oRemainingCNAmt = sBrfTableRowData.RemCnAmount;
				oBrfModel.setProperty("/oReSetDataOfCN", oKeepingDataForCreditLine);
				oBrfModel.setProperty("/longTextSetCancel", sBrfTableRowData.LongText);
				oBrfModel.setProperty("/SelcKeyForLocServ", sBrfTableRowData.LocationOfTheServicesReq);
				oBrfModel.setProperty("/oVisibleSet/countryComboBox", false);
				oBrfModel.setProperty("/oVisibleSet/editContyCod", true);
				oBrfModel.setProperty("/oVisibleSet/TaxPointDateEditDisplay", false);
				sBrfTableRowData.DocumentDate = "";
				sBrfTableRowData.PostingDate = "";
				//sBrfTableRowData.BillingSyntax="";
				oBrfModel.setProperty("/oVisibleSet/nonCreditNoteText", false);
				// if (sBrfTableRowData.LocationOfTheServicesReq === "US") {
				// 	oBrfModel.setProperty("/oVisibleSet/serviceRenderBox", true);
				// } else {
				// 	oBrfModel.setProperty("/oVisibleSet/serviceRenderBox", false);
				// }

				if (sBrfTableRowData.Curr1) {
					oBrfModel.setProperty("/CurrencySet", sBrfTableRowData.Curr1);
				}
				if (sBrfTableRowData.TaxpointDate === "00000000") {
					sBrfTableRowData.TaxpointDate = "";
				}

				oBrfModel.setProperty("/oVisibleSet/creditNoteField", true);
				oBrfModel.setProperty("/oVisibleSet/RI", false);
				oBrfModel.setProperty("/oVisibleSet/attachVisible", false);
				oBrfModel.setProperty("/oVisibleSet/amountfieldVisible", false);
				oBrfModel.setProperty("/oVisibleSet/lineItemVisibleForMF", true);
				oBrfModel.setProperty("/oVisibleSet/lineItemVisibleForGF", false);
				oBrfModel.setProperty("/oVisibleSet/lineItemVisibleForGF", false);
				oBrfModel.setProperty("/oVisibleSet/editReqMF", false);
				oBrfModel.setProperty("/oVisibleSet/vatEditDisplay", false);
				oBrfModel.setProperty("/entityEdit", false);
				oBrfModel.setProperty("/oVisibleSet/editable", false);
				oBrfModel.setProperty("/oVisibleSet/EditAPUrnforNP", false);
				oBrfModel.setProperty("/oVisibleSet/creditNoteTypeFieldVisible", true);
				oBrfModel.setProperty("/oVisibleSet/creditNoteTypeFieldEdit", true);
				oBrfModel.setProperty("/oVisibleSet/creditNoteAmount", true);
				oBrfModel.setProperty("/oVisibleSet/remaingAmount", false);
				oBrfModel.setProperty("/oVisibleSet/amountFieldEditableForCN", true);
				oBrfModel.setProperty("/oVisibleSet/postDate", true);
				oBrfModel.setProperty("/oVisibleSet/postDateEdit", true);
				oBrfModel.setProperty("/SelcKeySetBRF", sBrfTableRowData.RequestingMf);
				oBrfModel.setProperty("/linetText", "CREDITNOTE");

				if (sBrfTableRowData.CompanyCode === "9921") {
					oBrfModel.setProperty("/Bukrs9921", true);
					oBrfModel.setProperty("/Bukrs9901", false);
					oBrfModel.setProperty("/DocumentType", "");
					oBrfModel.setProperty("/oVisibleSet/documentTypeNoNCN", false);
					oBrfModel.setProperty("/oVisibleSet/documentTypeEditCN", true);
					oBrfModel.setProperty("/oVisibleSet/creditNoteDocumentVisible", true);
					switch (sBrfTableRowData.DocumentType) {
					case "OI":
						oBrfModel.setProperty("/DocumentType", "OC");
						oBrfModel.setProperty("/oVisibleSet/documentTypeEditCN", false);

						break;
					case "EI":
						oBrfModel.setProperty("/DocumentType", "EC");
						oBrfModel.setProperty("/oVisibleSet/documentTypeEditCN", false);
						break;
					}

				} else {
					oBrfModel.setProperty("/Bukrs9921", false);
					oBrfModel.setProperty("/Bukrs9901", true);
					oBrfModel.setProperty("/DocumentType", "RC");
					oBrfModel.setProperty("/oVisibleSet/documentTypeNoNCN", false);
					oBrfModel.setProperty("/oVisibleSet/documentTypeEditCN", false);
					oBrfModel.setProperty("/oVisibleSet/creditNoteDocumentVisible", true);

				}

				// if (checkDispBtn === "true") {
				// 	var frgText = this.getView().getModel("i18n").getProperty("DisplayLitem");
				// 	oBrfModel.setProperty("/fraggmentText", frgText);
				// 	this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/vatEditDisplay", false);
				// 	this.getModel("oBrfModel").setProperty("/LastDateSrv", false); /*Added on 26-May-2020*/
				// 	this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/EditAPUrnforNP", false); /*Added for defect 63363*/
				// 	this.byId(sap.ui.core.Fragment.createId("createBrfFragment", "checkboxVatId")).setProperty("enabled", false);

				// }
				if (checkDispBtn === "false" || !checkDispBtn) {
					var creditNoteText = this.getView().getModel("i18n").getProperty("creditNote");
					oBrfModel.setProperty("/fraggmentText", creditNoteText);

				}

				oBrfModel.setProperty("/lineItemBRFSet", sBrfTableRowData);

				if (sBrfTableRowData.GlobalCc === "N/A") {
					if (!oHdr.RrfNo) {
						oBrfModel.setProperty("/oVisibleSet/apUrnForMf", false);
						oBrfModel.setProperty("/oVisibleSet/withoutRef", true);
					}
					if (sBrfTableRowData.WhtCode && sBrfTableRowData.WhtCode !== "" && sBrfTableRowData.WhtCode !== "N/A") {
						oBrfModel.setProperty("/WhTFldsMandat", true);

					} else if (!sBrfTableRowData.WhtCode || sBrfTableRowData.WhtCode === "" || sBrfTableRowData.WhtCode === "N/A") {
						oBrfModel.setProperty("/WhTFldsMandat", false);
					}
					oBrfModel.setProperty("/oVisibleSet/lineItemVisibleForGF", false);
					oBrfModel.setProperty("/oVisibleSet/lineItemVisibleForMF", true);
					oBrfModel.setProperty("/SelcKeyForLocServ", sBrfTableRowData.LocationOfTheServicesReq);
					/*Start of defect 63418*/
					var bManual = oBrfModel.getProperty("/oVisibleSet/withoutRef");
					if (bManual === true && sBrfTableRowData.RequestingMf === "US") {
						oBrfModel.setProperty("/CodeMandat", true);
					} else {
						oBrfModel.setProperty("/CodeMandat", false);
					}
					/*End of defect 63418*/

					if (sBrfTableRowData.NatureOfService && sBrfTableRowData.NatureOfService !== "" && sBrfTableRowData.NatureOfService ===
						"Adhoc/One-Off") {
						oBrfModel.setProperty("/DateMandatory", true);
						oBrfModel.setProperty("/LastDateSrv", true);
					} else {
						oBrfModel.setProperty("/DateMandatory", false);
						oBrfModel.setProperty("/LastDateSrv", false);
					}
					if (sBrfTableRowData.CreditGl && (sBrfTableRowData.CreditGl === "160100" || sBrfTableRowData.CreditGl === "320150")) {
						this.getModel("oBrfModel").setProperty("/oVisibleSet/CRGL160100", true);
					} else if (sBrfTableRowData.CreditGl !== "160100" || sBrfTableRowData.CreditGl !== "320150") { /*Changed for defect 63348*/
						this.getModel("oBrfModel").setProperty("/oVisibleSet/CRGL160100", false);
					}
				}
				var createBrfFragment = this.getView().createId("createBrfFragment");

				if (!this._ofragmentBrf) {
					this._ofragmentBrf = sap.ui.xmlfragment(createBrfFragment, "KGO.kgoarrecharge_brf.view.createLineItemForBrf", this);
					this.getView().addDependent(this._ofragmentBrf);
				}
				if (this._ofragmentBrf) {

					this.byId(sap.ui.core.Fragment.createId("createBrfFragment", "checkboxVatId")).setProperty("enabled", false); //added by prashant
					this.byId(sap.ui.core.Fragment.createId("createBrfFragment", "checkboxVatId")).setProperty("selected", false);

					var oAnswer = this.getModel("oBrfModel").getProperty("/questionSetSubmit");
					var oAnswerShow = [];
					var _fFirstLineData = [];
					for (var t = 0; t < oAnswer.length; t++) {
						if (oAnswer[t].LineType === sBrfTableRowData.LineType && oAnswer[t].RequestingMf === sBrfTableRowData.RequestingMf && oAnswer[
								t]
							.MemberFirm === sBrfTableRowData.MemberFirm && oAnswer[t].ProcessGrp === sBrfTableRowData.ProcessGrp && oAnswer[t].TransactionType ===
							sBrfTableRowData.TransactionType) {
							var object = {};
							object.LineNo = oAnswer[t].LineNo;
							object.CompanyCode = oAnswer[t].CompanyCode;
							object.Mandatory = oAnswer[t].Mandatory;
							object.MemberFirm = oAnswer[t].MemberFirm;
							object.Question = oAnswer[t].Question;
							object.AnswerDesc = oAnswer[t].AnswerDesc;
							object.Answer = oAnswer[t].Answer;
							object.InternalExternal = oAnswer[t].InternalExternal;
							object.LineType = oAnswer[t].LineType;
							object.TransactionType = oAnswer[t].TransactionType;
							object.RequestingMf = oAnswer[t].RequestingMf;
							object.ProcessGrp = sBrfTableRowData.ProcessGrp;
							if (object.Answer === "Service from KPMGI" || object.Answer == "Service from external supplier") {
								_fFirstLineData.push(object);
							} else {
								oAnswerShow.push(object);
							}
						}
					}
					oBrfModel.setProperty("/questionSet", oAnswerShow);
					oBrfModel.setProperty("/firstQuestionSet", _fFirstLineData);

					var tbl = sap.ui.core.Fragment.byId(createBrfFragment, "QuestionTable2");
					var firstQtable = sap.ui.core.Fragment.byId(createBrfFragment, "QuestionTableFirst");
					if (_fFirstLineData && _fFirstLineData.length > 0) {
						firstQtable.getAggregation("items")[0].getCells()[2].setProperty("editable", false);

					}

					if (oAnswerShow.length > 0) {
						oBrfModel.setProperty("/oVisibleSet/questionPnVisibleBRF", true);
						for (var j = 0; j < oAnswerShow.length; j++) {
							if (oAnswerShow[j].Answer === "N/A") {
								tbl.getAggregation("items")[j].getCells()[3].setProperty("visible", false);
								tbl.getAggregation("items")[j].getCells()[2].setProperty("editable", false);
							} else {
								tbl.getAggregation("items")[j].getCells()[3].setProperty("visible", true);
								tbl.getAggregation("items")[j].getCells()[3].setProperty("editable", false);
								tbl.getAggregation("items")[j].getCells()[2].setProperty("editable", false);

							}
						}
					} else {
						oBrfModel.setProperty("/oVisibleSet/questionPnVisibleBRF", false);
					}

					this._ofragmentBrf.open();
					this.oPressCNflag = true;

				}

				jQuery.sap.delayedCall(1000, this, function () {
					var documentType = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "creditNoteDoType"));
					if (documentType) {
						var objVal = documentType.getDomRef();
						if (objVal) {
							objVal.firstElementChild.firstChild.setAttribute("readonly", true);
							//objVal.children[1].setAttribute("readonly", true);
						}
					}
				});

				var oCNTypeType = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "CNType"));
				jQuery.sap.delayedCall(1000, this, function () {
					if (oCNTypeType) {
						var objCNtype = oCNTypeType.getDomRef();
						if (objCNtype) {
							objCNtype.firstElementChild.firstChild.setAttribute("readonly", true);
							// objCNtype.children[1].setAttribute("readonly", true);
							// objCNtype.children[2].setAttribute("readonly", true);
						}
					}
				});

				/*Start of change by Satabdi Das on 05-March-2021 for SCTASK1838272*/
				var oRestGL = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "GL9921CR"));
				jQuery.sap.delayedCall(1000, this, function () {
					if (oRestGL) {
						var objRestGL = oRestGL.getDomRef();
						if (objRestGL) {
							objRestGL.firstElementChild.firstChild.setAttribute("readonly", true);
							//objRestGL.children[1].setAttribute("readonly", true);
							// objRestGL.children[2].setAttribute("readonly", true);
						}
					}
				});
				/*End of change by Satabdi Das on 05-March-2021 for SCTASK1838272*/

				this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "idselectokForedit")).setVisible(false);
				this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "addLineItemOkId")).setVisible(false);

			}

		},
		onPressOKofCreditNote: function (oEvent) {
			var oBrfModel = this.getView().getModel("oBrfModel");
			var bDisplay = oBrfModel.getProperty("/Display");
			var LineTEXt = oBrfModel.getProperty("/linetText");
			var oTblBRF = this.getView().byId("tableid");
			var that = this;
			var oDataToCN = {};
			var oLineItemData = oBrfModel.getProperty("/lineItemBRFSet");
			// var linestatusCN =oBrfModel.getProperty("/oReSetDataOfCN").linestatusCN;
			// oBrfModel.setProperty("/lineItemBRFSet/linestatus",linestatusCN);
			oLineItemData.LineType = "INVOICE";
			var CreditNoteDocType = oBrfModel.getProperty("/DocumentType");
			oLineItemData.Curr1 = oBrfModel.getProperty("/CurrencySet");
			oLineItemData.Ltt = oBrfModel.getProperty("/oReSetDataOfCN").LttCN;
			oDataToCN.AdlDescription = oLineItemData.AdlDescription;
			oLineItemData.AdlDescription = oBrfModel.getProperty("/oReSetDataOfCN").oAdlDescriptionCNLine;
			oDataToCN.LongText = oLineItemData.LongText;
			oLineItemData.LongText = oBrfModel.getProperty("/oReSetDataOfCN").LongTextCreditNote;
			oDataToCN.AddlDescAbove = oLineItemData.AddlDescAbove;
			oLineItemData.AddlDescAbove = oBrfModel.getProperty("/oReSetDataOfCN").AddlDescAboveCN;
			oDataToCN.DetailsDescriptionOfServic = oLineItemData.DetailsDescriptionOfServic;
			oLineItemData.DetailsDescriptionOfServic = oBrfModel.getProperty("/oReSetDataOfCN").oDetailsDescriptionOfServicCNLINE;
			oDataToCN.RechargeAmountDebit = oLineItemData.RechargeAmountDebit;
			oLineItemData.RechargeAmountDebit = oBrfModel.getProperty("/oReSetDataOfCN").oRechargeAmountDebitCNline;
			oDataToCN.RechargeAmountCredit = oLineItemData.RechargeAmountCredit;
			oLineItemData.RechargeAmountCredit = oBrfModel.getProperty("/oReSetDataOfCN").oRechargeAmountCreditCNline;
			oDataToCN.DocumentType = CreditNoteDocType;
			oLineItemData.DocumentType = oBrfModel.getProperty("/oReSetDataOfCN").DocumentTypeline;
			oDataToCN.DocumentDate = oLineItemData.DocumentDate;
			oLineItemData.DocumentDate = oBrfModel.getProperty("/oReSetDataOfCN").DocumDate;
			oDataToCN.PostingDate = oLineItemData.PostingDate;
			oLineItemData.PostingDate = oBrfModel.getProperty("/oReSetDataOfCN").PostDate;
			// oDataToCN.LocOfRenderingUs = oLineItemData.LocOfRenderingUs;
			// oLineItemData.LocOfRenderingUs = oBrfModel.getProperty("/oReSetDataOfCN").LocOfRenderingUs;

			oLineItemData.CnFlag = "X";
			if (!oLineItemData.CnType || !oLineItemData.Curr1) {
				var sMsgCN = this.getView().getModel("i18n").getProperty("cNMessage");
				MessageBox.alert(sMsgCN);
				return;
			}
			if (oDataToCN.RechargeAmountCredit !== oDataToCN.RechargeAmountDebit) {
				var sMsgCAmount = this.getView().getModel("i18n").getProperty("Amountmsg");
				MessageBox.alert(sMsgCAmount);
				return;
			}

			//questionnaire changes in credit note
			var _qfirstQuestionData = oBrfModel.getProperty("/firstQuestionSet");
			if ((oBrfModel.getProperty("/questionSet")) && (_qfirstQuestionData.length > 0)) {
				oBrfModel.getProperty("/firstQuestionSet")[0].LineType = "CREDITNOTE";
				oBrfModel.getProperty("/questionSetSubmit").push(_qfirstQuestionData[0]);
				for (var i = 0; i < oBrfModel.getProperty("/questionSet").length; i++) {
					oBrfModel.getProperty("/questionSet")[i].LineType = "CREDITNOTE";
					oBrfModel.getProperty("/questionSet")[i].TransactionType = oLineItemData.TransactionType;
					oBrfModel.getProperty("/questionSetSubmit").push(oBrfModel.getProperty("/questionSet")[i]);

				}

			}

			//end of credit note changes

			if (oLineItemData.CnType && oLineItemData.RequestingMf) {
				this.oPressCNflag = false;
				var oCNotedata = {};
				oCNotedata.LineType = "CREDITNOTE";
				oCNotedata.CnFlag = "";
				oCNotedata.TrackNo = oLineItemData.TrackNo;
				oCNotedata.AccrTrackNoCredit = oLineItemData.AccrTrackNoCredit;
				oCNotedata.AccrTrackNo = oLineItemData.AccrTrackNo;
				oCNotedata.Action = "";
				oCNotedata.LineStatus = "";
				oCNotedata.DocumentDate = oDataToCN.DocumentDate;
				oCNotedata.PostingDate = oDataToCN.PostingDate;
				oCNotedata.DocumentType = oDataToCN.DocumentType;
				oCNotedata.FiDocNo = "";
				oCNotedata.BillingSyntax = oLineItemData.BillingSyntax;
				oCNotedata.AddlCcEmails = oLineItemData.AddlCcEmails;
				oCNotedata.AddlDescAbove = oDataToCN.AddlDescAbove;
				oCNotedata.AdlDescription = oDataToCN.AdlDescription;
				oCNotedata.AdlEmail = oLineItemData.AdlEmail;
				oCNotedata.ArApprName = oLineItemData.ArApprName;
				oCNotedata.AttenBrf = oLineItemData.AttenBrf;
				oCNotedata.AttenBrfEmail = oLineItemData.AttenBrfEmail;
				oCNotedata.BrfNo = oLineItemData.BrfNo;
				oCNotedata.CcCode1 = oLineItemData.CcCode1;
				oCNotedata.CcCode2 = oLineItemData.CcCode2;
				oCNotedata.CntrlApprName = oLineItemData.CntrlApprName;
				oCNotedata.CnType = oLineItemData.CnType;
				oCNotedata.Comments = oLineItemData.Comments;
				oCNotedata.CompanyCode = oLineItemData.CompanyCode;
				oCNotedata.CreditGl = oLineItemData.CreditGl;
				oCNotedata.Curr1 = oLineItemData.Curr1;
				oCNotedata.Curr2 = oLineItemData.Curr2;
				oCNotedata.CurrentWorkitem = oLineItemData.CurrentWorkitem;
				oCNotedata.DebitGl = oLineItemData.DebitGl;
				oCNotedata.DetailsDescriptionOfServic = oDataToCN.DetailsDescriptionOfServic;
				oCNotedata.DocHeaderText = oLineItemData.DocHeaderText;
				oCNotedata.EditDisplay = oLineItemData.EditDisplay;
				oCNotedata.EditReqMf = oLineItemData.EditReqMf;
				oCNotedata.EntityAddress = oLineItemData.EntityAddress;
				oCNotedata.EntityName = oLineItemData.EntityName;
				oCNotedata.ExpenseGl = oLineItemData.ExpenseGl;
				oCNotedata.ExpenseGlCredit = oLineItemData.ExpenseGlCredit;
				oCNotedata.FunctionName = oLineItemData.FunctionName;
				oCNotedata.GfEmail = oLineItemData.GfEmail;
				oCNotedata.GfName = oLineItemData.GfName;
				oCNotedata.GlobalCc = oLineItemData.GlobalCc;
				oCNotedata.GpIdCredit = oLineItemData.GpIdCredit;
				oCNotedata.Gpid = oLineItemData.Gpid;
				oCNotedata.InvoiceReady = oLineItemData.InvoiceReady;
				oCNotedata.InvoiceStatus = "";
				oCNotedata.Landx = oLineItemData.Landx;
				oCNotedata.MemberFirm = oLineItemData.MemberFirm;
				oCNotedata.KpmgiVatId = oLineItemData.KpmgiVatId;
				oCNotedata.LastDateSrv = oLineItemData.LastDateSrv;
				oCNotedata.ProcessGrp = oLineItemData.ProcessGrp;
				oCNotedata.NextWorkitem = oLineItemData.NextWorkitem;
				oCNotedata.NatureOfService = oLineItemData.NatureOfService;
				oCNotedata.MfCostCenter = oLineItemData.MfCostCenter;
				oCNotedata.MfApEmail = oLineItemData.MfApEmail;
				oCNotedata.Ltt = "";
				oCNotedata.LttApprName = oLineItemData.LttApprName;
				oCNotedata.Ltext = oLineItemData.Ltext;
				oCNotedata.LongText = oDataToCN.LongText;
				oCNotedata.ProfitCenterDebit = oLineItemData.ProfitCenterDebit;
				oCNotedata.ProfitCenter = oLineItemData.ProfitCenter;
				oCNotedata.RechargeAmountCredit = oDataToCN.RechargeAmountCredit;
				oCNotedata.RechargeAmountDebit = oDataToCN.RechargeAmountDebit;
				oCNotedata.RechargeType = oLineItemData.RechargeType;
				oCNotedata.ReferenceDoc = oLineItemData.ReferenceDoc;
				oCNotedata.RemCnAmount = oLineItemData.RemCnAmount;
				oCNotedata.RequestingMf = oLineItemData.RequestingMf;
				oCNotedata.LocationOfTheServicesReq = oLineItemData.LocationOfTheServicesReq;
				oCNotedata.RrfLineStatus = oLineItemData.RrfLineStatus;
				oCNotedata.SalesTaxCode = oLineItemData.SalesTaxCode;
				oCNotedata.SapCodeMf = oLineItemData.SapCodeMf;
				oCNotedata.SchDate = oLineItemData.SchDate;
				oCNotedata.ServicePeriodEnd = oLineItemData.ServicePeriodEnd;
				oCNotedata.ServicePeriodEndCredit = oCNotedata.ServicePeriodEndCredit;
				oCNotedata.ServicePeriodStart = oLineItemData.ServicePeriodStart;
				oCNotedata.ServicePeriodStart = oLineItemData.ServicePeriodStart;
				oCNotedata.ServicePeriodStartCredit = oCNotedata.ServicePeriodStartCredit;
				oCNotedata.SuperUser = oLineItemData.SuperUser;
				oCNotedata.SuppApprName = oLineItemData.SuppApprName;
				oCNotedata.TaxpointDate = oCNotedata.TaxpointDate;
				oCNotedata.TotalCnAmount = oLineItemData.TotalCnAmount;
				oCNotedata.TransactionType = oLineItemData.TransactionType;
				oCNotedata.Urn = oCNotedata.Urn;
				oCNotedata.VatApprName = oLineItemData.VatApprName;
				oCNotedata.VatDesc = oLineItemData.VatDesc;
				oCNotedata.VatId = oCNotedata.VatId;
				oCNotedata.VatSapCode = oLineItemData.VatSapCode;
				oCNotedata.WhtCode = oLineItemData.WhtCode;
				oCNotedata.LineItemTotal = oLineItemData.LineItemTotal;
				// oCNotedata.LocOfRenderingUs = oLineItemData.LocOfRenderingUs;
				//transactionType assinging to credit note line
				// oBrfModel.getProperty("/brfTableSet")
				// oBrfModel.getProperty("/brfTableSet")[2].LineType
				// oBrfModel.getProperty("/brfTableSet")[2].TransactionType

				oBrfModel.getProperty("/brfTableSet").push(oCNotedata);

				this._ofragmentBrf.close();
				oBrfModel.setProperty("/questionSet", []);
				this.getView().getModel("oBrfModel").refresh();
				for (var i = 0; i < oTblBRF.getItems().length; i++) {
					var _oPartiCularLineData = oTblBRF.getBindingInfo("items").binding.oList[i];
					var oActionData = oTblBRF.getAggregation("items")[i].getCells()[9];
					var LttCheckBox = oTblBRF.getAggregation("items")[i].getCells()[7];
					var oRiField = oTblBRF.getAggregation("items")[i].getCells()[10];
					if (_oPartiCularLineData.Ltt === "X") {
						LttCheckBox.setProperty("selected", true);
					} else {
						LttCheckBox.setProperty("selected", false);
					}
					if (_oPartiCularLineData.LineStatus) {
						LttCheckBox.setProperty("enabled", false);
					}
					if ((_oPartiCularLineData.LineType === "INVOICE") && (_oPartiCularLineData.RequestingMf !== "N/A")) {
						oActionData.setProperty("visible", true);
						oActionData.setProperty("enabled", false);
					}

					if (_oPartiCularLineData.CnFlag === "X" && _oPartiCularLineData.LineStatus === "POSTED") {

						oActionData.setProperty("enabled", true);
						oActionData.setProperty("visible", true);

					} else {
						oTblBRF.getAggregation("items")[i].getCells()[9].setProperty("visible", false);
						oRiField.setProperty("visible", false);
					}
					if (_oPartiCularLineData.RiFlag === "") {
						oRiField.setProperty("visible", false);
					} else if (_oPartiCularLineData.RiFlag === "X") {
						oRiField.setProperty("visible", true);
					}
				}

			}

			oBrfModel.setProperty("/lineItemBRFSet", {});

		},
		onSelectingCreditNoteDocut: function (oEvent) {
			var selectedDocuType = oEvent.getSource().getProperty("value");
			this.getView().getModel("oBrfModel").setProperty("/DocumentType", selectedDocuType);
		},
		/*Start of Reissuance of Invoice by developer Satabdi Das on 14-Dec-2020 */
		onPressRIBtn: function (oEvent) {
			var oBrfModel = this.getView().getModel("oBrfModel");
			oBrfModel.setProperty("/oVisibleSet/creditNoteField", false);
			var oHdr = this.getView().getModel("oBrfModel").getProperty("/brfHeaderSet");
			var checkDispBtn = this.getView().getModel("oBrfModel").getProperty("/oDisplayBtnPress");
			var sBrfTableRowData = oEvent.getSource().getBindingContext("oBrfModel").getObject();
			var oModelAttachmentsLastForBF = oBrfModel.getProperty("/FileNameBRFSet");
			if (oModelAttachmentsLastForBF) {
				this.getView().getModel("oBrfModel").setProperty("/FileNameBRFSet", null);
			}
			oBrfModel.setProperty("/oVisibleSet/postDate", true);
			oBrfModel.setProperty("/oVisibleSet/postDateEdit", true);
			var oKeepingDataForRI = {};
			oKeepingDataForRI.TrackNoRI = sBrfTableRowData.TrackNo;
			oKeepingDataForRI.AccrTrackNoCreditRI = sBrfTableRowData.AccrTrackNoCredit;
			oKeepingDataForRI.AccrTrackNoRI = sBrfTableRowData.AccrTrackNo;
			oKeepingDataForRI.ActionRI = sBrfTableRowData.Action;
			oKeepingDataForRI.BillingSyn = sBrfTableRowData.BillingSyntax;
			oKeepingDataForRI.AddlCcEmailsRI = sBrfTableRowData.AddlCcEmails;
			oKeepingDataForRI.AddlDescAboveRI = sBrfTableRowData.AddlDescAbove;
			oKeepingDataForRI.AdlDescriptionRI = sBrfTableRowData.AdlDescription;
			oKeepingDataForRI.AdlEmailRI = sBrfTableRowData.AdlEmail;
			oKeepingDataForRI.ArApprNameRI = sBrfTableRowData.ArApprName;
			oKeepingDataForRI.AttenBrfRI = sBrfTableRowData.AttenBrf;
			oKeepingDataForRI.AttenBrfRIEmail = sBrfTableRowData.AttenBrfEmail;
			oKeepingDataForRI.BrfNoRI = sBrfTableRowData.BrfNo;
			oKeepingDataForRI.CcCode1RI = sBrfTableRowData.CcCode1;
			oKeepingDataForRI.CcCode2RI = sBrfTableRowData.CcCode2;
			oKeepingDataForRI.CntrlApprNameRI = sBrfTableRowData.CntrlApprName;
			oKeepingDataForRI.CnTypeRI = sBrfTableRowData.CnType;
			oKeepingDataForRI.CommentsRI = sBrfTableRowData.Comments;
			oKeepingDataForRI.CompanyCodeRI = sBrfTableRowData.CompanyCode;
			oKeepingDataForRI.CreditGlRI = sBrfTableRowData.CreditGl;
			oKeepingDataForRI.Curr1RI = sBrfTableRowData.Curr1;
			oKeepingDataForRI.Curr2RI = sBrfTableRowData.Curr2;
			oKeepingDataForRI.CurrentWorkitemRI = sBrfTableRowData.CurrentWorkitem;
			oKeepingDataForRI.DebitGlRI = sBrfTableRowData.DebitGl;
			oKeepingDataForRI.DetailsDescriptionOfServicRI = sBrfTableRowData.DetailsDescriptionOfServic;
			oKeepingDataForRI.DocHeaderTextRI = sBrfTableRowData.DocHeaderText;
			oKeepingDataForRI.DocumentDateRI = sBrfTableRowData.DocumentDate;
			oKeepingDataForRI.DocumentTypeRI = sBrfTableRowData.DocumentType;
			oKeepingDataForRI.EditDisplayRI = sBrfTableRowData.EditDisplay;
			oKeepingDataForRI.EditReqMfRI = sBrfTableRowData.EditReqMf;
			oKeepingDataForRI.EntityAddressRI = sBrfTableRowData.EntityAddress;
			oKeepingDataForRI.EntityNameRI = sBrfTableRowData.EntityName;
			oKeepingDataForRI.ExpenseGlRI = sBrfTableRowData.ExpenseGl;
			oKeepingDataForRI.ExpenseGlCreditRI = sBrfTableRowData.ExpenseGlCredit;
			oKeepingDataForRI.FiDocNoRI = sBrfTableRowData.FiDocNo;
			oKeepingDataForRI.LineStatusRI = sBrfTableRowData.LineStatus;
			oKeepingDataForRI.FunctionNameRI = sBrfTableRowData.FunctionName;
			oKeepingDataForRI.GfEmailRI = sBrfTableRowData.GfEmail;
			oKeepingDataForRI.GfNameRI = sBrfTableRowData.GfName;
			oKeepingDataForRI.GlobalCcRI = sBrfTableRowData.GlobalCc;
			oKeepingDataForRI.GpIdCreditRI = sBrfTableRowData.GpIdCredit;
			oKeepingDataForRI.GpidRI = sBrfTableRowData.Gpid;
			oKeepingDataForRI.InvoiceReadyRI = sBrfTableRowData.InvoiceReady;
			oKeepingDataForRI.InvoiceStatusRI = sBrfTableRowData.InvoiceStatus;
			oKeepingDataForRI.LandxRI = sBrfTableRowData.LandxRI;
			oKeepingDataForRI.KpmgiVatIdRI = sBrfTableRowData.KpmgiVatId;
			oKeepingDataForRI.LastDateSrvRI = sBrfTableRowData.LastDateSrv;
			oKeepingDataForRI.ProcessGrpRI = sBrfTableRowData.ProcessGrp;
			oKeepingDataForRI.PostingDateRI = sBrfTableRowData.PostingDate;
			oKeepingDataForRI.NextWorkitemRI = sBrfTableRowData.NextWorkitem;
			oKeepingDataForRI.NatureOfServiceRI = sBrfTableRowData.NatureOfService;
			oKeepingDataForRI.MfCostCenterRI = sBrfTableRowData.MfCostCenter;
			oKeepingDataForRI.MfApEmailRI = sBrfTableRowData.MfApEmail;
			oKeepingDataForRI.LttRI = sBrfTableRowData.Ltt;
			oKeepingDataForRI.LttApprNameRI = sBrfTableRowData.LttApprName;
			oKeepingDataForRI.LtextRI = sBrfTableRowData.Ltext;
			oKeepingDataForRI.LongTextRI = sBrfTableRowData.LongText;
			oKeepingDataForRI.ProfitCenterDebitRI = sBrfTableRowData.ProfitCenterDebit;
			oKeepingDataForRI.ProfitCenterRI = sBrfTableRowData.ProfitCenter;
			oKeepingDataForRI.RechargeAmountCreditRI = sBrfTableRowData.RechargeAmountCredit;
			oKeepingDataForRI.RechargeAmountDebitRI = sBrfTableRowData.RechargeAmountDebit;
			oKeepingDataForRI.RechargeTypeRI = sBrfTableRowData.RechargeType;
			oKeepingDataForRI.ReferenceDocRI = sBrfTableRowData.ReferenceDoc;
			oKeepingDataForRI.RemCnAmountRI = sBrfTableRowData.RemCnAmount;
			oKeepingDataForRI.RequestingMfRI = sBrfTableRowData.RequestingMf;
			oKeepingDataForRI.RrfLineStatusRI = sBrfTableRowData.RrfLineStatus;
			oKeepingDataForRI.SalesTaxCodeRI = sBrfTableRowData.SalesTaxCode;
			oKeepingDataForRI.SapCodeMfRI = sBrfTableRowData.SapCodeMf;
			oKeepingDataForRI.SchDateRI = sBrfTableRowData.SchDate;
			oKeepingDataForRI.ServicePeriodEndRI = sBrfTableRowData.ServicePeriodEnd;
			oKeepingDataForRI.ServicePeriodEndCreditRI = sBrfTableRowData.ServicePeriodEndCredit;
			oKeepingDataForRI.ServicePeriodStartRI = sBrfTableRowData.ServicePeriodStart;
			oKeepingDataForRI.ServicePeriodStartRI = sBrfTableRowData.ServicePeriodStart;
			oKeepingDataForRI.ServicePeriodStartCreditRI = sBrfTableRowData.ServicePeriodStartCredit;
			oKeepingDataForRI.SuperUserRI = sBrfTableRowData.SuperUser;
			oKeepingDataForRI.SuppApprNameRI = sBrfTableRowData.SuppApprName;
			oKeepingDataForRI.TaxpointDateRI = sBrfTableRowData.TaxpointDate;
			oKeepingDataForRI.TotalCnAmountRI = sBrfTableRowData.TotalCnAmount;
			oKeepingDataForRI.TransactionTypeRI = sBrfTableRowData.TransactionType;
			oKeepingDataForRI.UrnRI = sBrfTableRowData.Urn;
			oKeepingDataForRI.VatApprNameRI = sBrfTableRowData.VatApprName;
			oKeepingDataForRI.VatDescRI = sBrfTableRowData.VatDesc;
			oKeepingDataForRI.VatIdRI = sBrfTableRowData.VatId;
			oKeepingDataForRI.VatSapCodeRI = sBrfTableRowData.VatSapCode;
			oKeepingDataForRI.WhtCodeRI = sBrfTableRowData.WhtCode;
			oKeepingDataForRI.LineItemTotalRI = sBrfTableRowData.LineItemTotal;
			oKeepingDataForRI.LocationOfTheServicesReqRI = sBrfTableRowData.LocationOfTheServicesReq;
			// oKeepingDataForRI.LocOfRenderingUs = sBrfTableRowData.LocOfRenderingUs;
			oBrfModel.setProperty("/oReSetDataOfRI", oKeepingDataForRI);
			oBrfModel.setProperty("/CurrencySet", sBrfTableRowData.Curr1);
			oBrfModel.setProperty("/DocumentType", sBrfTableRowData.DocumentType);
			oBrfModel.setProperty("/oVisibleSet/creditNoteField", false);
			oBrfModel.setProperty("/oVisibleSet/creditNoteTypeFieldVisible", false);
			oBrfModel.setProperty("/oVisibleSet/RI", true);
			oBrfModel.setProperty("/oVisibleSet/editContyCod", true);
			oBrfModel.setProperty("/oVisibleSet/amountfieldVisible", true);
			oBrfModel.setProperty("/oVisibleSet/nonCreditNoteText", true); /*Added by Satabdi Das on 18-Jan-2021 for defect 63835*/
			oBrfModel.setProperty("/oVisibleSet/lineItemVisibleForMF", true);
			oBrfModel.setProperty("/oVisibleSet/lineItemVisibleForGF", false);
			oBrfModel.setProperty("/oVisibleSet/editReqMF", false);
			oBrfModel.setProperty("/entityEdit", true);
			oBrfModel.setProperty("/oVisibleSet/editable", true);
			oBrfModel.setProperty("/oVisibleSet/amountFieldEditableForCN", true);
			oBrfModel.setProperty("/oVisibleSet/creditNoteAmount", true);
			oBrfModel.setProperty("/SelcKeySetBRF", sBrfTableRowData.RequestingMf);
			oBrfModel.setProperty("/SelcKeyForLocServ", sBrfTableRowData.LocationOfTheServicesReq);
			oBrfModel.setProperty("/NatureOfService", sBrfTableRowData.NatureOfService);
			oBrfModel.setProperty("/linetText", "REISSUANCE");
			oBrfModel.setProperty("/oVisibleSet/vatEditDisplay", true);
			oBrfModel.setProperty("/oVisibleSet/TaxPointDateEditDisplay", true);
			sBrfTableRowData.FiDocNo = "";
			sBrfTableRowData.LineStatus = "";
			sBrfTableRowData.InvoiceStatus = "";
			sBrfTableRowData.DocumentDate = "";
			sBrfTableRowData.PostingDate = "";

			if ((oHdr.RrfNo && oHdr.RrfNo !== "" && oHdr.RrfNo.indexOf("NP") >= 0) || !oHdr.RrfNo) {
				this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/EditAPUrnforNP", true);

			} else {
				this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/EditAPUrnforNP", false);
			}

			// if (sBrfTableRowData.LocationOfTheServicesReq === "US") {
			// 	oBrfModel.setProperty("/oVisibleSet/serviceRenderBox", true);
			// } else {
			// 	oBrfModel.setProperty("/oVisibleSet/serviceRenderBox", false);
			// }

			/*if (checkDispBtn === "true") {
				var frgText = this.getView().getModel("i18n").getProperty("DisplayLitem");
				oBrfModel.setProperty("/fraggmentText", frgText);
				this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/vatEditDisplay", false);
				this.getModel("oBrfModel").setProperty("/LastDateSrv", false); 
				this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/EditAPUrnforNP", false); 
				this.byId(sap.ui.core.Fragment.createId("createBrfFragment", "checkboxVatId")).setProperty("enabled", false);

			}*/

			/*if (checkDispBtn === "false" || !checkDispBtn) {
				var sRiTxt = this.getView().getModel("i18n").getProperty("REISSUANCE");
				oBrfModel.setProperty("/fraggmentText", sRiTxt);
			}*/

			var sRiTxt = this.getView().getModel("i18n").getProperty("REISSUANCE");
			oBrfModel.setProperty("/fraggmentText", sRiTxt);

			if (oHdr.CompanyCode === "9921") {
				oBrfModel.setProperty("/Bukrs9921", true);
				oBrfModel.setProperty("/Bukrs9901", false);
				oBrfModel.setProperty("/oVisibleSet/documentTypeEditCN", false);
				oBrfModel.setProperty("/oVisibleSet/documentTypeNoNCN", true);
				oBrfModel.setProperty("/oVisibleSet/creditNoteDocumentVisible", false);
			} else {
				oBrfModel.setProperty("/Bukrs9921", false);
				oBrfModel.setProperty("/Bukrs9901", true);
				oBrfModel.setProperty("/oVisibleSet/documentTypeEditCN", false);
				oBrfModel.setProperty("/oVisibleSet/documentTypeNoNCN", false);
				oBrfModel.setProperty("/oVisibleSet/creditNoteDocumentVisible", false);
			}

			oBrfModel.setProperty("/lineItemBRFSet", sBrfTableRowData);
			// if (sBrfTableRowData.RequestingMf === "N/A") {
			// 	oBrfModel.setProperty("/oVisibleSet/lineItemVisibleForGF", true);
			// 	oBrfModel.setProperty("/oVisibleSet/lineItemVisibleForMF", false);
			// 	if (!oHdr.RrfNo) {
			// 		oBrfModel.setProperty("/oVisibleSet/assigmentUrn", false);
			// 		oBrfModel.setProperty("/oVisibleSet/withoutRef", true);

			// 	}

			// 	oBrfModel.setProperty("/SelcKeyForLocServ", "NMT");
			// 	sBrfTableRowData.LocationOfTheServicesReq = "NMT";
			// 	if (sBrfTableRowData.DebitGl && (sBrfTableRowData.DebitGl === "160100" || sBrfTableRowData.DebitGl === "320150")) {
			// 		this.getModel("oBrfModel").setProperty("/oVisibleSet/GL160100", true);
			// 	} else if (sBrfTableRowData.DebitGl !== "160100" || sBrfTableRowData.DebitGl !== "320150") { /*Changed for defect 63348*/
			// 		this.getModel("oBrfModel").setProperty("/oVisibleSet/GL160100", false);
			// 	}

			// 	if (sBrfTableRowData.CreditGl && (sBrfTableRowData.CreditGl === "160100" || sBrfTableRowData.CreditGl === "320150")) {
			// 		this.getModel("oBrfModel").setProperty("/oVisibleSet/CRGL160100", true);
			// 	} else if (sBrfTableRowData.CreditGl !== "160100" || sBrfTableRowData.CreditGl !== "320150") { /*Changed for defect 63348*/
			// 		this.getModel("oBrfModel").setProperty("/oVisibleSet/CRGL160100", false);
			// 	}

			// }
			if (sBrfTableRowData.TaxpointDate === "00000000") {
				sBrfTableRowData.TaxpointDate = "";
			}

			if (sBrfTableRowData.GlobalCc === "N/A") {
				if (!oHdr.RrfNo) {
					oBrfModel.setProperty("/oVisibleSet/apUrnForMf", false);
					oBrfModel.setProperty("/oVisibleSet/withoutRef", true);
				}
				if (sBrfTableRowData.WhtCode && sBrfTableRowData.WhtCode !== "" && sBrfTableRowData.WhtCode !== "N/A") {
					oBrfModel.setProperty("/WhTFldsMandat", true);

				} else if (!sBrfTableRowData.WhtCode || sBrfTableRowData.WhtCode === "" || sBrfTableRowData.WhtCode === "N/A") {
					oBrfModel.setProperty("/WhTFldsMandat", false);
				}
				oBrfModel.setProperty("/oVisibleSet/lineItemVisibleForGF", false);
				oBrfModel.setProperty("/oVisibleSet/lineItemVisibleForMF", true);
				oBrfModel.setProperty("/SelcKeyForLocServ", sBrfTableRowData.LocationOfTheServicesReq);
				/*Start of defect 63418*/
				var bManual = oBrfModel.getProperty("/oVisibleSet/withoutRef");
				if (sBrfTableRowData.RequestingMf === "US" || sBrfTableRowData.RequestingMf==="NL") {
					oBrfModel.setProperty("/CodeMandat", true);
				} else {
					oBrfModel.setProperty("/CodeMandat", false);
				}
				/*End of defect 63418*/

				if (sBrfTableRowData.NatureOfService && sBrfTableRowData.NatureOfService !== "" && sBrfTableRowData.NatureOfService ===
					"Adhoc/One-Off") {
					oBrfModel.setProperty("/DateMandatory", true);
					oBrfModel.setProperty("/LastDateSrv", true); /*Added for defect 63833 on 14-Jan-2021*/
				} else {
					oBrfModel.setProperty("/DateMandatory", false);
					oBrfModel.setProperty("/LastDateSrv", false); /*Added for defect 63833 on 14-Jan-2021*/
				}
				if (sBrfTableRowData.CreditGl && (sBrfTableRowData.CreditGl === "160100" || sBrfTableRowData.CreditGl === "320150")) {
					this.getModel("oBrfModel").setProperty("/oVisibleSet/CRGL160100", true);
				} else if (sBrfTableRowData.CreditGl !== "160100" || sBrfTableRowData.CreditGl !== "320150") { /*Changed for defect 63348*/
					this.getModel("oBrfModel").setProperty("/oVisibleSet/CRGL160100", false);
				}
			}
			var createBrfFragment = this.getView().createId("createBrfFragment");

			if (!this._ofragmentBrf) {
				this._ofragmentBrf = sap.ui.xmlfragment(createBrfFragment, "KGO.kgoarrecharge_brf.view.createLineItemForBrf", this);
				this.getView().addDependent(this._ofragmentBrf);
			}
			if (this._ofragmentBrf) {
				//questionnaire changes

				var oAnswer = this.getModel("oBrfModel").getProperty("/questionSetSubmit");
				var oAnswerShow = [];
				var _fFirstLineData = [];
				for (var t = 0; t < oAnswer.length; t++) {
					if (oAnswer[t].LineType === sBrfTableRowData.LineType && oAnswer[t].RequestingMf === sBrfTableRowData.RequestingMf && oAnswer[
							t]
						.MemberFirm === sBrfTableRowData.MemberFirm && oAnswer[t].ProcessGrp === sBrfTableRowData.ProcessGrp && oAnswer[t].TransactionType ===
						sBrfTableRowData.TransactionType) {
						var object = {};
						object.LineNo = oAnswer[t].LineNo;
						object.CompanyCode = oAnswer[t].CompanyCode;
						object.Mandatory = oAnswer[t].Mandatory;
						object.MemberFirm = oAnswer[t].MemberFirm;
						object.Question = oAnswer[t].Question;
						object.AnswerDesc = oAnswer[t].AnswerDesc;
						object.Answer = oAnswer[t].Answer;
						object.InternalExternal = oAnswer[t].InternalExternal;
						object.LineType = oAnswer[t].LineType;
						object.TransactionType = oAnswer[t].TransactionType;
						object.RequestingMf = oAnswer[t].RequestingMf;
						object.ProcessGrp = sBrfTableRowData.ProcessGrp;
						if (object.Answer === "Service from KPMGI" || object.Answer == "Service from external supplier") {
							_fFirstLineData.push(object);
						} else {
							oAnswerShow.push(object);
						}
					}
				}
				oBrfModel.setProperty("/questionSet", oAnswerShow);
				oBrfModel.setProperty("/firstQuestionSet", _fFirstLineData);

				var tbl = sap.ui.core.Fragment.byId(createBrfFragment, "QuestionTable2");
				var firstQtable = sap.ui.core.Fragment.byId(createBrfFragment, "QuestionTableFirst");
				if (_fFirstLineData && _fFirstLineData.length > 0) {
					firstQtable.getAggregation("items")[0].getCells()[2].setProperty("editable", false);

				}

				if (oAnswerShow.length > 0) {
					oBrfModel.setProperty("/oVisibleSet/questionPnVisibleBRF", true);
					for (var j = 0; j < oAnswerShow.length; j++) {
						if (oAnswerShow[j].Answer === "N/A") {
							tbl.getAggregation("items")[j].getCells()[3].setProperty("visible", false);
							tbl.getAggregation("items")[j].getCells()[2].setProperty("editable", false);
						} else {
							tbl.getAggregation("items")[j].getCells()[3].setProperty("visible", true);
							tbl.getAggregation("items")[j].getCells()[3].setProperty("editable", false);
							tbl.getAggregation("items")[j].getCells()[2].setProperty("editable", false);

						}
					}
				} else {
					oBrfModel.setProperty("/oVisibleSet/questionPnVisibleBRF", false);
				}

				this._ofragmentBrf.open();
				this.oPressRIflag = true;

			}

			/*	var oDatePicker1 = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "LastDateSrv"));
				jQuery.sap.delayedCall(1000, this, function () {
					if (oDatePicker1) {
						var objDate1 = oDatePicker1.getDomRef();
						if (objDate1) {
							objDate1.firstElementChild.firstChild.setAttribute("readonly", true);
							//objDate1.children[1].setAttribute("readonly", true);
						}
					}
				});*/

			var LastDateSrv = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "LastDateSrv"));
			LastDateSrv.addEventDelegate({
				onAfterRendering: function () {
					var oYear = this.$().find('.sapMInputBaseInner');
					var oID = oYear[0].id;
					$('#' + oID).attr("disabled", "disabled");
				}
			}, LastDateSrv);

			var oDatePicker4 = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "ServicePeriodStartMF"));
			jQuery.sap.delayedCall(1000, this, function () {
				if (oDatePicker4) {
					var objDate4 = oDatePicker4.getDomRef();
					if (objDate4) {
						objDate4.firstElementChild.firstChild.setAttribute("readonly", true);
						//objDate4.children[1].setAttribute("readonly", true);
					}
				}
			});
			var oDatePicker5 = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "ServicePeriodEndMF"));
			jQuery.sap.delayedCall(1000, this, function () {
				if (oDatePicker5) {
					var objDate5 = oDatePicker5.getDomRef();
					if (objDate5) {
						objDate5.firstElementChild.firstChild.setAttribute("readonly", true);
						//	objDate5.children[1].setAttribute("readonly", true);
					}
				}
			});
			var oNatureField = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "Nature"));
			jQuery.sap.delayedCall(1000, this, function () {
				if (oNatureField) {
					var objNature = oNatureField.getDomRef();
					if (objNature) {
						objNature.firstElementChild.firstChild.setAttribute("readonly", true);
						//objNature.children[1].setAttribute("readonly", true);
					}
				}
			});
			var oMFCurrency = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "MFCurr"));
			jQuery.sap.delayedCall(1000, this, function () {
				if (oMFCurrency) {
					var objMFCurr = oMFCurrency.getDomRef();
					if (objMFCurr) {
						objMFCurr.firstElementChild.firstChild.setAttribute("readonly", true);
						//	objMFCurr.children[1].setAttribute("readonly", true);
					}
				}
			});

			var oMFDocType = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "MFDocType"));
			jQuery.sap.delayedCall(1000, this, function () {
				if (oMFDocType) {
					var objMFDoc = oMFDocType.getDomRef();
					if (objMFDoc) {
						objMFDoc.firstElementChild.firstChild.setAttribute("readonly", true);
						// objMFDoc.children[1].setAttribute("readonly", true);
						// objMFDoc.children[2].setAttribute("readonly", true);
					}
				}
			});
			var oTaxPointDate = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "TaxPointDate"));
			jQuery.sap.delayedCall(1000, this, function () {
				if (oTaxPointDate) {
					var objTaxDate = oTaxPointDate.getDomRef();
					if (objTaxDate) {
						objTaxDate.firstElementChild.firstChild.setAttribute("readonly", true);
						//	objTaxDate.children[1].setAttribute("readonly", true);
					}
				}
			});

			this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "idselectokForedit")).setVisible(false);
			this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "addLineItemOkId")).setVisible(false);
		},
		onRIOkPress: function (oEvent) {
			var oBrfModel = this.getView().getModel("oBrfModel");
			var oTblBRF = this.getView().byId("tableid");
			var that = this;
			var oLineItemData = oBrfModel.getProperty("/lineItemBRFSet");

			oLineItemData.LineType = "INVOICE";
			oLineItemData.RiFlag = "X";
			var oDataForRI = {};

			oDataForRI.TrackNo = oLineItemData.TrackNo;
			oLineItemData.TrackNo = oBrfModel.getProperty("/oReSetDataOfRI").TrackNoRI;
			oDataForRI.AccrTrackNoCredit = oLineItemData.AccrTrackNoCredit;
			oLineItemData.AccrTrackNoCredit = oBrfModel.getProperty("/oReSetDataOfRI").AccrTrackNoCreditRI;
			oDataForRI.AccrTrackNo = oLineItemData.AccrTrackNo;
			oLineItemData.AccrTrackNo = oBrfModel.getProperty("/oReSetDataOfRI").AccrTrackNoRI;
			oDataForRI.Action = oLineItemData.Action;
			oLineItemData.Action = oBrfModel.getProperty("/oReSetDataOfRI").ActionRI;
			oDataForRI.BillingSyntax = oLineItemData.BillingSyntax;
			oLineItemData.BillingSyntax = oBrfModel.getProperty("/oReSetDataOfRI").BillingSyntaxRI;
			oDataForRI.AddlCcEmails = oLineItemData.AddlCcEmails;
			oLineItemData.AddlCcEmails = oBrfModel.getProperty("/oReSetDataOfRI").AddlCcEmailsRI;
			oDataForRI.AddlDescAbove = oLineItemData.AddlDescAbove;
			oLineItemData.AddlDescAbove = oBrfModel.getProperty("/oReSetDataOfRI").AddlDescAboveRI;
			oDataForRI.AdlDescription = oLineItemData.AdlDescription;
			oLineItemData.AdlDescription = oBrfModel.getProperty("/oReSetDataOfRI").AdlDescriptionRI;
			oDataForRI.AdlEmail = oLineItemData.AdlEmail;
			oLineItemData.AdlEmail = oBrfModel.getProperty("/oReSetDataOfRI").AdlEmailRI;
			oDataForRI.ArApprName = oLineItemData.ArApprName;
			oLineItemData.ArApprName = oBrfModel.getProperty("/oReSetDataOfRI").ArApprNameRI;
			oDataForRI.AttenBrf = oLineItemData.AttenBrf;
			oLineItemData.AttenBrf = oBrfModel.getProperty("/oReSetDataOfRI").AttenBrfRI;
			oDataForRI.AttenBrfEmail = oLineItemData.AttenBrfEmail;
			oLineItemData.AttenBrfEmail = oBrfModel.getProperty("/oReSetDataOfRI").AttenBrfRIEmail;
			oDataForRI.BrfNo = oLineItemData.BrfNo;
			oLineItemData.BrfNo = oBrfModel.getProperty("/oReSetDataOfRI").BrfNoRI;
			oDataForRI.CcCode1 = oLineItemData.CcCode1;
			oLineItemData.CcCode1 = oBrfModel.getProperty("/oReSetDataOfRI").CcCode1RI;
			oDataForRI.CcCode2 = oLineItemData.CcCode2;
			oLineItemData.CcCode2 = oBrfModel.getProperty("/oReSetDataOfRI").CcCode2RI;
			oDataForRI.CntrlApprName = oLineItemData.CntrlApprName;
			oLineItemData.CntrlApprName = oBrfModel.getProperty("/oReSetDataOfRI").CntrlApprNameRI;
			oDataForRI.CnType = oLineItemData.CnType;
			oLineItemData.CnType = oBrfModel.getProperty("/oReSetDataOfRI").CnTypeRI;
			oDataForRI.Comments = oLineItemData.Comments;
			oLineItemData.Comments = oBrfModel.getProperty("/oReSetDataOfRI").CommentsRI;
			oDataForRI.CompanyCode = oLineItemData.CompanyCode;
			oLineItemData.CompanyCode = oBrfModel.getProperty("/oReSetDataOfRI").CompanyCodeRI;
			oDataForRI.CreditGl = oLineItemData.CreditGl;
			oLineItemData.CreditGl = oBrfModel.getProperty("/oReSetDataOfRI").CreditGlRI;
			oDataForRI.Curr1 = oLineItemData.Curr1;
			oLineItemData.Curr1 = oBrfModel.getProperty("/oReSetDataOfRI").Curr1RI;
			oDataForRI.LocationOfTheServicesReq = oLineItemData.LocationOfTheServicesReq;
			oLineItemData.LocationOfTheServicesReq = oBrfModel.getProperty("/oReSetDataOfRI").LocationOfTheServicesReqRI;
			// oDataForRI.LocOfRenderingUs = oLineItemData.LocOfRenderingUs;
			// oLineItemData.LocOfRenderingUs = oBrfModel.getProperty("/oReSetDataOfRI").LocOfRenderingUs;

			oDataForRI.Curr2 = oLineItemData.Curr2;
			oLineItemData.Curr2 = oBrfModel.getProperty("/oReSetDataOfRI").Curr2RI;
			oDataForRI.CurrentWorkitem = oLineItemData.CurrentWorkitem;
			oLineItemData.CurrentWorkitem = oBrfModel.getProperty("/oReSetDataOfRI").CurrentWorkitemRI;
			oDataForRI.DebitGl = oLineItemData.DebitGl;
			oLineItemData.DebitGl = oBrfModel.getProperty("/oReSetDataOfRI").DebitGlRI;
			oDataForRI.DetailsDescriptionOfServic = oLineItemData.DetailsDescriptionOfServic;
			oLineItemData.DetailsDescriptionOfServic = oBrfModel.getProperty("/oReSetDataOfRI").DetailsDescriptionOfServicRI;
			oDataForRI.DocHeaderText = oLineItemData.DocHeaderText;
			oLineItemData.DocHeaderText = oBrfModel.getProperty("/oReSetDataOfRI").DocHeaderTextRI;
			oDataForRI.DocumentDate = oLineItemData.DocumentDate;
			oLineItemData.DocumentDate = oBrfModel.getProperty("/oReSetDataOfRI").DocumentDateRI;
			oDataForRI.DocumentType = oLineItemData.DocumentType;
			oLineItemData.DocumentType = oBrfModel.getProperty("/oReSetDataOfRI").DocumentTypeRI;
			oDataForRI.EditDisplay = oLineItemData.EditDisplay;
			oLineItemData.EditDisplay = oBrfModel.getProperty("/oReSetDataOfRI").EditDisplayRI;
			oDataForRI.EditReqMf = oLineItemData.EditReqMf;
			oLineItemData.EditReqMf = oBrfModel.getProperty("/oReSetDataOfRI").EditReqMfRI;
			oDataForRI.EntityAddress = oLineItemData.EntityAddress;
			oLineItemData.EntityAddress = oBrfModel.getProperty("/oReSetDataOfRI").EntityAddressRI;
			oDataForRI.EntityName = oLineItemData.EntityName;
			oLineItemData.EntityName = oBrfModel.getProperty("/oReSetDataOfRI").EntityNameRI;
			oDataForRI.ExpenseGl = oLineItemData.ExpenseGl;
			oLineItemData.ExpenseGl = oBrfModel.getProperty("/oReSetDataOfRI").ExpenseGlRI;
			oDataForRI.ExpenseGlCredit = oLineItemData.ExpenseGlCredit;
			oLineItemData.ExpenseGlCredit = oBrfModel.getProperty("/oReSetDataOfRI").ExpenseGlCreditRI;
			oDataForRI.FiDocNo = oLineItemData.FiDocNo;
			oLineItemData.FiDocNo = oBrfModel.getProperty("/oReSetDataOfRI").FiDocNoRI;
			oDataForRI.FunctionName = oLineItemData.FunctionName;
			oLineItemData.FunctionName = oBrfModel.getProperty("/oReSetDataOfRI").FunctionNameRI;
			oDataForRI.GfEmail = oLineItemData.GfEmail;
			oLineItemData.GfEmail = oBrfModel.getProperty("/oReSetDataOfRI").GfEmailRI;
			oDataForRI.GfName = oLineItemData.GfName;
			oLineItemData.GfName = oBrfModel.getProperty("/oReSetDataOfRI").GfNameRI;
			oDataForRI.GlobalCc = oLineItemData.GlobalCc;
			oLineItemData.GlobalCc = oBrfModel.getProperty("/oReSetDataOfRI").GlobalCcRI;
			oDataForRI.GpIdCredit = oLineItemData.GpIdCredit;
			oLineItemData.GpIdCredit = oBrfModel.getProperty("/oReSetDataOfRI").GpIdCreditRI;
			oDataForRI.Gpid = oLineItemData.Gpid;
			oLineItemData.Gpid = oBrfModel.getProperty("/oReSetDataOfRI").GpidRI;
			oDataForRI.InvoiceReady = oLineItemData.InvoiceReady;
			oLineItemData.InvoiceReady = oBrfModel.getProperty("/oReSetDataOfRI").InvoiceReadyRI;
			oDataForRI.InvoiceStatus = oLineItemData.InvoiceStatus;
			oLineItemData.InvoiceStatus = oBrfModel.getProperty("/oReSetDataOfRI").InvoiceStatusRI;
			oDataForRI.Landx = oLineItemData.Landx;;
			oDataForRI.MemberFirm = oLineItemData.MemberFirm;
			oDataForRI.KpmgiVatId = oLineItemData.KpmgiVatId;
			oLineItemData.KpmgiVatId = oBrfModel.getProperty("/oReSetDataOfRI").KpmgiVatIdRI;
			oDataForRI.LastDateSrv = oLineItemData.LastDateSrv;
			oLineItemData.LastDateSrv = oBrfModel.getProperty("/oReSetDataOfRI").LastDateSrvRI;
			oDataForRI.ProcessGrp = oLineItemData.ProcessGrp;
			oLineItemData.ProcessGrp = oBrfModel.getProperty("/oReSetDataOfRI").ProcessGrpRI;
			oDataForRI.PostingDate = oLineItemData.PostingDate;
			oLineItemData.PostingDate = oBrfModel.getProperty("/oReSetDataOfRI").PostingDateRI;
			oDataForRI.NextWorkitem = oLineItemData.NextWorkitem;
			oLineItemData.NextWorkitem = oBrfModel.getProperty("/oReSetDataOfRI").NextWorkitemRI;
			oDataForRI.NatureOfService = oLineItemData.NatureOfService;
			oLineItemData.NatureOfService = oBrfModel.getProperty("/oReSetDataOfRI").NatureOfServiceRI;
			oDataForRI.MfCostCenter = oLineItemData.MfCostCenter;
			oLineItemData.MfCostCenter = oBrfModel.getProperty("/oReSetDataOfRI").MfCostCenterRI;
			oDataForRI.MfApEmail = oLineItemData.MfApEmail;
			oLineItemData.MfApEmail = oBrfModel.getProperty("/oReSetDataOfRI").MfApEmailRI;
			oLineItemData.Ltt = oBrfModel.getProperty("/oReSetDataOfRI").LttRI;
			oDataForRI.LttApprName = oLineItemData.LttApprName;
			oLineItemData.LttApprName = oBrfModel.getProperty("/oReSetDataOfRI").LttApprNameRI;
			oDataForRI.Ltext = oLineItemData.Ltext;
			oLineItemData.Ltext = oBrfModel.getProperty("/oReSetDataOfRI").LtextRI;
			oDataForRI.LongText = oLineItemData.LongText;
			oLineItemData.LongText = oBrfModel.getProperty("/oReSetDataOfRI").LongTextRI;
			oDataForRI.ProfitCenterDebit = oLineItemData.ProfitCenterDebit;
			oLineItemData.ProfitCenterDebit = oBrfModel.getProperty("/oReSetDataOfRI").ProfitCenterDebitRI;
			oDataForRI.ProfitCenter = oLineItemData.ProfitCenter;
			oLineItemData.ProfitCenter = oBrfModel.getProperty("/oReSetDataOfRI").ProfitCenterRI;
			oDataForRI.RechargeAmountCredit = oLineItemData.RechargeAmountCredit;
			oLineItemData.RechargeAmountCredit = oBrfModel.getProperty("/oReSetDataOfRI").RechargeAmountCreditRI;
			oDataForRI.RechargeAmountDebit = oLineItemData.RechargeAmountDebit;
			oLineItemData.RechargeAmountDebit = oBrfModel.getProperty("/oReSetDataOfRI").RechargeAmountDebitRI;
			oDataForRI.RechargeType = oLineItemData.RechargeType;
			oLineItemData.RechargeType = oBrfModel.getProperty("/oReSetDataOfRI").RechargeTypeRI;
			oDataForRI.ReferenceDoc = oLineItemData.ReferenceDoc;
			oLineItemData.ReferenceDoc = oBrfModel.getProperty("/oReSetDataOfRI").ReferenceDocRI;
			oDataForRI.RemCnAmount = oLineItemData.RemCnAmount;
			oLineItemData.RemCnAmount = oBrfModel.getProperty("/oReSetDataOfRI").RemCnAmountRI;
			oDataForRI.RequestingMf = oLineItemData.RequestingMf;
			oLineItemData.RequestingMf = oBrfModel.getProperty("/oReSetDataOfRI").RequestingMfRI;
			oDataForRI.RrfLineStatus = oLineItemData.RrfLineStatus;
			oLineItemData.RrfLineStatus = oBrfModel.getProperty("/oReSetDataOfRI").RrfLineStatusRI;
			// oDataForRI.LineStatus = "";
			oLineItemData.LineStatus = oBrfModel.getProperty("/oReSetDataOfRI").LineStatusRI;
			oDataForRI.SalesTaxCode = oLineItemData.SalesTaxCode;
			oLineItemData.SalesTaxCode = oBrfModel.getProperty("/oReSetDataOfRI").SalesTaxCodeRI;
			oDataForRI.SapCodeMf = oLineItemData.SapCodeMf;
			oLineItemData.SapCodeMf = oBrfModel.getProperty("/oReSetDataOfRI").SapCodeMfRI;
			oDataForRI.SchDate = oLineItemData.SchDate;
			oLineItemData.SchDate = oBrfModel.getProperty("/oReSetDataOfRI").SchDateRI;
			oDataForRI.ServicePeriodEnd = oLineItemData.ServicePeriodEnd;
			oLineItemData.ServicePeriodEnd = oBrfModel.getProperty("/oReSetDataOfRI").ServicePeriodEndRI;
			oDataForRI.ServicePeriodEndCredit = oLineItemData.ServicePeriodEndCredit;
			oLineItemData.ServicePeriodEndCredit = oBrfModel.getProperty("/oReSetDataOfRI").ServicePeriodEndCreditRI;
			oDataForRI.ServicePeriodStart = oLineItemData.ServicePeriodStart;
			oLineItemData.ServicePeriodStart = oBrfModel.getProperty("/oReSetDataOfRI").ServicePeriodStartRI;
			// oDataForRI.ServicePeriodStart = oLineItemData.ServicePeriodStart;
			oDataForRI.ServicePeriodStartCredit = oLineItemData.ServicePeriodStartCredit;
			oLineItemData.ServicePeriodStartCredit = oBrfModel.getProperty("/oReSetDataOfRI").ServicePeriodStartCreditRI;
			oDataForRI.SuperUser = oLineItemData.SuperUser;
			oLineItemData.SuperUser = oBrfModel.getProperty("/oReSetDataOfRI").SuperUserRI;
			oDataForRI.SuppApprName = oLineItemData.SuppApprName;
			oLineItemData.SuppApprName = oBrfModel.getProperty("/oReSetDataOfRI").SuppApprNameRI;
			oDataForRI.TaxpointDate = oLineItemData.TaxpointDate;
			oLineItemData.TaxpointDate = oBrfModel.getProperty("/oReSetDataOfRI").TaxpointDateRI;
			oDataForRI.TotalCnAmount = oLineItemData.TotalCnAmount;
			oLineItemData.TotalCnAmount = oBrfModel.getProperty("/oReSetDataOfRI").TotalCnAmountRI;
			oDataForRI.TransactionType = oLineItemData.TransactionType;
			oLineItemData.TransactionType = oBrfModel.getProperty("/oReSetDataOfRI").TransactionTypeRI;
			oDataForRI.Urn = oLineItemData.Urn;
			oLineItemData.Urn = oBrfModel.getProperty("/oReSetDataOfRI").UrnRI;
			oDataForRI.VatApprName = oLineItemData.VatApprName;
			oLineItemData.VatApprName = oBrfModel.getProperty("/oReSetDataOfRI").VatApprNameRI;
			oDataForRI.VatDesc = oLineItemData.VatDesc;
			oLineItemData.VatDesc = oBrfModel.getProperty("/oReSetDataOfRI").VatDescRI;
			oDataForRI.VatId = oLineItemData.VatId;
			oLineItemData.VatId = oBrfModel.getProperty("/oReSetDataOfRI").VatIdRI;
			oDataForRI.VatSapCode = oLineItemData.VatSapCode;
			oLineItemData.VatSapCode = oBrfModel.getProperty("/oReSetDataOfRI").VatSapCodeRI;
			oDataForRI.WhtCode = oLineItemData.WhtCode;
			oLineItemData.WhtCode = oBrfModel.getProperty("/oReSetDataOfRI").WhtCodeRI;
			oDataForRI.LineItemTotal = oLineItemData.LineItemTotal;
			oLineItemData.LineItemTotal = oBrfModel.getProperty("/oReSetDataOfRI").LineItemTotalRI;

			if (oDataForRI.RechargeAmountCredit !== oDataForRI.RechargeAmountDebit) {
				var sMsgCAmount = this.getView().getModel("i18n").getProperty("Amountmsg");
				MessageBox.alert(sMsgCAmount);
				return;
			}

			//questionnaire chnages for Ri lines
			var _qfirstQuestionData = oBrfModel.getProperty("/firstQuestionSet");
			if ((oBrfModel.getProperty("/questionSet")) && (_qfirstQuestionData.length > 0)) {
				oBrfModel.getProperty("/firstQuestionSet")[0].LineType = "REISSUANCE";
				oBrfModel.getProperty("/questionSetSubmit").push(_qfirstQuestionData[0]);
				for (var i = 0; i < oBrfModel.getProperty("/questionSet").length; i++) {
					oBrfModel.getProperty("/questionSet")[i].LineType = "REISSUANCE";
					oBrfModel.getProperty("/questionSet")[i].TransactionType = oDataForRI.TransactionType;
					oBrfModel.getProperty("/questionSetSubmit").push(oBrfModel.getProperty("/questionSet")[i]);

				}

			}

			if (oLineItemData.RequestingMf) {
				var oRiData = {};
				oRiData.LineType = "REISSUANCE";
				oRiData.RiFlag = "";
				oRiData.TrackNo = oDataForRI.TrackNo;
				oRiData.AccrTrackNoCredit = oDataForRI.AccrTrackNoCredit;
				oRiData.AccrTrackNo = oDataForRI.AccrTrackNo;
				oRiData.Action = oDataForRI.Action;
				oRiData.AddlCcEmails = oDataForRI.AddlCcEmails;
				oRiData.AddlDescAbove = oDataForRI.AddlDescAbove;
				oRiData.AdlDescription = oDataForRI.AdlDescription;
				oRiData.AdlEmail = oDataForRI.AdlEmail;
				oRiData.ArApprName = oDataForRI.ArApprName;
				oRiData.AttenBrf = oDataForRI.AttenBrf;
				oRiData.AttenBrfEmail = oDataForRI.AttenBrfEmail;
				oRiData.BrfNo = oDataForRI.BrfNo;
				oRiData.CcCode1 = oDataForRI.CcCode1;
				oRiData.CcCode2 = oDataForRI.CcCode2;
				oRiData.CntrlApprName = oDataForRI.CntrlApprName;
				oRiData.CnType = oDataForRI.CnType;
				oRiData.Comments = oDataForRI.Comments;
				oRiData.CompanyCode = oDataForRI.CompanyCode;
				oRiData.CreditGl = oDataForRI.CreditGl;
				oRiData.Curr1 = oDataForRI.Curr1;
				oRiData.Curr2 = oDataForRI.Curr2;
				oRiData.CurrentWorkitem = oDataForRI.CurrentWorkitem;
				oRiData.DebitGl = oDataForRI.DebitGl;
				oRiData.DetailsDescriptionOfServic = oDataForRI.DetailsDescriptionOfServic;
				oRiData.DocHeaderText = oDataForRI.DocHeaderText;
				oRiData.DocumentDate = oDataForRI.DocumentDate;
				oRiData.DocumentType = oDataForRI.DocumentType;
				oRiData.EditDisplay = oDataForRI.EditDisplay;
				oRiData.EditReqMf = oDataForRI.EditReqMf;
				oRiData.EntityAddress = oDataForRI.EntityAddress;
				oRiData.EntityName = oDataForRI.EntityName;
				oRiData.ExpenseGl = oDataForRI.ExpenseGl;
				oRiData.ExpenseGlCredit = oDataForRI.ExpenseGlCredit;
				oRiData.FunctionName = oDataForRI.FunctionName;
				oRiData.GfEmail = oDataForRI.GfEmail;
				oRiData.GfName = oDataForRI.GfName;
				oRiData.GlobalCc = oDataForRI.GlobalCc;
				oRiData.GpIdCredit = oDataForRI.GpIdCredit;
				oRiData.Gpid = oDataForRI.Gpid;
				oRiData.InvoiceReady = oDataForRI.InvoiceReady;
				oRiData.BillingSyntax = oDataForRI.BillingSyntax;
				oRiData.Landx = oDataForRI.Landx;
				oRiData.MemberFirm = oDataForRI.MemberFirm;
				oRiData.KpmgiVatId = oDataForRI.KpmgiVatId;
				oRiData.LastDateSrv = oDataForRI.LastDateSrv;
				oRiData.ProcessGrp = oDataForRI.ProcessGrp;
				oRiData.PostingDate = oDataForRI.PostingDate;
				oRiData.NextWorkitem = oDataForRI.NextWorkitem;
				oRiData.NatureOfService = oDataForRI.NatureOfService;
				oRiData.MfCostCenter = oDataForRI.MfCostCenter;
				oRiData.MfApEmail = oDataForRI.MfApEmail;
				oRiData.Ltt = "";
				oRiData.LttApprName = oDataForRI.LttApprName;
				oRiData.Ltext = oDataForRI.Ltext;
				oRiData.LongText = oDataForRI.LongText;
				oRiData.ProfitCenterDebit = oDataForRI.ProfitCenterDebit;
				oRiData.ProfitCenter = oDataForRI.ProfitCenter;
				oRiData.RechargeAmountCredit = oDataForRI.RechargeAmountCredit;
				oRiData.RechargeAmountDebit = oDataForRI.RechargeAmountDebit;
				oRiData.RechargeType = oDataForRI.RechargeType;
				oRiData.ReferenceDoc = oDataForRI.ReferenceDoc;
				oRiData.RemCnAmount = oDataForRI.RemCnAmount;
				oRiData.RequestingMf = oDataForRI.RequestingMf;
				oRiData.RrfLineStatus = oDataForRI.RrfLineStatus;
				oRiData.LineStatus = "";
				oRiData.FiDocNo = "";
				oRiData.InvoiceStatus = "";
				oRiData.SalesTaxCode = oDataForRI.SalesTaxCode;
				oRiData.SapCodeMf = oDataForRI.SapCodeMf;
				oRiData.SchDate = oDataForRI.SchDate;
				oRiData.ServicePeriodEnd = oDataForRI.ServicePeriodEnd;
				oRiData.ServicePeriodEndCredit = oDataForRI.ServicePeriodEndCredit;
				oRiData.ServicePeriodStart = oDataForRI.ServicePeriodStart;
				oRiData.LocationOfTheServicesReq = oLineItemData.LocationOfTheServicesReq;
				// oRiData.LocOfRenderingUs = oDataForRI.LocOfRenderingUs;
				oRiData.ServicePeriodStartCredit = oDataForRI.ServicePeriodStartCredit;
				oRiData.SuperUser = oDataForRI.SuperUser;
				oRiData.SuppApprName = oDataForRI.SuppApprName;
				oRiData.TaxpointDate = oDataForRI.TaxpointDate;
				oRiData.TotalCnAmount = oDataForRI.TotalCnAmount;
				oRiData.TransactionType = oDataForRI.TransactionType;
				oRiData.Urn = oDataForRI.Urn;
				oRiData.VatApprName = oDataForRI.VatApprName;
				oRiData.VatDesc = oDataForRI.VatDesc;
				oRiData.VatId = oDataForRI.VatId;
				oRiData.VatSapCode = oDataForRI.VatSapCode;
				oRiData.WhtCode = oDataForRI.WhtCode;
				oRiData.LineItemTotal = oDataForRI.LineItemTotal;
				oBrfModel.getProperty("/brfTableSet").push(oRiData);
				this._ofragmentBrf.close();
				this.getView().getModel("oBrfModel").refresh();
				for (var i = 0; i < oTblBRF.getItems().length; i++) {
					var _oPartiCularLineData = oTblBRF.getBindingInfo("items").binding.oList[i];
					var LttCheckBox = oTblBRF.getAggregation("items")[i].getCells()[7];
					var oActionData = oTblBRF.getAggregation("items")[i].getCells()[9];
					var oRiField = oTblBRF.getAggregation("items")[i].getCells()[10];
					if ((_oPartiCularLineData.LineType === "INVOICE") && (_oPartiCularLineData.RequestingMf !== "N/A")) {
						oActionData.setProperty("visible", true);
						oActionData.setProperty("enabled", false);
					}
					if (_oPartiCularLineData.Ltt === "X") {
						LttCheckBox.setProperty("selected", true);
					}

					if (_oPartiCularLineData.CnFlag === "X" && _oPartiCularLineData.LineStatus === "POSTED") {

						oActionData.setProperty("enabled", true);
						oActionData.setProperty("visible", true);

					} else {
						oTblBRF.getAggregation("items")[i].getCells()[9].setProperty("visible", false);
						oRiField.setProperty("visible", false);
					}
					if (_oPartiCularLineData.RiFlag === "") {
						oRiField.setProperty("visible", false);
					} else if (_oPartiCularLineData.RiFlag === "X") {
						oRiField.setProperty("visible", true);
					}
				}

			}
			oBrfModel.setProperty("/lineItemBRFSet", {});

		},
		/*End of Reissuance of Invoice by developer Satabdi Das on 14-Dec-2020 */

		/*Start of BRF concurrent user lock change by Satabdi Das on 01-Apr-2021*/
		handleBrfConcurrentLock: function (oEvent) {
			var oBrfModel = this.getView().getModel("oBrfModel");
			var sBrfNo = oBrfModel.getProperty("/brfHeaderSet").BrfNo;
			var sCompCode = oBrfModel.getProperty("/brfHeaderSet").CompanyCode;
			var aFilter = [];

			if (sBrfNo && sCompCode) {
				aFilter.push(new Filter("RrfNo", FilterOperator.EQ, sBrfNo));
				aFilter.push(new Filter("CompanyCode", FilterOperator.EQ, sCompCode));
			}

			sap.ui.core.BusyIndicator.show(0);
			var functionSucess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
			}, this);

			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();
				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"

				});
			}, this);

			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_BRF_SRV/", {
				json: true
			});
			oModel1.read("/BRF_LockSet", {
				filters: aFilter,
				success: functionSucess,
				error: fnError
			});

		},
		/*End of BRF concurrent user lock change by Satabdi Das on 01-Apr-2021*/

		brfMFSearchHelp: function (oEvent) {
			sap.ui.core.BusyIndicator.show(0);
			// var sPath = "";
			// sPath = "/BRF_MFSet"; // + Constant.CV_PV_LEAD_FIORI;
			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				var oBrfModel = this.getView().getModel("oBrfModel");
				oBrfModel.setSizeLimit(500);
				oBrfModel.setProperty("/BRF_MF", d.results);
				this.getView().getModel("oBrfModel").setProperty("/SelcKeySetBRF", "");
				this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/LocationOfTheServicesReq", "");
				this.getView().getModel("oBrfModel").setProperty("/SelcKeyForLocServ", "");

				/*Below code mcommented by Satabdi Das on 11-Nov-2020*/
				this.getView().getModel("oBrfModel").refresh(true);
			}, this);
			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();
				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"
				});
			}, this);
			// var oObject = {};
			// oObject.successCallback = fnSuccess;
			// oObject.errorCallback = fnError;
			// oObject.sPath = sPath;
			// DataManagerBrf.getCoupaCreateHelp(oObject);
			/*R&D---start*/
			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_BRF_SRV/", {
				json: true
			});
			oModel1.read("/Member_FirmSet", {
				success: fnSuccess,
				error: fnError
			});
			/*R&D---end*/
		},
		brfMFLocationService: function (oEvent) {
			sap.ui.core.BusyIndicator.show(0);

			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				var oBrfModel = this.getView().getModel("oBrfModel");
				oBrfModel.setSizeLimit(d.results.length);
				oBrfModel.setProperty("/BRF_MFLocServ", d.results);
				this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/LocationOfTheServicesReq", "");
				this.getView().getModel("oBrfModel").setProperty("/SelcKeyForLocServ", "");

				/*Below code mcommented by Satabdi Das on 11-Nov-2020*/
				this.getView().getModel("oBrfModel").refresh(true);
			}, this);
			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();
				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"
				});
			}, this);
			// var oObject = {};
			// oObject.successCallback = fnSuccess;
			// oObject.errorCallback = fnError;
			// oObject.sPath = sPath;
			// DataManagerBrf.getCoupaCreateHelp(oObject);
			/*R&D---start*/
			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_BRF_SRV/", {
				json: true
			});
			oModel1.read("/BRF_MFSet", {
				success: fnSuccess,
				error: fnError
			});
			/*R&D---end*/
		},

		currencyDropDown: function (oEvent) {
			sap.ui.core.BusyIndicator.show(0);
			var sPath = "";
			sPath = "/CURRSet"; // + Constant.CV_PV_LEAD_FIORI;
			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				var oBrfModel = this.getView().getModel("oBrfModel");
				oBrfModel.setSizeLimit(d.results.length);
				oBrfModel.setProperty("/CurrSet", d.results);
				this.getView().getModel("oBrfModel").setProperty("/CurrencySet", "");
			}, this);
			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();
				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"
				});
			}, this);
			// var oObject = {};
			// oObject.successCallback = fnSuccess;
			// oObject.errorCallback = fnError;
			// oObject.sPath = sPath;
			// DataManagerBrf.getCoupaCreateHelp(oObject);
			/*R&D---start*/
			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_BRF_SRV/", {
				json: true
			});
			oModel1.read("/CURRSet", {
				success: fnSuccess,
				error: fnError
			});
			/*R&D---end*/
		},

		/*Start of change for new doc type field by developer Satabdi Das on 14-Sep-2020*/
		onSelectingMfDoc: function (oEvent) {
			var oBrfModel = this.getView().getModel("oBrfModel");
			if (oEvent.getParameter("selectedItem") !== null) {
				var sDocKey = oEvent.getParameter("selectedItem").getProperty("key");
				// this.getView().getModel("oBrfModel").setProperty("/DocumentType", sDocKey);
				this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/DocumentType", sDocKey);
				/*Start 63939 on 01-Apr-2021*/
				oBrfModel.setProperty("/selectedKeyCreditGl", "");
				if (oBrfModel.getProperty("/lineItemBRFSet/CreditGl") && oBrfModel.getProperty("/lineItemBRFSet/CreditGl") !== "") {
					oBrfModel.setProperty("/lineItemBRFSet/CreditGl", "");
				}
				if (oBrfModel.getProperty("/lineItemBRFSet/ExpenseGlCredit") && oBrfModel.getProperty("/lineItemBRFSet/ExpenseGlCredit") !== "") {
					oBrfModel.setProperty("/lineItemBRFSet/ExpenseGlCredit", "");
				}
				if (oBrfModel.getProperty("/lineItemBRFSet/AccrTrackNo") && oBrfModel.getProperty("/lineItemBRFSet/AccrTrackNo") !== "") {
					oBrfModel.setProperty("/lineItemBRFSet/AccrTrackNo", "");
				}
				this.getModel("oBrfModel").setProperty("/oVisibleSet/CRGL160100", false);
				/*End 63939 on 01-Apr-2021*/
				this.RestGlOptions(); /*SCTASK1838272 by Satabdi Das on 05-March-2021*/
			} else if (oEvent.getParameter("selectedItem") === null) {
				// this.getView().getModel("oBrfModel").setProperty("/DocumentType", "");
				this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/DocumentType", "");
			}
		},
		/*End of change for new doc type field by developer Satabdi Das on 14-Sep-2020*/
		/*Start of change by Satabdi Das on 05-March-2021 for SCTASK1838272*/
		RestGlOptions: function (oEvent) {
			sap.ui.core.BusyIndicator.show(0);
			var oBrfModel = this.getView().getModel("oBrfModel");
			var sCompCode = oBrfModel.getProperty("/brfHeaderSet").CompanyCode;
			var sDocType = oBrfModel.getProperty("/lineItemBRFSet/DocumentType");
			var sFragTxt = oBrfModel.getProperty("/fraggmentText"); /*Added for defect 63905 on 19-March-2021 by Satabdi Das*/
			var aFilter = [];
			var mArrayOut = [];
			var that = this;
			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				oBrfModel.setSizeLimit(d.results.length);
				for (var i = 0; i < d.results.length; i++) {
					var oGlobalGlAccont = {};
					oGlobalGlAccont.CreditGl = d.results[i].CreditGl;
					mArrayOut.push(oGlobalGlAccont);
				}
				oBrfModel.setProperty("/BRF_GL_SET", mArrayOut);
				/*Start of change for defect 63905 on 19-March-2021 by Satabdi Das*/
				if (sFragTxt !== "REISSUANCE") {
					oBrfModel.setProperty("/selectedKeyCreditGl", "");
					oBrfModel.setProperty("/lineItemBRFSet/CreditGl", "");
					/*Start 63939 on 01-Apr-2021*/
					if (oBrfModel.getProperty("/lineItemBRFSet/ExpenseGlCredit") && oBrfModel.getProperty("/lineItemBRFSet/ExpenseGlCredit") !==
						"") {
						oBrfModel.setProperty("/lineItemBRFSet/ExpenseGlCredit", "");
					}
					if (oBrfModel.getProperty("/lineItemBRFSet/AccrTrackNo") && oBrfModel.getProperty("/lineItemBRFSet/AccrTrackNo") !== "") {
						oBrfModel.setProperty("/lineItemBRFSet/AccrTrackNo", "");
					}
					that.getModel("oBrfModel").setProperty("/oVisibleSet/CRGL160100", false);
					/*End 63939 on 01-Apr-2021*/
				}
				/*End of change for defect 63905 on 19-March-2021 by Satabdi Das*/
				var createBrfFragment = this.getView().createId("createBrfFragment");
				var oRestGL = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "GL9921CR"));
				jQuery.sap.delayedCall(1000, this, function () {
					if (oRestGL) {
						var objRestGL = oRestGL.getDomRef();
						if (objRestGL) {
							objRestGL.firstElementChild.firstChild.setAttribute("readonly", true);
							//	objRestGL.children[1].setAttribute("readonly", true);
						}
					}
				});
				oBrfModel.refresh(); /* added for 63939*/
			}, this);
			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();
				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"
				});
			}, this);

			if (sFragTxt !== "REISSUANCE") {
				aFilter.push(new Filter("DocumentType", FilterOperator.EQ, sDocType));
			} else if (sFragTxt === "REISSUANCE") {
				var sDocTypeRI = oBrfModel.getProperty("/oReSetDataOfRI/DocumentTypeRI");
				aFilter.push(new Filter("DocumentType", FilterOperator.EQ, sDocTypeRI));
			}
			aFilter.push(new Filter("Bukrs", FilterOperator.EQ, sCompCode));
			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_BRF_SRV/", {
				json: true
			});
			oModel1.read("/BRF_GL_SET", {
				filters: aFilter,
				success: fnSuccess,
				error: fnError
			});
		},
		onSelectingCrGl: function (oEvent) {
			var sID = oEvent.getSource().getId();
			var oBrfModel = this.getView().getModel("oBrfModel");
			var sDocType = oBrfModel.getProperty("/lineItemBRFSet/DocumentType");
			var oSelection = oEvent.getParameter("selectedItem");
			if (oSelection !== null && sID.indexOf("GL9921CR") >= 0) {
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				var that = this;
				var key = oSelection.getProperty("key");
				if ((sDocType === "EI" || sDocType === "EC") && key === "160100") {
					oBrfModel.setProperty("/lineItemBRFSet/ExpenseGlCredit", "620001");
					that.getModel("oBrfModel").setProperty("/oVisibleSet/CRGL160100", true);
					MessageBox.information(
						that.getView().getModel("i18n").getProperty("AccruMandt_9921"), {
							styleClass: bCompact ? "sapUiSizeCompact" : ""
						}
					);
				} else if ((sDocType === "OI" || sDocType === "OC") && key === "160100") {
					oBrfModel.setProperty("/lineItemBRFSet/ExpenseGlCredit", "630001");
					that.getModel("oBrfModel").setProperty("/oVisibleSet/CRGL160100", true);
					MessageBox.information(
						that.getView().getModel("i18n").getProperty("AccruMandt_9921"), {
							styleClass: bCompact ? "sapUiSizeCompact" : ""
						}
					);
				} else {
					oBrfModel.setProperty("/lineItemBRFSet/ExpenseGlCredit", "");
					oBrfModel.setProperty("/lineItemBRFSet/AccrTrackNo", "");
					that.getModel("oBrfModel").setProperty("/oVisibleSet/CRGL160100", false);
				}
				oBrfModel.setProperty("/lineItemBRFSet/CreditGl", key);
				oBrfModel.setProperty("/selectedKeyCreditGl", key);
			} else {
				oBrfModel.setProperty("/lineItemBRFSet/CreditGl", key);
				oBrfModel.setProperty("/selectedKeyCreditGl", key);
				oBrfModel.setProperty("/lineItemBRFSet/ExpenseGlCredit", "");
				oBrfModel.setProperty("/lineItemBRFSet/AccrTrackNo", "");
				oBrfModel.setProperty("/oVisibleSet/CRGL160100", false);
			}
		},
		/*End of change by Satabdi Das on 05-March-2021 for SCTASK1838272*/

		onSelectingMF: function (oEvent) {
			var oBrfModel = this.getView().getModel("oBrfModel");
			var that = this;
			var format = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/;
			var sId = oEvent.getSource().getId().split("--")[2]; /*Added for defecr 63418*/ /*Change added for INC01499658 on 22-APR-2021*/
			var bManual = this.getView().getModel("oBrfModel").getProperty("/oVisibleSet/withoutRef"); /*Aded for Defect 63418*/
			var oKeepInstance = oEvent.getParameter("selectedItem");
			if (oBrfModel.getProperty("/lineItemBRFSet").RequestingMf) {
				var messageText = this.getModel("i18n").getProperty("requestingMfchangedmsg");
				MessageBox.information(messageText, {
					actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
					emphasizedAction: MessageBox.Action.OK,
					onClose: function (sAction) {
						if (sAction === "CANCEL") {
							var reqConty = oBrfModel.getProperty("/lineItemBRFSet").RequestingMf;
							oBrfModel.setProperty("/SelcKeySetBRF", reqConty);

						} else {

							if (oKeepInstance.getProperty("text").split(":")[0]) {
								var RequestingcountryName = oKeepInstance.getProperty("text").split(":")[1];
								var contrycode = oKeepInstance.getProperty("text").split(":")[0];
								if (format.test(contrycode)) {
									var specialcharmsgForMf = that.getModel("i18n").getProperty("specialcharmsgForMf");
									MessageBox.error(specialcharmsgForMf);
									return true;
								}
							}

							var oMemberFirm = oKeepInstance.getProperty("additionalText");
							//special character message check
							if (format.test(oMemberFirm)) {
								var specialcharmsgForMemberfirm = that.getModel("i18n").getProperty("specialcharmsgForMemberfirm");
								MessageBox.error(specialcharmsgForMemberfirm);
								return true;

							}
							oBrfModel.setProperty("/SelcKeySetBRF", contrycode);
							var key = oKeepInstance.getProperty("key");
							oBrfModel.setProperty("/SelcKeySetBRF", key);
							oBrfModel.setProperty("/lineItemBRFSet/MemberFirm", oMemberFirm);
							oBrfModel.setProperty("/lineItemBRFSet/Landx", RequestingcountryName);
							oBrfModel.setProperty("/lineItemBRFSet/EntityName", "");
							oBrfModel.setProperty("/lineItemBRFSet/EntityAddress", "");
							oBrfModel.setProperty("/lineItemBRFSet/SapCodeMf", "");
							oBrfModel.setProperty("/lineItemBRFSet/VatId", ""); /*Added for 63922 on 08-April by Satabdi Das*/
							oBrfModel.setProperty("/lineItemBRFSet/RequestingMf", key);

							if (sId === "RequestingMf" && (oBrfModel.getProperty("/lineItemBRFSet").RequestingMf === "US" || oBrfModel.getProperty(
									"/lineItemBRFSet").RequestingMf === "NL")) {
								oBrfModel.setProperty("/CodeMandat", true);
							} else {
								oBrfModel.setProperty("/CodeMandat", false);
							}
							//mModelSummary.setProperty("/updateRowDataNC/")
							//questionCall
							that.questionaCall();
							oBrfModel.setProperty("/SelcKeySetBRF", key);

						}
					}
				});
			} else {
				var countryName = oEvent.getParameter("selectedItem").getProperty("additionalText");
				//special character message check
				if (oEvent.getParameter("selectedItem").getProperty("text").split(":")[0]) {
					var RequestingcountryName = oEvent.getParameter("selectedItem").getProperty("text").split(":")[1];
					var contrycode = oEvent.getParameter("selectedItem").getProperty("text").split(":")[0];
					if (format.test(contrycode)) {
						var specialcharmsgForMf = that.getModel("i18n").getProperty("specialcharmsgForMf");
						MessageBox.error(specialcharmsgForMf);
						return true;
					}
				}
				if (format.test(countryName)) {
					var specialcharmsgForMemberfirm = that.getModel("i18n").getProperty("specialcharmsgForMemberfirm");
					MessageBox.error(specialcharmsgForMemberfirm);
					oBrfModel.setProperty("/SelcKeySetBRF", "");
					return true;
				}
				oBrfModel.setProperty("/SelcKeySetBRF", contrycode);
				var key = oEvent.getParameter("selectedItem").getProperty("key");
				oBrfModel.setProperty("/lineItemBRFSet/RequestingMf", key);
				oBrfModel.setProperty("/lineItemBRFSet/Landx", RequestingcountryName);
				oBrfModel.setProperty("/lineItemBRFSet/MemberFirm", countryName);
				/*Start of change for defect 63922 on 08-April-2021 by developer Satabdi Das*/
				oBrfModel.setProperty("/lineItemBRFSet/EntityName", "");
				oBrfModel.setProperty("/lineItemBRFSet/EntityAddress", "");
				oBrfModel.setProperty("/lineItemBRFSet/SapCodeMf", "");
				oBrfModel.setProperty("/lineItemBRFSet/VatId", "");
				/*End of change for defect 63922 on 08-April-2021 by developer Satabdi Das*/
				//question set call 
				this.questionaCall();
				oBrfModel.setProperty("/SelcKeySetBRF", contrycode);
				/*Start of defect 63418*/
				if (bManual === true) {
					if (sId === "RequestingMf" && (key === "US" || key === "NL")) {
						oBrfModel.setProperty("/CodeMandat", true);
					} else {
						oBrfModel.setProperty("/CodeMandat", false);
					}
				} else {
					oBrfModel.setProperty("/CodeMandat", false);
				}
				/*End of defect 63418*/

				if (sId === "RequestingMf" && (oBrfModel.getProperty("/lineItemBRFSet").RequestingMf === "US" || oBrfModel.getProperty(
						"/lineItemBRFSet").RequestingMf === "NL")) {
					oBrfModel.setProperty("/CodeMandat", true);
				} else {
					oBrfModel.setProperty("/CodeMandat", false);
				}

			}

			return oBrfModel.setProperty("/SelcKeySetBRF", oBrfModel.getProperty("/lineItemBRFSet").RequestingMf);
		},

		questionaCall: function () {

			var oBrfModel = this.getView().getModel("oBrfModel");
			var firstQuestion = this.getModel("i18n").getProperty("firstQuestionOfQuestionnaire");
			var contrycode = oBrfModel.getProperty("/lineItemBRFSet").RequestingMf;
			oBrfModel.setProperty("/questionSet", []);
			oBrfModel.setProperty("/firstQuestionSet", []);
			sap.ui.core.BusyIndicator.show(0);

			var aFilter = [];
			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				var questionArr = [];
				var firstQuestionArrey = [];
				if (d.results.length > 0) {
					for (var i = 0; i < d.results.length; i++) {
						var object = {};
						object.LineNo = d.results[i].LineNo;
						object.CompanyCode = d.results[i].CompanyCode;
						object.Mandatory = d.results[i].Mandatory;
						object.MemberFirm = d.results[i].MemberFirm;
						object.Question = d.results[i].Question;
						object.RequestingMf = d.results[i].RequestingMf;
						object.InternalExternal = d.results[i].InternalExternal;
						object.TransactionType = d.results[i].TransactionType;
						object.Answer = "";
						object.AnswerDesc = "";
						object.ProcessGrp = "";
						object.LineType = "INVOICE";
						questionArr.push(object);
						// if (i == 0) {
						// 	firstQuestionArrey.push(object);
						// 	// mModelSummary.setProperty("/firstQuestionSet",object );

						// } else {
						// 	questionArr.push(object);
						// }

					}

					oBrfModel.setProperty("/questionSet", questionArr);

					if (questionArr.length > 0) {
						var objectFirst = {};
						objectFirst.LineNo = "01";
						objectFirst.CompanyCode = object.CompanyCode;
						objectFirst.Mandatory = "";
						objectFirst.MemberFirm = object.MemberFirm;
						objectFirst.Question = firstQuestion;
						objectFirst.InternalExternal = "";
						objectFirst.RequestingMf = object.RequestingMf;
						objectFirst.Answer = "";
						objectFirst.TransactionType = object.TransactionType;
						objectFirst.AnswerDesc = "";
						objectFirst.ProcessGrp = "";
						objectFirst.LineType = "INVOICE";
						firstQuestionArrey.push(objectFirst);
					}

					oBrfModel.setProperty("/firstQuestionSet", firstQuestionArrey);
					oBrfModel.setProperty("/oVisibleSet/questionPnVisibleBRF", true);
					oBrfModel.refresh(true);
				} else {
					oBrfModel.setProperty("/oVisibleSet/questionPnVisibleBRF", false);
				}
				// oBrfModel.setProperty("/SelcKeySetBRF", contrycode);
				jQuery.sap.delayedCall(300, this, function () {
					oBrfModel.setProperty("/SelcKeySetBRF", contrycode);
				});

			}, this);

			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();

				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"

				});
			}, this);

			aFilter.push(new Filter("RequestingMf", FilterOperator.EQ, oBrfModel.getProperty("/lineItemBRFSet").RequestingMf));
			aFilter.push(new Filter("MemberFirm", FilterOperator.EQ, oBrfModel.getProperty("/lineItemBRFSet").MemberFirm));
			aFilter.push(new Filter("CompanyCode", FilterOperator.EQ, oBrfModel.getProperty("/lineItemBRFSet").CompanyCode));
			var sPath = "/BRF_QuestionSet";

			// var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_BRF_SRV/", {
			// 	json: true
			// });
			// oModel1.read("/BRF_QuestionSet", {
			// 	filters: aFilter,
			// 	success: fnSuccess,
			// 	error: fnError
			// });
			var sParams;
			var oObject = {};
			oObject.Filter = aFilter;
			oObject.Params = sParams;
			oObject.successCallback = fnSuccess;
			oObject.errorCallback = fnError;
			oObject.sPath = sPath;
			DataManagerBrf.getCoupaReqiNumberhelpValus(oObject);

		},
		onLocationServic: function (oEvent) {
			var oBrfModel = this.getView().getModel("oBrfModel");
			/*Start of defect 63383*/
			if (oEvent.getParameter("selectedItem") !== null) {

				var key = oEvent.getParameter("selectedItem").getProperty("key");
				oBrfModel.setProperty("/lineItemBRFSet/LocationOfTheServicesReq", key);
				//oBrfModel.setProperty("/SelcKeySetBRF", oBrfModel.getProperty("/lineItemBRFSet").RequestingMf);
				// if (key === "US") {
				// 	oBrfModel.setProperty("/oVisibleSet/serviceRenderBox", true);
				// } else {
				// 	oBrfModel.setProperty("/oVisibleSet/serviceRenderBox", false);
				// 	oBrfModel.setProperty("/lineItemBRFSet/LocOfRenderingUs", "");

				// }
			} else if (oEvent.getParameter("selectedItem") === null) {
				this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/LocationOfTheServicesReq", "");
			}
			oBrfModel.setProperty("/SelcKeySetBRF", oBrfModel.getProperty("/lineItemBRFSet").RequestingMf);
			return true;
			/*End of defect 63383*/

		},
		// onSelectingServiceRender: function (oEvent) {
		// 	var oBrfModel = this.getView().getModel("oBrfModel");
		// 	var locServiceRend = oEvent.getParameter("selectedItem").getProperty("key");
		// 	if (locServiceRend) {
		// 		oBrfModel.setProperty("/lineItemBRFSet/LocOfRenderingUs", locServiceRend);
		// 	}
		// },
		onSelectingFirstAns: function (oEvent) {
			var val = oEvent.getSource().getProperty("value");
			var questionTableData = this.getModel("oBrfModel").getProperty("/questionSet");
			var tbl;
			var createBrfFragment = this.getView().createId("createBrfFragment");
			tbl = sap.ui.core.Fragment.byId(createBrfFragment, "QuestionTable2");
			for (var interExt = 0; interExt < questionTableData.length; interExt++) {
				if (val === "Service from KPMGI") {
					if (questionTableData[interExt].InternalExternal === "EXTERNAL") {
						questionTableData[interExt].Answer = "N/A";
						questionTableData[interExt].AnswerDesc = " ";
						tbl.getAggregation("items")[interExt].getCells()[3].setProperty("visible", false);
						tbl.getAggregation("items")[interExt].getCells()[2].setProperty("editable", false);
					} else {
						questionTableData[interExt].Answer = " ";
						questionTableData[interExt].AnswerDesc = " ";
						tbl.getAggregation("items")[interExt].getCells()[3].setProperty("visible", false);
						tbl.getAggregation("items")[interExt].getCells()[2].setProperty("editable", true);
					}
				}
				if (val === "Service from external supplier") {
					if (questionTableData[interExt].InternalExternal === "INTERNAL") {
						questionTableData[interExt].Answer = "N/A";
						questionTableData[interExt].AnswerDesc = " ";
						tbl.getAggregation("items")[interExt].getCells()[3].setProperty("visible", false);
						tbl.getAggregation("items")[interExt].getCells()[2].setProperty("editable", false);
					} else {
						questionTableData[interExt].Answer = " ";
						questionTableData[interExt].AnswerDesc = " ";
						tbl.getAggregation("items")[interExt].getCells()[3].setProperty("visible", false);
						tbl.getAggregation("items")[interExt].getCells()[2].setProperty("editable", true);
					}
				}

			}
			this.getView().getModel("oBrfModel").refresh();

		},
		// onEnetrFirstAnswer:function(oEvent){

		// },
		onSelectingAns1: function (oEvent) {
			var val = oEvent.getSource().getProperty("value");
			var oBrfModel = this.getView().getModel("oBrfModel");
			//var questiData=oBrfModel.getProperty("/questionSet");
			var rowPath = oEvent.getSource().getParent().getBindingContextPath();
			var tbl;
			var showInputField;

			var createBrfFragment = this.getView().createId("createBrfFragment");
			tbl = sap.ui.core.Fragment.byId(createBrfFragment, "QuestionTable2");

			for (var i = 0; i < tbl.getAggregation("items").length; i++) {
				showInputField = tbl.getAggregation("items")[i].getBindingContext("oBrfModel").sPath;
				if ((showInputField === rowPath)) {
					for (var k = 0; k < tbl.getAggregation("items")[i].getCells().length; k++) {
						if (k === 3) {
							if (val === "YES") {
								tbl.getAggregation("items")[i].getCells()[3].setProperty("visible", true);
								oBrfModel.getProperty("/questionSet")[i].AnswerDesc = "";
								//tbl.getAggregation("items")[i].getCells()[3].setProperty("value", "");

							} else if (val === "NO") {
								tbl.getAggregation("items")[i].getCells()[3].setProperty("visible", true);
								//tbl.getAggregation("items")[i].getCells()[3].setProperty("value", "");
								oBrfModel.getProperty("/questionSet")[i].AnswerDesc = "";
							} else if (val === "Other") {
								tbl.getAggregation("items")[i].getCells()[3].setProperty("visible", true);
								oBrfModel.getProperty("/questionSet")[i].AnswerDesc = "";
								//tbl.getAggregation("items")[i].getCells()[3].setProperty("value", "");
							} else {
								tbl.getAggregation("items")[i].getCells()[3].setProperty("visible", false);
								oBrfModel.getProperty("/questionSet")[i].AnswerDesc = "";
							}
						}
					}
				}

			}

		},

		brfGlobalFunctionSearchHelp: function (oEvent) {
			var oBrfModel = this.getView().getModel("oBrfModel");
			var id = oEvent.getSource().getId();
			if (id.indexOf("GlobalCc") > 0) {
				this.CostCenterValue = "GLOBALCC";
				this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/GlobalCc", "");
			} else if (id.indexOf("MfCostCenter") > 0) {
				this.CostCenterValue = "MFCOSTCENTER";
			} else if (id.indexOf("CcCode1") > 0) {
				this.CostCenterValue = "COSTCENTERCODE";
				this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/CcCode1", "");
			}
			/*Start of change by developer Satabdi Das on 17-Sep-2020*/
			else if (id.indexOf("Comp9921CcCode1") > 0) {
				this.CostCenterValue = "COSTCENTERCODE";
				this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/CcCode1", "");
			} else if (id.indexOf("Cc9921Debit") > 0) {
				this.CostCenterValue = "DEBITCC";
				this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/CcCode2", "");
			} else if (id.indexOf("GF9921CreditCc") > 0) {
				this.CostCenterValue = "CREDITCC";
				this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/CcCode1", "");
			}
			/*End of change by developer Satabdi Das on 17-Sep-2020*/
			else if (id.indexOf("DebitCc") > 0) {
				this.CostCenterValue = "DEBITCC";
				this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/CcCode2", "");
			} else if (id.indexOf("CreditCc") > 0) {
				this.CostCenterValue = "CREDITCC";
				this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/CcCode1", "");
			} else if (id.indexOf("CcCode2") > 0) {
				this.CostCenterValue = "COSTCENTERDB";
				this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/CcCode2", ""); /*Added for defect 63445*/
			}
			var CCDetails = this.getView().getModel("oBrfModel").getProperty("/CostScnterSearchSet"); /*Added for defect 63412*/
			sap.ui.core.BusyIndicator.show(0);
			/*Start for defect 63412*/
			var aFilter = [];
			var oFilterSerach;
			if (CCDetails.GlobalCostCentre) {
				oFilterSerach = new sap.ui.model.Filter("GlobalCostCentre", sap.ui.model.FilterOperator.EQ, CCDetails.GlobalCostCentre);
				aFilter.push(oFilterSerach);
			}
			if (CCDetails.Ltext) {
				oFilterSerach = new sap.ui.model.Filter("Ltext", sap.ui.model.FilterOperator.EQ, CCDetails.Ltext);
				aFilter.push(oFilterSerach);
			}
			/*End for defect 63412*/

			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				oBrfModel.setProperty("/CostScnterSearchSet", []); /*Added for defect 63412*/
				oBrfModel.setSizeLimit(d.results.length);
				oBrfModel.setProperty("/BRF_CCSet", d.results);
				var fragmentIdBRFCC = this.getView().createId("ccForBRF");
				if (!this.ofragmentIdBRFforcostcenter) {
					this.ofragmentIdBRFforcostcenter = sap.ui.xmlfragment(fragmentIdBRFCC, "KGO.kgoarrecharge_brf.view.ccSearchHelp", this);
					this.getView().addDependent(this.ofragmentIdBRFforcostcenter);
				}
				this.ofragmentIdBRFforcostcenter.open();
				// this.onLocalSearchCC();
			}, this);
			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();
				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"
				});
			}, this);

			var sCompCode = oBrfModel.getProperty("/lineItemBRFSet/CompanyCode"); /*Added for new comp code by developer Satabdi Das on 15-Sep-2020*/
			aFilter.push(new Filter("Bukrs", FilterOperator.EQ, sCompCode)); /*Added for new comp code by developer Satabdi Das on 15-Sep-2020*/
			/*R&D---start*/
			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_BRF_SRV/", {
				json: true
			});
			oModel1.read("/BRF_KOSTLSet", {
				filters: aFilter,
				/*Added for defect 63412*/
				success: fnSuccess,
				error: fnError
			});
			/*R&D---end*/
		},
		onCloseSearchHelpCC: function () {
			this.ofragmentIdBRFforcostcenter.close();
			this.getView().getModel("oBrfModel").setProperty("/localBRFSearch", "");
		},
		onCCRowPress: function (oEvent) {
			var oRowCostCC = oEvent.getSource().getBindingContext("oBrfModel").getObject();
			var sCompCode = this.getView().getModel("oBrfModel").getProperty("/lineItemBRFSet/CompanyCode"); /*Added by Satabdi Das on 05-Oct-2020*/
			if (oRowCostCC) {
				this.ofragmentIdBRFforcostcenter.close();
				if (this.CostCenterValue === "GLOBALCC") {
					this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/GlobalCc", oRowCostCC.GlobalCostCentre);
					this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/Ltext", oRowCostCC.Ltext);
					this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/FunctionName", oRowCostCC.Descript);
					this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/CcCode2", oRowCostCC.GlobalCostCentre);

				} else if (this.CostCenterValue === "MFCOSTCENTER") {
					this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/MfCostCenter", oRowCostCC.GlobalCostCentre);
				} else if (this.CostCenterValue === "COSTCENTERCODE") {
					this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/CcCode1", oRowCostCC.GlobalCostCentre);
					/*Start of change for WHT Prctr defect 63501 by developer Satabdi Das on 20-Aug-2020*/
					/*var sWhT = this.getView().getModel("oBrfModel").getProperty("/lineItemBRFSet/WhtCode");
					if (sWhT && sWhT !== "" && sWhT !== "N/A") {
						this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/ProfitCenterDebit", oRowCostCC.GlobalCostCentre);
					} else {
						this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/ProfitCenterDebit", "");
					}*/
					/*End of for WHT Prctr defect 63501 by developer Satabdi Das on 20-Aug-2020*/
				} else if (this.CostCenterValue === "DEBITCC") {
					this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/CcCode2", oRowCostCC.GlobalCostCentre);
				} else if (this.CostCenterValue === "CREDITCC") {
					this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/CcCode1", oRowCostCC.GlobalCostCentre);
				} else if (this.CostCenterValue === "COSTCENTERDB") {
					this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/CcCode2", oRowCostCC.GlobalCostCentre);
				}
				this.getView().getModel("oBrfModel").setProperty("/localBRFSearch", "");
			}
		},

		/*Start of change by Satabdi Das on 04-March-2021 nfor 63648*/
		onPressRestCCSearch: function (oEvent) {
			var oBrfModel = this.getView().getModel("oBrfModel");
			var id = oEvent.getSource().getId();
			if (id.indexOf("CcCode1") > 0) {
				this.CostCenterValue = "COSTCENTERCODE";
				this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/CcCode1", "");
			} else if (id.indexOf("Comp9921CcCode1") > 0) {
				this.CostCenterValue = "COSTCENTERCODE";
				this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/CcCode1", "");
			} else if (id.indexOf("CreditCc") > 0) {
				this.CostCenterValue = "CREDITCC";
				this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/CcCode1", "");
			}

			var CCDetails = this.getView().getModel("oBrfModel").getProperty("/RestCCSearchSet");
			sap.ui.core.BusyIndicator.show(0);

			var aFilter = [];
			var oFilterSerach;
			if (CCDetails.GlobalCostCentre) {
				oFilterSerach = new Filter("GlobalCostCentre", FilterOperator.EQ, CCDetails.GlobalCostCentre);
				aFilter.push(oFilterSerach);
			}
			if (CCDetails.Ltext) {
				oFilterSerach = new Filter("Ltext", FilterOperator.EQ, CCDetails.Ltext);
				aFilter.push(oFilterSerach);
			}

			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				oBrfModel.setProperty("/RestCCSearchSet", []);
				oBrfModel.setSizeLimit(d.results.length);
				oBrfModel.setProperty("/BRF_RestCCSet", d.results);
				var fragmentIdBRFCC = this.getView().createId("RestCC");
				if (!this._oRestCC) {
					this._oRestCC = sap.ui.xmlfragment(fragmentIdBRFCC, "KGO.kgoarrecharge_brf.view.restCCSearchHelp", this);
					this.getView().addDependent(this._oRestCC);
				}
				this._oRestCC.open();
			}, this);

			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();
				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"
				});
			}, this);

			var sCompCode = oBrfModel.getProperty("/lineItemBRFSet/CompanyCode");
			aFilter.push(new Filter("Bukrs", FilterOperator.EQ, sCompCode));

			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_BRF_SRV/", {
				json: true
			});
			oModel1.read("/BRF_RestCCSet", {
				filters: aFilter,
				success: fnSuccess,
				error: fnError
			});
		},

		onCloseRestCCHelp: function () {
			this._oRestCC.close();
			this.getView().getModel("oBrfModel").setProperty("/RestCCSearchSet", []);
		},
		onSelectRestCC: function (oEvent) {
			var oRowCostCC = oEvent.getSource().getBindingContext("oBrfModel").getObject();
			var sCompCode = this.getView().getModel("oBrfModel").getProperty("/lineItemBRFSet/CompanyCode");
			if (oRowCostCC) {
				this._oRestCC.close();
				if (this.CostCenterValue === "COSTCENTERCODE") {
					this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/CcCode1", oRowCostCC.GlobalCostCentre);
				} else if (this.CostCenterValue === "CREDITCC") {
					this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/CcCode1", oRowCostCC.GlobalCostCentre);
				}
				this.getView().getModel("oBrfModel").setProperty("/RestCCSearchSet", []);
			}
		},
		/*End of change by Satabdi Das on 04-March-2021 for 63648*/

		onPressDeleteLineItem: function (oEvent) {
			var oDeleteRowData = oEvent.getSource().getBindingContext("oBrfModel").getObject();
			var oBrfModel = this.getView().getModel("oBrfModel");
			var BrfNo = this.getView().getModel("oBrfModel").getProperty("/brfHeaderSet").BrfNo;
			var bDisplay = this.getView().getModel("oBrfModel").getProperty("/Display"); /*Added on 06-MAY-2020*/
			if ((oDeleteRowData.LineType === "CREDITNOTE" || oDeleteRowData.LineType === "REISSUANCE") && (!oDeleteRowData.LineStatus)) {
				oDeleteRowData.EditDisplay = "";
				bDisplay = false;
			}
			if (bDisplay === false) { /*Aded on 06-MAY-2020*/
				var that = this;
				var lineDeleteText = this.getModel("i18n").getProperty("lineDeleteText");
				var ReqText;
				var reqGCC;
				var MF;
				var MemberFirmText;
			    var procesgrp;
			    var processinggrp;
				var event = oEvent.getSource();
				if (oDeleteRowData.RequestingMf !== "N/A" && oDeleteRowData.GlobalCc === "N/A") {
					reqGCC = oDeleteRowData.RequestingMf;
					MF = oDeleteRowData.MemberFirm;
					procesgrp=oDeleteRowData.ProcessGrp;
					ReqText = this.getModel("i18n").getProperty("requesDeleteText");
					MemberFirmText = this.getModel("i18n").getProperty("deleteMfText");
					processinggrp=this.getModel("i18n").getProperty("processgrp");
				} else {
					reqGCC = oDeleteRowData.GlobalCc;
					ReqText = this.getModel("i18n").getProperty("globalCC");
					MemberFirmText = "";
					MF = "";
					processinggrp="";
					procesgrp="";
				}
				if (oDeleteRowData.EditDisplay !== "X") { /*Aded on 06-MAY-2020*/
					if ((oDeleteRowData.LineStatus !== "AR(POST)") && (oDeleteRowData.LineStatus !== "POSTED") && (oDeleteRowData.LineStatus !==
							"PARKED") && (oDeleteRowData.LineStatus !== "Approved") && (oDeleteRowData.LineStatus !== "PARKED(LTT)") && (oDeleteRowData.LineStatus !==
							"VAT(LTT)") && (oDeleteRowData.LineStatus !==
							"LTT") && (oDeleteRowData.LineStatus !== "LTT1") && (oDeleteRowData.LineStatus !== "LTT2") && (oDeleteRowData.LineStatus !==
							"LTT3")) {
						var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
						MessageBox.warning(
						ReqText + reqGCC + " " + MemberFirmText + MF +  " " + processinggrp+ procesgrp + " " + lineDeleteText, {
							actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
							styleClass: bCompact ? "sapUiSizeCompact" : "",
								onClose: function (sAction) {
									if (sAction === "OK") {
										/*Start of change by developer Satabdi Das on 01-Oct-2020*/
										var oQuestionaireDataDelete = oBrfModel.getProperty("/questionSetSubmit");
										for (var i = oQuestionaireDataDelete.length - 1; i >= 0; i--) {
											if (oDeleteRowData.RequestingMf === oQuestionaireDataDelete[i].RequestingMf && oDeleteRowData.ProcessGrp ===
												oQuestionaireDataDelete[i].ProcessGrp && oDeleteRowData.MemberFirm === oQuestionaireDataDelete[i].MemberFirm &&
												oDeleteRowData.LineType === oQuestionaireDataDelete[i].LineType) {
												var y = i;
												y = parseInt(y);
												oQuestionaireDataDelete.splice(y, 1);
											}
										}

										if (oDeleteRowData.ProcessGrp) {
											oDeleteRowData.ProcessGrp = oDeleteRowData.ProcessGrp.replace(/\s/g, "*");
											/*Start of change for INC01584421 by developer Satabdi Das on 21-June-2021*/
											var forwardslash = /[/]+/;
											if (forwardslash.test(oDeleteRowData.ProcessGrp)) {
												oDeleteRowData.ProcessGrp = oDeleteRowData.ProcessGrp.replace(/[/]/g, "|");
											}

											var qQuestionChar = /[?]+/;
											if (qQuestionChar.test(oDeleteRowData.ProcessGrp)) {
												oDeleteRowData.ProcessGrp = oDeleteRowData.ProcessGrp.replace(/[?]/g, "(");
											}

											var pPercentage = /[%]+/;
											if (pPercentage.test(oDeleteRowData.ProcessGrp)) {
												oDeleteRowData.ProcessGrp = oDeleteRowData.ProcessGrp.replace(/[%]/g, ")");
											}
											/*End of change for INC01584421 by developer Satabdi Das on 21-June-2021*/
										}
										if (oDeleteRowData.MemberFirm) {
											oDeleteRowData.MemberFirm = oDeleteRowData.MemberFirm.replace(/\s/g, "*");
											/*Start of change for INC01584421 by developer Satabdi Das on 21-June-2021*/
											var forwardslashMmfirm = /[/]+/;
											if (forwardslashMmfirm.test(oDeleteRowData.MemberFirm)) {
												oDeleteRowData.MemberFirm = oDeleteRowData.MemberFirm.replace(/[/]/g, "|");
											}

											var qQuestionCharMemFm = /[?]+/;
											if (qQuestionCharMemFm.test(oDeleteRowData.MemberFirm)) {
												oDeleteRowData.MemberFirm = oDeleteRowData.MemberFirm.replace(/[?]/g, "(");
											}

											var pPercentageMF = /[%]+/;
											if (pPercentageMF.test(oDeleteRowData.MemberFirm)) {
												oDeleteRowData.MemberFirm = oDeleteRowData.MemberFirm.replace(/[%]/g, ")");
											}
											/*End of change for INC01584421 by developer Satabdi Das on 21-June-2021*/
										}

										/*End of change by developer Satabdi Das on 01-Oct-2020*/
										if (oDeleteRowData.RequestingMf === "N/A") {
											oDeleteRowData.RequestingMf = "NA";
										} else if (oDeleteRowData.GlobalCc === "N/A") {
											oDeleteRowData.GlobalCc = "NA";
										}
										if (BrfNo && oDeleteRowData.LineStatus) {
											var fnSuccess = jQuery.proxy(function (d) {
												sap.ui.core.BusyIndicator.hide(0);
												// that.handlePreBtnEdit();
												var x = event.getBindingContext("oBrfModel").getPath();
												var y = x.split("/");
												var z = y[2];
												z = parseInt(z);
												var s = event.getBindingContext("oBrfModel").getProperty("/brfTableSet");
												for (var i = s.length - 1; i >= 0; i--) {
													if (i === z) {
														s.splice(z, 1);
													}
												}
												that.getView().getModel("oBrfModel").refresh();
											}, that);
											var fnError = jQuery.proxy(function (d) {
												var r = JSON.parse(JSON.stringify(d));
											}, that);
											var sPath = "/BRFItemSet(CompanyCode='" + oDeleteRowData.CompanyCode + "',BrfNo='" + BrfNo +
												"',RequestingMf='" + oDeleteRowData.RequestingMf + "',MemberFirm='" + oDeleteRowData.MemberFirm + "',ProcessGrp='" +
												oDeleteRowData.ProcessGrp + "',GlobalCc='" +
												oDeleteRowData.GlobalCc + "',CcShortDesc='" + oDeleteRowData.CcShortDesc + "',TransactionType='" + oDeleteRowData.TransactionType +
												"')";
											var oObject = {};
											oObject.success = fnSuccess;
											oObject.error = fnError;
											oObject.sPath = sPath;
											oObject.groupId = "DeleteRow";
											that.deleteRecordBRF(oObject);
											that._submitBatchOperationTestforBRF("DeleteRow", fnSuccess, fnError);
										} else {
											var x = event.getBindingContext("oBrfModel").getPath();
											var y = x.split("/");
											var z = y[2];
											z = parseInt(z);
											var s = event.getBindingContext("oBrfModel").getProperty("/brfTableSet");
											for (var i = 0; i < s.length; i++) {
												if (i === z) {
													s.splice(z, 1);
													that.getView().getModel("oBrfModel").refresh();
												}
											}
										}
									}
								}
							}
						);
					} else {
						if (oDeleteRowData.RequestingMf !== "N/A" && oDeleteRowData.GlobalCc === "N/A") {
							MessageBox.alert(
								"Requesting country: " + oDeleteRowData.RequestingMf + " Member Firm :" + oDeleteRowData.MemberFirm +
								" and Processing group: " +
								oDeleteRowData.ProcessGrp +
								" line cannot be deleted as the line status is : " + oDeleteRowData.LineStatus + " .", {
									styleClass: bCompact ? "sapUiSizeCompact" : ""
								}
							);

						} else {
							MessageBox.alert(
								"Global CC : " + oDeleteRowData.GlobalCc + " line cannot be deleted as line status is : " + oDeleteRowData.LineStatus + " .", {
									styleClass: bCompact ? "sapUiSizeCompact" : ""
								}
							);
						}
					}
				} /*Aded on 06-MAY-2020*/
			} /*Added on 06-MAY-2020*/
		},
		deleteRecordBRF: function (oObject) {
			var _modelBase = this.getOwnerComponent().getModel(); //controllerRef.getOwnerComponent().getModel();
			_modelBase.setUseBatch(true);
			_modelBase.setDeferredGroups(["DeleteRow"]);
			var sPath = oObject.sPath;
			var groupId = oObject.groupId;
			var successCallback = oObject.success;
			var errorCallback = oObject.error;
			_modelBase.remove(sPath, {
				groupId: groupId,
				success: successCallback,
				error: errorCallback
			});
		},
		_submitBatchOperationTestforBRF: function (grpId, fnUpdSuccess, fnUpdError) {

			var fnSuccess1 = jQuery.proxy(function (d) {
				//this.handlePressEditBRF();
				sap.ui.core.BusyIndicator.hide(0);
				// that.onCoupaPressed();
			}, this);
			var _modelBase = this.getOwnerComponent().getModel(); //controllerRef.getOwnerComponent().getModel();
			_modelBase.submitChanges({
				groupId: grpId,
				success: fnSuccess1,
				error: fnUpdError
			});
		},
		checkWhTPercy: function (oEvent) {
			if (isNaN(oEvent.getParameter("value")) === true || (oEvent.getParameter("value") > 100)) {
				this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/WhtCode", "");
				this.getView().getModel("oBrfModel").refresh(true);
			}
		},
		onWhTax: function (oEvent) {
			var oBrfModel = this.getView().getModel("oBrfModel");
			var sCompCode = oBrfModel.getProperty("/lineItemBRFSet/CompanyCode"); /*Added by Satabdi Das 06-Oct-2020*/
			var sWhtGl = oBrfModel.getProperty("/lineItemBRFSet/DebitGl"); /*Added by Satabdi Das 06-Oct-2020*/
			var sVal;
			if (oEvent) {
				sVal = oEvent.getParameter("value");
			} else if (!oEvent) {
				var sWhT = oBrfModel.getProperty("/lineItemBRFSet/WhtCode");
				sVal = sWhT;
			}
			if (sVal && sVal !== "" && sVal !== "N/A") {
				oBrfModel.setProperty("/WhTFldsMandat", true);
				var nDebitAmt = Number(oBrfModel.getProperty("/lineItemBRFSet/RechargeAmountDebit"));
				var nWht = Number(sVal);
				if (nDebitAmt) {
					var nWhtAmt = ((nDebitAmt * 100) / (100 - nWht)) - nDebitAmt;
					var sWhtAmt = formatter.ValueExportFormatter(nWhtAmt, 2);
					oBrfModel.setProperty("/lineItemBRFSet/LineItemTotal", sWhtAmt);
					/*Start of change for WHT Prctr defect 63501 by developer Satabdi Das on 20-Aug-2020*/
					// var sCreditCC = oBrfModel.getProperty("/lineItemBRFSet/CcCode1");
					// if (sCreditCC && sCreditCC !== "") {
					// 	oBrfModel.setProperty("/lineItemBRFSet/ProfitCenterDebit", sCreditCC);
					// } else {
					// 	oBrfModel.setProperty("/lineItemBRFSet/ProfitCenterDebit", "");
					// }
					/*End of change for WHT Prctr defect 63501 by developer Satabdi Das on 20-Aug-2020*/
					/*Start of change by developer Satabdi Das on 06-Oct-2020*/
					if (!sWhtGl || sWhtGl === "") {
						/*oBrfModel.setProperty("/lineItemBRFSet/DebitGl", "120105");*/
						oBrfModel.setProperty("/lineItemBRFSet/DebitGl", "120110");
					}
					if (sCompCode === "9921") {
						var sCreditPrctr = oBrfModel.getProperty("/lineItemBRFSet/ProfitCenter");
						if (sCreditPrctr && sCreditPrctr !== "") {
							oBrfModel.setProperty("/lineItemBRFSet/ProfitCenterDebit", sCreditPrctr);
						} else {
							oBrfModel.setProperty("/lineItemBRFSet/ProfitCenterDebit", "");
						}
					}
					/*End of change by developer Satabdi Das on 06-Oct-2020*/
				} else {
					var sMsg = this.getView().getModel("i18n").getProperty("custAmtAlert");
					oBrfModel.setProperty("/lineItemBRFSet/WhtCode", "");
					MessageBox.alert(sMsg);
					return;
				}
			} else {
				oBrfModel.setProperty("/WhTFldsMandat", false);
				oBrfModel.setProperty("/lineItemBRFSet/LineItemTotal", "");
				oBrfModel.setProperty("/lineItemBRFSet/DebitGl", ""); /*Added by Satabdi Das on 06-Oct-2020*/
				oBrfModel.setProperty("/lineItemBRFSet/ProfitCenterDebit", ""); /*Added for WHT Prctr defect 63501 by developer Satabdi Das on 06-Oct-2020*/
			}

		},
		onWhAEnter: function (oEvent) {
			var oBrfModel = this.getView().getModel("oBrfModel");
			var sCompCode = oBrfModel.getProperty("/lineItemBRFSet/CompanyCode"); /*Added by Satabdi Das 06-Oct-2020*/
			var sWhtGl = oBrfModel.getProperty("/lineItemBRFSet/DebitGl"); /*Added by Satabdi Das 06-Oct-2020*/
			var sVal;
			if (oEvent) {
				sVal = oEvent.getParameter("value");
			} else if (!oEvent) {
				var nWhtAmt = oBrfModel.getProperty("/lineItemBRFSet/LineItemTotal");
				sVal = nWhtAmt;
			}
			if (sVal && sVal !== "" && sVal !== "N/A") {
				oBrfModel.setProperty("/WhTFldsMandat", true);
				var nDebitAmt = Number(oBrfModel.getProperty("/lineItemBRFSet").RechargeAmountDebit);
				var nWhtAmt = Number(sVal);
				if (nDebitAmt) {
					var nWht = ((nWhtAmt * 100) / (nWhtAmt + nDebitAmt));
					var nWht = formatter.ValueExportFormatter(nWht, 2);
					oBrfModel.setProperty("/lineItemBRFSet/WhtCode", nWht);
					/*Start of change for WHT Prctr defect 63501 by developer Satabdi Das on 20-Aug-2020*/
					// var sCreditCC = oBrfModel.getProperty("/lineItemBRFSet/CcCode1");
					// if (sCreditCC && sCreditCC !== "") {
					// 	oBrfModel.setProperty("/lineItemBRFSet/ProfitCenterDebit", sCreditCC);
					// } else {
					// 	oBrfModel.setProperty("/lineItemBRFSet/ProfitCenterDebit", "");
					// }
					/*End of change for WHT Prctr defect 63501 by developer Satabdi Das on 20-Aug-2020*/
					/*Start of change by developer Satabdi Das on 06-Oct-2020*/

				}
			}
		},
		checkAmount: function (oEvent) {

			var createBrfFragment = this.getView().createId("createBrfFragment");
			if (isNaN(oEvent.getParameter("value")) === true || (oEvent.getParameter("value") > 99999999999.99)) {
				var label1 = sap.ui.core.Fragment.byId(createBrfFragment, "Amount1");
				var label2 = sap.ui.core.Fragment.byId(createBrfFragment, "RechargeAmountDebit");
				var label3 = sap.ui.core.Fragment.byId(createBrfFragment, "RechargeAmountCredit");
				var label4 = sap.ui.core.Fragment.byId(createBrfFragment, "LineItemTotal");
				var label5 = sap.ui.core.Fragment.byId(createBrfFragment, "GrandTotal");
				var label6 = sap.ui.core.Fragment.byId(createBrfFragment, "GrandTotal2");
				var label7 = sap.ui.core.Fragment.byId(createBrfFragment, "linItemTotal");
				var label8 = sap.ui.core.Fragment.byId(createBrfFragment, "Amount2");
				if (label1 !== undefined) {
					label1.setValue("");
				}
				if (label2 !== undefined) {
					label2.setValue("");
				}
				if (label3 !== undefined) {
					label3.setValue("");
				}
				if (label4 !== undefined) {
					label4.setValue("");
				}
				if (label5 !== undefined) {
					label5.setValue("");
				}
				if (label6 !== undefined) {
					label6.setValue("");
				}
				if (label7 !== undefined) {
					label7.setValue("");
				}
				if (label8 !== undefined) {
					label8.setValue("");
				}
			}
		},
		CrditAmt: function (oEvent) {
			var createBrfFragment = this.getView().createId("createBrfFragment");
			var creditAmount = oEvent.getParameter("value");
			var oLineType = this.getView().getModel("oBrfModel").getProperty("/linetText");
			//var oFragmentValue=this.getView().getModel("oBrfModel").getProperty("/lineItemBRFSet");
			if (isNaN(oEvent.getParameter("value")) === true || (oEvent.getParameter("value") > 99999999999.99)) {
				var labelGFamtcredit = sap.ui.core.Fragment.byId(createBrfFragment, "RechargeAmountCredit");
				var Amt2 = sap.ui.core.Fragment.byId(createBrfFragment, "Amount2");
				if (labelGFamtcredit !== undefined) {
					labelGFamtcredit.setValue("");
				}
				if (Amt2 !== undefined) {
					Amt2.setValue("");
				}

			} else {
				if ((oLineType === "CREDITNOTE") && creditAmount) {
					this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/RechargeAmountDebit", creditAmount);
					var labelGFamtcredit = sap.ui.core.Fragment.byId(createBrfFragment, "RechargeAmountCredit");
					/*Start of change Satabdi Das on 30-Dec-2020*/
					var Amt2 = sap.ui.core.Fragment.byId(createBrfFragment, "Amount2");
					if (Amt2 && creditAmount) {
						// this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/RechargeAmountDebit", creditAmount);
						this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/RechargeAmountCredit", creditAmount);
						var sWhT = this.getView().getModel("oBrfModel").getProperty("/lineItemBRFSet/WhtCode");
						if (sWhT && sWhT !== "" && sWhT !== "N/A") {
							this.onWhTax();
						}
					}
					/*End of change Satabdi Das on 30-Dec-2020*/
				}
			}

		},
		onDebitAmount: function (oEvent) {
			var sValue = oEvent.getParameter("value");
			var sId = oEvent.getSource().getId().split("--")[2]; /*Change added for INC01499658 on 22-APR-2021*/
			if (sId && sValue) {
				if (sId === "Amount1") {
					this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/RechargeAmountDebit", sValue);
					this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/RechargeAmountCredit", sValue);
					var sWhT = this.getView().getModel("oBrfModel").getProperty("/lineItemBRFSet/WhtCode");
					if (sWhT && sWhT !== "" && sWhT !== "N/A") {
						this.onWhTax();
					}
				}
				if (sId === "RechargeAmountDebit") {
					this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/RechargeAmountCredit", sValue);
					this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/RechargeAmountDebit", sValue);
				}
			}

		},

		onPressGlAccount: function (oEvent) {
			var bDisplay = this.getView().getModel("oBrfModel").getProperty("/Display");
			var sFragTxt = this.getView().getModel("oBrfModel").getProperty("/fraggmentText"); //added for Reissuance visible by Satabdi Das on  14-Dec-2020
			if (bDisplay === false || sFragTxt === "REISSUANCE") { //added for Reissuance visible by Satabdi Das on  14-Dec-2020
				var id = oEvent.getSource().getId();
				var oBrfModel = this.getModel("oBrfModel");
				if (id.indexOf("GlobalGl1") > 0) {
					this.GlValue = "GLOBALGL1";
					oBrfModel.setProperty("/lineItemBRFSet/DebitGl", ""); /*Added for defect 63445*/
				} else if (id.indexOf("ExpenseGl") > 0) {
					this.GlValue = "EXPENSEGL";
					oBrfModel.setProperty("/lineItemBRFSet/ExpenseGl", ""); /*Added for defect 63445*/
				} else if (id.indexOf("ExpenseCRGL") > 0) {
					this.GlValue = "EXPENSECRGL";
					oBrfModel.setProperty("/lineItemBRFSet/ExpenseGlCredit", ""); /*Added for defect 63445*/
				} else if (id.indexOf("DebitGl") > 0) {
					this.GlValue = "DEBITGL";
					oBrfModel.setProperty("/lineItemBRFSet/DebitGl", "");
				} else if (id.indexOf("CreditGl") > 0) {
					this.GlValue = "CREDITGL";
					oBrfModel.setProperty("/lineItemBRFSet/CreditGl", "");
				} else if (id.indexOf("GLCR") > 0) {
					this.GlValue = "GLCR";
					oBrfModel.setProperty("/lineItemBRFSet/CreditGl", "");
				} else if (id.indexOf("MFCRExpGL") > 0) { /*Added for defect 63369*/
					this.GlValue = "MFCRGF";
					oBrfModel.setProperty("/lineItemBRFSet/ExpenseGlCredit", ""); /*Added for defect 63445*/
				}
				sap.ui.core.BusyIndicator.show(0);
				var aFilter = [];
				var mArrayOut = [];
				var sCompCode = oBrfModel.getProperty("/lineItemBRFSet/CompanyCode"); /*Added for new comp code by developer Satabdi Das on 15-Sep-2020*/
				var fnSuccess = jQuery.proxy(function (d) {
					sap.ui.core.BusyIndicator.hide(0);
					for (var i = 0; i < d.results.length; i++) {
						var oGlobalGlAccont = {};
						oGlobalGlAccont.Ktopl = d.results[i].Ktopl;
						oGlobalGlAccont.Saknr = d.results[i].Saknr;
						oGlobalGlAccont.Txt20 = d.results[i].Txt20;
						mArrayOut.push(oGlobalGlAccont);
					}
					oBrfModel.setProperty("/BRF_GLSet", mArrayOut);
					/*Below code mcommented by Satabdi Das on 11-Nov-2020*/
					// oBrfModel.refresh(true);
					var fragmentId = this.getView().createId("searchGlAccount");
					if (!this._oSeachGlAccount) {
						this._oSeachGlAccount = sap.ui.xmlfragment(fragmentId, "KGO.kgoarrecharge_brf.view.searchHelpForGL", this);
						this.getView().addDependent(this._oSeachGlAccount);
					}
					this._oSeachGlAccount.open();
				}, this);
				var fnError = jQuery.proxy(function (d) {
					var r = JSON.parse(JSON.stringify(d));
					sap.ui.core.BusyIndicator.hide();
					MessageToast.show(r.message, {
						autoClose: true,
						width: "20rem"
					});
				}, this);

				aFilter.push(new Filter("Bukrs", FilterOperator.EQ, sCompCode)); /*Added for new comp code by developer Satabdi Das on 15-Sep-2020*/

				var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_BRF_SRV/", {
					json: true
				});
				oModel1.read("/BRF_GLSet", {
					filters: aFilter,
					success: fnSuccess,
					error: fnError
				});
				/*R&D---end*/
			}
		},
		onSelectGlAccount: function (oEvent) {
			var GlAccount = oEvent.getSource().getBindingContext("oBrfModel").getObject();
			if (this.GlValue != undefined) {
				if (this.GlValue === "GLOBALGL1") {
					this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/DebitGl", GlAccount.Saknr);
				} else if (this.GlValue === "EXPENSEGL") {
					this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/ExpenseGl", GlAccount.Saknr);
				} else if (this.GlValue === "EXPENSECRGL") {
					this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/ExpenseGlCredit", GlAccount.Saknr);
				} else if (this.GlValue === "DEBITGL") {
					this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/DebitGl", GlAccount.Saknr);
					var sGLValue = this.getView().getModel("oBrfModel").getProperty("/lineItemBRFSet/DebitGl");
					var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
					var that = this;
					if (sGLValue === "160100" || sGLValue === "320150") {
						that.getModel("oBrfModel").setProperty("/oVisibleSet/GL160100", true);
						MessageBox.information(
							that.getView().getModel("i18n").getProperty("AccruMandt"), {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}
						);
					} else {
						that.getModel("oBrfModel").setProperty("/oVisibleSet/GL160100", false);
					}
				} else if (this.GlValue === "CREDITGL") {
					this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/CreditGl", GlAccount.Saknr);
					var sGLValue = this.getView().getModel("oBrfModel").getProperty("/lineItemBRFSet/CreditGl");
					var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
					var that = this;
					if (sGLValue === "160100" || sGLValue === "320150") {
						that.getModel("oBrfModel").setProperty("/oVisibleSet/CRGL160100", true);
						MessageBox.information(
							that.getView().getModel("i18n").getProperty("AccruMandt"), {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}
						);
					} else {
						that.getModel("oBrfModel").setProperty("/oVisibleSet/CRGL160100", false);
					}
				} else if (this.GlValue === "GLCR") {
					this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/CreditGl", GlAccount.Saknr);
					var sGLValue = this.getView().getModel("oBrfModel").getProperty("/lineItemBRFSet/CreditGl");
					var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
					var that = this;
					if (sGLValue === "160100" || sGLValue === "320150") {
						that.getModel("oBrfModel").setProperty("/oVisibleSet/CRGL160100", true);
						MessageBox.information(
							that.getView().getModel("i18n").getProperty("AccruMandt"), {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}
						);
					} else {
						that.getModel("oBrfModel").setProperty("/oVisibleSet/CRGL160100", false);
					}
				} /*Start fo change for Defect 63369*/
				else if (this.GlValue === "MFCRGF") {
					this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/ExpenseGlCredit", GlAccount.Saknr);
				} /*End of change for defect 63369*/
			}
			var fragId = this.getView().createId("searchGlAccount");
			var SearchId = sap.ui.core.Fragment.byId(fragId, "searchFldGl");
			SearchId.setValue("");
			var aFilter = [];
			aFilter.push(new Filter("Saknr", FilterOperator.Contains, ""));
			var frag = this.getView().createId("searchGlAccount");
			var table = sap.ui.core.Fragment.byId(frag, "listGlAcc");
			var oBinding = table.getBinding("items");
			oBinding.filter(aFilter, "Application");
			if (this._oSeachGlAccount) {
				this._oSeachGlAccount.close();
			}
		},
		onSearchGl: function (oEvent) {
			var aFilter = [];
			var sQuery = oEvent.getSource().getValue();
			sQuery = sQuery.trim();
			if (sQuery && sQuery.length > 0) {
				aFilter.push(new Filter("Saknr", FilterOperator.Contains, sQuery));
			}
			var fragmentId = this.getView().createId("searchGlAccount");
			var table = sap.ui.core.Fragment.byId(fragmentId, "listGlAcc");
			var oBinding = table.getBinding("items");
			oBinding.filter(aFilter, "Application");
		},
		onCloseGlHelp: function () {
			var fragId = this.getView().createId("searchGlAccount");
			var SearchId = sap.ui.core.Fragment.byId(fragId, "searchFldGl");
			SearchId.setValue("");
			var aFilter = [];
			aFilter.push(new Filter("Saknr", FilterOperator.Contains, ""));
			var frag = this.getView().createId("searchGlAccount");
			var table = sap.ui.core.Fragment.byId(frag, "listGlAcc");
			var oBinding = table.getBinding("items");
			oBinding.filter(aFilter, "Application");
			if (this._oSeachGlAccount) {
				this._oSeachGlAccount.close();
			}
		},
		onNameHelp: function (oEvent) {
			var bDisplay = this.getView().getModel("oBrfModel").getProperty("/Display");
			var sFragTxt = this.getView().getModel("oBrfModel").getProperty("/fraggmentText"); //added for Reissuance visible by Satabdi Das on  14-Dec-2020
			if (bDisplay === false || sFragTxt === "REISSUANCE") { //added for Reissuance visible by Satabdi Das on  14-Dec-2020
				var oBrfModel = this.getModel("oBrfModel");
				var sReqMf = oBrfModel.getProperty("/lineItemBRFSet/RequestingMf");
				var sCompCode = oBrfModel.getProperty("/lineItemBRFSet/CompanyCode"); /*Added for new comp code by developer Satabdi Das on 19-Aug-2020*/
				sap.ui.core.BusyIndicator.show(0);
				var aFilter = [];
				var sPath = "";
				sPath = "/EntitySet";
				var fnSuccess = jQuery.proxy(function (d) {
					sap.ui.core.BusyIndicator.hide(0);
					oBrfModel.setProperty("/EntitySet", d.results);
					var fragmentId = this.getView().createId("entityHelp");
					if (!this._oEntityHelp) {
						this._oEntityHelp = sap.ui.xmlfragment(fragmentId, "KGO.kgoarrecharge_brf.view.entityHelp", this);
						this.getView().addDependent(this._oEntityHelp);
					}
					this._oEntityHelp.open();
				}, this);
				var fnError = jQuery.proxy(function (d) {
					var r = JSON.parse(JSON.stringify(d));
					sap.ui.core.BusyIndicator.hide();
					MessageToast.show(r.message, {
						autoClose: true,
						width: "20rem"
					});
				}, this);
				if (sReqMf !== undefined && sReqMf !== "") {
					aFilter.push(new sap.ui.model.Filter("Land1", sap.ui.model.FilterOperator.EQ, sReqMf));
				}
				/*Start of changes for new comp code 9921 by developer Satabdi Das*/
				if (sCompCode !== undefined && sCompCode !== "") {
					aFilter.push(new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.EQ, sCompCode));
				}
				/*End of changes for new comp code 9921 by developer Satabdi Das*/
				/*R&D---start*/
				var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_BRF_SRV/", {
					json: true
				});
				oModel1.read("/EntitySet", {
					filters: aFilter,
					success: fnSuccess,
					error: fnError
				});
				/*R&D---end*/
			}
		},
		onPressEnName: function (oEvent) {
			var sEntity = oEvent.getSource().getBindingContext("oBrfModel").getObject();
			var sName = sEntity.Name1 + " " + sEntity.Name2;
			/*Start of change by developer Satabdi Das on 03-Nov-2020 for INC01227830*/
			// var sAddress = sEntity.Stras + ";" + " " + sEntity.Regio; /*Changed on 25-May-2020*/
			var sPin = sEntity.Pstlz;
			var sAddress;
			if (sEntity.Street !== "") {
				sAddress = sEntity.Street + "; " + sEntity.StrSuppl1 + "; " + sEntity.StrSuppl2 + "; " + sEntity.StrSuppl3 + "; " + sPin;
			} else {
				sAddress = sPin;
			}
			/*End of change by developer Satabdi Das on 03-Nov-2020 for INC01227830*/
			var sCity = sEntity.Ort01;
			var sCustNo = sEntity.Kunnr;
			var sVat = sEntity.Stceg;
			this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/EntityName", sName);
			this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/EntityAddress", sAddress);
			// this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/Pin", sPin);
			// this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/City", sCity);
			this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/SapCodeMf", sCustNo);
			this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/VatId", sVat);
			var fragId = this.getView().createId("entityHelp");
			var SearchId = sap.ui.core.Fragment.byId(fragId, "EnName");
			SearchId.setValue("");
			var aFilter = [];
			aFilter.push(new Filter("Name1", FilterOperator.Contains, ""));
			var frag = this.getView().createId("entityHelp");
			var table = sap.ui.core.Fragment.byId(frag, "entityName");
			var oBinding = table.getBinding("items");
			oBinding.filter(aFilter, "Application");
			if (this._oEntityHelp.isOpen()) {
				this._oEntityHelp.close();
			}
		},
		onSearchEnName: function (oEvent) {
			var aFilter = [];
			var sQuery = oEvent.getSource().getValue();
			sQuery = sQuery.trim();
			if (sQuery && sQuery.length > 0) {
				aFilter.push(new Filter("Name1", FilterOperator.Contains, sQuery));
			}
			var frag = this.getView().createId("entityHelp");
			var table = sap.ui.core.Fragment.byId(frag, "entityName");
			var oBinding = table.getBinding("items");
			oBinding.filter(aFilter, "Application");
		},
		onCloseEnName: function (oEvent) {
			var fragId = this.getView().createId("entityHelp");
			var SearchId = sap.ui.core.Fragment.byId(fragId, "EnName");
			SearchId.setValue("");
			var aFilter = [];
			aFilter.push(new Filter("Name1", FilterOperator.Contains, ""));
			var frag = this.getView().createId("entityHelp");
			var table = sap.ui.core.Fragment.byId(frag, "entityName");
			var oBinding = table.getBinding("items");
			oBinding.filter(aFilter, "Application");
			if (this._oEntityHelp.isOpen()) {
				this._oEntityHelp.close();
			}
		},
		onProfitCenterPress: function (oEvent) {
			var bDisplay = this.getView().getModel("oBrfModel").getProperty("/Display");
			var sFragTxt = this.getView().getModel("oBrfModel").getProperty("/fraggmentText"); //added for Reissuance visible by Satabdi Das on  14-Dec-2020
			if (bDisplay === false || sFragTxt === "REISSUANCE") { //added for Reissuance visible by Satabdi Das on  14-Dec-2020
				var id = oEvent.getSource().getId();
				var oBrfModel = this.getModel("oBrfModel");
				if (id.indexOf("MFPrctr") > 0) {
					this.ProfitCenter = "MFPROFITCENTER";
					oBrfModel.setProperty("/lineItemBRFSet/ProfitCenter", ""); /*Added for defect 63445*/
				}
				/*Start of change by developer Satabdi Das on 17-Sep-2020*/
				else if (id.indexOf("Comp9921MFPrctr") > 0) {
					this.ProfitCenter = "MFPROFITCENTER";
					oBrfModel.setProperty("/lineItemBRFSet/ProfitCenter", "");
				} else if (id.indexOf("DB9921Prctr") > 0) {
					this.ProfitCenter = "DBPROFITCENTER";
					oBrfModel.setProperty("/lineItemBRFSet/ProfitCenterDebit", "");
				} else if (id.indexOf("GF9921Prctr") > 0) {
					this.ProfitCenter = "GFPROFITCENTER";
					oBrfModel.setProperty("/lineItemBRFSet/ProfitCenter", "");
				}
				/*End of change by developer Satabdi Das on 17-Sep-2020*/
				else if (id.indexOf("GFPrctr") > 0) {
					this.ProfitCenter = "GFPROFITCENTER";
					oBrfModel.setProperty("/lineItemBRFSet/ProfitCenter", ""); /*Added for defect 63445*/
				} else if (id.indexOf("DBPrctr") > 0) {
					this.ProfitCenter = "DBPROFITCENTER";
					oBrfModel.setProperty("/lineItemBRFSet/ProfitCenterDebit", ""); /*Added for defect 63445*/
				} else if (id.indexOf("WHTPrctr") > 0) {
					this.ProfitCenter = "WHTPROFITCENTER";
					oBrfModel.setProperty("/lineItemBRFSet/ProfitCenterDebit", ""); /*Added for defect 63445*/
				}
				var PrctrDetails = oBrfModel.getProperty("/PrctrSearchSet"); /*Added for defect 63412*/
				sap.ui.core.BusyIndicator.show(0);
				var aFilter = [];
				/*Start of defect 63412*/
				var oFilterSerach;
				if (PrctrDetails.Prctr) {
					oFilterSerach = new sap.ui.model.Filter("Prctr", sap.ui.model.FilterOperator.EQ, PrctrDetails.Prctr);
					aFilter.push(oFilterSerach);
				}
				if (PrctrDetails.Ltext) {
					oFilterSerach = new sap.ui.model.Filter("Ltext", sap.ui.model.FilterOperator.EQ, PrctrDetails.Ltext);
					aFilter.push(oFilterSerach);
				}
				/*End of defect 63412*/
				var mArrayOut = [];
				var sCompCode = oBrfModel.getProperty("/lineItemBRFSet/CompanyCode"); /*Added for new comp code by developer Satabdi Das on 15-Sep-2020*/
				var fnSuccess = jQuery.proxy(function (d) {
					sap.ui.core.BusyIndicator.hide(0);
					oBrfModel.setProperty("/PrctrSearchSet", []); /*Added for defect 63412*/
					for (var i = 0; i < d.results.length; i++) {
						var oProfitCenter = {};
						oProfitCenter.Prctr = d.results[i].Prctr;
						oProfitCenter.Ltext = d.results[i].Ltext;
						mArrayOut.push(oProfitCenter);
					}
					oBrfModel.setProperty("/BRF_PRCTRSet", mArrayOut);
					/*Below code mcommented by Satabdi Das on 11-Nov-2020*/
					// oBrfModel.refresh(true);
					var fragmentId = this.getView().createId("searchPrctr");
					if (!this._oSearchPrctr) {
						this._oSearchPrctr = sap.ui.xmlfragment(fragmentId, "KGO.kgoarrecharge_brf.view.ProfitCenterHelp", this);
						this.getView().addDependent(this._oSearchPrctr);
					}
					this._oSearchPrctr.open();
				}, this);
				var fnError = jQuery.proxy(function (d) {
					var r = JSON.parse(JSON.stringify(d));
					sap.ui.core.BusyIndicator.hide();
					MessageToast.show(r.message, {
						autoClose: true,
						width: "20rem"
					});
				}, this);

				aFilter.push(new Filter("Bukrs", FilterOperator.EQ, sCompCode)); /*Added for new comp code by developer Satabdi Das on 15-Sep-2020*/

				/*R&D---start*/
				var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_BRF_SRV/", {
					json: true
				});
				oModel1.read("/BRF_PRCTRSet", {
					filters: aFilter,
					/*Added for defecf 63412*/
					success: fnSuccess,
					error: fnError
				});
				/*R&D---end*/
			}
		},
		onPrctrSelect: function (oEvent) {
			var ProfitCenter = oEvent.getSource().getBindingContext("oBrfModel").getObject();
			var sCompCode = this.getView().getModel("oBrfModel").getProperty("/lineItemBRFSet/CompanyCode"); /*Added by Satabdi Das 06-Oct-2020*/
			if (this.ProfitCenter != undefined) {
				if (this.ProfitCenter === "MFPROFITCENTER") {
					this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/ProfitCenter", ProfitCenter.Prctr);
					/*Start of change by developer Satabdi Das on 06-Oct-2020*/
					if (sCompCode === "9921") {
						var sWhT = this.getView().getModel("oBrfModel").getProperty("/lineItemBRFSet/WhtCode");
						if (sWhT && sWhT !== "" && sWhT !== "N/A") {
							this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/ProfitCenterDebit", ProfitCenter.Prctr);
						} else {
							this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/ProfitCenterDebit", "");
						}
					}
					/*End of change by Satabdi Das on 06-Oct-2020*/
				} else if (this.ProfitCenter === "GFPROFITCENTER") {
					this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/ProfitCenter", ProfitCenter.Prctr);
				} else if (this.ProfitCenter === "DBPROFITCENTER") {
					this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/ProfitCenterDebit", ProfitCenter.Prctr);
				} else if (this.ProfitCenter === "WHTPROFITCENTER") {
					this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/ProfitCenterDebit", ProfitCenter.Prctr);
				}
			}
			if (this._oSearchPrctr) {
				this._oSearchPrctr.close();
			}
		},
		onClosePrctr: function () {
			if (this._oSearchPrctr) {
				this._oSearchPrctr.close();
			}
		},
		onDocTypeHelp: function (oEvent) {
			var bDisplay = this.getView().getModel("oBrfModel").getProperty("/Display");
			var sFragTxt = this.getView().getModel("oBrfModel").getProperty("/fraggmentText"); //added for Reissuance visible by Satabdi Das on  14-Dec-2020
			if (bDisplay === false || sFragTxt === "REISSUANCE") { //added for Reissuance visible by Satabdi Das on  14-Dec-2020
				var oBrfModel = this.getModel("oBrfModel");
				sap.ui.core.BusyIndicator.show(0);
				var aFilter = [];
				var mArrayOut = [];
				var sPath = "";
				sPath = "/BRF_DOCTYPESet ";
				var fnSuccess = jQuery.proxy(function (d) {
					sap.ui.core.BusyIndicator.hide(0);
					for (var i = 0; i < d.results.length; i++) {
						var oDocType = {};
						oDocType.Blart = d.results[i].Blart;
						oDocType.Ltext = d.results[i].Ltext;
						mArrayOut.push(oDocType);
					}
					oBrfModel.setProperty("/BRF_DOCTYPESet", mArrayOut);
					oBrfModel.refresh(true);
					var fragmentId = this.getView().createId("searchDocType");
					if (!this._oSearchDocType) {
						this._oSearchDocType = sap.ui.xmlfragment(fragmentId, "KGO.kgoarrecharge_brf.view.DocTypeHelp", this);
						this.getView().addDependent(this._oSearchDocType);
					}
					this._oSearchDocType.open();
				}, this);
				var fnError = jQuery.proxy(function (d) {
					var r = JSON.parse(JSON.stringify(d));
					sap.ui.core.BusyIndicator.hide();
					MessageToast.show(r.message, {
						autoClose: true,
						width: "20rem"
					});
				}, this);
				// var sParams = {};
				// var oObject = {};
				// oObject.Filter = aFilter;
				// oObject.Params = sParams;
				// oObject.successCallback = fnSuccess;
				// oObject.errorCallback = fnError;
				// oObject.sPath = sPath;
				// DataManagerBrf.getCoupaCreateHelp(oObject);
				/*R&D---start*/
				var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_BRF_SRV/", {
					json: true
				});
				oModel1.read("/BRF_DOCTYPESet", {
					success: fnSuccess,
					error: fnError
				});
				/*R&D---end*/
			}
		},
		onDocTypeSelect: function (oEvent) {
			var DocType = oEvent.getSource().getBindingContext("oBrfModel").getObject();
			if (DocType) {
				this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/DocumentType", DocType.Blart);
			}
			var fragId = this.getView().createId("searchDocType");
			var SearchId = sap.ui.core.Fragment.byId(fragId, "searchFldDocType");
			SearchId.setValue("");
			var aFilter = [];
			aFilter.push(new Filter("Blart", FilterOperator.Contains, ""));
			var frag = this.getView().createId("searchDocType");
			var table = sap.ui.core.Fragment.byId(frag, "DocTypeforBRF");
			var oBinding = table.getBinding("items");
			oBinding.filter(aFilter, "Application");
			if (this._oSearchDocType) {
				this._oSearchDocType.close();
			}
		},
		onDocSearch: function (oEvent) {
			var aFilter = [];
			var sQuery = oEvent.getSource().getValue();
			sQuery = sQuery.trim();
			if (sQuery && sQuery.length > 0) {
				aFilter.push(new Filter("Blart", FilterOperator.Contains, sQuery));
			}
			var fragmentId = this.getView().createId("searchDocType");
			var table = sap.ui.core.Fragment.byId(fragmentId, "DocTypeforBRF");
			var oBinding = table.getBinding("items");
			oBinding.filter(aFilter, "Application");
		},
		onCloseDocHelp: function () {
			var fragId = this.getView().createId("searchDocType");
			var SearchId = sap.ui.core.Fragment.byId(fragId, "searchFldDocType");
			SearchId.setValue("");
			var aFilter = [];
			aFilter.push(new Filter("Blart", FilterOperator.Contains, ""));
			var frag = this.getView().createId("searchDocType");
			var table = sap.ui.core.Fragment.byId(frag, "DocTypeforBRF");
			var oBinding = table.getBinding("items");
			oBinding.filter(aFilter, "Application");
			if (this._oSearchDocType) {
				this._oSearchDocType.close();
			}
		},
		onChangeofReqc: function (oEvent) {
			var oBrfModel = this.getView().getModel("oBrfModel");
			var LineData = oBrfModel.getProperty("/lineItemBRFSet").RequestingMf;
			oBrfModel.setProperty("/SelcKeySetBRF", LineData.RequestingMf);
			return true;
		},
		onTypingMf: function (oEvent) {
			var sId = oEvent.getSource().getId().split("--")[2]; /*Change added for INC01499658 on 22-APR-2021*/
			var oBrfModel = this.getView().getModel("oBrfModel");
			var checkString = oEvent.getParameter("value");
			if (checkString != "" && checkString !== "GB:UNITED KINGDOM") {
				if (/[^A-Za-z\d]/.test(checkString) || isNaN(checkString) === false || /\d/.test(checkString)) {
					if (sId === "RequestingMf") {
						this.getView().getModel("oBrfModel").setProperty("/SelcKeySetBRF", "");
						this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/Landx", "");
					} else if (sId === "locServ") {
						this.getView().getModel("oBrfModel").setProperty("/SelcKeyForLocServ", "");
					} else if (sId === "LocationService") {
						this.getView().getModel("oBrfModel").setProperty("/SelcKeyForLocServ", "");
					} else if (sId === "CRLocationService") {
						this.getView().getModel("oBrfModel").setProperty("/SelcKeyForLocServ", "");
					}
				}
			}
		},
		/*Start of change by developer Satabdi Das for defect 63361 on 09-Nov-2020*/
		onComment: function (oEvent) {
			var sVal = oEvent.getParameter("value");
			var oBrfModel = this.getView().getModel("oBrfModel");
			if (sVal !== "" && sVal !== " ") {
				oBrfModel.setProperty("/hasComment", true);
			} else {
				oBrfModel.setProperty("/hasComment", false);
			}
		},

		openCommentBox: function (oEvent) {
			var oCommentBox = this.getView().createId("commentBox");
			if (!this._oCommentBox) {
				this._oCommentBox = sap.ui.xmlfragment(oCommentBox, "KGO.kgoarrecharge_brf.view.workflowComments", this);
				this.getView().addDependent(this._oCommentBox);
			}
			this._oCommentBox.open();
		},
		onPressTRFOwner: function (oEvent) {
			var oBrfModel = this.getView().getModel("oBrfModel");
			/*End defcet 63445*/
			var fragmentIdBRFCntlName = this.getView().createId("searchBRFEmail");
			if (!this.ofragmentIdBRFCntlName) {
				this.ofragmentIdBRFCntlName = sap.ui.xmlfragment(fragmentIdBRFCntlName, "KGO.kgoarrecharge_brf.view.brfContrlName", this);
				this.getView().addDependent(this.ofragmentIdBRFCntlName);
			}
			if (oBrfModel.getProperty("/TRFOwnerFlag") === true) {
				oBrfModel.setProperty("/enabledTrfSave", false);
			}
			this.ofragmentIdBRFCntlName.open();
			//oBrfModel.setProperty("/oVisibleSet/contrlNameEdit", true);
			oBrfModel.setProperty("/TRFOwnerFlag", true);
			oBrfModel.setProperty("/ContrlTableBRFSet", []);
			oBrfModel.setProperty("/ContrlerBRfSet", {});
			oBrfModel.setProperty("/oVisibleSet/visiblecntlForBRF", false);
		},
		onTransferOwnerPressedSave: function () {
			var oBrfModel = this.getView().getModel("oBrfModel");
			var brfHederData = oBrfModel.getProperty("/brfHeaderSet");
			if (brfHederData.BrfType && brfHederData.ContrlName && brfHederData.ContrlEmail && brfHederData.CompanyCode) {
				sap.ui.core.BusyIndicator.show(0);
				var action = "SUBMIT";
				var oPayLoad = {
					CompanyCode: brfHederData.CompanyCode,
					BrfType: brfHederData.BrfType,
					BrfCreatedBy: brfHederData.BrfCreatedBy,
					BrfCreatorName: brfHederData.BrfCreatorName,
					/* Added by Satabdi Das on 15-Jan-2021 for defect 63786*/
					BrfNo: brfHederData.BrfNo,
					BrfStatus: brfHederData.BrfStatus,
					Action: action,
					CntrlApprName: brfHederData.CntrlApprName,
					VatApprName: brfHederData.VatApprName,
					ArApprName: brfHederData.ArApprName,
					BrfDesc: brfHederData.BrfDesc,
					BrfCreationDate: brfHederData.BrfCreationDate,
					OfcBillNo: brfHederData.OfcBillNo,
					OfcInvoicNo: brfHederData.OfcInvoicNo,
					InvoicDate: brfHederData.InvoicDate,
					ContrlName: brfHederData.ContrlName,
					ContrlEmail: brfHederData.ContrlEmail,
					Gjahr: brfHederData.Gjahr,
					RrfNo: brfHederData.RrfNo,
					InvoiceAmount: brfHederData.InvoiceAmount,
					SchDate: brfHederData.SchDate,
					/*GrossAmtLocal: brfHederData.GrossAmtLocal,
					CurrencyLocal: brfHederData.CurrencyLocal,*/
					NetAmount: brfHederData.NetAmount,
					DocCurrency: brfHederData.DocCurrency,
					SapDocYear: brfHederData.SapDocYear,
					SapDocNum: brfHederData.SapDocNum,
					BukrsUrn: brfHederData.BukrsUrn,
					Manual: brfHederData.Manual,
					Urn: brfHederData.Urn,
					/*Added for new Comp Code 9921 by Satabdi Das*/
					BRFItemSet: [],
					BRF_AnswerSet: []

				};
				var that = this;
				var fnSuccess = jQuery.proxy(function (d) {
					sap.ui.core.BusyIndicator.hide(0);
					var bIsOpenTask = UIGlobal.getFromOpenTask();
					MessageBox.show(
						d.Message, {
							icon: MessageBox.Icon.SUCCESS,
							title: "Success",
							actions: [MessageBox.Action.OK],
							onClose: function (oAction) {
								if (oAction === "OK") {
									sap.ui.core.BusyIndicator.show(0);
									if (bIsOpenTask === true) {
										sap.ui.core.BusyIndicator.hide(0);
										UIGlobal.setFromOpenTask(false);
										var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
										oCrossAppNavigator.toExternal({
											target: {
												semanticObject: "#"
											}
										});
									} else {
										var oRouter = UIComponent.getRouterFor(that);
										oRouter.navTo("TargetBrfHomeView");

									}
								}

							}
						}
					);
					// if (d.Message) {
					// 	var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
					// 	MessageBox.success(
					// 		d.Message, {
					// 			styleClass: bCompact ? "sapUiSizeCompact" : ""
					// 		}
					// 	);
					// } 

				}, this);
				var fnError = jQuery.proxy(function (d) {
					sap.ui.core.BusyIndicator.hide(0);
					var r = JSON.parse(JSON.stringify(d));
					sap.ui.core.BusyIndicator.hide();
					MessageToast.show(r.message, {
						autoClose: true,
						width: "20rem"
					});
				}, this);
				var objectOne = {};
				var arr = [];
				var TableData = [];
				var arrAnsware = [];
				var _answre = [];
				objectOne.successCallback = fnSuccess;
				objectOne.errorCallback = fnError;
				arr = this.getView().getModel("oBrfModel").getProperty("/brfTableSet");
				//questionnaire changes brf prashant kumar 16.03.2021
				arrAnsware = this.getModel("oBrfModel").getProperty("/questionSetSubmit");
				for (var t = 0; t < arrAnsware.length; t++) {
					var objAns = {};
					objAns.GlobalCc = brfHederData.GlobalCc;
					objAns.MemberFirm = arrAnsware[t].MemberFirm;
					objAns.Question = arrAnsware[t].Question;
					objAns.RequestingMf = arrAnsware[t].RequestingMf;
					objAns.Answer = arrAnsware[t].Answer;
					objAns.InternalExternal = arrAnsware[t].InternalExternal;
					objAns.AnswerDesc = arrAnsware[t].AnswerDesc;
					objAns.LineType = arrAnsware[t].LineType;
					objAns.TransactionType = arrAnsware[t].TransactionType;
					objAns.ProcessGrp = arrAnsware[t].ProcessGrp;
					objAns.CompanyCode = brfHederData.CompanyCode;
					objAns.BrfNo = brfHederData.BrfNo;
					_answre.push(objAns);

				}
				oPayLoad.BRF_AnswerSet = _answre;
				if (arr) {
					for (var i in arr) {

						var fields = Object.keys(arr[i]);
						var obj = {};
						for (var j = 0; j < fields.length; j++) {
							if (fields[j] !== "__metadata") {
								obj[fields[j]] = arr[i][fields[j]];
							}
						}
						TableData.push(obj);
					}
					// oPayLoad.BRFItemSet = arr;
					oPayLoad.BRFItemSet = TableData;
					DataManagerBrf.SubmitBRFDataONSendWF(oPayLoad, objectOne);
				}
			}
		},
		submitBRFBeforeSendWorkFlow: function () {

			//var bDisplay = this.getView().getModel("oBrfModel").getProperty("/Display");
			var bDisplay = false; //added for submit for credit note
			var brfHederData = this.getView().getModel("oBrfModel").getProperty("/brfHeaderSet");
			if (bDisplay === false) {
				if (brfHederData.BrfType && brfHederData.ContrlName && brfHederData.ContrlEmail) {
					var action = "SUBMIT";

					sap.ui.core.BusyIndicator.show(0);
					/*Validation start for header amount */
					if (brfHederData.InvoiceAmount === "") {
						brfHederData.InvoiceAmount = "0.00";
					}
					if (brfHederData.NetAmount === "") {
						brfHederData.NetAmount = "0.00";
					}
					/*Validation end for header amount */

					var oPayLoad = {
						CompanyCode: brfHederData.CompanyCode,
						BrfType: brfHederData.BrfType,
						BrfCreatedBy: brfHederData.BrfCreatedBy,
						BrfCreatorName: brfHederData.BrfCreatorName,
						/* Added by Satabdi Das on 15-Jan-2021 for defect 63786*/
						BrfNo: brfHederData.BrfNo,
						BrfStatus: brfHederData.BrfStatus,
						Action: action,
						CntrlApprName: brfHederData.CntrlApprName,
						VatApprName: brfHederData.VatApprName,
						ArApprName: brfHederData.ArApprName,
						BrfDesc: brfHederData.BrfDesc,
						BrfCreationDate: brfHederData.BrfCreationDate,
						OfcBillNo: brfHederData.OfcBillNo,
						OfcInvoicNo: brfHederData.OfcInvoicNo,
						InvoicDate: brfHederData.InvoicDate,
						ContrlName: brfHederData.ContrlName,
						ContrlEmail: brfHederData.ContrlEmail,
						Gjahr: brfHederData.Gjahr,
						RrfNo: brfHederData.RrfNo,
						InvoiceAmount: brfHederData.InvoiceAmount,
						SchDate: brfHederData.SchDate,
						/*GrossAmtLocal: brfHederData.GrossAmtLocal,
						CurrencyLocal: brfHederData.CurrencyLocal,*/
						NetAmount: brfHederData.NetAmount,
						DocCurrency: brfHederData.DocCurrency,
						SapDocYear: brfHederData.SapDocYear,
						SapDocNum: brfHederData.SapDocNum,
						BukrsUrn: brfHederData.BukrsUrn,
						Manual: brfHederData.Manual,
						Urn: brfHederData.Urn,

						/*Added for new Comp Code 9921 by Satabdi Das*/
						BRFItemSet: [],
						BRF_AnswerSet: []

					};
					var that = this;
					var fnSuccess = jQuery.proxy(function (d) {
						sap.ui.core.BusyIndicator.hide(0);
						if (d.Flag) {
							var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
							MessageBox.error(
								d.Message, {
									styleClass: bCompact ? "sapUiSizeCompact" : ""
								}
							);
						} else {
							// MessageBox.show(
							// 	d.Message, {
							// 		icon: MessageBox.Icon.SUCCESS,
							// 		title: "Success",
							// 		actions: [MessageBox.Action.OK],
							// 		onClose: function (oAction) {
							// 			if (oAction === "OK") {
							// 				sap.ui.core.BusyIndicator.show(0);
							// 				that.handlePressEditBRF();
							// 			}

							// 			// var oRouter = UIComponent.getRouterFor(that);
							// 			// oRouter.navTo("TargetBrfHomeView");

							// 		}
							// 	}
							// );
							/*Start of chnage for defect 63096 on 31-Jan-2020*/
							var oTable = that.getView().byId("tableid");
							oTable.removeSelections(true);
							/*End of chnage for defect 63096 on 31-Jan-2020*/
						}
					}, this);
					var fnError = jQuery.proxy(function (d) {
						sap.ui.core.BusyIndicator.hide(0);
						var r = JSON.parse(JSON.stringify(d));
						sap.ui.core.BusyIndicator.hide();
						MessageToast.show(r.message, {
							autoClose: true,
							width: "20rem"
						});
					}, this);
					var objectOne = {};
					var arr = [];
					var TableData = [];
					var arrAnsware = [];
					var _answre = [];
					var LineNO;
					objectOne.successCallback = fnSuccess;
					objectOne.errorCallback = fnError;
					arr = this.getView().getModel("oBrfModel").getProperty("/brfTableSet");
					//questionnaire changes brf prashant kumar 16.03.2021
					arrAnsware = this.getModel("oBrfModel").getProperty("/questionSetSubmit");
					for (var t = 0; t < arrAnsware.length; t++) {
						var objAns = {};
						objAns.GlobalCc = brfHederData.GlobalCc;
						objAns.MemberFirm = arrAnsware[t].MemberFirm;
						objAns.Question = arrAnsware[t].Question;
						objAns.RequestingMf = arrAnsware[t].RequestingMf;
						objAns.Answer = arrAnsware[t].Answer;
						objAns.InternalExternal = arrAnsware[t].InternalExternal;
						objAns.AnswerDesc = arrAnsware[t].AnswerDesc;
						objAns.LineType = arrAnsware[t].LineType;
						objAns.TransactionType = arrAnsware[t].TransactionType;
						objAns.ProcessGrp = arrAnsware[t].ProcessGrp;
						objAns.CompanyCode = brfHederData.CompanyCode;
						objAns.BrfNo = brfHederData.BrfNo;
						_answre.push(objAns);

					}
					oPayLoad.BRF_AnswerSet = _answre;

					//validation for LineItem  start
					var msg = this.getView().getModel("i18n").getProperty("NoLineItemAlert");
					var sMsg2 = this.getView().getModel("i18n").getProperty("SaveMandtAlert"); /*Added by Satabdi Das on 17-Sep-2020*/
					if (!arr) {
						sap.ui.core.BusyIndicator.hide(0);
						var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
						MessageBox.alert(
							msg, {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}

						);
						return;
					}
					// else if (arr.length === 0) {
					// 	sap.ui.core.BusyIndicator.hide();
					// 	var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
					// 	MessageBox.alert(
					// 		msg, {
					// 			styleClass: bCompact ? "sapUiSizeCompact" : ""
					// 		}
					// 	);
					// 	return;
					// }  
					else if (brfHederData.BrfNo) {
						if (arr.length > 0) {
							for (var i = 0; i < arr.length; i++) {
								/*Start of defect 63367*/
								if (arr[i].ServicePeriodStart === "00000000") {
									arr[i].ServicePeriodStart = "";
								}
								if (arr[i].ServicePeriodEnd === "00000000") {
									arr[i].ServicePeriodEnd = "";
								}
								if (arr[i].ServicePeriodStartCredit === "00000000") {
									arr[i].ServicePeriodStartCredit = "";
								}
								if (arr[i].ServicePeriodEndCredit === "00000000") {
									arr[i].ServicePeriodEndCredit = "";
								}
								/*End of defect 63367*/

								if ((arr[i].RequestingMf != "N/A") && (arr[i].GlobalCc === "N/A") && (arr[i].LineStatus)) {
									if (!arr[i].RechargeAmountDebit || !arr[i].RechargeAmountCredit || !arr[i].CreditGl || (!arr[i].DetailsDescriptionOfServic &&
											!arr[i].LongText) ||
										!arr[i].ServicePeriodStart || !arr[i].ServicePeriodEnd ||
										arr[i].ServicePeriodStart === "" || arr[i].ServicePeriodEnd === "" ||
										!arr[i].LocationOfTheServicesReq || arr[i].LocationOfTheServicesReq === "" || !arr[i].NatureOfService || arr[i].NatureOfService ===
										"" || !arr[i].VatSapCode || arr[i].VatSapCode === "" || !arr[i].AdlDescription ||
										arr[i].AdlDescription === "" || !arr[i].AttenBrf || arr[i].AttenBrf ===
										"" || !arr[i].AttenBrfEmail || arr[i].AttenBrfEmail === "") { /*Added for defect 63391 on 21-Jan-2021*/
										LineNO = i + 1;
										sap.ui.core.BusyIndicator.hide();
										MessageBox.alert(sMsg2 + LineNO);
										return;
									}

									/*Start of change for new doc type field by developer Satabdi Das on 15-Sep-2020*/
									if (arr[i].CompanyCode === "9921") {
										if (!arr[i].DocumentType || arr[i].DocumentType === "") {
											LineNO = i + 1;
											sap.ui.core.BusyIndicator.hide();
											MessageBox.alert(sMsg2 + LineNO);
											return;
										}
									}
									/*End of change for new doc type field by developer Satabdi Das on 15-Sep-2020*/

								} else if ((arr[i].RequestingMf === "N/A") && (arr[i].GlobalCc != "N/A") && (arr[i].LineStatus)) {
									if (!arr[i].RechargeAmountDebit || !arr[i].RechargeAmountCredit || !arr[i].CreditGl || !arr[i].DebitGl || !arr[i].ServicePeriodStart ||
										!arr[i].ServicePeriodEnd || !arr[i].ServicePeriodStartCredit || !arr[i].ServicePeriodEndCredit ||
										arr[i].ServicePeriodStart === "" || arr[i].ServicePeriodEnd === "" || arr[i].ServicePeriodStartCredit === "" || arr[i].ServicePeriodEndCredit ===
										"" || !arr[i].LocationOfTheServicesReq || arr[i].LocationOfTheServicesReq === "" || !arr[i].AdlDescription ||
										arr[i].AdlDescription === "") { /*Added for defect 63367*/ /*Added for defect 63737 on 17-Nov-2020*/
										LineNO = i + 1;
										sap.ui.core.BusyIndicator.hide();
										MessageBox.alert(sMsg2 + LineNO);
										return;
									}
								}

							}
						}
					}
					if (arr) {
						for (var i in arr) {
							if (arr[i].RechargeAmountDebit === "") {
								arr[i].RechargeAmountDebit = "0.00";
							}
							if (arr[i].RechargeAmountCredit === "") {
								arr[i].RechargeAmountCredit = "0.00";
							}
							/*Start of change for INC01533653 by developer Satabdi Das on 28-May-2021*/
							if (arr[i].LineItemTotal === "") {
								arr[i].LineItemTotal = "0.00";
							}
							/*End of change for INC01533653 by developer Satabdi Das on 28-May-2021*/
							if (arr[i].RequestingMf === "N/A" && arr[i].LocationOfTheServicesReq === "") {
								arr[i].LocationOfTheServicesReq = "NMT";
							}
							var fields = Object.keys(arr[i]);
							var obj = {};
							for (var j = 0; j < fields.length; j++) {
								if (fields[j] !== "__metadata") {
									obj[fields[j]] = arr[i][fields[j]];
								}
							}
							TableData.push(obj);
						}
						// oPayLoad.BRFItemSet = arr;
						oPayLoad.BRFItemSet = TableData;
						DataManagerBrf.SubmitBRFDataONSendWF(oPayLoad, objectOne);
					}
				}
			}

		},

		onOkPress: function (oEvent) {

			var oBrfModel = this.getView().getModel("oBrfModel");
			var brfHederData = oBrfModel.getProperty("/brfHeaderSet");
			var oLineTbl = this.getView().byId("tableid");
			var bIsOpenTask = UIGlobal.getFromOpenTask();
			var sId = UIGlobal.getBtnId();
			var questionnaireData = oBrfModel.getProperty("/questionSetSubmit");
			var that = this;
			var arr = [];
			var action;
			var sComments = oBrfModel.getProperty("/lineItemBRFSet/Comments");
			this._oCommentBox.close();
			sap.ui.core.BusyIndicator.show(0);

			// Call Submit Data Before send the wotkflow

			if (sId === "supplier" || sId === "supplierLnk") {
				action = "SUPPLIER";
				oBrfModel.setProperty("/hasComment", false);
			} else if (sId === "controller" || sId === "controllerLnk") {
				action = "CONTROLLER";
				oBrfModel.setProperty("/hasComment", false);
			} else if (sId === "vatteam" || sId === "vatteamLnk") {
				action = "VAT";
				oBrfModel.setProperty("/hasComment", false);
			} else if (sId === "Arteam" || sId === "ArteamLnk") {
				action = "AR";
				oBrfModel.setProperty("/hasComment", false);
			} else if (sId === "Approve" || sId === "ApproveLnk") {
				action = "APPROVE";
				oBrfModel.setProperty("/hasComment", false);
			} else if (sId === "lttTeam" || sId === "lttteamIcon") {
				action = "LTT";
				oBrfModel.setProperty("/hasComment", false);
			} else if (sId === "lttTeam2" || sId === "lttteamIcon2") {
				action = "LTT2";
				oBrfModel.setProperty("/hasComment", false);
			} else if (sId === "lttTeam3" || sId === "lttteamIcon3") {
				action = "LTT3";
				oBrfModel.setProperty("/hasComment", false);
			}
			var oPayLoad = {
				CompanyCode: brfHederData.CompanyCode,
				BrfType: brfHederData.BrfType,
				BrfCreatedBy: brfHederData.BrfCreatedBy,
				BrfNo: brfHederData.BrfNo,
				Gjahr: brfHederData.Gjahr,

				Action: action,

				ContrlName: brfHederData.ContrlName,
				ContrlEmail: brfHederData.ContrlEmail,
				RrfNo: brfHederData.RrfNo,

				InvoiceAmount: brfHederData.InvoiceAmount,

				NetAmount: brfHederData.NetAmount,
				DocCurrency: brfHederData.DocCurrency,
				SapDocYear: brfHederData.SapDocYear,
				SapDocNum: brfHederData.SapDocNum,
				BukrsUrn: brfHederData.BukrsUrn,
				Urn: brfHederData.Urn,
				BRF_AnswerSet: [],
				BRFItemSet: [],
			};
			var TableData = UIGlobal.getTableDataWorkflow();
			UIGlobal.setTableDataWorkflow([]);
			var that = this;
			var oAnswerShow = [];
			for (var i = 0; i < TableData.length; i++) {
				TableData[i].Comments = sComments;

				//sending question answer changes
				for (var t = 0; t < questionnaireData.length; t++) {
					if ((TableData[i].RequestingMf === questionnaireData[t].RequestingMf) && (TableData[i].MemberFirm === questionnaireData[t].MemberFirm) &&
						(TableData[i].ProcessGrp === questionnaireData[t].ProcessGrp) && (TableData[i].LineType === questionnaireData[t].LineType) &&
						(TableData[i].TransactionType === questionnaireData[t].TransactionType)) {
						var object = {};
						object.LineNo = questionnaireData[t].LineNo;
						object.CompanyCode = questionnaireData[t].CompanyCode;
						object.Mandatory = questionnaireData[t].Mandatory;
						object.MemberFirm = questionnaireData[t].MemberFirm;
						object.Question = questionnaireData[t].Question;
						object.AnswerDesc = questionnaireData[t].AnswerDesc;
						object.Answer = questionnaireData[t].Answer;
						object.InternalExternal = questionnaireData[t].InternalExternal;
						object.LineType = questionnaireData[t].LineType;
						object.TransactionType = questionnaireData[t].TransactionType;
						object.RequestingMf = questionnaireData[t].RequestingMf;
						object.ProcessGrp = questionnaireData[t].ProcessGrp;
						object.BrfNo = brfHederData.BrfNo;
						oAnswerShow.push(object);
					}
				}
			}
			oPayLoad.BRF_AnswerSet = oAnswerShow;
			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				var oLineTbl = that.getView().byId("tableid");

				if (d.Flag) {
					var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
					MessageBox.error(
						d.Message, {
							styleClass: bCompact ? "sapUiSizeCompact" : ""
						}
					);

					for (var i = 0; i < oLineTbl.getItems().length; i++) {

						if (oLineTbl.getBindingInfo("items").binding.oList[i].CnFlag === "X") {

							oLineTbl.getAggregation("items")[i].getCells()[9].setProperty("enabled", true);
							//oTblBRF.getAggregation("items")[i].getCells()[9].setProperty("visible", false);

						} else {
							oLineTbl.getAggregation("items")[i].getCells()[9].setProperty("visible", false);
						}

						if (oLineTbl.getBindingInfo("items").binding.oList[i].RiFlag !== "X") {
							oLineTbl.getAggregation("items")[i].getCells()[10].setProperty("enabled", false);
							oLineTbl.getAggregation("items")[i].getCells()[10].setProperty("visible", false);
						} else if (oLineTbl.getBindingInfo("items").binding.oList[i].RiFlag === "X") {
							oLineTbl.getAggregation("items")[i].getCells()[10].setProperty("enabled", true);
							oLineTbl.getAggregation("items")[i].getCells()[10].setProperty("visible", true);
						}
						/*End of change by developer Satabdi Das on 06-Jan-2021*/
					}

					oLineTbl.removeSelections(true);
				}
				/*Start of change by Satabdi Das for duplicate check on 27-Apr-2021*/
				else if (d.BRFItemSet.results.length > 0 && d.BRF_DuplicateSet.results.length > 0) {
					if (d.Message) {
						oBrfModel.setProperty("/BRF_SuccessMsg", d.Message);
					}

					oBrfModel.setProperty("/BRF_DuplicateSet", d.BRF_DuplicateSet.results);
					oBrfModel.refresh(true);
					var fragmentId = this.getView().createId("duplicate");
					if (!this._oDuplicateLineCheck) {
						this._oDuplicateLineCheck = sap.ui.xmlfragment(fragmentId, "KGO.kgoarrecharge_brf.view.duplicateLineCheck", this);
						this.getView().addDependent(this._oDuplicateLineCheck);
					}

					//changes for duplicate check
					var oDuplicateTbl = this.byId(sap.ui.core.Fragment.createId(fragmentId, "duplicateLine"));

					oDuplicateTbl.addEventDelegate({
						onAfterRendering: function () {
							for (var duMess = 0; duMess < oDuplicateTbl.getItems().length; duMess++) {
								var Message = oDuplicateTbl.getBindingInfo("items").binding.oList[duMess].Message;
								if (!Message) {
									var oSelCheckBox = oDuplicateTbl.getAggregation("items")[duMess];
									if (oSelCheckBox) {
										oSelCheckBox.getMultiSelectControl().setVisible(false);
									}
								}
							}

						}
					}, this);

					// for (var duMess = 0; duMess < oDuplicateTbl.getItems().length; duMess++) {
					// 	var Message = oDuplicateTbl.getBindingInfo("items").binding.oList[duMess].Message;
					// 	if (!Message) {
					// var x = oDuplicateTbl.getAggregation("items")[duMess];
					// x.getMultiSelectControl().setVisible(false);

					// 	}

					// }

					this._oDuplicateLineCheck.open();

				}
				/*End of chnage by Satabdi Das for duplicate check on 27-Apr-2021*/
				else {

					MessageBox.show(
						d.Message, {
							icon: MessageBox.Icon.SUCCESS,
							title: "Success",
							actions: [MessageBox.Action.OK],
							onClose: function (oAction) {
								if (bIsOpenTask === false) {
									var oRouter = UIComponent.getRouterFor(that);
									oRouter.navTo("TargetBrfHomeView");
								} else if (bIsOpenTask === true) {
									UIGlobal.setFromOpenTask(false);
									var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
									oCrossAppNavigator.toExternal({
										target: {
											semanticObject: "#"
										}
									});

								}
							}
						}
					);
					this.getModel("oBrfModel").setProperty("/lineItemBRFSet/RequestingMf", "");
					oLineTbl.removeSelections(true);

				}
			}, this);
			var fnError = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				var r = JSON.parse(JSON.stringify(d));
				oLineTbl.removeSelections(true);
				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"
				});
			}, this);
			var objectOne = {};

			objectOne.successCallback = fnSuccess;
			objectOne.errorCallback = fnError;
			var aArray = []; /*Added on 27-Apr-2021 dor Duplicate check*/
			oPayLoad.BRF_DuplicateSet = aArray; /*Added on 27-Apr-2021 dor Duplicate check*/
			oPayLoad.BRFItemSet = TableData;
			DataManagerBrf.CreateBRFData(oPayLoad, objectOne);
			UIGlobal.setBtnId("");

		},
		onCommentBoxCancel: function (oEvent) {
			var oBrfModel = this.getView().getModel("oBrfModel");
			oBrfModel.setProperty("/lineItemBRFSet/Comments", "");
			oBrfModel.setProperty("/hasComment", false);
			this._oCommentBox.close();
		},

		onPresSendTo: function (oEvent) {
			var bDisplay = this.getView().getModel("oBrfModel").getProperty("/Display");
			if (bDisplay === false) {
				var sId = oEvent.getSource().getId().split("--")[1]; /*Change added for INC01499658 on 22-APR-2021*/
				UIGlobal.setBtnId(sId);
				var oBrfModel = this.getView().getModel("oBrfModel");
				var brfHederData = oBrfModel.getProperty("/brfHeaderSet");
				var oLineTbl = this.getView().byId("tableid");
				var sAcontext = oLineTbl.getSelectedContextPaths();
				var TableData = [];
				var sHdrTxt;
				var sMsgCommentBox = this.getView().getModel("i18n").getProperty("MsgCommentBox");
				var sBtnTxt;
				if (oEvent.getSource().getBindingInfo("text")) {
					sBtnTxt = oEvent.getSource().getText();
				}
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				switch (sId) {
				case "supplierLnk":
					sBtnTxt = this.getView().getModel("i18n").getProperty("sendtorechargemngr");
					break;
				case "controllerLnk":
					sBtnTxt = this.getView().getModel("i18n").getProperty("sendtocontroller");
					break;
				case "vatteamLnk":
					sBtnTxt = this.getView().getModel("i18n").getProperty("sendtovatteam");
					break;
				case "ArteamLnk":
					sBtnTxt = this.getView().getModel("i18n").getProperty("sendtoArteam");
					break;
				case "lttteamIcon":
					sBtnTxt = this.getView().getModel("i18n").getProperty("sendTolttTeam1");
					break;
				case "lttteamIcon2":
					sBtnTxt = this.getView().getModel("i18n").getProperty("sendTolttTeam2");
					break;
				case "lttteamIcon3":
					sBtnTxt = this.getView().getModel("i18n").getProperty("sendTolttTeam3");
					break;
				case "ApproveLnk":
					sBtnTxt = this.getView().getModel("i18n").getProperty("Approve");
					break;
				}
				// var bIsOpenTask = UIGlobal.getFromOpenTask();
				if (brfHederData.BrfType) {
					if (sAcontext.length !== 0) {
						for (var i = 0; i < sAcontext.length; i++) {
							var objRow = oBrfModel.getProperty(sAcontext[i]);
							TableData.push(objRow);
						}
						UIGlobal.setTableDataWorkflow(TableData);
						sHdrTxt = sMsgCommentBox + " - " + sBtnTxt;
						oBrfModel.setProperty("/setHdrMsg", sHdrTxt);
						oBrfModel.setProperty("/lineItemBRFSet/Comments", "");
						//calling submit for data update
						this.submitBRFBeforeSendWorkFlow();
						this.openCommentBox();

						// var that = this;

					} else if (sAcontext.length === 0 || !sAcontext) {
						sap.ui.core.BusyIndicator.hide(0);
						oLineTbl.removeSelections(true);
						MessageBox.error(
							this.getView().getModel("i18n").getProperty("RowWarning"), {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}
						);
						return;
					}
				} else {
					sap.ui.core.BusyIndicator.hide(0);
					oLineTbl.removeSelections(true);
					var BRFWarning = this.getView().getModel("i18n").getProperty("BRFWarning");
					MessageBox.information(BRFWarning);
				}
			}
		},

		/*Start of change for duplicate check */
		checkBoxVisible: function (message) {
			if (message && message !== "") {
				return true;
			} else {
				return false;
			}
		},

		onSelectDuplicateItem: function (oEvent) {
			var oBrfModel = this.getView().getModel("oBrfModel");
			this.oSelectedDuplicateItem = [];
			this.SelectedPath = oEvent.getSource()._aSelectedPaths;
			// oSelectedDuplicateItem.push(oBrfModel.getProperty("/BRF_DuplicateSet")[SelectedPath]);

			for (var dupLicateItem = 0; dupLicateItem < this.SelectedPath.length; dupLicateItem++) {
				var selectedItem = oEvent.getSource()._aSelectedPaths[dupLicateItem].split("/")[2];
				this.oSelectedDuplicateItem.push(oBrfModel.getProperty("/BRF_DuplicateSet")[selectedItem]);

			}

		},

		onPresssIgnore: function (oEvent) {
			var oBrfModel = this.getView().getModel("oBrfModel");
			var that = this;
			var fragmentId = this.getView().createId("duplicate");
			var oDuplicateTbl = this.byId(sap.ui.core.Fragment.createId(fragmentId, "duplicateLine"));
			var sAcontext = oDuplicateTbl.getSelectedContextPaths();
			var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
			var bIsOpenTask = UIGlobal.getFromOpenTask(); /*Added for defect 63966*/
			if (this.SelectedPath.length === 0 || !this.SelectedPath) {
				// sap.ui.core.BusyIndicator.hide(0);
				MessageBox.error(
					this.getView().getModel("i18n").getProperty("RowWarning"), {
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					}
				);
				return;
			} else {
				var brfHederData = oBrfModel.getProperty("/brfHeaderSet");
				var TableData = [];
				var oAnswerShow = [];
				var LineItemData = oBrfModel.getProperty("/brfTableSet");
				var questionnaireData = oBrfModel.getProperty("/questionSetSubmit");
				for (var i = 0; i < LineItemData.length; i++) {
					var odupItem = 0;
					while (odupItem < this.oSelectedDuplicateItem.length) {
						if (LineItemData[i].RequestingMf === this.oSelectedDuplicateItem[odupItem].RequestingMf && LineItemData[i].MemberFirm === this
							.oSelectedDuplicateItem[
								odupItem].MemberFirm && LineItemData[i].ProcessGrp === this.oSelectedDuplicateItem[odupItem].ProcessGrp) {
							LineItemData[i].DuplicateFlag = "X";
							TableData.push(LineItemData[i]);
						}
						odupItem++;
					}
				}
				var action = "APPROVE";
				var oLineTbl = this.getView().byId("tableid");
				var oPayLoad = {
					CompanyCode: brfHederData.CompanyCode,
					BrfType: brfHederData.BrfType,
					BrfCreatedBy: brfHederData.BrfCreatedBy,
					BrfNo: brfHederData.BrfNo,
					Gjahr: brfHederData.Gjahr,

					Action: action,

					ContrlName: brfHederData.ContrlName,
					ContrlEmail: brfHederData.ContrlEmail,
					RrfNo: brfHederData.RrfNo,

					InvoiceAmount: brfHederData.InvoiceAmount,

					NetAmount: brfHederData.NetAmount,
					DocCurrency: brfHederData.DocCurrency,
					SapDocYear: brfHederData.SapDocYear,
					SapDocNum: brfHederData.SapDocNum,
					BukrsUrn: brfHederData.BukrsUrn,
					Urn: brfHederData.Urn,
					BRF_AnswerSet: [],
					BRFItemSet: TableData,
					BRF_DuplicateSet: this.oSelectedDuplicateItem
				};

				for (var i = 0; i < TableData.length; i++) {
					//sending question answer changes
					for (var t = 0; t < questionnaireData.length; t++) {
						if ((TableData[i].RequestingMf === questionnaireData[t].RequestingMf) && (TableData[i].MemberFirm === questionnaireData[t].MemberFirm) &&
							(TableData[i].ProcessGrp === questionnaireData[t].ProcessGrp) && (TableData[i].LineType === questionnaireData[t].LineType) &&
							(TableData[i].TransactionType === questionnaireData[t].TransactionType)) {
							var object = {};
							object.LineNo = questionnaireData[t].LineNo;
							object.CompanyCode = questionnaireData[t].CompanyCode;
							object.Mandatory = questionnaireData[t].Mandatory;
							object.MemberFirm = questionnaireData[t].MemberFirm;
							object.Question = questionnaireData[t].Question;
							object.AnswerDesc = questionnaireData[t].AnswerDesc;
							object.Answer = questionnaireData[t].Answer;
							object.InternalExternal = questionnaireData[t].InternalExternal;
							object.LineType = questionnaireData[t].LineType;
							object.TransactionType = questionnaireData[t].TransactionType;
							object.RequestingMf = questionnaireData[t].RequestingMf;
							object.ProcessGrp = questionnaireData[t].ProcessGrp;
							object.BrfNo = brfHederData.BrfNo;
							oAnswerShow.push(object);
						}
					}
				}
				oPayLoad.BRF_AnswerSet = oAnswerShow;
				var fnSuccess = jQuery.proxy(function (d) {
					sap.ui.core.BusyIndicator.hide(0);

					if (d.Flag) {
						var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
						MessageBox.error(
							d.Message, {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}
						);

						oDuplicateTbl.removeSelections(true);

					} else {
						MessageBox.show(
							d.Message, {
								icon: MessageBox.Icon.SUCCESS,
								title: "Success",
								actions: [MessageBox.Action.OK],
								onClose: function (oAction) {
									/*Start of change for defect 63966 on 10-May-2021 by Satabdi Das*/
									if (bIsOpenTask === false) {
										var oRouter = UIComponent.getRouterFor(that);
										oRouter.navTo("TargetBrfHomeView");
									} else if (bIsOpenTask === true) {
										UIGlobal.setFromOpenTask(false);
										var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
										oCrossAppNavigator.toExternal({
											target: {
												semanticObject: "#"
											}
										});
									}
									/*End of change for defect 63966 on 10-May-2021 by Satabdi Das*/
								}
							}
						);
						oDuplicateTbl.removeSelections(true);
					}

				}, this);
				var fnError = jQuery.proxy(function (d) {
					sap.ui.core.BusyIndicator.hide(0);
					var r = JSON.parse(JSON.stringify(d));
					oLineTbl.removeSelections(true);
					MessageToast.show(r.message, {
						autoClose: true,
						width: "20rem"
					});
				}, this);
				var objectOne = {};

				objectOne.successCallback = fnSuccess;
				objectOne.errorCallback = fnError;
				DataManagerBrf.CreateBRFData(oPayLoad, objectOne);

			}
		},
		onPressDuplicateCancle: function (oEvent) {
			var oLineTbl = this.getView().byId("tableid");
			var bIsOpenTask = UIGlobal.getFromOpenTask();
			this._oDuplicateLineCheck.close();
			if (bIsOpenTask === false) {
				var oRouter = UIComponent.getRouterFor(this);
				oRouter.navTo("TargetBrfHomeView");
			} else if (bIsOpenTask === true) {
				UIGlobal.setFromOpenTask(false);
				var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
				oCrossAppNavigator.toExternal({
					target: {
						semanticObject: "#"
					}
				});
			}
			oLineTbl.removeSelections(true);
		},
		/*End of change for duplicate check*/
		/*onPresSendTo: function (oEvent) {
			var bDisplay = this.getView().getModel("oBrfModel").getProperty("/Display");
			if (bDisplay === false) {
				var sId = oEvent.getSource().getId().split("--")[2];
				var oBrfModel = this.getView().getModel("oBrfModel");
				var brfHederData = oBrfModel.getProperty("/brfHeaderSet");
				var oLineTbl = this.getView().byId("tableid");
				var sAcontext = oLineTbl.getSelectedContextPaths();
				var TableData = [];
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				var bIsOpenTask = UIGlobal.getFromOpenTask();
				if (brfHederData.BrfType) {
					if (sId === "supplier" || sId === "supplierLnk") {
						var action = "SUPPLIER";
					} else if (sId === "controller" || sId === "controllerLnk") {
						var action = "CONTROLLER";
					} else if (sId === "vatteam" || sId === "vatteamLnk") {
						var action = "VAT";
					} else if (sId === "Arteam" || sId === "ArteamLnk") {
						var action = "AR";
					} else if (sId === "Approve" || sId === "ApproveLnk") {
						var action = "APPROVE";
					} else if (sId === "lttTeam" || sId === "lttteamIcon") {
						var action = "LTT";
					}
					sap.ui.core.BusyIndicator.show(0);
					if (sAcontext.length !== 0) {
						var oPayLoad = {
							CompanyCode: brfHederData.CompanyCode,
							BrfType: brfHederData.BrfType,
							BrfCreatedBy: brfHederData.BrfCreatedBy,
							BrfNo: brfHederData.BrfNo,
							Gjahr: brfHederData.Gjahr,
							
							Action: action,
						
							ContrlName: brfHederData.ContrlName,
							ContrlEmail: brfHederData.ContrlEmail,
							RrfNo: brfHederData.RrfNo,
							
							InvoiceAmount: brfHederData.InvoiceAmount,
							
							NetAmount: brfHederData.NetAmount,
							DocCurrency: brfHederData.DocCurrency,
							SapDocYear: brfHederData.SapDocYear,
							SapDocNum: brfHederData.SapDocNum,
							BukrsUrn: brfHederData.BukrsUrn,
							Urn: brfHederData.Urn,

							
							BRFItemSet: [],
						};
						for (var i = 0; i < sAcontext.length; i++) {
							var objRow = oBrfModel.getProperty(sAcontext[i]);
							TableData.push(objRow);
						}
						
						var that = this;
						var fnSuccess = jQuery.proxy(function (d) {
							sap.ui.core.BusyIndicator.hide(0);
							if (d.Flag) {
								
								MessageBox.error(
									d.Message, {
										styleClass: bCompact ? "sapUiSizeCompact" : ""
									}
								);
								oLineTbl.removeSelections(true);
							} else {

								MessageBox.show(
									d.Message, {
										icon: MessageBox.Icon.SUCCESS,
										title: "Success",
										actions: [MessageBox.Action.OK],
										onClose: function (oAction) {
											if (bIsOpenTask === false) {
												var oRouter = UIComponent.getRouterFor(that);
												oRouter.navTo("TargetBrfHomeView");
											} else if (bIsOpenTask === true) {
												UIGlobal.setFromOpenTask(false);
												var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
												oCrossAppNavigator.toExternal({
													target: {
														semanticObject: "#"
													}
												});

											}
										}
									}
								);
								this.getModel("oBrfModel").setProperty("/lineItemBRFSet/RequestingMf", "");
								oLineTbl.removeSelections(true);

							}
						}, this);
						var fnError = jQuery.proxy(function (d) {
							sap.ui.core.BusyIndicator.hide(0);
							var r = JSON.parse(JSON.stringify(d));
							oLineTbl.removeSelections(true);
							MessageToast.show(r.message, {
								autoClose: true,
								width: "20rem"
							});
						}, this);
						var objectOne = {};
						var arr = [];
					
						objectOne.successCallback = fnSuccess;
						objectOne.errorCallback = fnError;
					
						oPayLoad.BRFItemSet = TableData;
						DataManagerBrf.CreateBRFData(oPayLoad, objectOne);
					} else if (sAcontext.length === 0 || !sAcontext) {
						sap.ui.core.BusyIndicator.hide(0);
						oLineTbl.removeSelections(true);
						MessageBox.error(
							this.getView().getModel("i18n").getProperty("RowWarning"), {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}
						);
						return;
					}
				} else {
					sap.ui.core.BusyIndicator.hide(0);
					oLineTbl.removeSelections(true);
					var BRFWarning = this.getView().getModel("i18n").getProperty("BRFWarning");
					MessageBox.information(BRFWarning);
				}
			}
		},*/

		/*End of change by developer Satabdi Das for defect 63361 on 09-Nov-2020*/
		onTypingCurrency: function (oEvent) {
			var checkString = oEvent.getParameter("value");
			if (checkString != "") {
				if (/[^A-Za-z\d]/.test(checkString) || isNaN(checkString) === false || /\d/.test(checkString)) {
					this.getView().getModel("oBrfModel").setProperty("/CurrencySet", "");
				}
			}
		},
		onSelectingCurrency: function (oEvent) {
			if (oEvent.getParameter("selectedItem") !== null) {
				var currencyKey = oEvent.getParameter("selectedItem").getProperty("key");
				this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/Curr1", currencyKey);
			} else if (oEvent.getParameter("selectedItem") === null) {
				this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/Curr1", "");
			}
		},

		/*Start of change for MMYY service period date by developer Satabdi Das on 24-Aug-2020*/
		checkServiceStrtDate: function (oEvent) {
			var sValue = oEvent.getParameter("value");
			var ServicePeriodStartDate = formatter.formatBrfSrvDate(sValue);
			var sID = oEvent.getParameter("id").split("--")[2]; /*Change added for INC01499658 on 22-APR-2021*/
			var ServicePeriodEndDate;
			var checkDate;
			var sStartFisYr;
			var sEndFisYr;
			var sFisYrDiff;
			var msg;
			var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
			if (sID === "ServicePeriodStart" || sID === "ServicePeriodStartMF") {
				ServicePeriodEndDate = this.getView().getModel("oBrfModel").getProperty("/lineItemBRFSet/ServicePeriodEnd");
				if (ServicePeriodEndDate && ServicePeriodEndDate !== "00000000" && ServicePeriodEndDate !== "") {
					// checkDate = ServicePeriodEndDate - ServicePeriodStartDate;
					checkDate = ServicePeriodEndDate.slice(0, 2) - ServicePeriodStartDate.slice(0, 2);
					// sStartFisYr = ServicePeriodStartDate.slice(2, 4);
					// sEndFisYr = ServicePeriodEndDate.slice(2, 4);
					sFisYrDiff = ServicePeriodEndDate.slice(2, 4) - ServicePeriodStartDate.slice(2, 4);
				}
				if (checkDate !== undefined) {
					if (checkDate < 0 && sFisYrDiff <= 0) {
						msg = this.getView().getModel("i18n").getProperty("SrvStartDateAtert");
						MessageBox.alert(
							msg, {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}
						);
						this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/ServicePeriodStart", "");
					} else if (checkDate >= 0 && sFisYrDiff < 0) {
						msg = this.getView().getModel("i18n").getProperty("SrvStartDateAtert");
						MessageBox.alert(
							msg, {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}
						);
						this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/ServicePeriodStart", "");
					} else {
						this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/ServicePeriodStart", ServicePeriodStartDate);
					}
				} else {
					this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/ServicePeriodStart", ServicePeriodStartDate);
				}
			} else if (sID === "ServicePeriodStartCR") {
				ServicePeriodEndDate = this.getView().getModel("oBrfModel").getProperty("/lineItemBRFSet/ServicePeriodEndCredit");
				if (ServicePeriodEndDate && ServicePeriodEndDate !== "00000000" && ServicePeriodEndDate !== "") {
					// checkDate = ServicePeriodEndDate - ServicePeriodStartDate;
					checkDate = ServicePeriodEndDate.slice(0, 2) - ServicePeriodStartDate.slice(0, 2);
					// sStartFisYr = ServicePeriodStartDate.slice(2, 4);
					// sEndFisYr = ServicePeriodEndDate.slice(2, 4);
					sFisYrDiff = ServicePeriodEndDate.slice(2, 4) - ServicePeriodStartDate.slice(2, 4);
				}
				if (checkDate !== undefined) {
					if (checkDate < 0 && sFisYrDiff <= 0) {
						msg = this.getView().getModel("i18n").getProperty("SrvStartDateAtert");
						MessageBox.alert(
							msg, {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}
						);
						this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/ServicePeriodStartCredit", "");
					} else if (checkDate >= 0 && sFisYrDiff < 0) {
						msg = this.getView().getModel("i18n").getProperty("SrvStartDateAtert");
						MessageBox.alert(
							msg, {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}
						);
						this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/ServicePeriodStartCredit", "");
					} else {
						this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/ServicePeriodStartCredit", ServicePeriodStartDate);
					}
				} else {
					this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/ServicePeriodStartCredit", ServicePeriodStartDate);
				}
			}
		},
		checkServiceEndDate: function (oEvent) {
			var sValue = oEvent.getParameter("value");
			var ServicePeriodEndDate = formatter.formatBrfSrvDate(sValue);
			var sID = oEvent.getParameter("id").split("--")[2]; /*Change added for INC01499658 on 22-APR-2021*/
			var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
			var msg;
			var ServicePeriodStartDate;
			var checkDate;
			var sStartFisYr;
			var sEndFisYr;
			var sFisYrDiff;
			if (sID === "ServicePeriodEnd" || sID === "ServicePeriodEndMF") {
				ServicePeriodStartDate = this.getView().getModel("oBrfModel").getProperty("/lineItemBRFSet/ServicePeriodStart");
				if (ServicePeriodStartDate && ServicePeriodStartDate !== "00000000" && ServicePeriodStartDate !== "") {
					// checkDate = ServicePeriodEndDate - ServicePeriodStartDate;
					checkDate = ServicePeriodEndDate.slice(0, 2) - ServicePeriodStartDate.slice(0, 2);
					// sStartFisYr = ServicePeriodStartDate.slice(2, 4);
					// sEndFisYr = ServicePeriodEndDate.slice(2, 4);
					sFisYrDiff = ServicePeriodEndDate.slice(2, 4) - ServicePeriodStartDate.slice(2, 4);
				}
				if (checkDate !== undefined) {
					if (checkDate < 0 && sFisYrDiff <= 0) {
						msg = this.getView().getModel("i18n").getProperty("SrvEndDateAtert");
						MessageBox.alert(
							msg, {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}
						);
						this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/ServicePeriodEnd", "");
					} else if (checkDate >= 0 && sFisYrDiff < 0) {
						msg = this.getView().getModel("i18n").getProperty("SrvEndDateAtert");
						MessageBox.alert(
							msg, {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}
						);
						this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/ServicePeriodEnd", "");
					} else {
						this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/ServicePeriodEnd", ServicePeriodEndDate);
					}
				} else {
					this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/ServicePeriodEnd", ServicePeriodEndDate);
				}
			} else if (sID === "ServicePeriodEndCR") {
				ServicePeriodStartDate = this.getView().getModel("oBrfModel").getProperty("/lineItemBRFSet/ServicePeriodStartCredit");
				if (ServicePeriodStartDate && ServicePeriodStartDate !== "00000000" && ServicePeriodStartDate !== "") {
					// checkDate = ServicePeriodEndDate - ServicePeriodStartDate;
					checkDate = ServicePeriodEndDate.slice(0, 2) - ServicePeriodStartDate.slice(0, 2);
					// sStartFisYr = ServicePeriodStartDate.slice(2, 4);
					// sEndFisYr = ServicePeriodEndDate.slice(2, 4);
					sFisYrDiff = ServicePeriodEndDate.slice(2, 4) - ServicePeriodStartDate.slice(2, 4);
				}
				if (checkDate !== undefined) {
					if (checkDate < 0 && sFisYrDiff <= 0) {
						msg = this.getView().getModel("i18n").getProperty("SrvEndDateAtert");
						MessageBox.alert(
							msg, {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}
						);
						this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/ServicePeriodEndCredit", "");
					} else if (checkDate >= 0 && sFisYrDiff < 0) {
						msg = this.getView().getModel("i18n").getProperty("SrvEndDateAtert");
						MessageBox.alert(
							msg, {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}
						);
						this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/ServicePeriodEndCredit", "");
					} else {
						this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/ServicePeriodEndCredit", ServicePeriodEndDate);
					}
				} else {
					this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/ServicePeriodEndCredit", ServicePeriodEndDate);
				}
			}
		},
		/*End of change for MMYY service period date by developer Satabdi Das on 24-Aug-2020*/

		/*Start of change by Satabdi Das on 03-Nov-2020 for Defect 63644*/
		handlePressTextEditor: function (oEvent) {
			var oBrfModel = this.getView().getModel("oBrfModel");
			var fragmentId = this.getView().createId("longTextFrag");
			var sValue = oBrfModel.getData().lineItemBRFSet.LongText;
			if (!this._oLongTextFrag) {
				this._oLongTextFrag = sap.ui.xmlfragment(fragmentId, "KGO.kgoarrecharge_brf.view.longTextEditor", this);
				this.getView().addDependent(this._oLongTextFrag);
			}
			if (sValue && sValue !== "") {
				if (sValue.indexOf("|") >= 0) {
					/*Start of chnage for Defect 63890 on 25-03-2021*/
					// sValue = sValue.replaceAll("|", "\n");
					var sPipeline = "|";
					var sNewLine = "\n";
					sValue = sValue.split(sPipeline).join(sNewLine);
					/*End of change for defect 63890 on 25-03-2021*/
				}
				oBrfModel.setProperty("/lineItemBRFSet/LongText", sValue);
			} else {
				oBrfModel.setProperty("/lineItemBRFSet/LongText", "");
			}
			/*handle 70 character limit*/
			// var txtArealongText = sap.ui.core.Fragment.byId(fragmentId, "longText");
			// var charlimit = UIGlobal.getLongTextCharLimit();
			// txtArealongText.onkeyup = function () {
			// 	var lines = txtArealongText.getValue().split('\n');
			// 	for (var i = 0; i < lines.length; i++) {
			// 		if (lines[i].length <= charlimit) continue;
			// 		var j = 0;
			// 		var space = charlimit;
			// 		while (j++ <= charlimit) {
			// 			if (lines[i].charAt(j) === ' ') space = j;
			// 		}
			// 		lines[i + 1] = lines[i].substring(space + 1) + (lines[i + 1] || "");
			// 		lines[i] = lines[i].substring(0, space);
			// 	}
			// 	txtArealongText.setValue(lines.slice(0, 100).join('\n'));
			// };

			this._oLongTextFrag.open();
		},

		onAddingText: function (oEvent) {
			var sValue = oEvent.getParameter("value");
			var oBrfModel = this.getView().getModel("oBrfModel");
			if (sValue !== "") {
				// if (sValue.length > 70) {
				// 	var chunks = sValue.match(/.{1,70}/g);
				// 	sValue = chunks.join("\n");
				// }
				oBrfModel.setProperty("/lineItemBRFSet/LongText", sValue);
			} else {
				oBrfModel.setProperty("/lineItemBRFSet/LongText", "");
			}
		},

		longTextClose: function (oEvent) {
			var oBrfModel = this.getView().getModel("oBrfModel");
			var sValue = oBrfModel.getProperty("/lineItemBRFSet/LongText");
			this._oLongTextFrag.close();
			if (sValue.indexOf("\n") >= 0) {
				/*Start of chnage for Defect 63890 on 25-03-2021*/
				// sValue = sValue.replaceAll("\n", "|");
				var sPipeline = "|";
				var sNewLine = "\n";
				sValue = sValue.split(sNewLine).join(sPipeline);
				/*End of change for defect 63890 on 25-03-2021*/
				oBrfModel.setProperty("/lineItemBRFSet/LongText", sValue);
			} else {
				oBrfModel.setProperty("/lineItemBRFSet/LongText", sValue);
			}
		},
		/*End of change by Satabdi Das on 03-Nov-2020 for Defect 63644*/

		/*Start of Attachement Section*/
		onAddAttachment: function (oEvent) {
			var uploadCollection = oEvent.getSource();
			var that = this;
			var collectionItemArr = uploadCollection.getItems();
			var files = oEvent.getParameter("files");
			var dupfile;
			for (var i = 0; i < collectionItemArr.length; i++) {
				if (collectionItemArr[i].getProperty("fileName") === files[0].name) {
					jQuery.sap.log.error("Duplicate file not allowed");
					sap.m.MessageBox.error("Duplicate filename not allowed", {
						title: "Error", // default
						onClose: null, // default
						styleClass: "", // default
						initialFocus: null, // default
						textDirection: sap.ui.core.TextDirection.Inherit // default
					});
					dupfile = true;
					break;
				}
			}
			if (files[0].size <= 0) {
				sap.m.MessageBox.error("Files with size 0kb not allowed to upload", {
					title: "Error", // default
					onClose: null, // default
					styleClass: "", // default
					initialFocus: null, // default
					textDirection: sap.ui.core.TextDirection.Inherit // default
				});
				oEvent.getSource().abortUpload(oEvent.getParameters());
				return;
			}
			if (dupfile === true) {
				oEvent.getSource().abortUpload(oEvent.getParameters());
				return;
			}
			var uploadUrl = "/sap/opu/odata/kgo/FI_AR_RECHARGE_BRF_SRV/AR_ATTSet";
			uploadCollection.setUploadUrl(uploadUrl);
			var mAttachments = this.getView().getModel();
			var token = "x-cs" + "rf-token";
			mAttachments.refreshSecurityToken();
			var T = mAttachments.getHeaders()[token];
			var csrfToken = new sap.m.UploadCollectionParameter({
				name: token,
				value: T
			});
			var reqType = new sap.m.UploadCollectionParameter({
				name: "X-Requested-With",
				value: "XMLHttpRequest"
			});
			uploadCollection.removeAllHeaderParameters();
			uploadCollection.addHeaderParameter(csrfToken);
			uploadCollection.addHeaderParameter(reqType);

		},
		onBeforeUploadStarts: function (oEvent) {

			var AttachPanelID = "BRF";
			var sValue = this.getView().getModel("oBrfModel").getProperty("/brfHeaderSet");
			var oRrfNo = sValue.RrfNo;
			if (sValue.BrfNo) {
				sValue.RrfNo = sValue.BrfNo;
			}
			var sMFGCC = this.getView().getModel("oBrfModel").getProperty("/lineItemBRFSet");
			if ((sMFGCC.RequestingMf === "N/A") || (!sMFGCC.RequestingMf)) {
				sMFGCC.RequestingMf = "NA";
				sMFGCC.MemberFirm = "";
				sMFGCC.CcShortDesc = "";
			}
			if ((sMFGCC.GlobalCc === "N/A") || (!sMFGCC.GlobalCc)) {
				sMFGCC.GlobalCc = "NA";
				sMFGCC.CcShortDesc = "";

			}

			if (!sMFGCC.ProcessGrp) {
				sMFGCC.ProcessGrp = "";
			}

			if (!sMFGCC.TransactionType) {
				sMFGCC.TransactionType = "";
			}
			// calling special char check function
			var isSpecialChar = this.checkFileNameSepecialchar(oEvent.getParameter("fileName"));
			if (isSpecialChar) {
				var sMsg = this.getView().getModel("i18n").getProperty("specialcharFileNameMsg");
				MessageBox.error(sMsg);
				return;
			}

			var uPloadpar = oEvent.getParameter("fileName") + "|" + sMFGCC.CompanyCode + "|" + sValue.BrfNo + "|" + sMFGCC.RequestingMf + "|" +
				sMFGCC.ProcessGrp + "|" + sMFGCC.GlobalCc + "|" + AttachPanelID + "|" + sMFGCC.TransactionType + "|" + sMFGCC.MemberFirm + "|" +
				sMFGCC.CcShortDesc; /*Added on 18-Feb-2020*/
			// Header Slug
			var oCustomerHeaderSlug = new sap.m.UploadCollectionParameter({
				name: "slug",
				value: uPloadpar
			});

			oEvent.getParameters().addHeaderParameter(oCustomerHeaderSlug);

			if (sMFGCC.RequestingMf === "NA" && sMFGCC.GlobalCc != "NA") {

				sMFGCC.RequestingMf = "N/A";
				sMFGCC.MemberFirm = "";
			}

			if (sMFGCC.GlobalCc === "NA") {
				sMFGCC.GlobalCc = "N/A";
				sMFGCC.CcShortDesc = "";
			}
			if (sValue.BrfNo) {
				sValue.RrfNo = oRrfNo;
			}
		},
		checkFileNameSepecialchar: function (fileName) {
			var format = /[:%/?]+/;

			if (format.test(fileName)) {
				//	MessageBox.error("Special characters  % , / ,? can not be allowed in file name");
				return true;
			} else {
				return false;
			}
		},

		handleUploadComplete: function (oEvent) {
			this.fetchAttachmentList();
		},

		fetchAttachmentList: function (oEvent) {
			var sValue = this.getView().getModel("oBrfModel").getProperty("/brfHeaderSet");
			var sMFGCCForBRF = this.getView().getModel("oBrfModel").getProperty("/lineItemBRFSet");
			if (sMFGCCForBRF.RequestingMf === "N/A") {
				sMFGCCForBRF.MemberFirm = "";
			}
			// else {
			sMFGCCForBRF.CcShortDesc = "";

			// }

			sap.ui.core.BusyIndicator.show(0);
			var fnSucces = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);

				this.getView().getModel("oBrfModel").setProperty("/FileNameBRFSet", d.results);
				/*Below code mcommented by Satabdi Das on 11-Nov-2020*/
				// this.getView().getModel("oBrfModel").refresh(true);
			}, this);

			var fnError = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
			}, this);

			var sPath1 = "/AR_ATTSet";
			var aFilterStr = [];
			var oFilterSerach;
			if (sValue.BrfNo && sMFGCCForBRF.CompanyCode && sMFGCCForBRF.RequestingMf && sMFGCCForBRF.GlobalCc) {
				oFilterSerach = new sap.ui.model.Filter("RrfNo", sap.ui.model.FilterOperator.EQ, sValue.BrfNo);
				aFilterStr.push(oFilterSerach);
				oFilterSerach = new sap.ui.model.Filter("CompanyCode", sap.ui.model.FilterOperator.EQ, sMFGCCForBRF.CompanyCode);
				aFilterStr.push(oFilterSerach);
				oFilterSerach = new sap.ui.model.Filter("RequestingMf", sap.ui.model.FilterOperator.EQ, sMFGCCForBRF.RequestingMf);
				aFilterStr.push(oFilterSerach);
				oFilterSerach = new sap.ui.model.Filter("GlobalCc", sap.ui.model.FilterOperator.EQ, sMFGCCForBRF.GlobalCc);
				aFilterStr.push(oFilterSerach);
				oFilterSerach = new sap.ui.model.Filter("ProcessGrp", sap.ui.model.FilterOperator.EQ, sMFGCCForBRF.ProcessGrp);
				aFilterStr.push(oFilterSerach);
				oFilterSerach = new sap.ui.model.Filter("TransactionType", sap.ui.model.FilterOperator.EQ, sMFGCCForBRF.TransactionType);
				aFilterStr.push(oFilterSerach);
				oFilterSerach = new sap.ui.model.Filter("MemberFirm", sap.ui.model.FilterOperator.EQ, sMFGCCForBRF.MemberFirm);
				aFilterStr.push(oFilterSerach);
				oFilterSerach = new sap.ui.model.Filter("CcShortDesc", sap.ui.model.FilterOperator.EQ, sMFGCCForBRF.CcShortDesc);
				aFilterStr.push(oFilterSerach);

			}
			// var oUrlParams = {};
			// DataManagerBrf._getODataARRecharge(sPath1, aFilterStr, oUrlParams, fnSucces, fnError);
			/*R&D---start*/
			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_BRF_SRV/", {
				json: true
			});
			oModel1.read("/AR_ATTSet", {
				filters: aFilterStr,
				success: fnSucces,
				error: fnError
			});
			/*R&D---end*/

		},

		handleTypeMissmatch: function (oEvent) {
			var aFileTypes = oEvent.getSource().getFileType();
			jQuery.each(aFileTypes, function (key, value) {
				aFileTypes[key] = "*." + value;
			});
			var sSupportedFileTypes = aFileTypes.join(", ");
			MessageToast.show("The file type *." + oEvent.getParameter("fileType") +
				" is not supported. Choose one of the following types: " +
				sSupportedFileTypes);
		},
		onDeleteAttachmentBRF: function (oEvent) {
			var AttachPanelID = "BRF";
			var oModelAttachments = this.getView().getModel("oBrfModel");
			var sValue = this.getView().getModel("oBrfModel").getProperty("/brfHeaderSet");
			var oRrfNo = sValue.RrfNo;

			// if (sValue.BrfNo) {
			// 	sValue.RrfNo = sValue.BrfNo;
			// }
			var sMFGCC = this.getView().getModel("oBrfModel").getProperty("/lineItemBRFSet");
			var sMf;
			var sPrGrp;
			if (oEvent.getParameter("item").getProperty("fileName")) {
				var fileName = oEvent.getParameter("item").getProperty("fileName").replace(/\s/g, "*");
				var ofileName1 = fileName;
				var forwardslashFile = /[/]+/;
				if (forwardslashFile.test(ofileName1)) {
					ofileName1 = ofileName1.replace(/[/]/g, "|");
				}
				var qQuestionCharFile = /[?]+/;
				if (qQuestionCharFile.test(ofileName1)) {
					ofileName1 = ofileName1.replace(/[?]/g, "(");
				}
				var pPercentageFile = /[%]+/;
				if (pPercentageFile.test(ofileName1)) {
					ofileName1 = ofileName1.replace(/[%]/g, ")");
				}
			}

			if (sMFGCC.RequestingMf === "N/A") {
				sMFGCC.RequestingMf = "NA";
				sMFGCC.MemberFirm = "";
				sMf = sMFGCC.MemberFirm;
			}
			if (sMFGCC.ProcessGrp) {
				sPrGrp = sMFGCC.ProcessGrp.replace(/\s/g, "*");
				/*Start of change for INC01584421 by developer Satabdi Das on 21-June-2021*/
				var forwardslash = /[/]+/;
				if (forwardslash.test(sPrGrp)) {
					sPrGrp = sPrGrp.replace(/[/]/g, "|");
				}

				var qQuestionChar = /[?]+/;
				if (qQuestionChar.test(sPrGrp)) {
					sPrGrp = sPrGrp.replace(/[?]/g, "(");
				}

				var pPercentage = /[%]+/;
				if (pPercentage.test(sPrGrp)) {
					sPrGrp = sPrGrp.replace(/[%]/g, ")");
				}
				/*End of change for INC01584421 by developer Satabdi Das on 21-June-2021*/
			}
			if (sMFGCC.MemberFirm) {
				sMf = sMFGCC.MemberFirm.replace(/\s/g, "*");
				/*Start of change for INC01584421 by developer Satabdi Das on 21-June-2021*/
				var forwardslashMmfirm = /[/]+/;
				if (forwardslashMmfirm.test(sMf)) {
					sMf = sMf.replace(/[/]/g, "|");
				}

				var qQuestionCharMemFm = /[?]+/;
				if (qQuestionCharMemFm.test(sMf)) {
					sMf = sMf.replace(/[?]/g, "(");
				}

				var pPercentageMF = /[%]+/;
				if (pPercentageMF.test(sMf)) {
					sMf = sMf.replace(/[%]/g, ")");
				}
				/*End of change for INC01584421 by developer Satabdi Das on 21-June-2021*/
			} else if (sMFGCC.MemberFirm === "") {
				sMf = sMFGCC.MemberFirm;
			}

			if (!sMFGCC.ProcessGrp && sMFGCC.GlobalCc) {
				sMFGCC.ProcessGrp = "";
				sPrGrp = sMFGCC.ProcessGrp;
			}
			if (sMFGCC.GlobalCc === "N/A") {
				sMFGCC.GlobalCc = "NA";
			}

			//Attachment to delete
			var selectedAttachment = oEvent.getParameter("documentId");

			//Update Attachment list in Front End
			var attachmentArray = oModelAttachments.getProperty("/FileNameBRFSet");
			for (var i = 0; i < attachmentArray.length; i++) {
				if (attachmentArray[i].Filename === selectedAttachment) {
					attachmentArray.splice(i, 1);
					break;
				}
			}
			oModelAttachments.setProperty("/FileNameBRFSet", attachmentArray);

			//Backend DELETE POST call queued

			/*	var sPath = "/AR_ATTSet(CompanyCode='" + sValue.CompanyCode + "',RrfNo='" + sValue.RrfNo +
					"',RequestingMf='" + sMFGCC.RequestingMf + "',ProcessGrp='" + sMFGCC.ProcessGrp + "',GlobalCc='" + sMFGCC.GlobalCc + "',CopLoa='" +
					AttachPanelID + "',Filename='" + fileName + "')";*/
			var sPath = "/AR_ATTSet(CompanyCode='" + sMFGCC.CompanyCode + "',RrfNo='" + sValue.BrfNo +
				"',RequestingMf='" + sMFGCC.RequestingMf + "',ProcessGrp='" + sPrGrp + "',MemberFirm='" + sMf +
				"',CopLoa='" + AttachPanelID + "',GlobalCc='" +
				sMFGCC.GlobalCc + "',CcShortDesc='" + sMFGCC.CcShortDesc + "',Filename='" + ofileName1 + "',TransactionType='" + sMFGCC.TransactionType +
				"')";

			if (sMFGCC.RequestingMf === "NA" && sMFGCC.GlobalCc != "NA") {
				sMFGCC.RequestingMf = "N/A";
			}
			if (sMFGCC.GlobalCc === "NA") {
				sMFGCC.GlobalCc = "N/A";
			}
			if (sValue.BrfNo) {
				sValue.RrfNo = oRrfNo;
			}

			var fnUpdSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide();
				this.getView().getModel("oBrfModel").refresh(true);

			}, this);
			var fnUpdError = jQuery.proxy(function (d) {

				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();

				MessageToast.show(r, {
					autoClose: true,
					width: "20rem"
				});

			}, this);
			var _oObject = {};
			_oObject.successCallback = fnUpdSuccess;
			_oObject.errorCallback = fnUpdError;
			_oObject.sPath = sPath;
			DataManagerBrf._deleteODataBRF(_oObject);

		},
		onDownLoadPressBRF: function (oEvent) {
			sap.ui.core.BusyIndicator.show(0);
			var AttachPanelID = "BRF";
			var ofileName = oEvent.getSource().getParent("oParent").getProperty("fileName");
			var ofileName1 = ofileName;
			var forwardslashFile = /[/]+/;
			if (forwardslashFile.test(ofileName1)) {
				ofileName1 = ofileName1.replace(/[/]/g, "|");
			}
			var qQuestionCharFile = /[?]+/;
			if (qQuestionCharFile.test(ofileName1)) {
				ofileName1 = ofileName1.replace(/[?]/g, "(");
			}
			var pPercentageFile = /[%]+/;
			if (pPercentageFile.test(ofileName1)) {
				ofileName1 = ofileName1.replace(/[%]/g, ")");
			}

			var sValue = this.getView().getModel("oBrfModel").getProperty("/brfHeaderSet");
			// if (sValue.BrfNo) {
			// 	sValue.RrfNo = sValue.BrfNo;
			// }

			var sMFGCC = this.getView().getModel("oBrfModel").getProperty("/lineItemBRFSet");
			if ((sMFGCC.RequestingMf === "N/A") || (!sMFGCC.RequestingMf)) {
				sMFGCC.RequestingMf = "NA";
				sMFGCC.MemberFirm = "";
			}
			if ((sMFGCC.GlobalCc === "N/A") || (!sMFGCC.GlobalCc)) {
				sMFGCC.GlobalCc = "NA";
				sMFGCC.CcShortDesc = "";
			}

			/*Start of change for INC01584421 by developer Prashant kumar on 22-June-2021*/
			var sMf = sMFGCC.MemberFirm;
			var forwardslashMmfirm = /[/]+/;
			if (forwardslashMmfirm.test(sMf)) {
				sMf = sMf.replace(/[/]/g, "|");
			}
			var qQuestionCharMemFm = /[?]+/;
			if (qQuestionCharMemFm.test(sMf)) {
				sMf = sMf.replace(/[?]/g, "(");
			}
			var pPercentageMF = /[%]+/;
			if (pPercentageMF.test(sMf)) {
				sMf = sMf.replace(/[%]/g, ")");
			}

			/*Start of change on 18-Feb-2020*/

			/*End of change on 18-Feb-2020*/

			if (!sMFGCC.ProcessGrp) {
				sMFGCC.ProcessGrp = "";
			}
			var sPrGrp = sMFGCC.ProcessGrp;
			/*Start of change for INC01584421 by developer Prashant kumar on 22-June-2021*/
			var forwardslash = /[/]+/;
			if (forwardslash.test(sPrGrp)) {
				sPrGrp = sPrGrp.replace(/[/]/g, "|");
			}
			var qQuestionChar = /[?]+/;
			if (qQuestionChar.test(sPrGrp)) {
				sPrGrp = sPrGrp.replace(/[?]/g, "(");
			}
			var pPercentage = /[%]+/;
			if (pPercentage.test(sPrGrp)) {
				sPrGrp = sPrGrp.replace(/[%]/g, ")");
			}

			var auxArray1 = new Array();
			var that = this;
			var pdfURL = null;
			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_BRF_SRV/", {
				json: true
			});

			var oDataQuery2 = "/AR_ATTSet(CompanyCode='" + sMFGCC.CompanyCode + "',RrfNo='" + sValue.BrfNo +
				"',RequestingMf='" + sMFGCC.RequestingMf + "',MemberFirm='" + sMf + "',GlobalCc='" + sMFGCC.GlobalCc +
				"',Filename='" + ofileName1 + "',ProcessGrp='" + sPrGrp + "',CopLoa='" + AttachPanelID + "',TransactionType='" + sMFGCC.TransactionType +
				"',CcShortDesc='" + sMFGCC.CcShortDesc +
				"')/$value";

			oModel1.read(oDataQuery2, null,
				null,
				false,

				function (oData, oResponse) {
					sap.ui.core.BusyIndicator.hide();
					if (oResponse) {
						sap.ui.core.BusyIndicator.hide(0);
						auxArray1 = oData;
						pdfURL = oResponse.requestUri;
						// that.showFile(oResponse.body);
					} else {
						var e = oResponse.headers;

						if (e) {
							sap.ui.core.BusyIndicator.hide(0);
							MessageBox.error("Some error has occured.");

						}
					}
				},
				function readError(e) {
					sap.ui.core.BusyIndicator.hide(0);
					var r = JSON.parse(JSON.stringify(e));
					// sap.ui.core.BusyIndicator.hide();

					MessageToast.show('No document generated', {
						autoClose: true,
						width: "20rem"
					});

				}
			);
			if (pdfURL) {

				window.open(pdfURL, "_self");
				setTimeout(function () {
					sap.ui.core.BusyIndicator.hide(0);
				}, 10000);
			} else {

				setTimeout(function () {
					sap.ui.core.BusyIndicator.hide(0);
				}, 1000);
			}

			if (sMFGCC.RequestingMf === "NA") {
				sMFGCC.RequestingMf = "N/A";
			}
			if (sMFGCC.GlobalCc === "NA") {
				sMFGCC.GlobalCc = "N/A";
			}

		},
		handleValueChange: function (oEvent) {
			MessageToast.show("Press 'Upload File' to upload file '" +
				oEvent.getParameter("newValue") + "'");
		},
		/*End of Attachment Section*/

		/*Start of change by developer Satabdi Das on 04-Dec-2020 for enhancement 63345*/
		onPressAPURN: function (oEvent) {
			var oBrfModel = this.getView().getModel("oBrfModel");
			var oHeaderCompanyCode = oBrfModel.getProperty("/brfHeaderSet").CompanyCode;
			oBrfModel.setProperty("/APURNHdrSet/Bukrs", oHeaderCompanyCode);
			oBrfModel.setProperty("/lineItemBRFSet/Urn", "");
			var fragmentId = this.getView().createId("searchAPURN");
			if (!this._oSearchAPURN) {
				this._oSearchAPURN = sap.ui.xmlfragment(fragmentId, "KGO.kgoarrecharge_brf.view.APUrnSearchHelp", this);
				this.getView().addDependent(this._oSearchAPURN);
			}
			this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/visibleDocInfo", false);
			this._oSearchAPURN.open();
		},

		onAPUrnHelp: function (oEvent) {
			var bDisplay = this.getView().getModel("oBrfModel").getProperty("/Display");
			var sFragTxt = this.getView().getModel("oBrfModel").getProperty("/fraggmentText"); //added for Reissuance visible by Satabdi Das on  14-Dec-2020
			if (bDisplay === false || sFragTxt === "REISSUANCE") { //added for Reissuance visible by Satabdi Das on  14-Dec-2020
				var oBrfModel = this.getModel("oBrfModel");
				sap.ui.core.BusyIndicator.show(0);
				var oSearchData = this.getView().getModel("oBrfModel").getProperty("/APURNHdrSet");

				var fnSuccess = jQuery.proxy(function (d) {
					sap.ui.core.BusyIndicator.hide(0);
					if (d.results.length === 0) {
						var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
						MessageBox.alert(
							"No results found.", {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}
						);
					} else {
						oBrfModel.setProperty("/oVisibleSet/visibleDocInfo", true);
						oBrfModel.setProperty("/URN_NoSet", d.results);
					}
					oBrfModel.refresh(true);
				}, this);

				var fnError = jQuery.proxy(function (d) {
					var r = JSON.parse(JSON.stringify(d));
					sap.ui.core.BusyIndicator.hide();
					MessageToast.show(r.message, {
						autoClose: true,
						width: "20rem"
					});
				}, this);

				var aFilter = [];
				var aFilterStr = [];
				var oFilterSerach;
				if (oSearchData.Urn || oSearchData.Bukrs || oSearchData.SapDocYear || oSearchData.DocType || oSearchData.Vendor) {
					if (oSearchData.Urn) {
						oSearchData.Urn = formatter.formatValueToString(oSearchData.Urn); /*Change added by developer Satabdi Das on 25-May-2021 for HTTP Error*/
						oFilterSerach = new sap.ui.model.Filter("Urn", sap.ui.model.FilterOperator.EQ, oSearchData.Urn);
						aFilterStr.push(oFilterSerach);
					}
					if (oSearchData.Bukrs) {
						oSearchData.Bukrs = formatter.formatValueToString(oSearchData.Bukrs); /*Change added by developer Satabdi Das on 25-May-2021 for HTTP Error*/
						oFilterSerach = new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.EQ, oSearchData.Bukrs);
						aFilterStr.push(oFilterSerach);
					}
					if (oSearchData.SapDocYear) {
						oSearchData.SapDocYear = formatter.formatValueToString(oSearchData.SapDocYear); /*Change added by developer Satabdi Das on 25-May-2021 for HTTP Error*/
						oFilterSerach = new sap.ui.model.Filter("SapDocYear", sap.ui.model.FilterOperator.EQ, oSearchData.SapDocYear);
						aFilterStr.push(oFilterSerach);
					}
					if (oSearchData.DocType) {
						oSearchData.DocType = formatter.formatValueToString(oSearchData.DocType); /*Change added by developer Satabdi Das on 25-May-2021 for HTTP Error*/
						oFilterSerach = new sap.ui.model.Filter("DocType", sap.ui.model.FilterOperator.EQ, oSearchData.DocType);
						aFilterStr.push(oFilterSerach);
					}
					if (oSearchData.Vendor) {
						oSearchData.Vendor = formatter.formatValueToString(oSearchData.Vendor); /*Change added by developer Satabdi Das on 25-May-2021 for HTTP Error*/
						oFilterSerach = new sap.ui.model.Filter("Vendor", sap.ui.model.FilterOperator.EQ, oSearchData.Vendor);
						aFilterStr.push(oFilterSerach);
					}
					var oFilterStr = new sap.ui.model.Filter({
						filters: aFilterStr,
						and: true
					});
					aFilter.push(oFilterStr);
				}
				var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_BRF_SRV/", {
					json: true
				});
				oModel1.read("/URN_NoSet?$skip=0&$top=50", {
					filters: aFilter,
					success: fnSuccess,
					error: fnError
				});
			}
		},

		onURNSelect: function (oEvent) {
			var oAPUrn = oEvent.getSource().getBindingContext("oBrfModel").getObject();
			/*if (URN_NoSet.Flag === "X") {
				MessageBox.information("URN number " + URN_NoSet.Urn + " has been used in other BRF please select other one. ");
				return;
			}*/
			if (oAPUrn) {
				this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/Urn", oAPUrn.Urn);
			}
			this.getView().getModel("oBrfModel").setProperty("/URN_NoSet", []);
			this.getView().getModel("oBrfModel").setProperty("/APURNHdrSet", {});
			this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/visibleDocInfo", false);

			if (this._oSearchAPURN) {
				this._oSearchAPURN.close();
			}
			this.reloadLocaServData();
		},

		onCloseURNHelp: function () {
			this.getView().getModel("oBrfModel").setProperty("/URN_NoSet", []);
			this.getView().getModel("oBrfModel").setProperty("/APURNHdrSet", {});
			this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/visibleDocInfo", false);
			if (this._oSearchAPURN) {
				this._oSearchAPURN.close();

			}
			this.reloadLocaServData();
		},

		reloadLocaServData: function () {
			var oBrfModel = this.getView().getModel("oBrfModel");
			oBrfModel.setSizeLimit(5000);
			var locionServ = this.getView().getModel("oBrfModel").getProperty("/lineItemBRFSet").LocationOfTheServicesReq;
			this.getView().getModel("oBrfModel").setProperty("/SelcKeyForLocServ", locionServ);
			this.getView().getModel("oBrfModel").refresh(true);
		},
		/*End of change by developer Satabdi Das on 04-Dec-2020 for enhancement 63345*/
		onPressTaxHelp: function (oEvent) {
			var bDisplay = this.getView().getModel("oBrfModel").getProperty("/Display");
			var sFragTxt = this.getView().getModel("oBrfModel").getProperty("/fraggmentText"); //added for Reissuance visible by Satabdi Das on  14-Dec-2020
			if (bDisplay === false || sFragTxt === "REISSUANCE") { //added for Reissuance visible by Satabdi Das on  14-Dec-2020
				var oBrfModel = this.getModel("oBrfModel");
				var sId = oEvent.getSource().getId();
				if (sId.indexOf("SalesTaxCode") >= 0) {
					this.taxCode = "SalesTaxCodeGF";
				} else if (sId.indexOf("VatSapCode") >= 0) {
					this.taxCode = "VatSapCodeMF";
					oBrfModel.setProperty("/lineItemBRFSet/KpmgiVatId", "");
					oBrfModel.setProperty("/lineItemBRFSet/VatSapCode", ""); /*Added for defect 63445*/
					oBrfModel.setProperty("/lineItemBRFSet/VatDesc", ""); /*Added for defect 63445*/
				}
				var fragmentId = this.getView().createId("searchTaxCode");
				if (!this._oSeachTaxCode) {
					this._oSeachTaxCode = sap.ui.xmlfragment(fragmentId, "KGO.kgoarrecharge_brf.view.TaxCodeHelp", this);
					this.getView().addDependent(this._oSeachTaxCode);
				}
				oBrfModel.setProperty("/oVisibleSet/visibleTaxInfo", false);
				this._oSeachTaxCode.open();
			}
		},

		onSearchTaxCode: function (oEvent) {
			var bDisplay = this.getView().getModel("oBrfModel").getProperty("/Display");
			var sFragTxt = this.getView().getModel("oBrfModel").getProperty("/fraggmentText"); //added for Reissuance visible by Satabdi Das on  14-Dec-2020
			if (bDisplay === false || sFragTxt === "REISSUANCE") { //added for Reissuance visible by Satabdi Das on  14-Dec-2020
				var oBrfModel = this.getModel("oBrfModel");
				sap.ui.core.BusyIndicator.show(0);
				var oSearchData = this.getView().getModel("oBrfModel").getProperty("/TaxHdrSet");
				var sCompCode = oBrfModel.getProperty("/lineItemBRFSet/CompanyCode"); /*Added for new comp code by developer Satabdi Das on 19-Aug-2020*/
				var aFilter = [];
				var mArrayOut = [];
				var sPath = "";
				sPath = "/Tax_CodeSet?$skip=0&$top=50";
				var fnSuccess = jQuery.proxy(function (d) {
					sap.ui.core.BusyIndicator.hide(0);
					if (d.results.length === 0) {
						var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
						MessageBox.alert(
							"No results found.", {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}
						);
					} else {
						for (var i = 0; i < d.results.length; i++) {
							var oTaxCode = {};
							oTaxCode.SalesTaxCode = d.results[i].SalesTaxCode;
							oTaxCode.Text1 = d.results[i].Text1;
							oTaxCode.Lstml = d.results[i].Lstml;
							oTaxCode.Stceg = d.results[i].Stceg;
							mArrayOut.push(oTaxCode);
						}
						oBrfModel.setProperty("/oVisibleSet/visibleTaxInfo", true);
						oBrfModel.setProperty("/Tax_CodeSet", mArrayOut);
					}
					//oBrfModel.refresh(true);
				}, this);
				var fnError = jQuery.proxy(function (d) {
					var r = JSON.parse(JSON.stringify(d));
					sap.ui.core.BusyIndicator.hide();
					MessageToast.show(r.message, {
						autoClose: true,
						width: "20rem"
					});
				}, this);
				var aFilterStr = [];
				var oFilterSerach;
				if (oSearchData.Lstml) {
					oSearchData.Lstml = formatter.formatValueToString(oSearchData.Lstml); /*Change added by developer Satabdi Das on 25-May-2021 for HTTP Error*/
					oFilterSerach = new sap.ui.model.Filter("Lstml", sap.ui.model.FilterOperator.EQ, oSearchData.Lstml);
					aFilterStr.push(oFilterSerach);

					var oFilterStr = new sap.ui.model.Filter({
						filters: aFilterStr,
						and: true
					});

					aFilter.push(oFilterStr);
				}
				/*Start of changes for new comp code 9921 by developer Satabdi Das*/
				if (sCompCode && sCompCode !== "") {
					sCompCode = formatter.formatValueToString(sCompCode); /*Change added by developer Satabdi Das on 25-May-2021 for HTTP Error*/
					aFilter.push(new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.EQ, sCompCode));
				}
				/*End of changes for new comp code 9921 by developer Satabdi Das*/
				var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_BRF_SRV/", {
					json: true
				});
				oModel1.read("/Tax_CodeSet?$skip=0&$top=50", {
					filters: aFilter,
					success: fnSuccess,
					error: fnError
				});
			}
		},
		onSelectTaxCode: function (oEvent) {
			var sTaxCode = oEvent.getSource().getBindingContext("oBrfModel").getObject();
			var oBrfModel = this.getView().getModel("oBrfModel");
			var reqMF = oBrfModel.getProperty("/lineItemBRFSet").RequestingMf;
			if (sTaxCode && this.taxCode) {
				if (this.taxCode === "SalesTaxCodeGF") {
					this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/SalesTaxCode", sTaxCode.SalesTaxCode);
				} else if (this.taxCode === "VatSapCodeMF") {
					oBrfModel.setProperty("/lineItemBRFSet/KpmgiVatId", sTaxCode.Stceg);
					oBrfModel.setProperty("/lineItemBRFSet/VatSapCode", sTaxCode.SalesTaxCode);
					this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/VatDesc", sTaxCode.Text1);
				}
			}
			this.getView().getModel("oBrfModel").setProperty("/Tax_CodeSet", []);
			this.getView().getModel("oBrfModel").setProperty("/TaxHdrSet", {});
			this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/visibleTaxInfo", false);
			if (this._oSeachTaxCode) {
				this._oSeachTaxCode.close();
			}

			oBrfModel.setProperty("/SelcKeySetBRF", reqMF);
		},
		onCloseTaxHelp: function () {
			this.getView().getModel("oBrfModel").setProperty("/Tax_CodeSet", []);
			this.getView().getModel("oBrfModel").setProperty("/TaxHdrSet", {});
			this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/visibleTaxInfo", false);
			if (this._oSeachTaxCode) {
				this._oSeachTaxCode.close();
			}
		},
		onPressDocNoHelp: function (oEvent) {

			var oBrfModel = this.getView().getModel("oBrfModel");
			var oHeaderCompanyCode = oBrfModel.getProperty("/brfHeaderSet").CompanyCode;
			oBrfModel.setProperty("/DocumentHdrSet/Bukrs", oHeaderCompanyCode);
			oBrfModel.setProperty("/brfHeaderSet/BukrsUrn", "");
			oBrfModel.setProperty("/brfHeaderSet/Urn", "");
			oBrfModel.setProperty("/brfHeaderSet/SapDocYear", "");
			oBrfModel.setProperty("/brfHeaderSet/DocCurrency", "");
			oBrfModel.setProperty("/brfHeaderSet/NetAmount", "");
			oBrfModel.setProperty("/brfHeaderSet/InvoiceAmount", "");
			/*End defect 63445*/
			var fragmentId = this.getView().createId("searchDocNo");
			if (!this._oSearchDocNo) {
				this._oSearchDocNo = sap.ui.xmlfragment(fragmentId, "KGO.kgoarrecharge_brf.view.SAPDocNoHelp", this);
				this.getView().addDependent(this._oSearchDocNo);
			}
			this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/visibleDocInfo", false);
			this._oSearchDocNo.open();

		},
		onDocNoHelp: function (oEvent) {
			var bDisplay = this.getView().getModel("oBrfModel").getProperty("/Display");
			var sFragTxt = this.getView().getModel("oBrfModel").getProperty("/fraggmentText"); //added for Reissuance visible by Satabdi Das on  14-Dec-2020
			if (bDisplay === false || sFragTxt === "REISSUANCE") { //added for Reissuance visible by Satabdi Das on  14-Dec-2020
				var oBrfModel = this.getModel("oBrfModel");
				sap.ui.core.BusyIndicator.show(0);
				var oSearchData = this.getView().getModel("oBrfModel").getProperty("/DocumentHdrSet");
				var mArrayOut = [];
				var fnSuccess = jQuery.proxy(function (d) {
					sap.ui.core.BusyIndicator.hide(0);
					if (d.results.length === 0) {
						var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
						MessageBox.alert(
							"No results found.", {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}
						);
					} else {
						for (var i = 0; i < d.results.length; i++) {
							var oDocNo = {};
							oDocNo.Bukrs = d.results[i].Bukrs;
							oDocNo.Urn = d.results[i].Urn;
							oDocNo.SapDocNum = d.results[i].SapDocNum;
							oDocNo.SapDocYear = d.results[i].SapDocYear;
							oDocNo.DocType = d.results[i].DocType;
							/*oDocNo.GrossAmtLocal = d.results[i].GrossAmtLocal;
							oDocNo.CurrencyLocal = d.results[i].CurrencyLocal;*/
							oDocNo.NetAmount = d.results[i].NetAmount;
							oDocNo.DocCurrency = d.results[i].DocCurrency;
							oDocNo.Vendor = d.results[i].Vendor;
							oDocNo.Flag = d.results[i].Flag;
							mArrayOut.push(oDocNo);
						}
						oBrfModel.setProperty("/oVisibleSet/visibleDocInfo", true);
						oBrfModel.setProperty("/DocumentnoSet", mArrayOut);

					}
					oBrfModel.refresh(true);
				}, this);
				var fnError = jQuery.proxy(function (d) {
					var r = JSON.parse(JSON.stringify(d));
					sap.ui.core.BusyIndicator.hide();
					MessageToast.show(r.message, {
						autoClose: true,
						width: "20rem"
					});
				}, this);
				var sPath = "/DocumentnoSet?$skip=0&$top=50";
				var aFilter = [];
				var aFilterStr = [];
				var oFilterSerach;
				if (oSearchData.Urn || oSearchData.Bukrs || oSearchData.SapDocYear || oSearchData.DocType || oSearchData.Vendor) {
					if (oSearchData.Urn) {
						oSearchData.Urn = formatter.formatValueToString(oSearchData.Urn); /*Change added by developer Satabdi Das on 25-May-2021 for HTTP Error*/
						oFilterSerach = new sap.ui.model.Filter("Urn", sap.ui.model.FilterOperator.EQ, oSearchData.Urn);
						aFilterStr.push(oFilterSerach);
					}
					if (oSearchData.Bukrs) {
						oSearchData.Bukrs = formatter.formatValueToString(oSearchData.Bukrs); /*Change added by developer Satabdi Das on 25-May-2021 for HTTP Error*/
						oFilterSerach = new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.EQ, oSearchData.Bukrs);
						aFilterStr.push(oFilterSerach);
					}
					if (oSearchData.SapDocYear) {
						oSearchData.SapDocYear = formatter.formatValueToString(oSearchData.SapDocYear); /*Change added by developer Satabdi Das on 25-May-2021 for HTTP Error*/
						oFilterSerach = new sap.ui.model.Filter("SapDocYear", sap.ui.model.FilterOperator.EQ, oSearchData.SapDocYear);
						aFilterStr.push(oFilterSerach);
					}
					if (oSearchData.DocType) {
						oSearchData.DocType = formatter.formatValueToString(oSearchData.DocType); /*Change added by developer Satabdi Das on 25-May-2021 for HTTP Error*/
						oFilterSerach = new sap.ui.model.Filter("DocType", sap.ui.model.FilterOperator.EQ, oSearchData.DocType);
						aFilterStr.push(oFilterSerach);
					}
					if (oSearchData.Vendor) {
						oSearchData.Vendor = formatter.formatValueToString(oSearchData.Vendor); /*Change added by developer Satabdi Das on 25-May-2021 for HTTP Error*/
						oFilterSerach = new sap.ui.model.Filter("Vendor", sap.ui.model.FilterOperator.EQ, oSearchData.Vendor);
						aFilterStr.push(oFilterSerach);
					}
					var oFilterStr = new sap.ui.model.Filter({
						filters: aFilterStr,
						and: true
					});
					aFilter.push(oFilterStr);
				}
				// var sParams = [];
				// var oObject = {};
				// sParams.push("$skip=0");
				// sParams.push("$top=50");
				// oObject.Filter = aFilter;
				// oObject.Params = sParams;
				// oObject.successCallback = fnSuccess;
				// oObject.errorCallback = fnError;
				// oObject.sPath = sPath;
				// DataManagerBrf.getCoupaCreateHelp(oObject);
				/*R&D---start*/
				var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_BRF_SRV/", {
					json: true
				});
				oModel1.read("/DocumentnoSet?$skip=0&$top=50", {
					filters: aFilter,
					success: fnSuccess,
					error: fnError
				});
				/*R&D---end*/
			}
		},
		onDocNoSelect: function (oEvent) {
			var oDocNo = oEvent.getSource().getBindingContext("oBrfModel").getObject();
			if (oDocNo.Flag === "X") {
				MessageBox.information("URN number " + oDocNo.Urn + " has been used in other BRF please select other one. ");
				return;
			}
			if (oDocNo) {
				this.getView().getModel("oBrfModel").setProperty("/brfHeaderSet/BukrsUrn", oDocNo.Bukrs);
				this.getView().getModel("oBrfModel").setProperty("/brfHeaderSet/Urn", oDocNo.Urn);
				this.getView().getModel("oBrfModel").setProperty("/brfHeaderSet/SapDocNum", oDocNo.SapDocNum);
				this.getView().getModel("oBrfModel").setProperty("/brfHeaderSet/SapDocYear", oDocNo.SapDocYear);
				/*this.getView().getModel("oBrfModel").setProperty("/brfHeaderSet/CurrencyLocal", oDocNo.CurrencyLocal);
				this.getView().getModel("oBrfModel").setProperty("/brfHeaderSet/GrossAmtLocal", oDocNo.GrossAmtLocal);*/
				this.getView().getModel("oBrfModel").setProperty("/brfHeaderSet/DocCurrency", oDocNo.DocCurrency);
				this.getView().getModel("oBrfModel").setProperty("/brfHeaderSet/NetAmount", oDocNo.NetAmount);
			}
			this.getView().getModel("oBrfModel").setProperty("/DocumentnoSet", []);
			this.getView().getModel("oBrfModel").setProperty("/DocumentHdrSet", {});
			this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/visibleDocInfo", false);

			if (this._oSearchDocNo) {
				this._oSearchDocNo.close();
			}
		},
		onCloseDocNoHelp: function () {
			this.getView().getModel("oBrfModel").setProperty("/DocumentnoSet", []);
			this.getView().getModel("oBrfModel").setProperty("/DocumentHdrSet", {});
			this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/visibleDocInfo", false);
			if (this._oSearchDocNo) {
				this._oSearchDocNo.close();
			}
		},
		//added by prashantkumar 05.01.2021
		onSelectCreditNoteType: function (oEvent) {
			var oBrfModel = this.getView().getModel("oBrfModel");
			var oSelectedCreditNoteType = oEvent.getParameter("value");
			var RemainingCNAmt = oBrfModel.getProperty("/oReSetDataOfCN").oRemainingCNAmt;
			if (oSelectedCreditNoteType === "Full") {
				oBrfModel.setProperty("/oVisibleSet/creditNoteAmount", false);
				oBrfModel.setProperty("/lineItemBRFSet/RechargeAmountCredit", RemainingCNAmt);
				oBrfModel.setProperty("/lineItemBRFSet/RechargeAmountDebit", RemainingCNAmt);

			} else {
				oBrfModel.setProperty("/oVisibleSet/creditNoteAmount", true);
			}
		},
		//end of changes
		//added by prashant for Ltt Revie change 30.09.2020
		onLttCheckBoxSelected: function (oEvent) {
			//var oSelectedCheckBoxPath=oEvent.getSource().getBindingContext("oBrfModel").sPath;
			var oSelectedRowValue = oEvent.getSource().getBindingContext("oBrfModel").getObject();
			var oSelectedCheckBox = oEvent.getSource().getProperty("selected");
			if (oSelectedCheckBox === true) {
				oSelectedRowValue.Ltt = "X";
			} else {
				oSelectedRowValue.Ltt = "";
			}

		},
		onSelectLttFromFragment: function (oEvent) {
			var oLttCheckbox = oEvent.getSource().getProperty("selected");
			if (oLttCheckbox === true) {
				this.oStoreData.Ltt = "X";
			} else {
				this.oStoreData.Ltt = "";
			}

			// var z = this.oStorePath.split("/")[2];
			//  z = parseInt(z);
			// var oLttCheckbox =oEvent.getSource().getProperty("selected");
			// var oLineTbl = this.getView().byId('tableid');
			// for (var i = 0; i < oLineTbl.getItems().length; i++) {
			// 	if (oLineTbl.getBindingInfo("items").binding.oList[i].RequestingMf && oLineTbl.getBindingInfo("items").binding.oList[i].RequestingMf !=
			// 		"N/A") {
			// 			if(i===z){
			// 		for (var k = 0; k < oLineTbl.getAggregation("items")[i].getCells().length; k++) {
			// 			if (k === 6) {
			// 					if (oLttCheckbox === true) {
			// 						oLineTbl.getAggregation("items")[i].getCells()[k].setProperty("selected", true);
			// 						this.getView().getModel("oBrfModel").getProperty("/brfTableSet")[i].Ltt = "X";
			// 					} else {
			// 						oLineTbl.getAggregation("items")[i].getCells()[k].setProperty("selected", false);
			// 						this.getView().getModel("oBrfModel").getProperty("/brfTableSet")[i].Ltt = "";
			// 					}

			// 			}

			// 		}
			// 			}
			// 	}
			// }
			// this.getView().getModel("oBrfModel").refresh();

		},

		//end of ltt changes
		/*Start of change on 25-May-2020*/
		onSelectNatureOfService: function (oEvent) {
			// var sComboBoxItemText = oEvent.getParameter("selectedItem").getProperty("text");
			// var sComboKey = oEvent.getParameter("selectedItem").getProperty("key");
			var sComboBoxItemText = oEvent.getParameter("value");
			this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/NatureOfService", sComboBoxItemText);
			// if (sComboKey === "A") {
			// this.getModel("oBrfModel").setProperty("/LastDateSrv", true);
			// this.getModel("oBrfModel").setProperty("/DateMandatory", true);
			if (sComboBoxItemText === "Adhoc/One-Off") {
				var createBrfFragment = this.getView().createId("createBrfFragment");
				var oDatePicker1 = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "LastDateSrv"));
				this.getModel("oBrfModel").setProperty("/LastDateSrv", true);
				this.getModel("oBrfModel").setProperty("/DateMandatory", true);
				/*jQuery.sap.delayedCall(1000, this, function () {
					if (oDatePicker1) {
						var objDate1 = oDatePicker1.getDomRef();
						if (objDate1) {
							objDate1.firstElementChild.firstChild.setAttribute("readonly", true);
							//objDate1.children[1].setAttribute("readonly", true);
						}
					}
				});*/

				// var LastDateSrv = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "LastDateSrv"));
				// LastDateSrv.addEventDelegate({
				// 	onAfterRendering: function () {
				// 		var oYear = this.$().find('.sapMInputBaseInner');
				// 		var oID = oYear[0].id;
				// 		$('#' + oID).attr("disabled", "disabled");
				// 	}
				// }, LastDateSrv);

				// var oNature = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "Nature"));
				// oNature.addEventDelegate({
				// 	onAfterRendering: function () {
				// 		var oYear = this.$().find('.sapMInputBaseInner');
				// 		var oID = oYear[0].id;
				// 		$('#' + oID).attr("disabled", "disabled");
				// 	}
				// }, oNature);

			}
			// else if (sComboKey === "C") {
			else if (sComboBoxItemText === "Continuous") {
				this.getModel("oBrfModel").setProperty("/LastDateSrv", false);
				this.getModel("oBrfModel").setProperty("/lineItemBRFSet/LastDateSrv", "");
				this.getModel("oBrfModel").setProperty("/DateMandatory", false);
			}

			jQuery.sap.delayedCall(1000, this, function () {
				var oNature = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "Nature"));
				if (oNature) {
					var objNature1 = oNature.getDomRef();
					if (objNature1) {
						objNature1.firstElementChild.firstChild.setAttribute("readonly", true);
					}
				}

				var oLastDateSrv = this.byId(sap.ui.core.Fragment.createId(createBrfFragment, "LastDateSrv"));
				if (oLastDateSrv) {
					var objLastDateSrv = oLastDateSrv.getDomRef();
					if (objLastDateSrv) {
						objLastDateSrv.firstElementChild.firstChild.setAttribute("readonly", true);
					}
				}

			});
		},
		checkExpand: function (oEvent) {
			var oBrfModel = this.getView().getModel("oBrfModel");
			var bDisplay = oBrfModel.getProperty("/Display");
			if (bDisplay === false && oEvent.getParameters().expand === true) {
				var oLineItemData = this.getView().getModel("oBrfModel").getProperty("/lineItemBRFSet");

				if (oBrfModel.getProperty("/oVisibleSet/lineItemVisibleForMF") === true) {

					if (oLineItemData.ProcessGrp === undefined || oLineItemData.ProcessGrp === "" || oLineItemData.RequestingMf === "" ||
						oLineItemData.RequestingMf === undefined) {
						oEvent.getSource().setExpanded(false);
						MessageBox.alert("Please enter mandatory fields.");
						return;
					}
				}
				if (oBrfModel.getProperty("/oVisibleSet/lineItemVisibleForGF") === true) {
					if (oLineItemData.GlobalCc === undefined || oLineItemData.GlobalCc === "") {
						MessageBox.alert("Please enter mandatory fields.");
						oEvent.getSource().setExpanded(false);
						return;
					}
				}
			}
		},
		getRemainingCharLineItem: function (value, maxLength) {

			var remainingLength = maxLength;
			if (value && value !== "") {
				var charLength = value.length;
				remainingLength = maxLength - charLength;
			}
			return remainingLength + " characters remaining";
		},
		handleLiveLongText: function (event) {
			var maxCharLimit = event.getSource().getProperty("maxLength");
			var longText = event.getParameters().value;
			if (longText.length > maxCharLimit) {
				event.getSource().setValue(longText.substring(0, maxCharLimit));
			} else {
				event.getSource().setValue(longText);
			}
		}

		/*End of change on 25-May-2020*/
		/*Start of defect 63331*/
		// onCheckServiceStrtDate: function (oEvent) {
		// 	var ServicePeriodStartDate = oEvent.getParameter("selectedItem").getProperty("text");
		// 	var sID = oEvent.getParameter("id").split("--")[3];
		// 	var ServicePeriodEndDate;
		// 	var checkDate;
		// 	var msg;
		// 	var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
		// 	if (sID === "ServicePeriodStart" || sID === "ServicePeriodStartMF") {
		// 		ServicePeriodEndDate = this.getView().getModel("oBrfModel").getProperty("/lineItemBRFSet/ServicePeriodEnd");
		// 		if (ServicePeriodEndDate !== "") {
		// 			checkDate = ServicePeriodEndDate - ServicePeriodStartDate;
		// 		}
		// 		if (checkDate < 0) {
		// 			msg = this.getView().getModel("i18n").getProperty("SrvStartDateAtert");
		// 			MessageBox.alert(
		// 				msg, {
		// 					styleClass: bCompact ? "sapUiSizeCompact" : ""
		// 				}
		// 			);
		// 			this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/ServicePeriodStart", "");
		// 		} else {
		// 			this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/ServicePeriodStart", ServicePeriodStartDate);
		// 		}
		// 	} else if (sID === "ServicePeriodStartCR") {
		// 		ServicePeriodEndDate = this.getView().getModel("oBrfModel").getProperty("/lineItemBRFSet/ServicePeriodEndCredit");
		// 		if (ServicePeriodEndDate !== "") {
		// 			checkDate = ServicePeriodEndDate - ServicePeriodStartDate;
		// 		}
		// 		if (checkDate < 0) {
		// 			msg = this.getView().getModel("i18n").getProperty("SrvStartDateAtert");
		// 			MessageBox.alert(
		// 				msg, {
		// 					styleClass: bCompact ? "sapUiSizeCompact" : ""
		// 				}
		// 			);
		// 			this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/ServicePeriodStartCredit", "");
		// 		} else {
		// 			this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/ServicePeriodStartCredit", ServicePeriodStartDate);
		// 		}
		// 	}
		// },
		// oncheckServiceEndDate: function (oEvent) {
		// 	var ServicePeriodEndDate = oEvent.getParameter("selectedItem").getProperty("text");
		// 	var sID = oEvent.getParameter("id").split("--")[3];
		// 	var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
		// 	var msg;
		// 	var ServicePeriodStartDate;
		// 	var checkDate;
		// 	if (sID === "ServicePeriodEnd" || sID === "ServicePeriodEndMF") {
		// 		ServicePeriodStartDate = this.getView().getModel("oBrfModel").getProperty("/lineItemBRFSet/ServicePeriodStart");
		// 		checkDate = ServicePeriodEndDate - ServicePeriodStartDate;
		// 		if (checkDate < 0) {
		// 			msg = this.getView().getModel("i18n").getProperty("SrvEndDateAtert");
		// 			MessageBox.alert(
		// 				msg, {
		// 					styleClass: bCompact ? "sapUiSizeCompact" : ""
		// 				}
		// 			);
		// 			// return;
		// 			this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/ServicePeriodEnd", "");
		// 		} else {
		// 			this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/ServicePeriodEnd", ServicePeriodEndDate);
		// 		}
		// 	} else if (sID === "ServicePeriodEndCR") {
		// 		ServicePeriodStartDate = this.getView().getModel("oBrfModel").getProperty("/lineItemBRFSet/ServicePeriodStartCredit");
		// 		checkDate = ServicePeriodEndDate - ServicePeriodStartDate;
		// 		if (checkDate < 0) {
		// 			msg = this.getView().getModel("i18n").getProperty("SrvEndDateAtert");
		// 			MessageBox.alert(
		// 				msg, {
		// 					styleClass: bCompact ? "sapUiSizeCompact" : ""
		// 				}
		// 			);
		// 			// return;
		// 			this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/ServicePeriodEndCredit", "");
		// 		} else {
		// 			this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/ServicePeriodEndCredit", ServicePeriodEndDate);
		// 		}
		// 	}
		// },
		/*End of defect 63331*/

	});
});