sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"sap/m/MessageToast",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"KGO/kgoarrecharge_brf/formatter/formatter",
	"sap/m/MessageBox",
	"sap/ui/core/Fragment",
	"KGO/kgoarrecharge_brf/util/DataManagerBrf",
	"sap/ui/core/UIComponent"
], function (Controller, History, MessageToast, JSONModel, Filter, FilterOperator, formatter, MessageBox, Fragment, DataManagerBrf,
	UIComponent) {
	"use strict";
	return Controller.extend("kgo.ARRecharge.controller.BaseController", {

		/**
		 * Convenience method for accessing the router in every controller of the application.
		 * @public
		 * @returns {sap.ui.core.routing.Router} the router for this component
		 */
		getRouter: function () {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},

		/**
		 * Convenience method for getting the view model by name in every controller of the application.
		 * @public
		 * @param {string} sName the model name
		 * @returns {sap.ui.model.Model} the model instance
		 */
		getModel: function (sName) {
			return this.getView().getModel(sName);
		},

		/**
		 * Convenience method for setting the view model in every controller of the application.
		 * @public
		 * @param {sap.ui.model.Model} oModel the model instance
		 * @param {string} sName the model name
		 * @returns {sap.ui.mvc.View} the view instance
		 */
		setModel: function (oModel, sName) {
			return this.getView().setModel(oModel, sName);
		},

		/**
		 * Convenience method for getting the resource bundle.
		 * @public
		 * @returns {sap.ui.model.resource.ResourceModel} the resourceModel of the component
		 */
		getResourceBundle: function () {
			return this.getOwnerComponent().getModel("i18n").getResourceBundle();
		},

		/**
		 * Event handler for navigating back.
		 * It there is a history entry or an previous app-to-app navigation we go one step back in the browser history
		 * If not, it will replace the current entry of the browser history with the master route.
		 * @public
		 */
		onNavBack: function () {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				this.getRouter().navTo("appHome", {}, true);
			}
		},
		createHelpRRF: function (oEvent) {

			sap.ui.core.BusyIndicator.show(0);

			var aFilter = [];

			var sPath = "";

			sPath = "/RRF_NOSet"; // + Constant.CV_PV_LEAD_FIORI;

			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				/*Start change on 08-May-2020*/
				for (var i = 0; i < d.results.length; i++) {
					d.results[i].RrfCreationDate = formatter.formatBrfCreationDate(d.results[i].RrfCreationDate);
				}
				/*End change on 08-May-2020*/

				var oBrfModel = this.getView().getModel("oBrfModel");
				oBrfModel.setProperty("/RRF_NOSet", d.results);
				var fragmentIdRRF = this.getView().createId("searchRRFNo");

				if (!this._oSearchCoordinatorForRRF) {
					this._oSearchCoordinatorForRRF = sap.ui.xmlfragment(fragmentIdRRF, "KGO.kgoarrecharge_brf.view.searchHelpRRF", this);
					this.getView().addDependent(this._oSearchCoordinatorForRRF);
				}
				this.byId(sap.ui.core.Fragment.createId(fragmentIdRRF, "flexboxRRFNumTable")).setVisible(true);
				this.byId(sap.ui.core.Fragment.createId(fragmentIdRRF, "flexboxBRFTable")).setVisible(false);
				var sRrfTxt = this.getView().getModel("i18n").getProperty("RRF");
				oBrfModel.setProperty("/setHelpText", sRrfTxt);
				this._oSearchCoordinatorForRRF.open();
				this.onSearchRRFNo();

			}, this);

			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();

				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"

				});
			}, this);

			// var oObject = {};

			// oObject.successCallback = fnSuccess;
			// oObject.errorCallback = fnError;
			// oObject.sPath = sPath;
			// DataManagerBrf.getCoupaCreateHelp(oObject);
			/*R&D---start*/
			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_BRF_SRV/", {
				json: true
			});
			oModel1.read("/RRF_NOSet", {
				success: fnSuccess,
				error: fnError
			});
			/*R&D---end*/

		},
		onSearchRRFNo: function (oEvent) {
			var aFilter = [];

			if (this.getView().getModel("oBrfModel").getProperty("/localBRFSearch")) {
				var sQuery = this.getView().getModel("oBrfModel").getProperty("/localBRFSearch");
				sQuery = sQuery.trim();
			}
			if (sQuery && sQuery.length > 0) {
				aFilter.push(new Filter("RrfNo", FilterOperator.Contains, sQuery));
			}
			var fragmentIdRRF = this.getView().createId("searchRRFNo");
			var table = sap.ui.core.Fragment.byId(fragmentIdRRF, "tableRrfSearch");
			var oBinding = table.getBinding("items");
			oBinding.filter(aFilter, "Application");
		},

		onRRFSelect: function (oEvent) {
			var oRowData = oEvent.getSource().getBindingContext("oBrfModel").getObject();
			if (oRowData) {
				var fragId = this.getView().createId("searchRRFNo");
				var SearchId = sap.ui.core.Fragment.byId(fragId, "searchRRF");
				SearchId.setValue("");
				var aFilter = [];
				aFilter.push(new Filter("RrfNo", FilterOperator.Contains, ""));
				var fragmentIdRRF = this.getView().createId("searchRRFNo");
				var table = sap.ui.core.Fragment.byId(fragmentIdRRF, "tableRrfSearch");
				var oBinding = table.getBinding("items");
				oBinding.filter(aFilter, "Application");
				this._oSearchCoordinatorForRRF.close();
				this.getView().getModel("oBrfModel").setProperty("/localBRFSearch", "");
				this.getView().getModel("oBrfModel").setProperty("/RRF_NOSet", []);
				this.getView().getModel("oBrfModel").setProperty("/brfHeaderSet/RrfNo", oRowData.RrfNo);
			}
		},
		OnSearchHelpBRFNo: function (oEvent) {

			sap.ui.core.BusyIndicator.show(0);

			var aFilter = [];

			var sPath = "";

			sPath = "/BRF_NOSet"; // + Constant.CV_PV_LEAD_FIORI;

			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				var oBrfModel = this.getView().getModel("oBrfModel");
				oBrfModel.setProperty("/brfHeaderSet/BrfNo", "");
				oBrfModel.setProperty("/RRF_NOSet", d.results);
				var fragmentIdRRF = this.getView().createId("searchRRFNo");

				if (!this._oSearchCoordinatorForRRF) {
					this._oSearchCoordinatorForRRF = sap.ui.xmlfragment(fragmentIdRRF, "KGO.kgoarrecharge_brf.view.searchHelpRRF", this);
					this.getView().addDependent(this._oSearchCoordinatorForRRF);
				}
				this.byId(sap.ui.core.Fragment.createId(fragmentIdRRF, "flexboxBRFTable")).setVisible(true);
				this.byId(sap.ui.core.Fragment.createId(fragmentIdRRF, "flexboxRRFNumTable")).setVisible(false);
				var sBrfTxt = this.getView().getModel("i18n").getProperty("BRF");
				oBrfModel.setProperty("/setHelpText", sBrfTxt);
				this._oSearchCoordinatorForRRF.open();
				this.onSearchBRFNo();

			}, this);

			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();

				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"

				});
			}, this);

			// var oObject = {};

			// oObject.successCallback = fnSuccess;
			// oObject.errorCallback = fnError;
			// oObject.sPath = sPath;
			// DataManagerBrf.getCoupaCreateHelp(oObject);
			/*R&D---start*/
			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_BRF_SRV/", {
				json: true
			});
			oModel1.read("/BRF_NOSet", {
				success: fnSuccess,
				error: fnError
			});
			/*R&D---end*/

		},
		//added by prashant for other edit options
		OnSearchHelpRRFNo: function (oEvent) {

			sap.ui.core.BusyIndicator.show(0);

			var aFilter = [];
			var oBrfModel = this.getView().getModel("oBrfModel");

			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				oBrfModel.setProperty("/BrfCreatorSet", d.results);
				var oRRFFragment = this.getView().createId("RRFNumberSearch2");
				if (!this._oSearchterminatorForRRF) {
					this._oSearchterminatorForRRF = sap.ui.xmlfragment(oRRFFragment, "KGO.kgoarrecharge_brf.view.rrfNumberSearchHelp", this);
					this.getView().addDependent(this._oSearchterminatorForRRF);
				}
				/*Start of change by Satabdi Das on 04-Sep-2020*/
				if (this.oSelectedRadiobatton === 1) {
					var sRrfTxt = this.getView().getModel("i18n").getProperty("RRFNumber");
					oBrfModel.setProperty("/setPlaceHolderText", sRrfTxt);

				} else if (this.oSelectedRadiobatton === 2) {
					var sBrfTxt = this.getView().getModel("i18n").getProperty("BRFCreatedBy");
					oBrfModel.setProperty("/setPlaceHolderText", sBrfTxt);
				}
				/*End of change by Satabdi Das on 04-Sep-2020*/

				this._oSearchterminatorForRRF.open();
				this.onLiveChangSearch();

			}, this);

			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();

				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"

				});
			}, this);

			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_BRF_SRV/", {
				json: true
			});
			/*Start of change by developer Satabdi Das on 03-Sep-2020*/
			if (oBrfModel.getProperty("/oVisibleRRF") === true) {
				var flag = "X";
				aFilter.push(new Filter("Flag", FilterOperator.EQ, flag));
				oModel1.read("/BRF_CreatorSet", {
					filters: aFilter,
					success: fnSuccess,
					error: fnError
				});
			} else {
				oModel1.read("/BRF_CreatorSet", {
					success: fnSuccess,
					error: fnError
				});
			}
			/*End of change by developer Satabdi Das on 03-Sep-2020*/
		},
		//end of changes
		onCloseRRFSearchHelp: function (oEvent) {

			var oBrfModel = this.getView().getModel("oBrfModel");
			oBrfModel.setProperty("localBRFSearch", "");

			if (this._oSearchterminatorForRRF) {
				this._oSearchterminatorForRRF.close();
				this.getView().getModel("oBrfModel").setProperty("/localBRFSearch", "");
			}
		},

		brfMFSearchHelp: function (oEvent) {
			sap.ui.core.BusyIndicator.show(0);
			// var sPath = "";
			// sPath = "/BRF_MFSet"; // + Constant.CV_PV_LEAD_FIORI;
			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				var oBrfModel = this.getView().getModel("oBrfModel");
				oBrfModel.setSizeLimit(500);
				oBrfModel.setProperty("/BRF_MF", d.results);
				this.getView().getModel("oBrfModel").setProperty("/SelcKeySetBRF", "");
				this.getView().getModel("oBrfModel").setProperty("/SelcKeyForLocServ", "");
				this.getView().getModel("oBrfModel").refresh(true);
			}, this);
			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();
				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"
				});
			}, this);
			// var oObject = {};
			// oObject.successCallback = fnSuccess;
			// oObject.errorCallback = fnError;
			// oObject.sPath = sPath;
			// DataManagerBrf.getCoupaCreateHelp(oObject);
			/*R&D---start*/
			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_BRF_SRV/", {
				json: true
			});
			oModel1.read("/Member_FirmSet", {
				success: fnSuccess,
				error: fnError
			});
			/*R&D---end*/
		},

		onCloseHelpRRF: function (oEvent) {
			var fragId = this.getView().createId("searchRRFNo");
			var SearchId = sap.ui.core.Fragment.byId(fragId, "localBRFSearch");
			SearchId.setValue("");
			var aFilter = [];
			aFilter.push(new Filter("BrfNo", FilterOperator.Contains, ""));
			var frag = this.getView().createId("searchRRFNo");
			var table = sap.ui.core.Fragment.byId(frag, "tableBRFSerch");
			var oBinding = table.getBinding("items");
			oBinding.filter(aFilter, "Application");
			this._oSearchCoordinatorForRRF.close();
			this.getView().getModel("oBrfModel").setProperty("/RRF_NOSet", []);
			this.getView().getModel("oBrfModel").setProperty("/localBRFSearch", "");

		},
		onSelectBRFNumber: function (oEvent) {
			var oRowData = oEvent.getSource().getBindingContext("oBrfModel").getObject();
			var fragId = this.getView().createId("searchRRFNo");
			var SearchId = sap.ui.core.Fragment.byId(fragId, "localBRFSearch");
			SearchId.setValue("");
			var aFilter = [];
			aFilter.push(new Filter("BrfNo", FilterOperator.Contains, ""));
			var frag = this.getView().createId("searchRRFNo");
			var table = sap.ui.core.Fragment.byId(frag, "tableBRFSerch");
			var oBinding = table.getBinding("items");
			oBinding.filter(aFilter, "Application");
			if (oRowData) {
				this._oSearchCoordinatorForRRF.close();
				this.getView().getModel("oBrfModel").setProperty("/localBRFSearch", "");
				this.getView().getModel("oBrfModel").setProperty("/brfHeaderSet/BrfNo", oRowData.BrfNo);
			}
		},
		onSearchBRFNo: function (oEvent) {

			var aFilter = [];

			if (this.getView().getModel("oBrfModel").getProperty("/localBRFSearch")) {
				var sQuery = this.getView().getModel("oBrfModel").getProperty("/localBRFSearch");
				sQuery = sQuery.trim();
			}
			if (sQuery && sQuery.length > 0) {
				aFilter.push(new Filter("BrfNo", FilterOperator.Contains, sQuery));
			}
			var fragmentIdRRF = this.getView().createId("searchRRFNo");
			var table = sap.ui.core.Fragment.byId(fragmentIdRRF, "tableBRFSerch");
			var oBinding = table.getBinding("items");
			oBinding.filter(aFilter, "Application");

		},
		handlePressEditBRF: function (oEvent) {
			//code added by prashant for other edit options on 28.08.2020
			//checking authorization
			var oBrfModel = this.getView().getModel("oBrfModel");
			var oAuthAccess = oBrfModel.getProperty("/authoSet");
			if (oAuthAccess.GpEditDisplay) {
				if (((this.oSelectedRadiobatton === 1) || (this.oSelectedRadiobatton === 2)) && (oEvent)) {
					var oLiveSearchText;
					var oBrfModel = this.getView().getModel("oBrfModel");
					oBrfModel.setProperty("/oVisibleSet/displayLinkShow", false);
					oBrfModel.setProperty("/oVisibleSet/editLinkShow", true);
					var rrfNo = oBrfModel.getProperty("/brfHeaderSet").BrfNo;
					var sErrorMsg = this.getView().getModel("i18n").getProperty("noResultsError"); /*Added by Satabdi Das on 04-Sep-2020*/
					if (rrfNo !== "") { /*Added by Satabdi Das on 04-Sep-2020*/
						sap.ui.core.BusyIndicator.show(0);
						var aFilter = [];

						var fnSuccess = jQuery.proxy(function (d) {
							sap.ui.core.BusyIndicator.hide(0);
							if (d.results.length > 0) {
								oBrfModel.setProperty("/BrfCreatorSet", d.results);

								var oRRFFragment = this.getView().createId("RRFNumberSearch2");
								if (!this._oSearchterminatorForRRF) {
									this._oSearchterminatorForRRF = sap.ui.xmlfragment(oRRFFragment, "KGO.kgoarrecharge_brf.view.rrfNumberSearchHelp", this);
									this.getView().addDependent(this._oSearchterminatorForRRF);
								}
								this._oSearchterminatorForRRF.open();
								this.onLiveChangSearch();

							} else {
								MessageBox.error(sErrorMsg);
							}

						}, this);

						var fnError = jQuery.proxy(function (d) {
							var r = JSON.parse(JSON.stringify(d));
							sap.ui.core.BusyIndicator.hide();

							MessageToast.show(r.message, {
								autoClose: true,
								width: "20rem"

							});
						}, this);

						var oFilterSerach;
						if ((this.oSelectedRadiobatton == 1)) {
							oLiveSearchText = this.getView().getModel("i18n").getProperty("brfNumber");
							oBrfModel.setProperty("/setPlaceHolderText", oLiveSearchText);
							oFilterSerach = new sap.ui.model.Filter("RrfNo", sap.ui.model.FilterOperator.EQ, rrfNo);
							aFilter.push(oFilterSerach);
						} else if ((this.oSelectedRadiobatton == 2)) {
							oLiveSearchText = this.getView().getModel("i18n").getProperty("brfNumber");
							oBrfModel.setProperty("/setPlaceHolderText", oLiveSearchText);
							oFilterSerach = new sap.ui.model.Filter("BrfCreatedBy", sap.ui.model.FilterOperator.EQ, rrfNo);
							aFilter.push(oFilterSerach);
						}
						var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_BRF_SRV/", {
							json: true
						});
						oModel1.read("/BRF_CreatorSet", {
							filters: aFilter,
							success: fnSuccess,
							error: fnError
						});
						/*R&D---end*/
						/*Start of change by developer Satabdi Das on 04-Sep-2020*/
					} else {
						MessageBox.error(sErrorMsg);
					}
					/*End of change by developer Satabdi Das on 04-Sep-2020*/
				} //end of changes on 28.08.2020
				else {
					if (oAuthAccess.GpEditDisplay === "D" && oEvent) {
						var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
						MessageBox.error(
							"You are not authorized to edit/view this BRF.", {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}
						);
						return;
					}
					var that = this;
					var oBrfModel = this.getView().getModel("oBrfModel");
					// var bWithRef = oBrfModel.getProperty("/oVisibleSet/withRRF");
					var editBRFText = this.getView().getModel("i18n").getProperty("editBRFText");
					oBrfModel.setProperty("/setDashBoardTextForBRF", editBRFText);
					var title = this.getView().getModel("i18n").getProperty("title");
					var fisYr = this.getView().getModel("i18n").getProperty("fiscalyear");
					var year;
					var sHeading;
					this.getModel("oBrfModel").setProperty("/oVisibleSet/attachVisible", true);
					if (oEvent) {
						if ((!oBrfModel.getProperty("/brfHeaderSet").BrfNo) && (oEvent.getParameter("id").split("--")[2] !==
								"editBrfFragment")) {
							var getObjectVal = oEvent.getSource().getBindingContext("oBrfModel");
							if (!getObjectVal) {
								MessageBox.error("This BRF does not exist in the system.");
								return;
							} else {
								var oBRFNumber = getObjectVal.getObject();
								oBrfModel.setProperty("/brfHeaderSet/BrfNo", oBRFNumber.BrfNo);
							}

						}
					} else {
						if (((this.oSelectedRadiobatton === 1) || (this.oSelectedRadiobatton === 2))) {
							oBrfModel.setProperty("/brfHeaderSet/BrfNo", this.oBrfNumber);
						}
					}

					var oRouter = UIComponent.getRouterFor(this);
					this.brfMFSearchHelp();
					this.currencyDropDown();
					this.DocTypeDropDown(); /*Added on 15-Sep-2020 by Satabdi Das*/
					if (oBrfModel.getProperty("/brfHeaderSet").BrfNo) {
						var BrfNo = oBrfModel.getProperty("/brfHeaderSet").BrfNo;
						//start change
						var fnSuccess = jQuery.proxy(function (d) {
							sap.ui.core.BusyIndicator.hide(0);
							if (d.results.length !== 0) {
								if (!d.results[0].BrfNo) {
									MessageBox.error("This BRF does not exist in the system.");
									return;
								}
								var arrAnswer = [];
								var bFlag; /*Added on 06-MAY-2020*/
								if (d.results[0].RrfNo !== "" && d.results[0].RrfNo !== undefined) {
									this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/withRRF", true); /*Added by Satabdi Das on 28-Oct-2020 for defect 63391*/
									this.getModel("oBrfModel").setProperty("/oVisibleSet/buttonVis", false);
									oBrfModel.setProperty("/oVisibleSet/addIcon", false);
									oBrfModel.setProperty("/oVisibleSet/AddDisplIcon", false);
									oBrfModel.setProperty("/oVisibleSet/fieldEditable", false);
									oBrfModel.setProperty("/oVisibleSet/contrlNameEdit", false);
									if (d.results[0].RrfNo.indexOf("PO") >= 0) {
										this.getView().getModel("oBrfModel").setProperty("/PORef", true);
									} else {
										this.getView().getModel("oBrfModel").setProperty("/PORef", false);
									}

								} else {
									this.getModel("oBrfModel").setProperty("/oVisibleSet/buttonVis", true);
									this.getView().getModel("oBrfModel").setProperty("/PORef", false);
									this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/withRRF", false); /*Added by Satabdi Das on 28-Oct-2020 for defect 63391*/
								}
								if (d.results[0].Display === "X") {
									this.getModel("oBrfModel").setProperty("/Display", true);
									this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/editable", false);
									this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/vatEditDisplay", false);
									this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/vatEditDisplay", false);
									this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/fieldEditable", false);
									this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/contrlNameEdit", false);
									oBrfModel.setProperty("/oVisibleSet/sendToContrl", false);
									oBrfModel.setProperty("/oVisibleSet/sendToSupp", false);
									oBrfModel.setProperty("/oVisibleSet/sendToVat", false);
									oBrfModel.setProperty("/oVisibleSet/sendToAR", false);
									oBrfModel.setProperty("/oVisibleSet/sendToAprrv", false);

									if (this.getModel("oBrfModel").getProperty("/oVisibleSet").buttonVis === false) {
										oBrfModel.setProperty("/oVisibleSet/addIcon", false);
										oBrfModel.setProperty("/oVisibleSet/AddDisplIcon", false);
										oBrfModel.setProperty("/oVisibleSet/SuppForwardIcon", false); /*Added by Satabdi Das for defect 63391 on 28-Oct-2020*/
										oBrfModel.setProperty("/oVisibleSet/SuppDisplayFwdIcon", true); /*Added by Satabdi Das for defect 63391 on 28-Oct-2020*/

									} else {
										oBrfModel.setProperty("/oVisibleSet/SuppForwardIcon", false); /*Added by Satabdi Das for defect 63391 on 28-Oct-2020*/
										oBrfModel.setProperty("/oVisibleSet/SuppDisplayFwdIcon", false); /*Added by Satabdi Das for defect 63391 on 28-Oct-2020*/
										if (this.getView().getModel("oBrfModel").getProperty("/oDisplayBtnPress") === "true") {

											oBrfModel.setProperty("/oVisibleSet/addIcon", false);
											oBrfModel.setProperty("/oVisibleSet/AddDisplIcon", true);
											oBrfModel.setProperty("/oVisibleSet/enableAddMF", false);
											oBrfModel.setProperty("/oVisibleSet/enableAddGF", false);
										} else {
											oBrfModel.setProperty("/oVisibleSet/addIcon", true);
											oBrfModel.setProperty("/oVisibleSet/AddDisplIcon", false);
											oBrfModel.setProperty("/oVisibleSet/enableAddMF", true);
											oBrfModel.setProperty("/oVisibleSet/enableAddGF", true);
										}
									}

								} else {
									if ((oBrfModel.getProperty("/oDisplayBtnPress") === "false") || !this.getView().getModel(
											"oBrfModel").getProperty("/oDisplayBtnPress")) {
										this.getModel("oBrfModel").setProperty("/Display", false);
										this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/editable", true);
										oBrfModel.setProperty("/oVisibleSet/sendToContrl", true);
										oBrfModel.setProperty("/oVisibleSet/sendToSupp", true);
										oBrfModel.setProperty("/oVisibleSet/sendToVat", true);
										oBrfModel.setProperty("/oVisibleSet/sendToAR", true);
										oBrfModel.setProperty("/oVisibleSet/sendToAprrv", true);
										oBrfModel.setProperty("/oVisibleSet/forwardIcon", true);
										oBrfModel.setProperty("/oVisibleSet/displayFwdIcon", false);
										oBrfModel.setProperty("/oVisibleSet/fieldEditable", false);
										oBrfModel.setProperty("/oVisibleSet/contrlNameEdit", false);

										if (this.getModel("oBrfModel").getProperty("/oVisibleSet").buttonVis === false) {
											oBrfModel.setProperty("/oVisibleSet/SuppForwardIcon", true); /*Added by Satabdi Das for defect 63391 on 28-Oct-2020*/
											oBrfModel.setProperty("/oVisibleSet/SuppDisplayFwdIcon", false); /*Added by Satabdi Das for defect 63391 on 28-Oct-2020*/
											oBrfModel.setProperty("/oVisibleSet/addIcon", false);
											oBrfModel.setProperty("/oVisibleSet/AddDisplIcon", false);
										} else {
											oBrfModel.setProperty("/oVisibleSet/SuppForwardIcon", false); /*Added by Satabdi Das for defect 63391 on 28-Oct-2020*/
											oBrfModel.setProperty("/oVisibleSet/SuppDisplayFwdIcon", false); /*Added by Satabdi Das for defect 63391 on 28-Oct-2020*/
											oBrfModel.setProperty("/oVisibleSet/addIcon", true);
											oBrfModel.setProperty("/oVisibleSet/AddDisplIcon", false);
										}

										/*Start of change on 06-MAY-2020*/
										// for (var i = 0; i < d.results[0].BRFItemSet.results.length; i++) {
										// 	if (d.results[0].BRFItemSet.results[i].LineStatus === "CONTROLLER" || d.results[0].BRFItemSet.results[i].LineStatus ===
										// 		"SUPPLIER") {
										// 		bFlag = true;
										// 	}
										// }
										// if (bFlag === true) {
										// 	oBrfModel.setProperty("/oVisibleSet/enableAddMF", true);
										// 	oBrfModel.setProperty("/oVisibleSet/enableAddGF", true);
										// 	oBrfModel.setProperty("/oVisibleSet/buttonVis", true);
										// } else if (bFlag === undefined) {
										// 	oBrfModel.setProperty("/oVisibleSet/enableAddMF", false);
										// 	oBrfModel.setProperty("/oVisibleSet/enableAddGF", false);
										// 	oBrfModel.setProperty("/oVisibleSet/buttonVis", false);
										// }
										/*End of change on 06-MAY-2020*/
									} else {
										this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/editable", false);
										oBrfModel.setProperty("/oVisibleSet/sendToContrl", false);
										oBrfModel.setProperty("/oVisibleSet/sendToSupp", false);
										oBrfModel.setProperty("/oVisibleSet/sendToVat", false);
										oBrfModel.setProperty("/oVisibleSet/sendToAR", false);
										oBrfModel.setProperty("/oVisibleSet/sendToAprrv", false);
										oBrfModel.setProperty("/oVisibleSet/enableAddMF", false);
										oBrfModel.setProperty("/oVisibleSet/enableAddGF", false);
										oBrfModel.setProperty("/oVisibleSet/forwardIcon", false);
										oBrfModel.setProperty("/oVisibleSet/displayFwdIcon", true);
										oBrfModel.setProperty("/oVisibleSet/fieldEditable", false);
										oBrfModel.setProperty("/oVisibleSet/contrlNameEdit", false);

										if (this.getModel("oBrfModel").getProperty("/oVisibleSet").buttonVis === false) {
											oBrfModel.setProperty("/oVisibleSet/addIcon", false);
											oBrfModel.setProperty("/oVisibleSet/AddDisplIcon", false);
											oBrfModel.setProperty("/oVisibleSet/SuppForwardIcon", false); /*Added by Satabdi Das for defect 63391 on 28-Oct-2020*/
											oBrfModel.setProperty("/oVisibleSet/SuppDisplayFwdIcon", true); /*Added by Satabdi Das for defect 63391 on 28-Oct-2020*/
										} else {
											oBrfModel.setProperty("/oVisibleSet/addIcon", false);
											oBrfModel.setProperty("/oVisibleSet/AddDisplIcon", true);
											oBrfModel.setProperty("/oVisibleSet/SuppForwardIcon", false); /*Added by Satabdi Das for defect 63391 on 28-Oct-2020*/
											oBrfModel.setProperty("/oVisibleSet/SuppDisplayFwdIcon", false); /*Added by Satabdi Das for defect 63391 on 28-Oct-2020*/
										}

									}
								}
								for (var i = 0; i < d.results.length; i++) {
									var obj = {};
									var oLineItemArr = [];
									obj.BrfNo = d.results[i].BrfNo;
									obj.RrfNo = d.results[i].RrfNo;
									obj.BrfType = d.results[i].BrfType;
									obj.ContrlName = d.results[i].ContrlName;
									obj.ContrlEmail = d.results[i].ContrlEmail;
									obj.BrfCreationDate = d.results[i].BrfCreationDate;
									obj.BrfCreatedBy = d.results[i].BrfCreatedBy;
									obj.BrfCreatorName = d.results[i].BrfCreatorName; /* Added by Satabdi Das on 15-Jan-2021 for defect 63786*/
									obj.Gjahr = d.results[i].Gjahr;
									obj.SchDate = d.results[i].SchDate;
									obj.Automated = d.results[i].Automated;
									obj.Flag = d.results[i].Flag; /*Added on 01-Apr-2021*/
									obj.Message = d.results[i].Message; /*Added on 01-Apr-2021*/
									obj.InvoiceAmount = d.results[i].InvoiceAmount;
									obj.GrossAmtLocal = d.results[i].GrossAmtLocal;
									obj.CurrencyLocal = d.results[i].CurrencyLocal;
									obj.NetAmount = d.results[i].NetAmount;
									obj.DocCurrency = d.results[i].DocCurrency;
									obj.SapDocYear = d.results[i].SapDocYear;
									obj.SapDocNum = d.results[i].SapDocNum;
									obj.BukrsUrn = d.results[i].BukrsUrn;
									obj.Urn = d.results[i].Urn;
									obj.ToDisplay = d.results[i].ToDisplay;
									obj.CompanyCode = d.results[i].CompanyCode; /*Added for new Comp Code 9921 by Satabdi Das*/
									obj.Display = d.results[i].Display;
									oLineItemArr = d.results[i].BRFItemSet;
									arrAnswer = d.results[i].BRF_AnswerSet;
									this.getView().getModel("oBrfModel").setProperty("/brfHeaderSet", obj);
									this.getView().getModel("oBrfModel").setProperty("/brfTableSet", oLineItemArr.results);
									this.getView().getModel("oBrfModel").setProperty("/questionSetSubmit", arrAnswer.results);
								}

								if (obj.BrfNo) {
									oBrfModel.setProperty("/oVisibleSet/vendorInvoiceField", false);
								}
								year = this.getView().getModel("oBrfModel").getProperty("/brfHeaderSet").Gjahr;
								sHeading = title + " " + BrfNo + " " + fisYr + " " + year;
								this.getView().getModel("oBrfModel").setProperty("/setHeading", sHeading);
								var fragId = this.getView().createId("searchRRFNo");
								var SearchId = sap.ui.core.Fragment.byId(fragId, "localBRFSearch");
								if (SearchId) {
									SearchId.setValue("");
									var aFilter = [];
									aFilter.push(new Filter("BrfNo", FilterOperator.Contains, ""));
									var frag = this.getView().createId("searchRRFNo");
									var table = sap.ui.core.Fragment.byId(frag, "tableBRFSerch");
									var oBinding = table.getBinding("items");
									oBinding.filter(aFilter, "Application");
									this._oSearchCoordinatorForRRF.close();
								}
								//SCTASK Transfer owner
								if (obj.ToDisplay === "X" && (oBrfModel.getProperty("/oDisplayBtnPress") === "false")) {
									oBrfModel.setProperty("/oVisibleSet/contrlNameEdit", false);
								} else {
									oBrfModel.setProperty("/oVisibleSet/contrlNameEdit", false);
								}

								if (!obj.Flag) {
									oRouter.navTo("TargetcoupaBrf", {
										No: obj.BrfNo
											/*	No: obj.CompanyCode*/
									});
								} else {
									MessageBox.error(obj.Message);
								}
								/*End of change by satabdi das for concurrent user lock on 01-Apr-2021*/

							} else {
								MessageBox.error("This BRF does not exist in the system.");
							}
						}, this);

						var fnError = jQuery.proxy(function (d) {
								var r = JSON.parse(JSON.stringify(d));
								sap.ui.core.BusyIndicator.hide();
								MessageToast.show(r.message, {
									autoClose: true,
									width: "20rem"

								});

							}, this

						);

						var sPath = "/BRFHeaderSet";
						var aFilter = [];

						var oFilterSerach;

						/*Start of change by developer Satabdi Das on 25-May-2021 for HTTP Error*/
						if (BrfNo) {
							BrfNo = formatter.formatValueToString(BrfNo); /*Change added by developer Satabdi Das on 25-May-2021 for HTTP Error*/
						}
						/*End of change by developer Satabdi Das on 25-May-2021 for HTTP Error*/
						oFilterSerach = new sap.ui.model.Filter("BrfNo", sap.ui.model.FilterOperator.EQ, BrfNo);
						aFilter.push(oFilterSerach);

						if (this.getView().getModel("oBrfModel").getProperty("/oDisplayBtnPress") === "true") {
							oFilterSerach = new Filter("CompanyCode", FilterOperator.EQ, "D");
							aFilter.push(oFilterSerach);
						}

						// var sParams = {};
						// var oObject = {};
						// oObject.Filter = aFilter;
						// oObject.Params = sParams;
						// oObject.successCallback = fnSuccess;
						// oObject.errorCallback = fnError;
						// oObject.sPath = sPath;
						// DataManagerBrf.getRRFHeaderSetvalueBRF(oObject);
						/*R&D---start*/
						var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_BRF_SRV/", {
							json: true
						});
						oModel1.read("/BRFHeaderSet", {
							filters: aFilter,
							urlParameters: {
								"$expand": "BRFItemSet,BRF_AnswerSet"
							},
							success: fnSuccess,
							error: fnError
						});
						/*R&D---end*/

						//end changes
					} else {
						MessageBox.error("Please enter  BRF number.");
					}

				}
			} else {
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				MessageBox.error(
					"You are not authorized to edit/view this BRF.", {
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					}
				);
				return;
			}

		},

		/*Start of change by developer Satabdi Das on 15-Sep-2020*/
		DocTypeDropDown: function (oEvent) {
			sap.ui.core.BusyIndicator.show(0);

			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				var oBrfModel = this.getView().getModel("oBrfModel");
				oBrfModel.setSizeLimit(d.results.length);
				oBrfModel.setProperty("/Doctype", d.results);
				this.getView().getModel("oBrfModel").setProperty("/DocumentType", "");
			}, this);

			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();
				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"
				});
			}, this);

			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_BRF_SRV/", {
				json: true
			});
			oModel1.read("/DoctypeSet", {
				success: fnSuccess,
				error: fnError
			});
		},
		/*End of change by developer Satabdi Das on 15-Sep-2020*/

		onBrfContrlNameHelpPress: function (oEvent) {
			var oBrfModel = this.getModel("oBrfModel");
			var oCheckField = oEvent.getSource().getBindingInfo("value").binding.sPath.split("/")[2];
			oBrfModel.setProperty("/fieldvalText", oCheckField);
			// var fieldVal = oCheckField.split("/")[2];
			/*Start defect 63445*/
			var sId = oEvent.getSource().getId().split("--")[2]; /*Change added for INC01499658 on 22-APR-2021*/
			/*if (sId === "attenPersonNameMF" || sId === "BudgetApproverNameGF") {*/
			if (sId === "BudgetApproverNameGF") { /*Changed by Satabdi Das for defect 63391 on 21-Jan-2021*/
				oBrfModel.setProperty("/lineItemBRFSet/AttenBrf", "");
				oBrfModel.setProperty("/lineItemBRFSet/AttenBrfEmail", "");
			}
			if (sId === "HeadKPMGIGFName") {
				oBrfModel.setProperty("/lineItemBRFSet/GfName", "");
				oBrfModel.setProperty("/lineItemBRFSet/GfEmail", "");
			}
			/*End defcet 63445*/
			var fragmentIdBRFCntlName = this.getView().createId("searchBRFEmail");

			if (!this.ofragmentIdBRFCntlName) {
				this.ofragmentIdBRFCntlName = sap.ui.xmlfragment(fragmentIdBRFCntlName, "KGO.kgoarrecharge_brf.view.brfContrlName", this);
				this.getView().addDependent(this.ofragmentIdBRFCntlName);
			}
			if (oBrfModel.getProperty("/TRFOwnerFlag") === true) {
				oBrfModel.setProperty("/enabledTrfSave", false);
			}
			this.ofragmentIdBRFCntlName.open();

		},
		onContrlNameSearchCancel: function () {
			var oBrfModel = this.getModel("oBrfModel");
			this.ofragmentIdBRFCntlName.close();
			oBrfModel.setProperty("/oVisibleSet/visiblecntlForBRF", false);
			oBrfModel.setProperty("/ContrlTableBRFSet", []);
			oBrfModel.setProperty("/ContrlerBRfSet", {});

		},
		onPressControlNameSearch: function (oEvent) {
			sap.ui.core.BusyIndicator.show(0);
			/*Start of change for INC01413954 on 08-Feb-2021 by Satabdi Das*/
			var fName = this.getView().getModel("oBrfModel").getProperty("/ContrlerBRfSet").firstName;
			var lastName = this.getView().getModel("oBrfModel").getProperty("/ContrlerBRfSet").lastName;
			var Memberfirm = this.getView().getModel("oBrfModel").getProperty("/ContrlerBRfSet").Memberfirm;
			var City = this.getView().getModel("oBrfModel").getProperty("/ContrlerBRfSet").City;
			var Department = this.getView().getModel("oBrfModel").getProperty("/ContrlerBRfSet").Department;
			var Businesstitle = this.getView().getModel("oBrfModel").getProperty("/ContrlerBRfSet").Businesstitle;
			/*End of change for INC01413954 on 08-Feb-2021 by Satabdi Das*/
			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide();
				if (d.results.length === 0) {
					var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
					MessageBox.alert(
						"No results found.", {
							styleClass: bCompact ? "sapUiSizeCompact" : ""
						}
					);
				} else {
					var oBrfModel = this.getModel("oBrfModel");
					oBrfModel.setProperty("/oVisibleSet/visiblecntlForBRF", true);
					oBrfModel.setProperty("/ContrlTableBRFSet", d.results);
				}
				/*Below code mcommented by Satabdi Das on 11-Nov-2020*/
				// oBrfModel.refresh(true); 
			}, this);
			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();
				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"

				});
			}, this);

			var aFilter = [];
			var aFilterStr = [];
			var oFilterSerach;
			/*Start of change for INC01413954 on 08-Feb-2021 by Satabdi Das*/
			if (fName || lastName || Memberfirm || City || Department || Businesstitle) {
				if (fName) {
					fName = formatter.formatValueToString(fName); /*Change added by developer Satabdi Das on 25-May-2021 for HTTP Error*/
					oFilterSerach = new sap.ui.model.Filter("Firstname", sap.ui.model.FilterOperator.EQ, fName);
					aFilterStr.push(oFilterSerach);

				}
				if (lastName) {
					lastName = formatter.formatValueToString(lastName); /*Change added by developer Satabdi Das on 25-May-2021 for HTTP Error*/
					oFilterSerach = new sap.ui.model.Filter("Lastname", sap.ui.model.FilterOperator.EQ, lastName);
					aFilterStr.push(oFilterSerach);
				}
				if (Memberfirm) {
					Memberfirm = formatter.formatValueToString(Memberfirm); /*Change added by developer Satabdi Das on 25-May-2021 for HTTP Error*/
					oFilterSerach = new sap.ui.model.Filter("Memberfirm", sap.ui.model.FilterOperator.EQ, Memberfirm);
					aFilterStr.push(oFilterSerach);
				}
				if (City) {
					City = formatter.formatValueToString(City); /*Change added by developer Satabdi Das on 25-May-2021 for HTTP Error*/
					oFilterSerach = new sap.ui.model.Filter("City", sap.ui.model.FilterOperator.EQ, City);
					aFilterStr.push(oFilterSerach);
				}
				if (Department) {
					Department = formatter.formatValueToString(Department); /*Change added by developer Satabdi Das on 25-May-2021 for HTTP Error*/
					oFilterSerach = new sap.ui.model.Filter("Department", sap.ui.model.FilterOperator.EQ, Department);
					aFilterStr.push(oFilterSerach);
				}
				if (Businesstitle) {
					Businesstitle = formatter.formatValueToString(Businesstitle); /*Change added by developer Satabdi Das on 25-May-2021 for HTTP Error*/
					oFilterSerach = new sap.ui.model.Filter("Businesstitle", sap.ui.model.FilterOperator.EQ, Businesstitle);
					aFilterStr.push(oFilterSerach);
				}

				var oFilterStr = new sap.ui.model.Filter({
					filters: aFilterStr,
					and: true
				});
				aFilter.push(oFilterStr);
			}
			/*End of change for INC01413954 on 08-Feb-2021 by Satabdi Das*/
			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_BRF_SRV/", {
				json: true
			});
			oModel1.read("/BRF_CONAMESet?$skip=0&$top=50", {
				filters: aFilter,
				success: fnSuccess,
				error: fnError
			});
			/*R&D---end*/
		},
		onSelectContrlNameSelctForBRF: function (oEvent) {
			var that = this;
			var oBrfModel = this.getView().getModel("oBrfModel");
			var oGetHederData = oBrfModel.getProperty("/brfHeaderSet");
			var fieldVal = oBrfModel.getProperty("/fieldvalText");
			var oRowDataForContlName = oEvent.getSource().getBindingContext("oBrfModel").getObject();
			var Name = oRowDataForContlName.Firstname + " " + oRowDataForContlName.Lastname;
			switch (oRowDataForContlName.Employeestatuscode) {
			case "1":
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				MessageBox.information(
					"Employee status not currently assigned. Please select active employee", {
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					}
				);
				break;
			case "3":
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				MessageBox.information(
					"The individual is on leave", {
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					}
				);
				break;
			case "4":
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				MessageBox.information(
					"The individual is separated from the legal entity.", {
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					}
				);
				break;
			case "5":
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				MessageBox.information(
					"The individual will join the legal entity at a future date.", {
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					}
				);
			}
			//Changes for Transfer owner cntr by prashant kumar
			if (oBrfModel.getProperty("/TRFOwnerFlag") === true && oRowDataForContlName.Employeestatuscode == 2) {

				MessageBox.warning("Controller will be changed to  : " + Name + " . Do you want to Proceed ?", {
					actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
					emphasizedAction: MessageBox.Action.OK,
					onClose: function (sAction) {
						if (sAction === "OK") {
							oBrfModel.setProperty("/brfHeaderSet/ContrlName", Name);
							oBrfModel.setProperty("/brfHeaderSet/ContrlEmail", oRowDataForContlName.Emailid);
							that.ofragmentIdBRFCntlName.close();
							that.onTransferOwnerPressedSave();
							oBrfModel.setProperty("/TRFOwnerFlag", false);
						}
					}

				});
				return true;

			}
			if (fieldVal === "ContrlName" && oRowDataForContlName.Employeestatuscode == 2) {
				this.ofragmentIdBRFCntlName.close();
				this.getView().getModel("oBrfModel").setProperty("/brfHeaderSet/ContrlName", Name);
				this.getView().getModel("oBrfModel").setProperty("/brfHeaderSet/ContrlEmail", oRowDataForContlName.Emailid);
				this.getView().getModel("oBrfModel").setProperty("/ContrlTableBRFSet", []);
				this.getView().getModel("oBrfModel").setProperty("/ContrlerBRfSet", {});
				this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/visiblecntlForBRF", false);
			}
			if (fieldVal === "AttenBrf" && oRowDataForContlName.Employeestatuscode == 2) {
				this.ofragmentIdBRFCntlName.close();
				this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/AttenBrf", Name);
				this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/AttenBrfEmail", oRowDataForContlName.Emailid);
				this.getView().getModel("oBrfModel").setProperty("/ContrlTableBRFSet", []);
				this.getView().getModel("oBrfModel").setProperty("/ContrlerBRfSet", {});
				this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/visiblecntlForBRF", false);
			}
			if (fieldVal === "GfName" && oRowDataForContlName.Employeestatuscode == 2) {
				this.ofragmentIdBRFCntlName.close();
				this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/GfName", Name);
				this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/GfEmail", oRowDataForContlName.Emailid);
				this.getView().getModel("oBrfModel").setProperty("/ContrlTableBRFSet", []);
				this.getView().getModel("oBrfModel").setProperty("/ContrlerBRfSet", {});
				this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/visiblecntlForBRF", false);
			}
			if (fieldVal === "FunctionName" && oRowDataForContlName.Employeestatuscode == 2) {
				this.ofragmentIdBRFCntlName.close();
				this.getView().getModel("oBrfModel").setProperty("/lineItemBRFSet/FunctionName", Name);
				this.getView().getModel("oBrfModel").setProperty("/ContrlTableBRFSet", []);
				this.getView().getModel("oBrfModel").setProperty("/ContrlerBRfSet", {});
				this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/visiblecntlForBRF", false);
			}

			if (oGetHederData.ToDisplay === "X") {
				this.getView().byId("trfOwnerId").setProperty("enabled", true);
			}

		},

		//company code default set addition by prashant 14.08.2020
		companyCodeDefaluValueforBRF: function (oEvent) {

			// var fragmentId = this.getView().createId("searchCoordinator");
			sap.ui.core.BusyIndicator.show(0);

			var obj = {};

			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				var oBrfModel = this.getModel("oBrfModel");

				for (var i = 0; i < d.results.length; i++) {

					obj.CompanyCode = d.results[i].CompanyCode;
					//obj.GpCreate = d.results[i].GpCreate;
					// obj.RrfStatus = d.results[i].RrfStatus;

					obj.Currency = d.results[i].Currency;
					oBrfModel.setProperty("/brfHeaderSet/CompanyCode", obj.CompanyCode);

				}

				oBrfModel.refresh(true);

			}, this);

			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();

				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"

				});
			}, this);

			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_BRF_SRV/", {
				json: true
			});
			oModel1.read("/BRF_DVSet", {
				success: fnSuccess,
				error: fnError
			});
		},
		//end of changes
		/*Start of change by developer Satabdi Das on 10-Nov-2020 for defect 63361 */
		brfHistoryTab: function (oEvent) {
			var oBrfModel = this.getView().getModel("oBrfModel");
			var sBrfNo = this.getView().getModel("oBrfModel").getProperty("/brfHeaderSet").BrfNo;
			var sCompCode = this.getView().getModel("oBrfModel").getProperty("/brfHeaderSet").CompanyCode;
			var aFilter = [];
			sap.ui.core.BusyIndicator.show(0);

			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				oBrfModel.setProperty("/BRFHistorySet", d.results);
				/*Below code mcommented by Satabdi Das on 11-Nov-2020*/
				// oBrfModel.refresh(true);
			}, this);

			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide(0);
				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"
				});
			}, this);

			aFilter.push(new Filter("BrfNo", FilterOperator.EQ, sBrfNo));
			aFilter.push(new Filter("CompanyCode", FilterOperator.EQ, sCompCode));

			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_BRF_SRV/", {
				json: true
			});
			oModel1.read("/BRFHistorySet", {
				filters: aFilter,
				success: fnSuccess,
				error: fnError
			});
		},
		/*End of change by developer Satabdi Das on 10-Nov-2020 for defect 63361 */
	});
});