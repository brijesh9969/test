sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"KGO/kgoarrecharge_brf/model/models",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/HashChanger"
], function (UIComponent, Device, models, JSONModel, HashChanger) {
	"use strict";

	return UIComponent.extend("KGO.kgoarrecharge_brf.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function () {
			// call the base component's init function
			HashChanger.getInstance().replaceHash("");
			UIComponent.prototype.init.apply(this, arguments);

			// enable routing
			this.getRouter().initialize();

			// set the device model
			this.setModel(models.createDeviceModel(), "device");

			var oBrfModel = new JSONModel({});
			oBrfModel.setDefaultBindingMode("TwoWay");
			this.setModel(oBrfModel, "oBrfModel");

			this.getModel("oBrfModel").setProperty("/brfHeaderSet", {});
			this.getModel("oBrfModel").setProperty("/brfTableSet", []);
			this.getModel("oBrfModel").setProperty("/questionSetSubmit", []);
			this.getModel("oBrfModel").setProperty("/lineItemBRFSet", {});
			this.getModel("oBrfModel").setProperty("/localBRFSearch");
			this.getModel("oBrfModel").setProperty("/ContrlerBRfSet", {});
			this.getModel("oBrfModel").setProperty("/DocumentHdrSet", {});
			this.getModel("oBrfModel").setProperty("/APURNHdrSet", {}); /*Added by developer Satabdi Das on 04-Dec-2020 for enhancement 63345*/
			this.getModel("oBrfModel").setProperty("/TaxHdrSet", {});
			this.getModel("oBrfModel").setProperty("/Display", false);
			this.getModel("oBrfModel").setProperty("/PORef",false);
			this.getModel("oBrfModel").setProperty("/entityEdit",false);	/*Added for defect 63290*/
			this.getModel("oBrfModel").setProperty("/LastDateSrv" , false); /*Added on 25-May-2020*/
			this.getModel("oBrfModel").setProperty("/DateMandatory" , false);
			this.getModel("oBrfModel").setProperty("/WhTFldsMandat" , false);
			this.getModel("oBrfModel").setProperty("/hasComment" , false); /*Added by developer Satabdi Das for defect 63361 on 09-Nov-2020*/
			this.getModel("oBrfModel").setProperty("/CodeMandat" , false);	/*Added for defect 63418*/
			this.getModel("oBrfModel").setProperty("/CostScnterSearchSet", []); /*Added for defect 63412*/
			this.getModel("oBrfModel").setProperty("/RestCCSearchSet", []); /*Added by Satabdi Das on 04-March-2021 for 63648*/
			this.getModel("oBrfModel").setProperty("/PrctrSearchSet", []); /*Added for defect 63412*/
			this.getModel("oBrfModel").setProperty("/Bukrs9901", true); /*Added by Satabdi Das on 17-Sep-2020*/
			this.getModel("oBrfModel").setProperty("/Bukrs9921", true); /*Added by Satabdi Das on 14-Sep-2020*/
			this.getModel("oBrfModel").setProperty("/TRFOwnerFlag", false);
			this.getModel("oBrfModel").setProperty("/enabledTrfSave", false);
			var myJasonBRF = {
				"lineItemVisibleForGF": false,
				"lineItemVisibleForMF": false,
				"visiblecntlForBRF": false,
				"visibleDocInfo": false,
				"visibleTaxInfo": false,
				"brfeditRB1": true,
				"editMode": true,
				"editReqMF": true,
				"attachVisible": false,
				"buttonVis": true,
				"GL160100": false,
				"CRGL160100": false,
				"attchmentExpnded": false,
				"withRRF": true,
				"fieldEditable": true,
				"contrlNameEdit":false,
				"editable": true,
				"vatEditDisplay": true,
				"recvdDetailExpand": true,
				"billingDetailExpand": false,
				"processDetailExpand": false,
				"vatDetailExpand": false,
				"attchEnable": true,
				"sendToSupp": true,
				"sendToContrl": true,
				"sendToVat": true,
				"sendToAR": true,
				"sendToAprrv": true,
				"enableAddMF":true,
				"enableAddGF":true,
				"reqFnName":true,
				"vendorInvoiceField":false,
				"enableDeltBtn":true,
				"addIcon":true,
				"AddDisplIcon":false,
				"forwardIcon":true,
				"SuppForwardIcon":true,	/*Added by Satabdi Das for defect 63391 on 28-Oct-2020*/
				"displayFwdIcon":false,
				"SuppDisplayFwdIcon":false, /*Added by Satabdi Das for defect 63391 on 28-Oct-2020*/
				"assigmentUrn":true,
				"withoutRef":false,
				"EditAPUrnforNP":false, /*Added for defect 63363*/
				"apUrnForMf":true,
				"editLinkShow":true,//added by prashant for other edit options
				"displayLinkShow":true,//added by prashant for other display options
				"RI":false, //added for Reissuance visible by Satabdi Das on  14-Dec-2020
				"creditNoteField":false, //added for credit field visible by prashant 09.12.2020
				"amountfieldVisible":false, //added for credit field visible by prashant 09.12.2020
				"amountFieldEditableForCN":false, //added for credit field visible by prashant 09.12.2020
				"documentTypeEditCN":false,
				"documentTypeNoNCN":false,
				"creditNoteDocumentVisible":false,
				"creditNoteTypeFieldVisible":false,
				"creditNoteTypeFieldEdit":false,
				"creditNoteAmount":true,
				"nonCreditNoteText":false,
				"remaingAmount":true,
				"postDate":false,
				"postDateEdit":false,
				"editContyCod":false,
				"countryComboBox":false,
				"questionPnVisibleBRF":false,
				"TaxPointDateEditDisplay":true

			};

			this.getModel("oBrfModel").setProperty("/oVisibleSet", myJasonBRF);

		}
	});
});