jQuery.sap.declare("KGO.kgoarrecharge_brf.formatter.formatter");
sap.ui.define([], function () {
	"use strict";
	return {
		formatBrfCreationDate: function (dateValue) {
			if (dateValue) {
				for (var i = 0; i < dateValue.length; i++) {
					var vUTCyear = dateValue.slice(0, 4);
					var vUTCMonth = dateValue.slice(4, 6);
					var vUTCDay = dateValue.slice(6, 8);
					var vDate = vUTCMonth + '-' + vUTCDay + '-' + vUTCyear;
				}
				return vDate;
			} else {
				return dateValue;
			}
		},
		formatFromUTCDate: function (arr) {
			for (var i = 0; i < arr.results.length; i++) {
				if (arr.results[i].CoupaRequisitionDate) {
					var vUTCyear = arr.results[i].CoupaRequisitionDate.slice(0, 4);
					var vUTCMonth = arr.results[i].CoupaRequisitionDate.slice(4, 6);
					var vUTCDay = arr.results[i].CoupaRequisitionDate.slice(6, 8);
					var vDate = vUTCDay + '-' + vUTCMonth + '-' + vUTCyear;
					arr.results[i].CoupaRequisitionDate = vDate;
				}
			}
			return arr;
		},
		ValueExportFormatter: function (value, decimal) {
			if (value) {
				var formattedAmount = value;
				var fmtOptions = {
					currencyCode: false,
					showMeasure: true,
					groupingEnabled: false,
					maxFractionDigits: decimal
				};

				var slocale = sap.ui.getCore().getConfiguration().getLanguage();
				var oLocale = new sap.ui.core.Locale(slocale);

				var currencyFormat = sap.ui.core.format.NumberFormat.getCurrencyInstance(fmtOptions, oLocale);
				formattedAmount = currencyFormat.format(formattedAmount);
				if (formattedAmount.indexOf(",") >= 0) {
					for (var i = 0; i < formattedAmount.split(",").length; i++) {

					}
				}

				return formattedAmount;
			} else {
				return "";
			}
		},
		/*Start of change for MMYY service period date by developer Satabdi Das on 24-Aug-2020*/
		formatBrfSrvDate: function (dateValue) {
			if (dateValue) {
				var sYear = dateValue.slice(2, 4);
				var nMonth;
				var sMonth;
				var sUSMonth;
				var sUSYr;
				if (Number(dateValue.slice(0, 2)) === 10) {
					sMonth = "01";
					sYear = Number(sYear) + 1;
					sUSYr = sYear.toString();
				} else if (Number(dateValue.slice(0, 2)) === 11) {
					sMonth = "02";
					sYear = Number(sYear) + 1;
					sUSYr = sYear.toString();
				} else if (Number(dateValue.slice(0, 2)) === 12) {
					sMonth = "03";
					sYear = Number(sYear) + 1;
					sUSYr = sYear.toString();
				} else {
					nMonth = Number(dateValue.slice(0, 2)) + 3;
					sUSYr = sYear;
				}
				if (nMonth >= 4 && nMonth <= 9) {
					sUSMonth = "0" + nMonth.toString();
				} else if (nMonth >= 10 & nMonth <= 12) {
					sUSMonth = nMonth.toString();
				} else {
					sUSMonth = sMonth;
				}
				var sDate = sUSMonth + sUSYr;
				return sDate;
			} else {
				return dateValue;
			}
		},
		/*End of change for MMYY service period date by developer Satabdi Das on 24-Aug-2020*/

		/*Start of change by developer Satabdi Das on 25-May-2021 for string converison  of the filter value*/
		formatValueToString: function (value) {
			if (value) {
				value = value.toString();
				return value;
			} else {
				return value;
			}
		},
		/*End of change by developer Satabdi Das on 25-May-2021 for string converison  of the filter value*/
	};
});