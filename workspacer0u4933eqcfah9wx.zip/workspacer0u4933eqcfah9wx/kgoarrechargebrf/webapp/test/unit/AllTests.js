sap.ui.define([
	"KGO/kgoarrecharge_brf/test/unit/controller/BrfHomeView.controller"
], function () {
	"use strict";
});