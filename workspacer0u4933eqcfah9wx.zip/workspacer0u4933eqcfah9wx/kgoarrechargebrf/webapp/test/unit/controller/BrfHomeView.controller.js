/*global QUnit*/

sap.ui.define([
	"KGO/kgoarrecharge_brf/controller/BrfHomeView.controller"
], function (Controller) {
	"use strict";

	QUnit.module("BrfHomeView Controller");

	QUnit.test("I should test the BrfHomeView controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});