sap.ui.define([
	"KGO/kgoarrecharge_brf/controller/BaseController",
	"sap/ui/core/mvc/Controller",
	'sap/ui/core/UIComponent', /*Added by Satabdi on 26-Nov-2019*/
	'sap/ui/core/Fragment', /*Added by Satabdi on 26-Nov-2019*/
	"sap/m/MessageToast",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"KGO/kgoarrecharge_brf/util/DataManagerBrf",
	"KGO/kgoarrecharge_brf/util/UIGlobal", /*Added on 21-APR-2020*/
	"KGO/kgoarrecharge_brf/formatter/formatter",
	"sap/m/MessageBox",
], function (BaseController, Controller, UIComponent, Fragment, MessageToast, Filter, FilterOperator, DataManagerBrf, UIGlobal, formatter,
	MessageBox) { /*Added by Satabdi on 26-Nov-2019*/
	"use strict";

	return BaseController.extend("KGO.kgoarrecharge_brf.controller.BrfHomeView", {
		formatter: formatter,

		onInit: function () {
			var oRefOdata = this.getOwnerComponent().getModel();
			var oObject = {};
			oObject.OData = oRefOdata;
			DataManagerBrf.init(oObject);
			/*Start of change by Satabdi Das on 21-APR-2020*/
			var sUrl;
			sUrl = window.location.href;
			var sBRFId = sUrl.indexOf("?BRF=");
			if (sBRFId >= 0) {
				// var sBR = sUrl.split("=")[1].split("&")[0];
				var sBR = sUrl.substr(sBRFId + 5, 12);
				var oRouter = UIComponent.getRouterFor(this);
				UIGlobal.setFromOpenTask(true);
				oRouter.navTo("TargetcoupaBrf", {
					No: sBR
				});
			}
			/*End of change by Satabdi Das on 21-APR-2020*/

		},
		createBrfFrag: function () {
			var oBrfModel = this.getView().getModel("oBrfModel");
			this.getView().getModel("oBrfModel").setProperty("/brfHeaderSet", {});
			oBrfModel.setProperty("/oVisibleSet/editMode", true);
			oBrfModel.setProperty("/oVisibleSet/editable", true);
			oBrfModel.setProperty("/oVisibleSet/vatEditDisplay", true);
			oBrfModel.setProperty("/oVisibleSet/fieldEditable", true);
			oBrfModel.setProperty("/oVisibleSet/contrlNameEdit", true);
			oBrfModel.setProperty("/oVisibleSet/attchEnable", true);
			oBrfModel.setProperty("/oVisibleSet/editReqMF", true);
			oBrfModel.setProperty("/oVisibleSet/sendToContrl", false);
			oBrfModel.setProperty("/oVisibleSet/sendToSupp", false);
			oBrfModel.setProperty("/oVisibleSet/sendToVat", false);
			oBrfModel.setProperty("/oVisibleSet/sendToAR", false);
			oBrfModel.setProperty("/oVisibleSet/sendToAprrv", false);
			oBrfModel.setProperty("/oDisplayBtnPress", "false");
			oBrfModel.setProperty("/oVisibleSet/enableAddMF", true);
			oBrfModel.setProperty("/oVisibleSet/enableAddGF", true);
			oBrfModel.setProperty("/oVisibleSet/enableDeltBtn", true);
			oBrfModel.setProperty("/oVisibleSet/addIcon", true);
			oBrfModel.setProperty("/oVisibleSet/AddDisplIcon", false);
			oBrfModel.setProperty("/oVisibleSet/forwardIcon", true);
			oBrfModel.setProperty("/oVisibleSet/apUrnForMf", true);
			oBrfModel.setProperty("/oVisibleSet/assigmentUrn", true);
			oBrfModel.setProperty("/oVisibleSet/withoutRef", false);
			oBrfModel.setProperty("/oVisibleSet/displayFwdIcon", false); //added on 08.05.2020
			oBrfModel.setProperty("/oVisibleSet/creditNoteField", false);
			oBrfModel.setProperty("/oVisibleSet/amountfieldVisible", false);

			var createBrf = this.getView().createId("createBrf");
			if (!this.createBrf) {
				this.createBrf = sap.ui.xmlfragment(createBrf, "KGO.kgoarrecharge_brf.view.createNewBrf", this);
				this.getView().addDependent(this.createBrf);
			}
			if (this.createBrf.isOpen()) {
				this.createBrf.close();
			} else {
				this.createBrf.open();
			}

			this._ofragmentIdUse = createBrf;
		},
		handleCreateBrfCoupa: function (oEvent) {

			this.getView().getModel("oBrfModel").setProperty("/brfHeaderSet", {});
			this.getView().getModel("oBrfModel").setProperty("/RRF_NOSet", []);
			this.getView().getModel("oBrfModel").setProperty("/localBRFSearch", "");
			this.getModel("oBrfModel").setProperty("/oVisibleSet/attachVisible", false);
			this.createBrfFrag();
			if (this.selectedIndex !== 1) {
				this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/withRRF", true);
				this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/SuppForwardIcon", true); /*Added by Satabdi Das for defect 63391 on 28-Oct-2020*/
				this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/SuppDisplayFwdIcon", false); /*Added by Satabdi Das for defect 63391 on 28-Oct-2020*/

			} else {
				this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/withRRF", false);
				this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/SuppForwardIcon", false); /*Added by Satabdi Das for defect 63391 on 28-Oct-2020*/
				this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/SuppDisplayFwdIcon", false); /*Added by Satabdi Das for defect 63391 on 28-Oct-2020*/

			}
		},
		onPressCancel: function () {
			if (this.createBrf.isOpen()) {
				this.createBrf.close();
			}
		},
		onSelectOption: function (oEvent) {
			var sId = oEvent.getParameters().selectedIndex;
			switch (sId) {
			case 0:
				this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/withRRF", true);
				break;
			case 1:
				var oBrfModel = this.getView().getModel("oBrfModel");
				var createtext = this.getView().getModel("i18n").getProperty("createDashbrdText");
				oBrfModel.setProperty("/setDashBoardTextForBRF", createtext);
				oBrfModel.setProperty("/oVisibleSet/withRRF", false);
				oBrfModel.setProperty("/brfHeaderSet/RrfNo", "");
				//company code changes added by prashant on 14.08.2020
				this.companyCodeDefaluValueforBRF();
				//ends of cc changes
				break;

			}
			this.selectedIndex = sId;
		},
		authoCheck: function (oEvent) {
			var oBrfModel = this.getModel("oBrfModel");

			sap.ui.core.BusyIndicator.show(0);

			var aFilter = [];

			var sPath = "";
			var obj = {};
			sPath = "/BRF_DVSet"; // + Constant.CV_PV_LEAD_FIORI;

			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				obj.GpCreate = d.results[0].GpCreate;
				obj.GpEditDisplay = d.results[0].GpEditDisplay;
				obj.GfEditDisplay = d.results[0].GfEditDisplay;

				oBrfModel.setProperty("/authoSet", obj);

				oBrfModel.refresh(true);

			}, this);

			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();

				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"

				});
			}, this);
			// var sParams = {};
			// var oObject = {};

			// oObject.Filter = aFilter;
			// oObject.Params = sParams;
			// oObject.successCallback = fnSuccess;
			// oObject.errorCallback = fnError;
			// oObject.sPath = sPath;
			// DataManagerARrecharge.getCoupaReqiNumberhelpValus(oObject);
			/*R&D---start*/
			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_BRF_SRV/", {
				json: true
			});
			oModel1.read("/BRF_DVSet", {
				success: fnSuccess,
				error: fnError
			});
			/*R&D---end*/

		},
		onPressCreate: function (oEvent) {
			var invoice = "Invoice";
			var oBrfModel = this.getView().getModel("oBrfModel");
			var title = this.getView().getModel("i18n").getProperty("title");
			this.getView().getModel("oBrfModel").setProperty("/setHeading", title);
			this.getModel("oBrfModel").setProperty("/Display", false);
			this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/editable", true);
			this.getModel("oBrfModel").setProperty("/oVisibleSet/editMode", true);
			var createtext = this.getView().getModel("i18n").getProperty("createDashbrdText");
			oBrfModel.setProperty("/setDashBoardTextForBRF", createtext);
			oBrfModel.setProperty("/oVisibleSet/creditNoteField", false);
			oBrfModel.setProperty("/oVisibleSet/amountfieldVisible", false);
			this.getModel("oBrfModel").setProperty("/questionSetSubmit", []);
			oBrfModel.setProperty("/ContrlTableBRFSet", []);
			oBrfModel.setProperty("/ContrlerBRfSet", {});
			oBrfModel.setProperty("/oVisibleSet/visiblecntlForBRF", false);
			oBrfModel.setProperty("/TRFOwnerFlag", false);
			this.currencyDropDown();
			this.DocTypeDropDown(); /*Added on 15-Sep-2020 by Satabdi Das*/
			this.brfMFSearchHelp();
			this.authoCheck();

			var oRouter = UIComponent.getRouterFor(this);
			if (this.getView().getModel("oBrfModel").getProperty("/RRF_NOSet").length > 0) {
				var rrfN = oEvent.getSource().getBindingContext("oBrfModel").getObject();
				this.getView().getModel("oBrfModel").setProperty("/brfHeaderSet/RrfNo", rrfN.RrfNo);
			}
			if (this.selectedIndex === 0 || this.selectedIndex === undefined) {
				var sRrfNo = oBrfModel.getProperty("/brfHeaderSet").RrfNo;
				/*if (this.getView().getModel("oBrfModel").getProperty("/brfHeaderSet").RrfNo) {*/
				this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/SuppForwardIcon", true); /*Added by Satabdi Das for defect 63391 on 28-Oct-2020*/
				oBrfModel.setProperty("/oVisibleSet/SuppDisplayFwdIcon", false); /*Added by Satabdi Das for defect 63391 on 28-Oct-2020*/
				if ((sRrfNo && sRrfNo !== "") && (sRrfNo.indexOf("PO") >= 0 || sRrfNo.indexOf("NP") >= 0)) {
					oBrfModel.setProperty("/oVisibleSet/fieldEditable", false);
					oBrfModel.setProperty("/oVisibleSet/contrlNameEdit", false);
					var rrfNo = this.getView().getModel("oBrfModel").getProperty("/brfHeaderSet").RrfNo;
					if (rrfNo.indexOf("PO") >= 0) {
						this.getView().getModel("oBrfModel").setProperty("/PORef", true);
					} else {
						this.getView().getModel("oBrfModel").setProperty("/PORef", false);
					}
					this.getView().getModel("oBrfModel").setProperty("/brfHeaderSet/BrfType", invoice);
					this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/buttonVis", false);
					oBrfModel.setProperty("/oVisibleSet/addIcon", false);
					oBrfModel.setProperty("/oVisibleSet/AddDisplIcon", false);
					this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/vatEditDisplay", true);
					//start change
					var fnSuccess = jQuery.proxy(function (d) {
						if (d.results.length !== 0) {
							sap.ui.core.BusyIndicator.hide(0);
							var arrAnswer = [];
							for (var i = 0; i < d.results.length; i++) {
								var obj = {};
								var oLineItemArr = [];
								obj.RrfNo = d.results[i].RrfNo;
								obj.BrfType = invoice;
								obj.Automated = d.results[i].Automated;
								obj.ContrlName = d.results[i].ContrlName;
								obj.ContrlEmail = d.results[i].ContrlEmail;
								obj.CompanyCode = d.results[i].CompanyCode; /*Added for new Comp Code 9921 by developer Satabdi Das*/
								obj.Message = d.results[i].Message;
								oLineItemArr = d.results[i].BRFItemSet;
								arrAnswer = d.results[i].BRF_AnswerSet;
								this.getView().getModel("oBrfModel").setProperty("/brfHeaderSet", obj);
								this.getView().getModel("oBrfModel").setProperty("/brfTableSet", oLineItemArr.results);
								this.getView().getModel("oBrfModel").setProperty("/questionSetSubmit", arrAnswer.results);

							}

							if (obj.Automated === "X") {
								oBrfModel.setProperty("/oVisibleSet/vendorInvoiceField", false);
							} else {
								oBrfModel.setProperty("/oVisibleSet/vendorInvoiceField", true);
							}
							var fragId = this.getView().createId("searchRRFNo");
							var SearchId = sap.ui.core.Fragment.byId(fragId, "searchRRF");
							if (SearchId) {
								SearchId.setValue("");
								var aFilter = [];
								aFilter.push(new Filter("RrfNo", FilterOperator.Contains, ""));
								var fragmentIdRRF = this.getView().createId("searchRRFNo");
								var table = sap.ui.core.Fragment.byId(fragmentIdRRF, "tableRrfSearch");
								var oBinding = table.getBinding("items");
								oBinding.filter(aFilter, "Application");

								this._oSearchCoordinatorForRRF.close();
							}

							if (obj.Message) {
								MessageBox.information(obj.Message, {
									actions: [MessageBox.Action.OK],
									emphasizedAction: MessageBox.Action.OK,
									onClose: function (sAction) {
										if (sAction === "OK" && oLineItemArr.results.length > 0) {
											oRouter.navTo("TargetcoupaBrf", {
												No: obj.RrfNo
											});
										} else {
											return;
										}

									}

								});
							} else {
								oRouter.navTo("TargetcoupaBrf", {
									No: obj.RrfNo
								});
							}
						} else {
							var msg = this.getView().getModel("i18n").getProperty("RefRRFValidMsg");
							MessageBox.error(msg);
						}
					}, this);
					var fnError = jQuery.proxy(function (d) {
						var r = JSON.parse(JSON.stringify(d));
						sap.ui.core.BusyIndicator.hide();
						MessageToast.show(r.message, {
							autoClose: true,
							width: "20rem"
						});
					}, this);
					var sPath = "/BRFHeaderSet";
					var aFilter = [];
					var oFilterSerach;
					/*Start of change by developer Satabdi Das on 25-May-2021 for HTTP Error*/
					if (rrfNo) {
						rrfNo = formatter.formatValueToString(rrfNo); /*Change added by developer Satabdi Das on 25-May-2021 for HTTP Error*/
					}
					/*End of change by developer Satabdi Das on 25-May-2021 for HTTP Error*/
					oFilterSerach = new sap.ui.model.Filter("BrfNo", sap.ui.model.FilterOperator.EQ, rrfNo);
					aFilter.push(oFilterSerach);

					if (this.getView().getModel("oBrfModel").getProperty("/oDisplayBtnPress") === "true") {
						oFilterSerach = new Filter("CompanyCode", FilterOperator.EQ, "D");
						aFilter.push(oFilterSerach);
					}
					// var sParams = {};
					// var oObject = {};
					// oObject.Filter = aFilter;
					// oObject.Params = sParams;
					// oObject.successCallback = fnSuccess;
					// oObject.errorCallback = fnError;
					// oObject.sPath = sPath;
					// DataManagerBrf.getRRFHeaderSetvalueBRF(oObject);
					/*R&D---start*/
					var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_BRF_SRV/", {
						json: true
					});
					oModel1.read("/BRFHeaderSet", {
						filters: aFilter,
						urlParameters: {
							"$expand": "BRFItemSet,BRF_AnswerSet"
						},
						success: fnSuccess,
						error: fnError
					});
					/*R&D---end*/
					//end changes
				} else {
					var msg = this.getView().getModel("i18n").getProperty("RefRRFValidMsg");
					MessageBox.information(msg);

				}

			} else if (this.selectedIndex === 1) {
				var sCompCode = oBrfModel.getProperty("/brfHeaderSet/CompanyCode");
				if (!sCompCode) {
					sCompCode = "9901";
				}
				this.getView().getModel("oBrfModel").setProperty("/PORef", false);
				this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/SuppForwardIcon", false); /*Added by Satabdi Das for defect 63391 on 28-Oct-2020*/
				oBrfModel.setProperty("/oVisibleSet/SuppDisplayFwdIcon", false); /*Added by Satabdi Das for defect 63391 on 28-Oct-2020*/
				this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/buttonVis", true);
				oBrfModel.setProperty("/oVisibleSet/fieldEditable", true);
				oBrfModel.setProperty("/oVisibleSet/contrlNameEdit", true);
				this.getView().getModel("oBrfModel").setProperty("/brfHeaderSet/BrfType", invoice);
				this.getView().getModel("oBrfModel").setProperty("/brfTableSet", []);
				this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/vatEditDisplay", true);
				oRouter.navTo("TargetcoupaBrf", {
					/*Start of change for New comp code 9921 by developer Satabdi Das*/
					// No: "9901"   
					No: sCompCode
						/*End of changes for new comp code 9921 by developer Satabdi Das*/
						/*	No: obj.CompanyCode*/
				});
			}
		},

		onPressEditBrf: function (oEvent) {
			var oBrfModel = this.getView().getModel("oBrfModel");
			var oPlaceholdertext = this.getView().getModel("i18n").getProperty("BRFNumber");
			oBrfModel.setProperty("/brfHeaderSet", {});
			oBrfModel.setProperty("/oVisibleSet/editMode", true);
			oBrfModel.setProperty("/oVisibleSet/editable", true);
			oBrfModel.setProperty("/oVisibleSet/vatEditDisplay", true);
			oBrfModel.setProperty("/oVisibleSet/fieldEditable", false);
			oBrfModel.setProperty("/oVisibleSet/contrlNameEdit", false);
			this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/attchEnable", true);
			oBrfModel.setProperty("/oVisibleSet/editReqMF", true);
			oBrfModel.setProperty("/oVisibleSet/sendToContrl", false);
			oBrfModel.setProperty("/oVisibleSet/sendToSupp", false);
			oBrfModel.setProperty("/oVisibleSet/sendToVat", false);
			oBrfModel.setProperty("/oVisibleSet/sendToAR", false);
			oBrfModel.setProperty("/oVisibleSet/sendToAprrv", false);
			oBrfModel.setProperty("/oVisibleSet/enableAddMF", true);
			oBrfModel.setProperty("/oVisibleSet/enableAddGF", true);
			oBrfModel.setProperty("/oVisibleSet/enableDeltBtn", true);
			oBrfModel.setProperty("/oVisibleSet/apUrnForMf", true);
			oBrfModel.setProperty("/oDisplayBtnPress", false);
			oBrfModel.setProperty("/oVisibleSet/assigmentUrn", true);
			oBrfModel.setProperty("/oVisibleSet/withoutRef", false);
			oBrfModel.setProperty("/placeHolderText", oPlaceholdertext);
			oBrfModel.setProperty("/localBRFSearch", "");
			oBrfModel.setProperty("/oVisibleSet/creditNoteField", false);
			oBrfModel.setProperty("/oVisibleSet/amountfieldVisible", false);
			this.getModel("oBrfModel").setProperty("/questionSetSubmit", []);
			oBrfModel.setProperty("/TRFOwnerFlag", false);
			oBrfModel.setProperty("/ContrlTableBRFSet", []);
			oBrfModel.setProperty("/ContrlerBRfSet", {});
			oBrfModel.setProperty("/oVisibleSet/visiblecntlForBRF", false);
			oBrfModel.setProperty("/oDisplayBtnPress", "false");
			switch (this.oSelectedRadiobatton) {
			case 0:
				oPlaceholdertext = this.getView().getModel("i18n").getProperty("BRFNumber");
				oBrfModel.setProperty("/brfHeaderSet/BrfNo", "");
				oBrfModel.setProperty("/placeHolderText", oPlaceholdertext);
				break;
			case 1:

				oPlaceholdertext = this.getView().getModel("i18n").getProperty("RRFRefNo");
				oBrfModel.setProperty("/brfHeaderSet/BrfNo", "");
				oBrfModel.setProperty("/placeHolderText", oPlaceholdertext);
				break;
			case 2:
				oPlaceholdertext = this.getView().getModel("i18n").getProperty("createdby");

				oBrfModel.setProperty("/brfHeaderSet/BrfNo", "");
				oBrfModel.setProperty("/placeHolderText", oPlaceholdertext);
				break;

			}
			var oEditBrfFrg = this.getView().createId("editBrfFragment");
			if (!this._oEditBRFfragment) {
				this._oEditBRFfragment = sap.ui.xmlfragment(oEditBrfFrg, "KGO.kgoarrecharge_brf.view.editBRF", this);
				this.getView().addDependent(this._oEditBRFfragment);
			}
			if (this._oEditBRFfragment.isOpen()) {
				this._oEditBRFfragment.close();
			} else {
				this._oEditBRFfragment.open();
				this.authoCheck();
			}

		},
		onPressCancelEditBRF: function (oEvent) {
			var oBrfModel = this.getView().getModel("oBrfModel");
			oBrfModel.setProperty("/brfHeaderSet", {});
			if (this._oEditBRFfragment.isOpen()) {
				this._oEditBRFfragment.close();
			}
		},

		onSelectOptionEditBRF: function (oEvent) {

			var oPlaceholdertext;
			var oSelectedRadio = oEvent.getSource().getProperty("selectedIndex");
			this.oSelectedRadiobatton = oSelectedRadio;
			var oBrfModel = this.getView().getModel("oBrfModel");
			oBrfModel.setProperty("/placeHolderText");

			switch (oSelectedRadio) {
			case 0:
				oPlaceholdertext = this.getView().getModel("i18n").getProperty("BRFNumber");
				oBrfModel.setProperty("/brfHeaderSet/BrfNo", "");
				oBrfModel.setProperty("/placeHolderText", oPlaceholdertext);
				break;
			case 1:

				oPlaceholdertext = this.getView().getModel("i18n").getProperty("RRFRefNo");
				oBrfModel.setProperty("/brfHeaderSet/BrfNo", "");
				oBrfModel.setProperty("/placeHolderText", oPlaceholdertext);
				break;
			case 2:
				oPlaceholdertext = this.getView().getModel("i18n").getProperty("createdby");

				oBrfModel.setProperty("/brfHeaderSet/BrfNo", "");
				oBrfModel.setProperty("/placeHolderText", oPlaceholdertext);
				break;

			}

		},
		onPressSearchHelpEdit: function (oEvent) {
			var oBrfModel = this.getView().getModel("oBrfModel");

			if (this.oSelectedRadiobatton) {
				if (this.oSelectedRadiobatton === 0) {
					this.OnSearchHelpBRFNo(oEvent);
				} else if (this.oSelectedRadiobatton === 1) {
					oBrfModel.setProperty("/oVisibleRRF", true);
					oBrfModel.setProperty("/oVisibleSet/displayLinkShow", true);
					oBrfModel.setProperty("/oVisibleSet/editLinkShow", true);
					this.OnSearchHelpRRFNo(oEvent);
				} else if (this.oSelectedRadiobatton === 2) {
					oBrfModel.setProperty("/oVisibleSet/displayLinkShow", true);
					oBrfModel.setProperty("/oVisibleSet/editLinkShow", true);
					oBrfModel.setProperty("/oVisibleRRF", false);
					this.OnSearchHelpRRFNo(oEvent);
				}
			} else {
				this.OnSearchHelpBRFNo(oEvent);
			}
		},

		// handlePressEditBRF: function (oEvent) {
		// 	//code added by prashant for other edit options on 28.08.2020
		// 	//checking authorization
		// 	var oBrfModel = this.getView().getModel("oBrfModel");
		// 	var oAuthAccess = oBrfModel.getProperty("/authoSet");
		// 	if (oAuthAccess.GpEditDisplay) {
		// 		if (((this.oSelectedRadiobatton === 1) || (this.oSelectedRadiobatton === 2)) && (oEvent)) {
		// 			var oLiveSearchText;
		// 			var oBrfModel = this.getView().getModel("oBrfModel");
		// 			oBrfModel.setProperty("/oVisibleSet/displayLinkShow", false);
		// 			oBrfModel.setProperty("/oVisibleSet/editLinkShow", true);
		// 			var rrfNo = this.getView().getModel("oBrfModel").getProperty("/brfHeaderSet").BrfNo;
		// 			var sErrorMsg = this.getView().getModel("i18n").getProperty("noResultsError"); /*Added by Satabdi Das on 04-Sep-2020*/
		// 			if (rrfNo !== "") { /*Added by Satabdi Das on 04-Sep-2020*/
		// 				sap.ui.core.BusyIndicator.show(0);
		// 				var aFilter = [];

		// 				var fnSuccess = jQuery.proxy(function (d) {
		// 					sap.ui.core.BusyIndicator.hide(0);
		// 					if (d.results.length > 0) {
		// 						oBrfModel.setProperty("/BrfCreatorSet", d.results);

		// 						var oRRFFragment = this.getView().createId("RRFNumberSearch2");
		// 						if (!this._oSearchterminatorForRRF) {
		// 							this._oSearchterminatorForRRF = sap.ui.xmlfragment(oRRFFragment, "KGO.kgoarrecharge_brf.view.rrfNumberSearchHelp", this);
		// 							this.getView().addDependent(this._oSearchterminatorForRRF);
		// 						}
		// 						this._oSearchterminatorForRRF.open();
		// 						this.onLiveChangSearch();

		// 					} else {
		// 						MessageBox.error(sErrorMsg);
		// 					}

		// 				}, this);

		// 				var fnError = jQuery.proxy(function (d) {
		// 					var r = JSON.parse(JSON.stringify(d));
		// 					sap.ui.core.BusyIndicator.hide();

		// 					MessageToast.show(r.message, {
		// 						autoClose: true,
		// 						width: "20rem"

		// 					});
		// 				}, this);

		// 				var oFilterSerach;
		// 				if ((this.oSelectedRadiobatton == 1)) {
		// 					oLiveSearchText = this.getView().getModel("i18n").getProperty("brfNumber");
		// 					oBrfModel.setProperty("/setPlaceHolderText", oLiveSearchText);
		// 					oFilterSerach = new sap.ui.model.Filter("RrfNo", sap.ui.model.FilterOperator.EQ, rrfNo);
		// 					aFilter.push(oFilterSerach);
		// 				} else if ((this.oSelectedRadiobatton == 2)) {
		// 					oLiveSearchText = this.getView().getModel("i18n").getProperty("brfNumber");
		// 					oBrfModel.setProperty("/setPlaceHolderText", oLiveSearchText);
		// 					oFilterSerach = new sap.ui.model.Filter("BrfCreatedBy", sap.ui.model.FilterOperator.EQ, rrfNo);
		// 					aFilter.push(oFilterSerach);
		// 				}
		// 				var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_BRF_SRV/", {
		// 					json: true
		// 				});
		// 				oModel1.read("/BRF_CreatorSet", {
		// 					filters: aFilter,
		// 					success: fnSuccess,
		// 					error: fnError
		// 				});
		// 				/*R&D---end*/
		// 				/*Start of change by developer Satabdi Das on 04-Sep-2020*/
		// 			} else {
		// 				MessageBox.error(sErrorMsg);
		// 			}
		// 			/*End of change by developer Satabdi Das on 04-Sep-2020*/
		// 		} //end of changes on 28.08.2020
		// 		else {
		// 			if (oAuthAccess.GpEditDisplay === "D" && oEvent) {
		// 				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
		// 				MessageBox.error(
		// 					"You are not authorized to edit/view this BRF.", {
		// 						styleClass: bCompact ? "sapUiSizeCompact" : ""
		// 					}
		// 				);
		// 				return;
		// 			}
		// 			var that = this;
		// 			var oBrfModel = this.getView().getModel("oBrfModel");
		// 			// var bWithRef = oBrfModel.getProperty("/oVisibleSet/withRRF");
		// 			var editBRFText = this.getView().getModel("i18n").getProperty("editBRFText");
		// 			oBrfModel.setProperty("/setDashBoardTextForBRF", editBRFText);
		// 			var title = this.getView().getModel("i18n").getProperty("title");
		// 			var fisYr = this.getView().getModel("i18n").getProperty("fiscalyear");
		// 			var year;
		// 			var sHeading;
		// 			this.getModel("oBrfModel").setProperty("/oVisibleSet/attachVisible", true);
		// 			if (oEvent) {
		// 				if ((!oBrfModel.getProperty("/brfHeaderSet").BrfNo) && (oEvent.getParameter("id").split("--")[2] !==
		// 						"editBrfFragment")) {
		// 					var getObjectVal = oEvent.getSource().getBindingContext("oBrfModel");
		// 					if (!getObjectVal) {
		// 						MessageBox.error("This BRF does not exist in the system.");
		// 						return;
		// 					} else {
		// 						var oBRFNumber = getObjectVal.getObject();
		// 						oBrfModel.setProperty("/brfHeaderSet/BrfNo", oBRFNumber.BrfNo);
		// 					}

		// 				}
		// 			} else {
		// 				if (((this.oSelectedRadiobatton === 1) || (this.oSelectedRadiobatton === 2))) {
		// 					oBrfModel.setProperty("/brfHeaderSet/BrfNo", this.oBrfNumber);
		// 				}
		// 			}

		// 			var oRouter = UIComponent.getRouterFor(this);
		// 			this.brfMFSearchHelp();
		// 			this.currencyDropDown();
		// 			this.DocTypeDropDown(); /*Added on 15-Sep-2020 by Satabdi Das*/
		// 			if (oBrfModel.getProperty("/brfHeaderSet").BrfNo) {
		// 				var BrfNo = oBrfModel.getProperty("/brfHeaderSet").BrfNo;
		// 				//start change
		// 				var fnSuccess = jQuery.proxy(function (d) {
		// 					if (d.results.length !== 0) {
		// 						if (!d.results[0].BrfNo) {
		// 							MessageBox.error("This BRF does not exist in the system.");
		// 							return;
		// 						}

		// 						var arrAnswer = [];
		// 						sap.ui.core.BusyIndicator.hide(0);
		// 						var bFlag; /*Added on 06-MAY-2020*/
		// 						if (d.results[0].RrfNo !== "" && d.results[0].RrfNo !== undefined) {
		// 							this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/withRRF", true); /*Added by Satabdi Das on 28-Oct-2020 for defect 63391*/
		// 							this.getModel("oBrfModel").setProperty("/oVisibleSet/buttonVis", false);
		// 							oBrfModel.setProperty("/oVisibleSet/addIcon", false);
		// 							oBrfModel.setProperty("/oVisibleSet/AddDisplIcon", false);
		// 							oBrfModel.setProperty("/oVisibleSet/fieldEditable", false);
		// 							oBrfModel.setProperty("/oVisibleSet/contrlNameEdit", false);
		// 							if (d.results[0].RrfNo.indexOf("PO") >= 0) {
		// 								this.getView().getModel("oBrfModel").setProperty("/PORef", true);
		// 							} else {
		// 								this.getView().getModel("oBrfModel").setProperty("/PORef", false);
		// 							}

		// 						} else {
		// 							this.getModel("oBrfModel").setProperty("/oVisibleSet/buttonVis", true);
		// 							this.getView().getModel("oBrfModel").setProperty("/PORef", false);
		// 							this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/withRRF", false); /*Added by Satabdi Das on 28-Oct-2020 for defect 63391*/
		// 						}
		// 						if (d.results[0].Display === "X") {
		// 							this.getModel("oBrfModel").setProperty("/Display", true);
		// 							this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/editable", false);
		// 							this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/vatEditDisplay", false);
		// 							this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/vatEditDisplay", false);
		// 							this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/fieldEditable", false);
		// 							oBrfModel.setProperty("/oVisibleSet/contrlNameEdit", false);
		// 							oBrfModel.setProperty("/oVisibleSet/sendToContrl", false);
		// 							oBrfModel.setProperty("/oVisibleSet/sendToSupp", false);
		// 							oBrfModel.setProperty("/oVisibleSet/sendToVat", false);
		// 							oBrfModel.setProperty("/oVisibleSet/sendToAR", false);
		// 							oBrfModel.setProperty("/oVisibleSet/sendToAprrv", false);

		// 							if (this.getModel("oBrfModel").getProperty("/oVisibleSet").buttonVis === false) {
		// 								oBrfModel.setProperty("/oVisibleSet/addIcon", false);
		// 								oBrfModel.setProperty("/oVisibleSet/AddDisplIcon", false);
		// 								oBrfModel.setProperty("/oVisibleSet/SuppForwardIcon", false); /*Added by Satabdi Das for defect 63391 on 28-Oct-2020*/
		// 								oBrfModel.setProperty("/oVisibleSet/SuppDisplayFwdIcon", true); /*Added by Satabdi Das for defect 63391 on 28-Oct-2020*/

		// 							} else {
		// 								oBrfModel.setProperty("/oVisibleSet/SuppForwardIcon", false); /*Added by Satabdi Das for defect 63391 on 28-Oct-2020*/
		// 								oBrfModel.setProperty("/oVisibleSet/SuppDisplayFwdIcon", false); /*Added by Satabdi Das for defect 63391 on 28-Oct-2020*/
		// 								if (this.getView().getModel("oBrfModel").getProperty("/oDisplayBtnPress") === "true") {

		// 									oBrfModel.setProperty("/oVisibleSet/addIcon", false);
		// 									oBrfModel.setProperty("/oVisibleSet/AddDisplIcon", true);
		// 									oBrfModel.setProperty("/oVisibleSet/enableAddMF", false);
		// 									oBrfModel.setProperty("/oVisibleSet/enableAddGF", false);
		// 								} else {
		// 									oBrfModel.setProperty("/oVisibleSet/addIcon", true);
		// 									oBrfModel.setProperty("/oVisibleSet/AddDisplIcon", false);
		// 									oBrfModel.setProperty("/oVisibleSet/enableAddMF", true);
		// 									oBrfModel.setProperty("/oVisibleSet/enableAddGF", true);
		// 								}
		// 							}

		// 						} else {
		// 							if ((this.getView().getModel("oBrfModel").getProperty("/oDisplayBtnPress") === "false") || !this.getView().getModel(
		// 									"oBrfModel").getProperty("/oDisplayBtnPress")) {
		// 								this.getModel("oBrfModel").setProperty("/Display", false);
		// 								this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/editable", true);
		// 								oBrfModel.setProperty("/oVisibleSet/sendToContrl", true);
		// 								oBrfModel.setProperty("/oVisibleSet/sendToSupp", true);
		// 								oBrfModel.setProperty("/oVisibleSet/sendToVat", true);
		// 								oBrfModel.setProperty("/oVisibleSet/sendToAR", true);
		// 								oBrfModel.setProperty("/oVisibleSet/sendToAprrv", true);
		// 								oBrfModel.setProperty("/oVisibleSet/forwardIcon", true);
		// 								oBrfModel.setProperty("/oVisibleSet/displayFwdIcon", false);
		// 								oBrfModel.setProperty("/oVisibleSet/fieldEditable", false);
		// 								oBrfModel.setProperty("/oVisibleSet/contrlNameEdit", false);
		// 								if (this.getModel("oBrfModel").getProperty("/oVisibleSet").buttonVis === false) {
		// 									oBrfModel.setProperty("/oVisibleSet/SuppForwardIcon", true); /*Added by Satabdi Das for defect 63391 on 28-Oct-2020*/
		// 									oBrfModel.setProperty("/oVisibleSet/SuppDisplayFwdIcon", false); /*Added by Satabdi Das for defect 63391 on 28-Oct-2020*/
		// 									oBrfModel.setProperty("/oVisibleSet/addIcon", false);
		// 									oBrfModel.setProperty("/oVisibleSet/AddDisplIcon", false);
		// 								} else {
		// 									oBrfModel.setProperty("/oVisibleSet/SuppForwardIcon", false); /*Added by Satabdi Das for defect 63391 on 28-Oct-2020*/
		// 									oBrfModel.setProperty("/oVisibleSet/SuppDisplayFwdIcon", false); /*Added by Satabdi Das for defect 63391 on 28-Oct-2020*/
		// 									oBrfModel.setProperty("/oVisibleSet/addIcon", true);
		// 									oBrfModel.setProperty("/oVisibleSet/AddDisplIcon", false);
		// 								}

		// 								/*Start of change on 06-MAY-2020*/
		// 								// for (var i = 0; i < d.results[0].BRFItemSet.results.length; i++) {
		// 								// 	if (d.results[0].BRFItemSet.results[i].LineStatus === "CONTROLLER" || d.results[0].BRFItemSet.results[i].LineStatus ===
		// 								// 		"SUPPLIER") {
		// 								// 		bFlag = true;
		// 								// 	}
		// 								// }
		// 								// if (bFlag === true) {
		// 								// 	oBrfModel.setProperty("/oVisibleSet/enableAddMF", true);
		// 								// 	oBrfModel.setProperty("/oVisibleSet/enableAddGF", true);
		// 								// 	oBrfModel.setProperty("/oVisibleSet/buttonVis", true);
		// 								// } else if (bFlag === undefined) {
		// 								// 	oBrfModel.setProperty("/oVisibleSet/enableAddMF", false);
		// 								// 	oBrfModel.setProperty("/oVisibleSet/enableAddGF", false);
		// 								// 	oBrfModel.setProperty("/oVisibleSet/buttonVis", false);
		// 								// }
		// 								/*End of change on 06-MAY-2020*/
		// 							} else {
		// 								this.getView().getModel("oBrfModel").setProperty("/oVisibleSet/editable", false);
		// 								oBrfModel.setProperty("/oVisibleSet/sendToContrl", false);
		// 								oBrfModel.setProperty("/oVisibleSet/sendToSupp", false);
		// 								oBrfModel.setProperty("/oVisibleSet/sendToVat", false);
		// 								oBrfModel.setProperty("/oVisibleSet/sendToAR", false);
		// 								oBrfModel.setProperty("/oVisibleSet/sendToAprrv", false);
		// 								oBrfModel.setProperty("/oVisibleSet/enableAddMF", false);
		// 								oBrfModel.setProperty("/oVisibleSet/enableAddGF", false);
		// 								oBrfModel.setProperty("/oVisibleSet/forwardIcon", false);
		// 								oBrfModel.setProperty("/oVisibleSet/displayFwdIcon", true);
		// 								oBrfModel.setProperty("/oVisibleSet/fieldEditable", false);
		// 								oBrfModel.setProperty("/oVisibleSet/contrlNameEdit", false);

		// 								if (this.getModel("oBrfModel").getProperty("/oVisibleSet").buttonVis === false) {
		// 									oBrfModel.setProperty("/oVisibleSet/addIcon", false);
		// 									oBrfModel.setProperty("/oVisibleSet/AddDisplIcon", false);
		// 									oBrfModel.setProperty("/oVisibleSet/SuppForwardIcon", false); /*Added by Satabdi Das for defect 63391 on 28-Oct-2020*/
		// 									oBrfModel.setProperty("/oVisibleSet/SuppDisplayFwdIcon", true); /*Added by Satabdi Das for defect 63391 on 28-Oct-2020*/
		// 								} else {
		// 									oBrfModel.setProperty("/oVisibleSet/addIcon", false);
		// 									oBrfModel.setProperty("/oVisibleSet/AddDisplIcon", true);
		// 									oBrfModel.setProperty("/oVisibleSet/SuppForwardIcon", false); /*Added by Satabdi Das for defect 63391 on 28-Oct-2020*/
		// 									oBrfModel.setProperty("/oVisibleSet/SuppDisplayFwdIcon", false); /*Added by Satabdi Das for defect 63391 on 28-Oct-2020*/
		// 								}

		// 							}
		// 						}
		// 						for (var i = 0; i < d.results.length; i++) {
		// 							var obj = {};
		// 							var oLineItemArr = [];
		// 							obj.BrfNo = d.results[i].BrfNo;
		// 							obj.RrfNo = d.results[i].RrfNo;
		// 							obj.BrfType = d.results[i].BrfType;
		// 							obj.ContrlName = d.results[i].ContrlName;
		// 							obj.ContrlEmail = d.results[i].ContrlEmail;
		// 							obj.BrfCreationDate = d.results[i].BrfCreationDate;
		// 							obj.BrfCreatedBy = d.results[i].BrfCreatedBy;
		// 							obj.BrfCreatorName = d.results[i].BrfCreatorName; /* Added by Satabdi Das on 15-Jan-2021 for defect 63786*/
		// 							obj.Gjahr = d.results[i].Gjahr;
		// 							obj.SchDate = d.results[i].SchDate;
		// 							obj.Automated = d.results[i].Automated;
		// 							obj.Flag = d.results[i].Flag; /*Added on 01-Apr-2021*/
		// 							obj.Message = d.results[i].Message; /*Added on 01-Apr-2021*/
		// 							obj.InvoiceAmount = d.results[i].InvoiceAmount;
		// 							obj.GrossAmtLocal = d.results[i].GrossAmtLocal;
		// 							obj.CurrencyLocal = d.results[i].CurrencyLocal;
		// 							obj.NetAmount = d.results[i].NetAmount;
		// 							obj.DocCurrency = d.results[i].DocCurrency;
		// 							obj.SapDocYear = d.results[i].SapDocYear;
		// 							obj.SapDocNum = d.results[i].SapDocNum;
		// 							obj.BukrsUrn = d.results[i].BukrsUrn;
		// 							obj.Urn = d.results[i].Urn;
		// 							obj.ToDisplay = d.results[i].ToDisplay;
		// 							obj.CompanyCode = d.results[i].CompanyCode; /*Added for new Comp Code 9921 by Satabdi Das*/
		// 							obj.Display = d.results[i].Display;
		// 							oLineItemArr = d.results[i].BRFItemSet;
		// 							arrAnswer = d.results[i].BRF_AnswerSet;
		// 							this.getView().getModel("oBrfModel").setProperty("/brfHeaderSet", obj);
		// 							this.getView().getModel("oBrfModel").setProperty("/brfTableSet", oLineItemArr.results);
		// 							this.getView().getModel("oBrfModel").setProperty("/questionSetSubmit", arrAnswer.results);
		// 						}

		// 						if (obj.BrfNo) {
		// 							oBrfModel.setProperty("/oVisibleSet/vendorInvoiceField", false);
		// 						}
		// 						year = this.getView().getModel("oBrfModel").getProperty("/brfHeaderSet").Gjahr;
		// 						sHeading = title + " " + BrfNo + " " + fisYr + " " + year;
		// 						this.getView().getModel("oBrfModel").setProperty("/setHeading", sHeading);
		// 						var fragId = this.getView().createId("searchRRFNo");
		// 						var SearchId = sap.ui.core.Fragment.byId(fragId, "localBRFSearch");
		// 						if (SearchId) {
		// 							SearchId.setValue("");
		// 							var aFilter = [];
		// 							aFilter.push(new Filter("BrfNo", FilterOperator.Contains, ""));
		// 							var frag = this.getView().createId("searchRRFNo");
		// 							var table = sap.ui.core.Fragment.byId(frag, "tableBRFSerch");
		// 							var oBinding = table.getBinding("items");
		// 							oBinding.filter(aFilter, "Application");
		// 							this._oSearchCoordinatorForRRF.close();
		// 						}
		// 						//SCTASK Transfer owner
		// 						// if (obj.ToDisplay === "X"  && (oBrfModel.getProperty("/oDisplayBtnPress")==="false")) {
		// 						// 	oBrfModel.setProperty("/oVisibleSet/contrlNameEdit", true);
		// 						// }else{
		// 						// 	oBrfModel.setProperty("/oVisibleSet/contrlNameEdit", false);
		// 						// }
		// 						if (!obj.Flag) {
		// 							oRouter.navTo("TargetcoupaBrf", {
		// 								No: obj.BrfNo
		// 									/*	No: obj.CompanyCode*/
		// 							});
		// 						} else {
		// 							MessageBox.error(obj.Message);
		// 						}
		// 						/*End of change by satabdi das for concurrent user lock on 01-Apr-2021*/

		// 					} else {
		// 						MessageBox.error("This BRF does not exist in the system.");
		// 					}
		// 				}, this);

		// 				var fnError = jQuery.proxy(function (d) {
		// 						var r = JSON.parse(JSON.stringify(d));
		// 						sap.ui.core.BusyIndicator.hide();
		// 						MessageToast.show(r.message, {
		// 							autoClose: true,
		// 							width: "20rem"

		// 						});

		// 					}, this

		// 				);

		// 				var sPath = "/BRFHeaderSet";
		// 				var aFilter = [];

		// 				var oFilterSerach;

		// 				/*Start of change by developer Satabdi Das on 25-May-2021 for HTTP Error*/
		// 				if (BrfNo) {
		// 					BrfNo = formatter.formatValueToString(BrfNo); /*Change added by developer Satabdi Das on 25-May-2021 for HTTP Error*/
		// 				}
		// 				/*End of change by developer Satabdi Das on 25-May-2021 for HTTP Error*/
		// 				oFilterSerach = new sap.ui.model.Filter("BrfNo", sap.ui.model.FilterOperator.EQ, BrfNo);
		// 				aFilter.push(oFilterSerach);

		// 				if (this.getView().getModel("oBrfModel").getProperty("/oDisplayBtnPress") === "true") {
		// 					oFilterSerach = new Filter("CompanyCode", FilterOperator.EQ, "D");
		// 					aFilter.push(oFilterSerach);
		// 				}

		// 				// var sParams = {};
		// 				// var oObject = {};
		// 				// oObject.Filter = aFilter;
		// 				// oObject.Params = sParams;
		// 				// oObject.successCallback = fnSuccess;
		// 				// oObject.errorCallback = fnError;
		// 				// oObject.sPath = sPath;
		// 				// DataManagerBrf.getRRFHeaderSetvalueBRF(oObject);
		// 				/*R&D---start*/
		// 				var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_BRF_SRV/", {
		// 					json: true
		// 				});
		// 				oModel1.read("/BRFHeaderSet", {
		// 					filters: aFilter,
		// 					urlParameters: {
		// 						"$expand": "BRFItemSet,BRF_AnswerSet"
		// 					},
		// 					success: fnSuccess,
		// 					error: fnError
		// 				});
		// 				/*R&D---end*/

		// 				//end changes
		// 			} else {
		// 				MessageBox.error("Please enter  BRF number.");
		// 			}

		// 		}
		// 	} else {
		// 		var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
		// 		MessageBox.error(
		// 			"You are not authorized to edit/view this BRF.", {
		// 				styleClass: bCompact ? "sapUiSizeCompact" : ""
		// 			}
		// 		);
		// 		return;
		// 	}

		// },

		onDisplayPress: function (oEvent) {
			var oBrfModel = this.getModel("oBrfModel");
			var oAuthAccess = oBrfModel.getProperty("/authoSet");
			if (oAuthAccess.GpEditDisplay) {
				oBrfModel.setProperty("/oDisplayBtnPress", "true");
				var editBRFText = this.getView().getModel("i18n").getProperty("displayBRF");
				oBrfModel.setProperty("/setDashBoardTextForBRF", editBRFText);

				if ((!oBrfModel.getProperty("/brfHeaderSet").BrfNo) && (oEvent.getParameter("id").split("--")[2] != "editBrfFragment")) {
					var brfNo = oEvent.getSource().getBindingContext("oBrfModel").getObject();
					this.getView().getModel("oBrfModel").setProperty("/brfHeaderSet/BrfNo", brfNo.BrfNo);

				}
				if ((this.oSelectedRadiobatton === 0) || (!this.oSelectedRadiobatton)) {

					this.handlePressEditBRF();
					var editBRFText = this.getView().getModel("i18n").getProperty("displayBRF");
					oBrfModel.setProperty("/setDashBoardTextForBRF", editBRFText);
					this.getModel("oBrfModel").setProperty("/oVisibleSet/editMode", false);
					oBrfModel.setProperty("/oVisibleSet/editable", false);
					oBrfModel.setProperty("/oVisibleSet/vatEditDisplay", false);
					oBrfModel.setProperty("/oVisibleSet/fieldEditable", false);
					oBrfModel.setProperty("/oVisibleSet/contrlNameEdit", false);
					oBrfModel.setProperty("/oVisibleSet/attchEnable", false);
					oBrfModel.setProperty("/oVisibleSet/editReqMF", false);
					oBrfModel.setProperty("/oVisibleSet/enableDeltBtn", false);
					oBrfModel.setProperty("/entityEdit", false); /*Added for defect 63290*/
					oBrfModel.setProperty("/oVisibleSet/sendToContrl", false);
					oBrfModel.setProperty("/oVisibleSet/sendToSupp", false);
					oBrfModel.setProperty("/oVisibleSet/sendToVat", false);
					oBrfModel.setProperty("/oVisibleSet/sendToAR", false);
					oBrfModel.setProperty("/oVisibleSet/sendToAprrv", false);

				}
				if ((this.oSelectedRadiobatton === 1) || (this.oSelectedRadiobatton === 2)) {

					if ((oEvent.getSource().getProperty("text") === "Display") && (oEvent.getParameter("id").split("--")[2] !== "editBrfFragment")) {
						var brfNo = oEvent.getSource().getBindingContext("oBrfModel").getObject();
						this.oBrfNumber = brfNo.BrfNo;
						this.handlePressEditBRF();
						var editBRFText = this.getView().getModel("i18n").getProperty("displayBRF");
						oBrfModel.setProperty("/setDashBoardTextForBRF", editBRFText);
						this.getModel("oBrfModel").setProperty("/oVisibleSet/editMode", false);
						oBrfModel.setProperty("/oVisibleSet/editable", false);
						oBrfModel.setProperty("/oVisibleSet/vatEditDisplay", false);
						oBrfModel.setProperty("/oVisibleSet/fieldEditable", false);
						oBrfModel.setProperty("/oVisibleSet/contrlNameEdit", false);
						oBrfModel.setProperty("/oVisibleSet/attchEnable", false);
						oBrfModel.setProperty("/oVisibleSet/editReqMF", false);
						oBrfModel.setProperty("/oVisibleSet/enableDeltBtn", false);
						oBrfModel.setProperty("/entityEdit", false); /*Added for defect 63290*/
						oBrfModel.setProperty("/oVisibleSet/sendToContrl", false);
						oBrfModel.setProperty("/oVisibleSet/sendToSupp", false);
						oBrfModel.setProperty("/oVisibleSet/sendToVat", false);
						oBrfModel.setProperty("/oVisibleSet/sendToAR", false);
						oBrfModel.setProperty("/oVisibleSet/sendToAprrv", false);

					} else {
						this.onPressDisplayforOtherRadio();
						oBrfModel.setProperty("/oVisibleSet/editLinkShow", false);
						oBrfModel.setProperty("/oVisibleSet/displayLinkShow", true);
					}
				}
			} else {
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				MessageBox.error(
					"You are not authorized to edit/view  BRF.", {
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					}
				);
				return;
			}

		},
		//added by prashant for other edit options 26.08.2020

		onPressDisplayforOtherRadio: function () {
			if (((this.oSelectedRadiobatton == 1) || (this.oSelectedRadiobatton == 2))) {

				var rrfNo = this.getView().getModel("oBrfModel").getProperty("/brfHeaderSet").BrfNo;
				var sErrorMsg = this.getView().getModel("i18n").getProperty("noResultsError"); /*Added by Satabdi Das on 04-Sep-2020*/
				if (rrfNo !== "") { /*Added by Satabdi Das on 04-Sep-2020*/

					sap.ui.core.BusyIndicator.show(0);

					var aFilter = [];

					var fnSuccess = jQuery.proxy(function (d) {
						sap.ui.core.BusyIndicator.hide(0);
						if (d.results.length > 0) {

							var oBrfModel = this.getView().getModel("oBrfModel");
							oBrfModel.setProperty("/BrfCreatorSet", d.results);

							var oRRFFragment = this.getView().createId("RRFNumberSearch2");
							if (!this._oSearchterminatorForRRF) {
								this._oSearchterminatorForRRF = sap.ui.xmlfragment(oRRFFragment, "KGO.kgoarrecharge_brf.view.rrfNumberSearchHelp", this);
								this.getView().addDependent(this._oSearchterminatorForRRF);
							}
							this._oSearchterminatorForRRF.open();
							this.onLiveChangSearch();
						} else {
							MessageBox.error(sErrorMsg);
						}

					}, this);

					var fnError = jQuery.proxy(function (d) {
						var r = JSON.parse(JSON.stringify(d));
						sap.ui.core.BusyIndicator.hide();

						MessageToast.show(r.message, {
							autoClose: true,
							width: "20rem"

						});
					}, this);

					var oFilterSerach;
					if ((this.oSelectedRadiobatton == 1)) {
						oFilterSerach = new sap.ui.model.Filter("RrfNo", sap.ui.model.FilterOperator.EQ, rrfNo);
						aFilter.push(oFilterSerach);
					} else if ((this.oSelectedRadiobatton == 2)) {
						oFilterSerach = new sap.ui.model.Filter("BrfCreatedBy", sap.ui.model.FilterOperator.EQ, rrfNo);
						aFilter.push(oFilterSerach);
					}
					var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_BRF_SRV/", {
						json: true
					});
					oModel1.read("/BRF_CreatorSet", {
						filters: aFilter,
						success: fnSuccess,
						error: fnError
					});
					/*R&D---end*/
					/*Start of change by developer Satabdi Das on 04-Sep-2020*/
				} else {
					MessageBox.error(sErrorMsg);
				}
				/*End of change by developer Satabdi Das on 04-Sep-2020*/

			}
		},
		onEditLinkPress: function (oEvent) {
			var oBrfModel = this.getModel("oBrfModel");
			var oAuthAccess = oBrfModel.getProperty("/authoSet");
			if (oAuthAccess.GpEditDisplay === "E") {
				var oRRFNumber = oEvent.getSource().getBindingContext("oBrfModel").getObject();
				if (this.oSelectedRadiobatton == 1) {
					if ((oRRFNumber.RrfNo)) {
						this.oBrfNumber = oRRFNumber.BrfNo;
						this.handlePressEditBRF();

					} else {
						MessageBox.error("Please Select  RRF  Number.");
					}

				}

				if (this.oSelectedRadiobatton == 2) {
					this.oBrfNumber = oRRFNumber.BrfNo;
					this.handlePressEditBRF();
				}
			} else {
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				MessageBox.error(
					"You are not authorized to edit/view  BRF.", {
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					}
				);
				return;
			}
		},

		onLiveChangSearch: function (oEvent) {
			var aFilter = [];
			var oBrfModel = this.getView().getModel("oBrfModel");
			var oLiveSrchText = oBrfModel.getProperty("/setPlaceHolderText");
			if (oBrfModel.getProperty("/localBRFSearch")) {
				var sQuery = oBrfModel.getProperty("/localBRFSearch");
				sQuery = sQuery.trim();
			}
			if (sQuery && (this.oSelectedRadiobatton === 0 || !this.oSelectedRadiobatton)) {
				aFilter.push(new Filter("BrfNo", FilterOperator.Contains, sQuery));
			} else if (sQuery && (this.oSelectedRadiobatton === 1) && (oLiveSrchText !== "BRF Number")) {
				aFilter.push(new Filter("RrfNo", FilterOperator.Contains, sQuery));
			} else if (sQuery && (this.oSelectedRadiobatton === 2) && (oLiveSrchText !== "BRF Number")) {
				aFilter.push(new Filter("BrfCreatedBy", FilterOperator.Contains, sQuery));
			} else if (sQuery && (oLiveSrchText === "BRF Number") && (this.oSelectedRadiobatton !== 0)) {
				aFilter.push(new Filter("BrfNo", FilterOperator.Contains, sQuery));
			}

			var oRRFFragment = this.getView().createId("RRFNumberSearch2");
			var table = sap.ui.core.Fragment.byId(oRRFFragment, "tableRCr");
			var oBinding = table.getBinding("items");
			oBinding.filter(aFilter, "Application");

		},

		// handlePressEditBRF: function (oEvent) {
		// 	this.onNavbtn();

		// },
		// onNavbtn: function (oEvent) {

		// 	var xnavservice = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService && sap.ushell.Container.getService(
		// 		"CrossApplicationNavigation");
		// 	var href = (xnavservice && xnavservice.hrefForExternal({
		// 		target: {
		// 			semanticObject: "SupplierInvoice",
		// 			action: "manage"

		// 		},
		// 		params: {
		// 			"ProductID": this.getView().getModel("oBrfModel").getProperty("/brfHeaderSet").BrfNo
		// 		}
		// 	})) || "";
		// 	var finalUrl = window.location.href.split("#")[0] + href;
		// 	sap.m.URLHelper.redirect(finalUrl,true);
		// },

		currencyDropDown: function (oEvent) {
			sap.ui.core.BusyIndicator.show(0);
			var sPath = "";
			sPath = "/CURRSet"; // + Constant.CV_PV_LEAD_FIORI;
			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				var oBrfModel = this.getView().getModel("oBrfModel");
				oBrfModel.setSizeLimit(d.results.length);
				oBrfModel.setProperty("/CurrSet", d.results);
				this.getView().getModel("oBrfModel").setProperty("/CurrencySet", "");
			}, this);
			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();
				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"
				});
			}, this);
			// var oObject = {};
			// oObject.successCallback = fnSuccess;
			// oObject.errorCallback = fnError;
			// oObject.sPath = sPath;
			// DataManagerBrf.getCoupaCreateHelp(oObject);
			/*R&D---start*/
			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_BRF_SRV/", {
				json: true
			});
			oModel1.read("/CURRSet", {
				success: fnSuccess,
				error: fnError
			});
			/*R&D---end*/
		},

	});
});