jQuery.sap.declare("KGO.kgoarrecharge_brf.util.UIGlobal");

KGO.kgoarrecharge_brf.util.UIGlobal = (function () {
	var _isFromOpenTask = false;

	var _tableDataWorkflow = [];
	
	var _btnId = "";
	var _LongTextCharLimit = 70;

	return {
		getLongTextCharLimit: function () {
			return _LongTextCharLimit;
		},
		getFromOpenTask: function () {
			return _isFromOpenTask;
		},
		setFromOpenTask: function (isFromOpenTask) {
			_isFromOpenTask = isFromOpenTask;
		},
		getTableDataWorkflow: function () {
			return _tableDataWorkflow;
		},
		setTableDataWorkflow: function (tableDataWorkflow) {
			_tableDataWorkflow = tableDataWorkflow;
		},
		getBtnId: function () {
			return _btnId;
		},
		setBtnId: function (btnId) {
			_btnId = btnId;
		},
	};
}());