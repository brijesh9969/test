sap.ui.define([
	"sap/ui/model/json/JSONModel"

], function (JSONModel) {
	"use strict";

	var _modelBase = null;

	return {

		init: function (oObject) {

			// Getting model instance
			_modelBase = oObject.OData;

		},

		_getODataBrf: function (sPath, filter, oUrlParams, successCallback, errorCallback) {

			_modelBase.read(sPath, {
				filters: filter,
				success: successCallback,
				error: errorCallback,
				urlParameters: oUrlParams
			});

		},
		CreateBRFData: function (oPayload, oObject) {
			_modelBase.create("/BRFHeaderSet", oPayload, {
				success: oObject.successCallback,
				error: oObject.errorCallback
			});
		},
		SubmitBRFDataONSendWF: function (oPayload, oObject) {
			_modelBase.create("/BRFHeaderSet", oPayload, {
				success: oObject.successCallback,
				error: oObject.errorCallback
			});
		},
		getRRFHeaderSetvalueBRF: function (oObject) {
			var sFilter = oObject.Filter;
			//	var sParam = oObject.Params;
			var sParam = {
				"$expand": "BRFItemSet"
			};

			var fnSuccess = oObject.successCallback;
			var fnError = oObject.errorCallback;
			var sPath = oObject.sPath;
			this._getODataBrf(sPath, sFilter, sParam, fnSuccess, fnError);
		},

		getCoupaCreateHelp: function (oObject) {
			var sFilter = oObject.Filter;
			var sParam = oObject.Params;
			var fnSuccess = oObject.successCallback;
			var fnError = oObject.errorCallback;
			var sPath = oObject.sPath;
			this._getODataBrf(sPath, sFilter, sParam, fnSuccess, fnError);
		},
		getBRFContrlName: function (oObject) {
			var sFilter = oObject.Filter;
			var sParam = oObject.Params;
			var fnSuccess = oObject.successCallback;
			var fnError = oObject.errorCallback;
			var sPath = oObject.sPath;
			this._getODataBrf(sPath, sFilter, sParam, fnSuccess, fnError);
		},
		_getODataARRecharge: function (sPath, filter, oUrlParams, successCallback, errorCallback) {

			_modelBase.read(sPath, {
				filters: filter,
				success: successCallback,
				error: errorCallback,
				urlParameters: oUrlParams
			});

		},
		getCoupaReqiNumberhelpValus: function (oObject) {
			var sFilter = oObject.Filter;
			var sParam = oObject.Params;
			var fnSuccess = oObject.successCallback;
			var fnError = oObject.errorCallback;
			var sPath = oObject.sPath;
			this._getODataARRecharge(sPath, sFilter, sParam, fnSuccess, fnError);
		},
		_deleteODataBRF: function (_oObject) {
			_modelBase.remove(_oObject.sPath, {
				success: _oObject.successCallback,
				error: _oObject.errorCallback
			});
		},

	};
});