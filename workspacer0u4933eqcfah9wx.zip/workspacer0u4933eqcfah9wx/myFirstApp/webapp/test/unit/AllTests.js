sap.ui.define([
	"z/myFirstApp/test/unit/controller/View1.controller"
], function () {
	"use strict";
});