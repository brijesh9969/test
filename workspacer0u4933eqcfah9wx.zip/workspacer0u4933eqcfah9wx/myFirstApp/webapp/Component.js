sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"z/myFirstApp/model/models",
	"sap/ui/model/json/JSONModel"
], function (UIComponent, Device, models, JSONModel) {
	"use strict";

	return UIComponent.extend("z.myFirstApp.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function () {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// enable routing
			this.getRouter().initialize();

			// set the device model
			this.setModel(models.createDeviceModel(), "device");
			var oModelTtest = new JSONModel({});
			oModelTtest.setDefaultBindingMode("TwoWay");
			this.setModel(oModelTtest, "oModelTtest");
			var obj = {};
			var oldData={};
			obj.Name = "PK Sinha";
			obj.MobNum = "8438976423";
			obj.Street = "D/67";
			obj.zip = "851133";
			obj.state = "Manipur";
			obj.EmailId = "abc@XYZ.com";
			oldData.Name1 = "PK Sinha";
			oldData.MobNum1 = "8438976423";
			oldData.Street1 = "D/67";
			oldData.zip1 = "851133";
			oldData.state1 = "Manipur";
			oldData.EmailId1 = "abc@XYZ.com";
			oModelTtest.setProperty("/AddressSet", obj);
			oModelTtest.setProperty("/oldDataSet", oldData);
		}
	});
});