sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/UIComponent"
], function (Controller, UIComponent) {
	"use strict";

	return Controller.extend("z.myFirstApp.controller.View1", {
		onInit: function () {
			var oRouter = UIComponent.getRouterFor(this);
			
			this.byId('edit').setEnabled(true);

		},
		handleEditPress: function (oEvent) {
			this.getView().byId("EditBlock").setVisible(true);
			this.getView().byId("save").setVisible(true);
			this.getView().byId("cancel").setVisible(true);
			this.getView().byId("edit").setVisible(false);
			this.getView().byId("DisplayBlock").setVisible(false);
		},
		handleCancelPress: function (oEvent) {
			var getCancelData = this.getView().getModel("oModelTtest").getProperty("/oldDataSet");
			var oldData = {};
			oldData.Name = getCancelData.Name1;
			oldData.MobNum = getCancelData.MobNum1;
			oldData.Street = getCancelData.Street1;
			oldData.zip = getCancelData.zip1;
			oldData.state = getCancelData.state1;
			oldData.EmailId = getCancelData.EmailId1;
			this.getView().getModel("oModelTtest").setProperty("/AddressSet", oldData);
			this.getView().byId("edit").setVisible(true);
			this.getView().byId("DisplayBlock").setVisible(true);
			this.getView().byId("cancel").setVisible(false);
			this.getView().byId("save").setVisible(false);
			this.getView().byId("EditBlock").setVisible(false);
		},
		handleSavePress: function (oEvent) {
			var oUpdatedData = this.getView().getModel("oModelTtest").getProperty("/AddressSet");
			var object = {};
			object.Name1 = oUpdatedData.Name;
			object.MobNum1 = oUpdatedData.MobNum;
			object.Street1 = oUpdatedData.Street;
			object.zip1 = oUpdatedData.zip;
			object.state1 = oUpdatedData.state;
			object.EmailId1 = oUpdatedData.EmailId;
			this.getView().getModel("oModelTtest").setProperty("/oldDataSet", object);
			this.getView().byId("edit").setVisible(true);
			this.getView().byId("DisplayBlock").setVisible(true);
			this.getView().byId("cancel").setVisible(false);
			this.getView().byId("save").setVisible(false);
			this.getView().byId("EditBlock").setVisible(false);
		},
		onPressNave: function (oEvent) {
			var oRouter = UIComponent.getRouterFor(this);
			oRouter.navTo("RouteView2", {
				    
			});
		}
	});
});