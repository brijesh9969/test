jQuery.sap.declare(“z.myFirstApp.controller.Select”);
jQuery.sap.require(“sap.m.Select”);
jQuery.sap.require(“sap.m.SelectRenderer”);
sap.m.Select.extend(“z.myFirstApp.controller.Select”, {

     renderer: “sap.m.SelectRenderer”

});