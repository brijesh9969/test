sap.ui.define([
	"sap/ui/core/mvc/Controller",
	'sap/ui/core/routing/History',
		"sap/ui/core/UIComponent",
		"sap/m/MessageToast"
], function (Controller,History,UIComponent,MessageToast) {
	"use strict";

	return Controller.extend("z.myFirstApp.controller.View2", {
		onInit: function () {
		var oRouter = UIComponent.getRouterFor(this);
		

		},
		onPressBack:function(oEvent){
			var oRouter = UIComponent.getRouterFor(this);
			oRouter.navTo("RouteView1", {
				    
			});
		},
		onPressTile:function(oEvent){
			var msg=this.getView().getModel("i18n").getProperty("tilepress");
			MessageToast.show(msg);
		}
		
		});
	});