sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"sap/m/MessageToast",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox",
	"sap/ui/core/Fragment",
	"kgo/ARRecharge/util/DataManagerARrecharge",
	"kgo/ARRecharge/formatter/formatter",
	"sap/ui/core/UIComponent"
], function (Controller, History, MessageToast, JSONModel, Filter, FilterOperator, MessageBox, Fragment, DataManagerARrecharge, formatter,
	UIComponent) {
	"use strict";
	return Controller.extend("kgo.ARRecharge.controller.BaseController", {
		formatter: formatter,

		/**
		 * Convenience method for accessing the router in every controller of the application.
		 * @public
		 * @returns {sap.ui.core.routing.Router} the router for this component
		 */
		getRouter: function () {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},

		/**
		 * Convenience method for getting the view model by name in every controller of the application.
		 * @public
		 * @param {string} sName the model name
		 * @returns {sap.ui.model.Model} the model instance
		 */
		getModel: function (sName) {
			return this.getView().getModel(sName);
		},

		/**
		 * Convenience method for setting the view model in every controller of the application.
		 * @public
		 * @param {sap.ui.model.Model} oModel the model instance
		 * @param {string} sName the model name
		 * @returns {sap.ui.mvc.View} the view instance
		 */
		setModel: function (oModel, sName) {
			return this.getView().setModel(oModel, sName);
		},

		/**
		 * Convenience method for getting the resource bundle.
		 * @public
		 * @returns {sap.ui.model.resource.ResourceModel} the resourceModel of the component
		 */
		getResourceBundle: function () {
			return this.getOwnerComponent().getModel("i18n").getResourceBundle();
		},

		/**
		 * Event handler for navigating back.
		 * It there is a history entry or an previous app-to-app navigation we go one step back in the browser history
		 * If not, it will replace the current entry of the browser history with the master route.
		 * @public
		 */
		onNavBack: function () {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				this.getRouter().navTo("appHome", {}, true);
			}
		},

		onCompanyCodeValueHelp: function () {

			//	this.getView().getModel("mModelSummary").refresh();
			this.getView().getModel("mModelSummary").setProperty("/HeaderData/CompanyCode", []);
			var mModelSummary = this.getModel("mModelSummary");
			if (mModelSummary.getProperty("/HeaderData/CompanyCode")) {
				var vComanyCode = mModelSummary.getProperty("/HeaderData/CompanyCode");
			} else {
				vComanyCode = "";
			}

			var sSrchVal = vComanyCode;
			// var fragmentId = this.getView().createId("searchCoordinator");
			sap.ui.core.BusyIndicator.show(0);

			var aFilter = [];
			var mArrayOut = [];

			var oFilter;
			var sPath = "";
			/*oFilter = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Bukrs", FilterOperator.Contains, sSrchVal)
				]

			});*/

			// aFilter.push(oFilter);
			//sPath = "/RRF_COMPANYCODESet"; // + Constant.CV_PV_LEAD_FIORI;

			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				mModelSummary = this.getModel("mModelSummary");
				for (var i = 0; i < d.results.length; i++) {
					var oCompanyCode = {};

					oCompanyCode.Bukrs = d.results[i].Bukrs;
					oCompanyCode.Butxt = d.results[i].Butxt;
					mArrayOut.push(oCompanyCode);
				}
				mModelSummary.setProperty("/companyCodeSet", mArrayOut);

				mModelSummary.refresh(true);
				var fragmentId = this.getView().createId("searchCompanyCode");

				if (!this._oSearchCoordinator) {
					this._oSearchCoordinator = sap.ui.xmlfragment(fragmentId, "kgo.ARRecharge.view.searchHelp", this);
					this.getView().addDependent(this._oSearchCoordinator);
				}

				this._oSearchCoordinator.open();
			}, this);

			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();

				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"

				});
			}, this);

			/*R&D---start*/
			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
				json: true
			});
			oModel1.read("/RRF_COMPANYCODESet", {
				success: fnSuccess,
				error: fnError
			});
			/*R&D---end*/

			// var sParams = {};
			// var oObject = {};

			// oObject.Filter = aFilter;
			// oObject.Params = sParams;
			// oObject.successCallback = fnSuccess;
			// oObject.errorCallback = fnError;
			// oObject.sPath = sPath;
			// DataManagerARrecharge.getCompanyCodeSearchHelpValues(oObject);

		},
		onCntlerEmailPressHelp: function (oEvent) {
			var mModelSummary = this.getView().getModel("mModelSummary");
			mModelSummary.setProperty("/TRFOwnerFlag", false);
			var checkField = oEvent.getSource().getBinding("value").getPath();
			var valueField = checkField.split("/")[2];
			var sId = oEvent.getSource().getId().split("--")[2]; /*Added for defect 63445*/
			this.getView().getModel("mModelSummary").setProperty("/EmailFieldLnItem", valueField);
			sap.ui.core.BusyIndicator.show(0);
			this.getView().getModel("mModelSummary").setProperty("/ContrlNameSet", []);

			this.getView().getModel("mModelSummary").setProperty("/oEditable/visibleForcntrlEmail", false);
			/*Start defect 63445*/
			if (sId === "ContactPersonLOAId") {
				mModelSummary.setProperty("/updateRowData/LoaContact", "");
				mModelSummary.setProperty("/updateRowData/LoaEmail", "");
			}
			if (sId === "AdlLoaContact") {
				mModelSummary.setProperty("/updateRowData/AdlLoaContact", "");
				mModelSummary.setProperty("/updateRowData/AdlLoaEmail", "");
			}
			if (sId === "AttentionToPersoninBRFId") {
				mModelSummary.setProperty("/updateRowData/AttenBrf", "");
				mModelSummary.setProperty("/updateRowData/AttenBrfEmail", "");
			}

			// if(sId === "AttentionToPersoninBRFId"){
			// 		mModelSummary.setProperty("/updateRowData/AttenBrf", "");
			// 	   mModelSummary.setProperty("/updateRowData/AttenBrfEmail", "");
			// }
			/*End defect 63445*/
			var fragmentId = this.getView().createId("contrlName");

			if (!this.oContrlName) {
				this.oContrlName = sap.ui.xmlfragment(fragmentId, "kgo.ARRecharge.view.contrlName", this);
				this.getView().addDependent(this.oContrlName);

			}
			sap.ui.core.BusyIndicator.hide(0);
			this.oContrlName.open();
		},
		onPressSearch: function (oEvent) {
			sap.ui.core.BusyIndicator.show(0);
			var fName = this.getView().getModel("mModelSummary").getProperty("/ContrlerEmailSet").firstName;
			var lastName = this.getView().getModel("mModelSummary").getProperty("/ContrlerEmailSet").lastName;
			var Memberfirm = this.getView().getModel("mModelSummary").getProperty("/ContrlerEmailSet").Memberfirm;
			var City = this.getView().getModel("mModelSummary").getProperty("/ContrlerEmailSet").City;
			var Department = this.getView().getModel("mModelSummary").getProperty("/ContrlerEmailSet").Department;
			var Businesstitle = this.getView().getModel("mModelSummary").getProperty("/ContrlerEmailSet").Businesstitle;

			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide();
				if (d.results.length === 0) {
					var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
					MessageBox.alert(
						"No results found.", {
							styleClass: bCompact ? "sapUiSizeCompact" : ""
						}
					);
				} else {
					var mModelSummary = this.getModel("mModelSummary");
					mModelSummary.setProperty("/oEditable/visibleForcntrlEmail", true);
					mModelSummary.setProperty("/ContrlNameSet", d.results);
				}

				// mModelSummary.refresh(true);

			}, this);

			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();

				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"

				});
			}, this);

			var sPath = "/RRF_CONAMESet?$top=0&$skip=50";
			var aFilter = [];
			var aFilterStr = [];
			var oFilterSerach;
			if (fName || lastName || Memberfirm || City || Department || Businesstitle) {
				if (fName) {
					fName = formatter.formatValueToString(fName); /*Change added by developer Satabdi Das on 25-May-2021 for HTTP Error*/
					oFilterSerach = new sap.ui.model.Filter("Firstname", sap.ui.model.FilterOperator.EQ, fName);
					aFilterStr.push(oFilterSerach);

				}
				if (lastName) {
					lastName = formatter.formatValueToString(lastName); /*Change added by developer Satabdi Das on 25-May-2021 for HTTP Error*/
					oFilterSerach = new sap.ui.model.Filter("Lastname", sap.ui.model.FilterOperator.EQ, lastName);
					aFilterStr.push(oFilterSerach);
				}
				if (Memberfirm) {
					Memberfirm = formatter.formatValueToString(Memberfirm); /*Change added by developer Satabdi Das on 25-May-2021 for HTTP Error*/
					oFilterSerach = new sap.ui.model.Filter("Memberfirm", sap.ui.model.FilterOperator.EQ, Memberfirm);
					aFilterStr.push(oFilterSerach);
				}
				if (City) {
					City = formatter.formatValueToString(City); /*Change added by developer Satabdi Das on 25-May-2021 for HTTP Error*/
					oFilterSerach = new sap.ui.model.Filter("City", sap.ui.model.FilterOperator.EQ, City);
					aFilterStr.push(oFilterSerach);
				}
				if (Department) {
					Department = formatter.formatValueToString(Department); /*Change added by developer Satabdi Das on 25-May-2021 for HTTP Error*/
					oFilterSerach = new sap.ui.model.Filter("Department", sap.ui.model.FilterOperator.EQ, Department);
					aFilterStr.push(oFilterSerach);
				}
				if (Businesstitle) {
					Businesstitle = formatter.formatValueToString(Businesstitle); /*Change added by developer Satabdi Das on 25-May-2021 for HTTP Error*/
					oFilterSerach = new sap.ui.model.Filter("Businesstitle", sap.ui.model.FilterOperator.EQ, Businesstitle);
					aFilterStr.push(oFilterSerach);
				}
				var oFilterStr = new sap.ui.model.Filter({
					filters: aFilterStr,
					and: true
				});
				aFilter.push(oFilterStr);

			}

			var sParams = [];
			sParams.push("$skip=0");
			sParams.push("$top=50");

			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
				json: true
			});
			oModel1.read("/RRF_CONAMESet?$top=0&$skip=50", {
				filters: aFilter,
				success: fnSuccess,
				error: fnError
			});

			// var oObject = {};
			// oObject.Filter = aFilter;
			// oObject.Params = sParams;
			// oObject.successCallback = fnSuccess;
			// oObject.errorCallback = fnError;
			// oObject.sPath = sPath;
			// DataManagerARrecharge.getContrlEmailValue(oObject);

		},

		onTransferOwnerbtnPress: function (oEvent) {
			var mModelSummary = this.getView().getModel("mModelSummary");
			mModelSummary.setProperty("/TRFOwnerFlag", true);
			mModelSummary.setProperty("/oEditable/visibleForcntrlEmail", false);
			mModelSummary.setProperty("/ContrlNameSet", []);
			mModelSummary.setProperty("/ContrlerEmailSet", []);
			var fragmentId = this.getView().createId("contrlName");
			if (!this.oContrlName) {
				this.oContrlName = sap.ui.xmlfragment(fragmentId, "kgo.ARRecharge.view.contrlName", this);
				this.getView().addDependent(this.oContrlName);

			}
			this.oContrlName.open();
		},
		onPressTransferownerNP: function () {
			var mModelSummary = this.getView().getModel("mModelSummary");
			mModelSummary.setProperty("/TRFOwnerFlagNP", true);
			mModelSummary.setProperty("/oEditableNC/visibleForcntrlEmail", false);
			mModelSummary.setProperty("/ContrlNameSet", []);
			mModelSummary.setProperty("/ContrlerEmailSet", []);
			var fragmentId = this.getView().createId("contrlNameNC");
			if (!this.oContrlNameNC) {
				this.oContrlNameNC = sap.ui.xmlfragment(fragmentId, "kgo.ARRecharge.view.contrlNameNC", this);
				this.getView().addDependent(this.oContrlNameNC);

			}
			sap.ui.core.BusyIndicator.hide(0);
			this.oContrlNameNC.open();
		},

		onContrlCoCancel: function () {
			this.getView().getModel("mModelSummary").setProperty("/ContrlerEmailSet", []);

			if (this.oContrlName.isOpen()) {
				this.oContrlName.close();
			}
		},
		onSelectContrlNameSelct: function (oEvent) {
			var mModelSummary = this.getView().getModel("mModelSummary");
			var checkLineItemText = mModelSummary.getProperty("/TextForLineItemEmailSrch");
			mModelSummary.setProperty("/ContrlerEmailSet", []);
			var contrlName = oEvent.getSource().getBindingContext("mModelSummary").getObject();
			var valueField = mModelSummary.getProperty("/EmailFieldLnItem");
			var that = this;
			var ControllerName = contrlName.Firstname + " " + contrlName.Lastname;

			if (contrlName.Employeestatuscode == 1) {
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				MessageBox.information(
					"Employee status not currently assigned. Please select active employee", {
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					}
				);
				return;
			} else if (contrlName.Employeestatuscode == 3) {
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				MessageBox.information(
					"The individual is on leave", {
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					}
				);
				return;
			} else if (contrlName.Employeestatuscode == 4) {
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				MessageBox.information(
					"The individual is separated from the legal entity.", {
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					}
				);
				return;
			} else if (contrlName.Employeestatuscode == 5) {
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				MessageBox.information(
					"The individual will join the legal entity at a future date.", {
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					}
				);
				return;
			}

			if (mModelSummary.getProperty("/TRFOwnerFlag") === true && contrlName.Employeestatuscode == 2) {
				MessageBox.warning("RRF created by will be changed to  : " + ControllerName + " . Do you want to Proceed ?", {
					actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
					emphasizedAction: MessageBox.Action.OK,
					onClose: function (sAction) {
						if (sAction === "OK") {
							that.oContrlName.close();
							// mModelSummary.setProperty("/HeaderData/ContrlName", ControllerName);
							// mModelSummary.setProperty("/HeaderData/ContrlEmail", contrlName.Emailid);
							mModelSummary.setProperty("/HeaderData/RrfCreator", contrlName.Sapid);
							that.onOKPressOfTransferOwner();
							mModelSummary.setProperty("/TRFOwnerFlag", false);
							mModelSummary.setProperty("/ContrlNameSet", []);
							mModelSummary.setProperty("/ContrlerEmailSet", []);

						}
					}

				});
				return true;
			}

			if (!checkLineItemText && (contrlName.Employeestatuscode == 2)) {
				var ContrlName = contrlName.Firstname + " " + contrlName.Lastname;
				this.getView().getModel("mModelSummary").setProperty("/HeaderData/ContrlName", ContrlName);
				this.getView().getModel("mModelSummary").setProperty("/HeaderData/ContrlEmail", contrlName.Emailid);
				if (this.oContrlName.isOpen()) {
					this.oContrlName.close();
				}

			}
			if ((valueField === "AddlContactPerson") && (contrlName.Employeestatuscode == 2)) {
				var ContrlName1 = contrlName.Firstname + " " + contrlName.Lastname;
				this.getView().getModel("mModelSummary").setProperty("/updateRowData/AddlContactPerson", ContrlName1);
				this.getView().getModel("mModelSummary").setProperty("/updateRowData/AddlContactEmail", contrlName.Emailid);
				if (this.oContrlName.isOpen()) {
					this.oContrlName.close();
				}

			}
			if ((valueField === "ContactPCop") && (contrlName.Employeestatuscode == 2)) {
				var ContrlName1 = contrlName.Firstname + " " + contrlName.Lastname;
				this.getView().getModel("mModelSummary").setProperty("/updateRowData/ContactPCop", ContrlName1);
				this.getView().getModel("mModelSummary").setProperty("/updateRowData/CopEmailId", contrlName.Emailid);
				if (this.oContrlName.isOpen()) {
					this.oContrlName.close();
				}

			}
			if ((valueField === "LoaContact") && (contrlName.Employeestatuscode == 2)) {
				var ContrlName2 = contrlName.Firstname + " " + contrlName.Lastname;
				this.getView().getModel("mModelSummary").setProperty("/updateRowData/LoaContact", ContrlName2);
				this.getView().getModel("mModelSummary").setProperty("/updateRowData/LoaEmail", contrlName.Emailid);
				if (this.oContrlName.isOpen()) {
					this.oContrlName.close();
				}

			}
			if ((valueField === "AdlLoaContact") && (contrlName.Employeestatuscode == 2)) {
				var ContrlName3 = contrlName.Firstname + " " + contrlName.Lastname;
				this.getView().getModel("mModelSummary").setProperty("/updateRowData/AdlLoaContact", ContrlName3);
				this.getView().getModel("mModelSummary").setProperty("/updateRowData/AdlLoaEmail", contrlName.Emailid);
				if (this.oContrlName.isOpen()) {
					this.oContrlName.close();
				}

			}
			if ((valueField === "MfApEmail") && (contrlName.Employeestatuscode == 2)) {
				this.getView().getModel("mModelSummary").setProperty("/updateRowData/MfApEmail", contrlName.Emailid);
				if (this.oContrlName.isOpen()) {
					this.oContrlName.close();
				}

			}
			if ((valueField === "AttenBrf") && (contrlName.Employeestatuscode == 2)) {
				var ContrlName4 = contrlName.Firstname + " " + contrlName.Lastname;
				this.getView().getModel("mModelSummary").setProperty("/updateRowData/AttenBrf", ContrlName4);
				this.getView().getModel("mModelSummary").setProperty("/updateRowData/AttenBrfEmail", contrlName.Emailid);
				if (this.oContrlName.isOpen()) {
					this.oContrlName.close();
				}

			}
			if (!checkLineItemText && (contrlName.Employeestatuscode == 2)) {
				var ContrlName = contrlName.Firstname + " " + contrlName.Lastname;
				this.getView().getModel("mModelSummary").setProperty("/HeaderData/ContrlName", ContrlName);
				this.getView().getModel("mModelSummary").setProperty("/HeaderData/ContrlEmail", contrlName.Emailid);
				if (this.oContrlName.isOpen()) {
					this.oContrlName.close();
				}

			} else if (contrlName.Employeestatuscode == 1) {
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				MessageBox.information(
					"Employee status not currently assigned. Please select active employee", {
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					}
				);
			} else if (contrlName.Employeestatuscode == 3) {
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				MessageBox.information(
					"The individual is on leave", {
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					}
				);
			} else if (contrlName.Employeestatuscode == 4) {
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				MessageBox.information(
					"The individual is separated from the legal entity.", {
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					}
				);
			} else if (contrlName.Employeestatuscode == 5) {
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				MessageBox.information(
					"The individual will join the legal entity at a future date.", {
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					}
				);
			}

		},
		onOKPressOfTransferOwner: function (oEvent) {
			var mModelSummary = this.getView().getModel("mModelSummary");
			var hederData = mModelSummary.getProperty("/HeaderData");
			hederData.Currency = mModelSummary.getProperty("/CurrKeySet");
			sap.ui.core.BusyIndicator.show(0);
			var TableData = [];
			var PoHeaderData = [];
			var PoLineItemData = [];
			var oPayLoad = {
				CompanyCode: hederData.CompanyCode,
				ContractTerm: hederData.ContractTerm,
				ContarctStartDate: hederData.ContarctStartDate,
				ContarctEndDate: hederData.ContarctEndDate,
				SupplierAgreementDate: hederData.SupplierAgreementDate,
				AddlInfo: hederData.AddlInfo,
				CoupaRequisitionNumber: hederData.CoupaRequisitionNumber,
				CoupaRequisitionDate: hederData.CoupaRequisitionDate,
				CoupaReqCreatedBy: hederData.CoupaReqCreatedBy,
				TotalPoAmount: hederData.TotalPoAmount,
				Currency: hederData.Currency,
				VendorName: hederData.VendorName,
				Vendor: hederData.Vendor,
				RrfNo: hederData.RrfNo,
				RrfDesc: hederData.RrfDesc,
				ContrlName: hederData.ContrlName,
				ContrlEmail: hederData.ContrlEmail,
				PoNumber: hederData.PoNumber,
				PoDescription: hederData.PoDescription,
				GlobalCostCentre: hederData.GlobalCostCentre,
				Kostl: hederData.Kostl,
				Ltext: hederData.Ltext,
				RrfType: hederData.RrfType,
				/*Added by Satabdi Das on 26-Nov-2020*/
				PoDashboard: hederData.PoDashboard,
				ToDisplay: hederData.ToDisplay,
				RrfStatus: hederData.RrfStatus,
				GlobalCc: hederData.GlobalCc,
				RrfCreator: hederData.RrfCreator,
				GlAccount: hederData.GlAccount,
				RRF_Line_itemSet: [],
				RRF_HEADERPOSet: [],
				RRF_LINEPOSet: []

			};
			var that = this;
			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				MessageBox.show(
					d.Message, {
						icon: MessageBox.Icon.SUCCESS,
						title: "Success",
						actions: [MessageBox.Action.OK],
						onClose: function (oAction) {
							if (oAction === "OK") {
								sap.ui.core.BusyIndicator.show(0);
								var oRouter = UIComponent.getRouterFor(that);
								oRouter.navTo("TargetSelectionView");
								sap.ui.core.BusyIndicator.hide(0);
							}

						}
					}
				);
			}, this);
			var fnError = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();
				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"

				});
			}, this);
			var arr = [];
			var arrPoHeader = [];
			var arrPoLineItem = [];
			arr = this.getView().getModel("mModelSummary").getProperty("/TableItemSet");
			arrPoHeader = this.getView().getModel("mModelSummary").getProperty("/PoTableSet");
			arrPoLineItem = this.getModel("mModelSummary").getProperty("/oLinePoTableSet");
			if (arrPoHeader.length > 0) {
				for (var i in arrPoHeader) {
					var fields = Object.keys(arrPoHeader[i]);
					var obj = {};
					for (var j = 0; j < fields.length; j++) {
						if (fields[j] !== "__metadata") {
							obj[fields[j]] = arrPoHeader[i][fields[j]];
						}
					}
					PoHeaderData.push(obj);
				}
				oPayLoad.RRF_HEADERPOSet = PoHeaderData;
			}
			if (arrPoLineItem.length > 0) {
				for (var i in arrPoLineItem) {
					fields = Object.keys(arrPoLineItem[i]);
					obj = {};
					for (var j = 0; j < fields.length; j++) {
						if (fields[j] !== "__metadata") {
							obj[fields[j]] = arrPoLineItem[i][fields[j]];
						}
					}
					PoLineItemData.push(obj);
				}
				oPayLoad.RRF_LINEPOSet = PoLineItemData;
			}

			for (var i in arr.results) {
				fields = Object.keys(arr.results[i]);
				obj = {};
				for (var j = 0; j < fields.length; j++) {
					if (fields[j] !== "__metadata") {
						obj[fields[j]] = arr.results[i][fields[j]];
					}
				}
				TableData.push(obj);
			}
			oPayLoad.RRF_Line_itemSet = TableData;
			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
				json: true
			});
			oModel1.create("/RRF_HeaderSet", oPayLoad, {
				success: fnSuccess,
				error: fnError
			});

		},
		onContrlerNameSearch: function (oEvent) {
			var aFilter = [];
			var sQuery = oEvent.getSource().getValue();
			sQuery = sQuery.trim();
			if (sQuery && sQuery.length > 0) {
				aFilter.push(new Filter("Firstname", FilterOperator.Contains, sQuery));
			}
			var fragmentId = this.getView().createId("contrlName");
			var table = sap.ui.core.Fragment.byId(fragmentId, "controllerNameId");
			var oBinding = table.getBinding("items");
			oBinding.filter(aFilter, "Application");

		},
		onSelectCompanyCode: function (oEvent) {
			var cocode = oEvent.getSource().getBindingContext("mModelSummary").getObject();
			this.getView().getModel("mModelSummary").setProperty("/HeaderData/CompanyCode", cocode.Bukrs);

			if (this._oSearchCoordinator.isOpen()) {
				this._oSearchCoordinator.close();
			}
		},
		onSelectRRFValue: function (oEvent) {

			this.getView().getModel("mModelSummary").setProperty("/filterSearch", "");
			var fragmentId = this.getView().createId("fragmentId");

			var sRRFNumber = sap.ui.core.Fragment.byId(fragmentId, "RB-1");
			var sCoupaRequistionNumber = sap.ui.core.Fragment.byId(fragmentId, "RB-3");
			var oCoupaPoSelect = sap.ui.core.Fragment.byId(fragmentId, "RB-4");
			if (sRRFNumber.getSelected() === true) {
				var coupaRRFNumber = oEvent.getSource().getBindingContext("mModelSummary").getObject();
				this.getView().getModel("mModelSummary").setProperty("/HeaderData", coupaRRFNumber);
				if (this.coupaFrgOne.isOpen()) {

					this.coupaFrgOne.close();

				}
			}
			if (sCoupaRequistionNumber.getSelected() === true) {
				var coupaRequNumber = oEvent.getSource().getBindingContext("mModelSummary").getObject();
				this.getView().getModel("mModelSummary").setProperty("/HeaderData", coupaRequNumber);
				if (this.oCoupaReqNumberfrg.isOpen()) {

					this.oCoupaReqNumberfrg.close();
				}
			}

		},
		onSelectValue: function (oEvent) {
			var mModelSummary = this.getModel("mModelSummary");
			var sButtonIndex = this.copaSelectIndexLast;
			if (sButtonIndex === 3) {
				var RrfCreator = oEvent.getSource().getBindingContext("mModelSummary").getObject().RrfCreator;
				if (RrfCreator === "") {
					var msg1 = "Please select RRF creator name";
					MessageToast.show(msg1);
				} else {
					this.getView().getModel("mModelSummary").setProperty("/RRF_SH/RrfCreator", RrfCreator);
					if (this.oSearchHelpRRFFive.isOpen()) {
						this.oSearchHelpRRFFive.close();
					}
				}
			}
			if (sButtonIndex === 4) {
				var RrfCreationDate = oEvent.getSource().getBindingContext("mModelSummary").getObject().RrfCreationDate;
				if (RrfCreationDate === "") {
					var msg2 = "Please select RRF creation date";
					MessageToast.show(msg2);
				} else {
					this.getView().getModel("mModelSummary").setProperty("/RRF_SH/RrfCreationDate", RrfCreationDate);
					if (this.oSearchHelpRRFSix.isOpen()) {
						this.oSearchHelpRRFSix.close();
					}
				}
			}
			if (sButtonIndex === 5) {
				var VendorName = oEvent.getSource().getBindingContext("mModelSummary").getObject().VendorName;
				if (VendorName === "") {
					var msg3 = "Please select vendor name";
					MessageToast.show(msg3);
				} else {
					this.getView().getModel("mModelSummary").setProperty("/RRF_SH/VendorName", VendorName);
					if (this.oSearchHelpRRFEight.isOpen()) {
						this.oSearchHelpRRFEight.close();
					}
				}
			}
		},
		onSearch: function (oEvent) {

			var aFilter = [];
			var sQuery = oEvent.getSource().getValue();
			sQuery = sQuery.trim();
			if (sQuery && sQuery.length > 0) {
				aFilter.push(new Filter("Bukrs", FilterOperator.Contains, sQuery));
			}
			var fragmentId = this.getView().createId("searchCompanyCode");
			var table = sap.ui.core.Fragment.byId(fragmentId, "listCoordinator");
			var oBinding = table.getBinding("items");
			oBinding.filter(aFilter, "Application");

		},
		onSearchRRFNumber: function (oEvent) {
			var aFilter = [];
			var sQuery = this.getView().getModel("mModelSummary").getProperty("/filterSearch");
			if (sQuery) {
				sQuery = sQuery.trim();
			}

			if (sQuery && sQuery.length > 0) {
				aFilter.push(new Filter("RrfNo", FilterOperator.Contains, sQuery));
			}

			var searchHelpRRFNoOne = this.getView().createId("rrfCoupaReqNofrg");
			//var table=this.getView().getModel("mModelSummary").getProperty("/RRF_NOSet");
			var table = sap.ui.core.Fragment.byId(searchHelpRRFNoOne, "tableIdForRrfSearch");
			var oBinding = table.getBinding("items");
			oBinding.filter(aFilter, "Application");

		},
		onSearchCoupaRequisitionNbr: function (oEvent) {
			var aFilter = [];
			var sQuery = this.getView().getModel("mModelSummary").getProperty("/filterSearch");
			if (sQuery) {
				sQuery = sQuery.trim();
			}

			if (sQuery && sQuery.length > 0) {
				aFilter.push(new Filter("CoupaRequisitionNumber", FilterOperator.Contains, sQuery));
			}

			var coupaRequisitionNumber = this.getView().createId("searchHelpCoupaReqNo");
			var table = sap.ui.core.Fragment.byId(coupaRequisitionNumber, "CoupaRequisitionId");
			var oBinding = table.getBinding("items");
			oBinding.filter(aFilter, "Application");
		},
		onSearchCoupaPoNumber: function (oEvent) {
			var aFilter = [];
			var sQuery = oEvent.getSource().getValue();
			sQuery = sQuery.trim();
			if (sQuery && sQuery.length > 0) {
				aFilter.push(new Filter("PoNumber", FilterOperator.Contains, sQuery));
			}

			var coupaRequisitionNumber = this.getView().createId("searchCoupaPoCode");
			var table = sap.ui.core.Fragment.byId(coupaRequisitionNumber, "CopaPoId");
			var oBinding = table.getBinding("items");
			oBinding.filter(aFilter, "Application");
		},
		onLiveSearch: function (oEvent) {
			var aLiveTextValue = this.getView().getModel("mModelSummary").getProperty("/setLiveSearchText");

			var sButtonIndex = this.copaSelectIndexLast;
			var aFilter = [];
			var sQuery = this.getView().getModel("mModelSummary").getProperty("/filterSearch");
			if (sQuery) {
				sQuery = sQuery.trim();
			}
			if (sQuery && sQuery.length > 0) {
				if (aLiveTextValue === "RRF Number") {
					aFilter.push(new Filter("RrfNo", FilterOperator.Contains, sQuery));

				} else {
					if (sButtonIndex === 2) {

						aFilter.push(new Filter("RrfCreator", FilterOperator.Contains, sQuery));

					} else if (sButtonIndex === 3) {

						aFilter.push(new Filter("VendorName", FilterOperator.Contains, sQuery));

					} else if (sButtonIndex === 4) {
						aFilter.push(new Filter("Kostl", FilterOperator.Contains, sQuery));
					}

				}
			}
			var frag = this.getView().createId("rrfDetail");
			var table = sap.ui.core.Fragment.byId(frag, "rrfDetailTable");
			var oBinding = table.getBinding("items");
			oBinding.filter(aFilter, "Application");
		},
		onEngMngrCoCancel: function (oEvent) {
			if (this._oSearchCoordinator.isOpen()) {
				this._oSearchCoordinator.close();
			}
		},
		handlePreBtnEdit: function (oEvent) {
			var oChackAutho = this.getModel("mModelSummary").getProperty("/authoSet");
			if (oChackAutho.GpEditDisplay) {
				var mModelSummary = this.getView().getModel("mModelSummary");
				var that = this;
				this.getCurrencySet();
				mModelSummary.setProperty("/displayMode", false); /*Added by Saptarshi on 22-Nov-2019*/
				sap.ui.core.BusyIndicator.show(0);
				var avlue = this.getModel("i18n").getProperty("editrrf");
				mModelSummary.setProperty("/oEditable/contractNbr", false);
				mModelSummary.setProperty("/oEditable/attachVisible", true);
				mModelSummary.setProperty("/oEditable/entityName", false);
				mModelSummary.setProperty("/setDashBoardText", avlue);
				mModelSummary.setProperty("/oCopLoaSucesFlag", false);

				var arr = [];
				var arrHeaderPo = [];
				var arrPoLineItem = [];
				var AR_ATTSet = [];
				var oHeaderAttachmentList = [];
				var arrAnswer = [];
				var RRfHeaderset = {};
				this.onMfSearchHelpValue();
				this.onMfLocValue(); /*Added by Satabdi Das on 17-Feb-2021 for SCTASK1919812*/
				if (oEvent && oChackAutho.GpEditDisplay === "E") {

					RRfHeaderset.rrfNumber = this.getOwnerComponent().getModel("mModelSummary").getProperty("/HeaderData").RrfNo;
					//	RRfHeaderset.CoupaRequisitionNumber = this.getOwnerComponent().getModel("mModelSummary").getProperty("/HeaderData").CoupaRequisitionNumber;

				} else {
					if (!oEvent && ((oChackAutho.GpEditDisplay === "D") || (oChackAutho.GpEditDisplay === "E"))) {
						RRfHeaderset.rrfNumber = this.getOwnerComponent().getModel("mModelSummary").getProperty("/HeaderData").RrfNo;
						//	RRfHeaderset.CoupaRequisitionNumber = this.getOwnerComponent().getModel("mModelSummary").getProperty("/HeaderData").CoupaRequisitionNumber;
					} else {
						var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
						MessageBox.error(
							"You are not authorized to edit/view this RRF.", {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}
						);
						return true;
					}
				}
				if (RRfHeaderset.rrfNumber) {
					var fnSuccess = jQuery.proxy(function (d) {
						sap.ui.core.BusyIndicator.hide(0);
						mModelSummary = this.getModel("mModelSummary");
						if (!d.results.length) {
							// MessageBox.error(
							// 	"Please enter correct details", {
							// 		styleClass: bCompact ? "sapUiSizeCompact" : ""
							// 	});
							MessageBox.error("This RRF does not exist in the system.");
							return;

							// else if (oChackAutho.GpEditDisplay !== "E" || oChackAutho.GpEditDisplay !== "D") {
							// 	var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
							// 	MessageBox.error(
							// 		"Please enter correct details.", {
							// 			styleClass: bCompact ? "sapUiSizeCompact" : ""
							// 		}
							// 	);
							// 	return;
							// } else {
							// 	var msg2 = "Please enter correct details";
							// 	MessageToast.show(msg2);
							// }
						}
						var sObj = {};
						for (var i = 0; i < d.results.length; i++) {
							sObj.GpEditDisplay = d.results[i].GpEditDisplay;
							sObj.CompanyCode = d.results[i].CompanyCode;
							sObj.CoupaRequisitionNumber = d.results[i].CoupaRequisitionNumber;
							sObj.CopInitiate = d.results[i].CopInitiate;
							sObj.LoaInitiate = d.results[i].LoaInitiate;
							sObj.ContrlName = d.results[i].ContrlName;
							sObj.ContrlEmail = d.results[i].ContrlEmail;
							sObj.ContarctStartDate = d.results[i].ContarctStartDate;
							sObj.ContarctEndDate = d.results[i].ContarctEndDate;
							sObj.RrfCreationDate = d.results[i].RrfCreationDate;
							sObj.SupplierAgreementDate = d.results[i].SupplierAgreementDate;
							sObj.RrfCreator = d.results[i].RrfCreator;
							sObj.RrfCreatorName = d.results[i].RrfCreatorName;
							sObj.ContractTerm = d.results[i].ContractTerm;
							sObj.AddlInfo = d.results[i].AddlInfo;
							sObj.GlAccount = d.results[i].GlAccount;
							sObj.RrfNo = d.results[i].RrfNo;
							sObj.Vendor = d.results[i].Vendor;
							sObj.VendorName = d.results[i].VendorName;
							sObj.RrfNo = d.results[i].RrfNo;
							sObj.RrfDesc = d.results[i].RrfDesc;
							sObj.CoupaRequisitionDate = d.results[i].CoupaRequisitionDate;
							sObj.TotalPoAmount = d.results[i].TotalPoAmount;
							sObj.CoupaReqCreatedBy = d.results[i].CoupaReqCreatedBy;
							sObj.Currency = d.results[i].Currency;
							sObj.SupplierVendorName = d.results[i].SupplierVendorName;
							sObj.PoNumber = d.results[i].PoNumber;
							sObj.PoDashboard = d.results[i].PoDashboard;
							sObj.PoDescription = d.results[i].PoDescription;
							sObj.EngManagerPartnerName = d.results[i].EngManagerPartnerName;
							sObj.GlobalCostCentre = d.results[i].GlobalCostCentre;
							sObj.ToDisplay = d.results[i].ToDisplay;
							sObj.Kostl = d.results[i].Kostl;
							sObj.Ltext = d.results[i].Ltext;
							sObj.RrfType = d.results[i].RrfType; /*Added by developer Satabdi Das on 26-Nov-2020*/
							sObj.Flag = d.results[i].Flag;
							sObj.Message = d.results[i].Message;
							sObj.RrfStatus = d.results[i].RrfStatus;
							arr = d.results[i].RRF_Line_itemSet;
							arrAnswer = d.results[i].RRF_AnswerSet;
							arrHeaderPo = d.results[i].RRF_HEADERPOSet;
							arrPoLineItem = d.results[i].RRF_LINEPOSet;
							AR_ATTSet = d.results[i].AR_ATTSet;
							arr = formatter.formatFromUTCforCoupaDate(arr);
							mModelSummary.setProperty("/CurrKeySet", sObj.Currency);
							mModelSummary.setProperty("/PoTableSet", arrHeaderPo.results);
							mModelSummary.setProperty("/copPoTableSet", arrPoLineItem.results);
							mModelSummary.setProperty("/oLinePoTableSet", arrPoLineItem.results);
							mModelSummary.setProperty("/TableItemSet", arr);
							mModelSummary.setProperty("/HeaderData", sObj);
							mModelSummary.setProperty("/FileHeaderSet", AR_ATTSet);
							mModelSummary.setProperty("/questionSetSubmit", arrAnswer.results);

							for (var j = 0; j < AR_ATTSet.results.length; j++) {
								if (AR_ATTSet.results[j].CopLoa === "CON") {
									oHeaderAttachmentList.push(AR_ATTSet.results[j]);
								}
							}
							mModelSummary.setProperty("/FileHeaderSet", oHeaderAttachmentList);
							if (this.getView().getModel("mModelSummary").getProperty("/displayMode") === "false") {
								if (mModelSummary.getProperty("/FileHeaderSet").length < 1) {
									mModelSummary.setProperty("/oEditable/contractAttachEnable", false);
								} else {
									mModelSummary.setProperty("/oEditable/contractAttachEnable", true);
								}
							}

							var oRouter = UIComponent.getRouterFor(this);

							if (sObj.LoaInitiate === "X") {
								//Saptarshi on 24.01.2020	// this.getView().getModel("mModelSummary").setProperty("/oEditable/enableCOP", false);
								this.getView().getModel("mModelSummary").setProperty("/oEditable/enableLOA", true);
							} else {
								//Saptarshi on 24.01.2020	// this.getView().getModel("mModelSummary").setProperty("/oEditable/enableCOP", true);
								this.getView().getModel("mModelSummary").setProperty("/oEditable/enableLOA", false);
							}
							//Begin  Saptarshi on 24.01.2020
							if (sObj.CopInitiate === "X") {
								this.getView().getModel("mModelSummary").setProperty("/oEditable/enableCOP", true);
							} else {
								this.getView().getModel("mModelSummary").setProperty("/oEditable/enableCOP", false);
							}
							// End Saptarshi on 24.01.2020
							if ((!sObj.Flag) || (mModelSummary.getProperty("/displayMode") === true)) {
								if (sObj.GpEditDisplay === "E") {
									oRouter.navTo("RouteHomeView", {
										No: sObj.RrfNo

									});
								} else if (sObj.GpEditDisplay === "D") {
									oRouter.navTo("RouteHomeView", {
										No: sObj.RrfNo

									});
								} else {
									if (!sObj.RrfNo) {
										MessageBox.error(
											"This RRF does not exist in the system.", {
												styleClass: bCompact ? "sapUiSizeCompact" : ""
											});
										return;
									} else {
										var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
										MessageBox.error(
											"You are not authorized to edit/view this RRF.", {
												styleClass: bCompact ? "sapUiSizeCompact" : ""
											}
										);
									}
								}

							} else {
								if (!sObj.RrfNo) {
									if (sObj.Message) {
										MessageBox.error(sObj.Message);
										return;
									} else {
										MessageBox.error(
											"This RRF does not exist in the system.", {
												styleClass: bCompact ? "sapUiSizeCompact" : ""
											});
										return;
									}
								} else {
									MessageBox.error("You are not authorized to edit/view this RRF.");
								}

							}

						}
						if (!oEvent) {
							for (var i = 0; i < this.getView().getModel("mModelSummary").getProperty("/TableItemSet/results").length; i++) {
								var tbl = this.getView().byId('tableid');

								var copInitiate = this.getView().getModel("mModelSummary").getProperty("/TableItemSet/results")[i].CopInitiate;

								if (copInitiate === "X") {
									var flagSupplier = true;
									var x = tbl.getAggregation("items")[i];
									x.getMultiSelectControl().setEnabled(false);
								}

							}
						}

						if (flagSupplier === true) {
							this.getModel("mModelSummary").setProperty("/oEditable/suppEdit", false);
						}

					}, this);

					var fnError = jQuery.proxy(function (d) {
							var r = JSON.parse(JSON.stringify(d));
							sap.ui.core.BusyIndicator.hide();
							MessageToast.show(r.message, {
								autoClose: true,
								width: "20rem"

							});

						}, this

					);

					var sPath = "/RRF_HeaderSet";
					var aFilter = [];
					var sFilter;
					var aFilterStr = [];
					var oFilterSerach;
					// if (RRfHeaderset.CoupaRequisitionNumber) {
					// 	oFilterSerach = new sap.ui.model.Filter("CoupaRequisitionNumber", sap.ui.model.FilterOperator.EQ, RRfHeaderset.CoupaRequisitionNumber);
					// 	aFilterStr.push(oFilterSerach);

					// }
					if (RRfHeaderset.rrfNumber) {
						RRfHeaderset.rrfNumber = formatter.formatValueToString(RRfHeaderset.rrfNumber); /*Change added by developer Satabdi Das on 25-May-2021 for HTTP Error*/
						oFilterSerach = new sap.ui.model.Filter("RrfNo", sap.ui.model.FilterOperator.EQ, RRfHeaderset.rrfNumber);
						aFilterStr.push(oFilterSerach);
					}
					if (mModelSummary.getProperty("/checkDisplayPress") === true) {
						oFilterSerach = new sap.ui.model.Filter("CompanyCode", sap.ui.model.FilterOperator.EQ, "D");
						aFilterStr.push(oFilterSerach);
					}

					var oFilterStr = new sap.ui.model.Filter({
						filters: aFilterStr,
						and: true
					});
					aFilter.push(oFilterStr);
					// var sParams = {};
					// var oObject = {};
					// oObject.Filter = aFilter;
					// oObject.Params = sParams;
					// oObject.successCallback = fnSuccess;
					// oObject.errorCallback = fnError;
					// oObject.sPath = sPath;
					// DataManagerARrecharge.getRRFHeaderSetvalue(oObject);
					/*R&D---start*/
					var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
						json: true
					});
					oModel1.read("/RRF_HeaderSet", {
						filters: aFilter,
						urlParameters: {
							"$expand": "RRF_Line_itemSet,RRF_HEADERPOSet,RRF_LINEPOSet,AR_ATTSet,RRF_AnswerSet"
						},
						success: fnSuccess,
						error: fnError
					});
					/*R&D---end*/

				} else {
					sap.ui.core.BusyIndicator.hide(0);
					var msg2;
					if (!oChackAutho.GpEditDisplay) {
						var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
						MessageBox.error(
							"You are not authorized to edit/view this RRF.", {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}
						);
						return true;
					}
					if (!this.copaSelectIndexLast) {
						msg2 = "Please Enter valid RRF number";
						MessageToast.show(msg2);
					}
					if (this.copaSelectIndexLast === 0) {
						msg2 = "Please Enter valid RRF number";
						MessageToast.show(msg2);
					}
					if (this.copaSelectIndexLast === 1) {
						msg2 = "Please Enter Correct Details";
						MessageToast.show(msg2);
					}

					if (this.copaSelectIndexLast === 2) {
						msg2 = "Please Enter Correct Details";
						MessageToast.show(msg2);
					}
					if (this.copaSelectIndexLast === 3) {
						msg2 = "Please Enter Correct Details";
						MessageToast.show(msg2);
					}

				}

			} else {
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				MessageBox.error(
					"You are not authorized to edit/view this RRF.", {
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					}
				);
			}

		},

		handleDisplayBtn: function (oEvent) {
			var oChackAutho = this.getModel("mModelSummary").getProperty("/authoSet");
			var mModelSummary = this.getView().getModel("mModelSummary");
			mModelSummary.setProperty("/checkDisplayPress", true);
			if ((oChackAutho.GpEditDisplay === "D") || (oChackAutho.GpEditDisplay === "E")) {

				var sButtonIndex = this.copaSelectIndexLast;
				if (sButtonIndex === 2 || sButtonIndex === 3 || sButtonIndex === 4) {
					this.onPressEdit();
					this.getModel("mModelSummary").setProperty("/oEditable/visibleForEdit", false);
					this.getModel("mModelSummary").setProperty("/oEditable/visibleForDisply", true);
					this.getView().getModel("mModelSummary").setProperty("/oEditable/editPercy", false);
					this.getView().getModel("mModelSummary").setProperty("/oEditable/attachmentEnable", true);
					this.getView().getModel("mModelSummary").setProperty("/oEditable/attachmentDelete", false);
					this.getModel("mModelSummary").setProperty("/oEditable/lastsrvDate", false);
					this.getModel("mModelSummary").setProperty("/oEditable/contractAttachEnable", true);
					this.getModel("mModelSummary").setProperty("/oEditable/suppEdit", false);

				} else {
					this.handlePreBtnEdit();
					this.getModel("mModelSummary").setProperty("/oEditable", {});
					// this.getView().getModel("mModelSummary").setProperty("/oEditable/entityName", false); 
					this.getModel("mModelSummary").setProperty("/oEditable/contractNbr", false);
					this.getModel("mModelSummary").setProperty("/oEditable/editHeaderItem", false);
					this.getModel("mModelSummary").setProperty("/oEditable/editInformationItem", false);
					this.getModel("mModelSummary").setProperty("/oEditable/editLineItemCop", false);
					this.getModel("mModelSummary").setProperty("/oEditable/editLineItemMF", false);
					this.getModel("mModelSummary").setProperty("/oEditable/editLineItemLOA", false);
					this.getModel("mModelSummary").setProperty("/oEditable/lastsrvDate", false);
					this.getModel("mModelSummary").setProperty("/oEditable/suppEdit", false);
					this.getModel("mModelSummary").setProperty("/oEditable/contractAttachEnable", true);
					var avlue = this.getModel("i18n").getProperty("display");

					this.getView().getModel("mModelSummary").setProperty("/setDashBoardText", avlue);
					this.getView().getModel("mModelSummary").setProperty("/oEditable/checkBox", false); /*Added on 27-Jan-2020*/
					this.getView().getModel("mModelSummary").setProperty("/oEditable/entityName", false);
					this.getView().getModel("mModelSummary").setProperty("/oEditable/editPercy", false);
					this.getView().getModel("mModelSummary").setProperty("/oEditable/attachmentEnable", true);
					this.getView().getModel("mModelSummary").setProperty("/oEditable/attachmentDelete", false);

					this.getModel("mModelSummary").setProperty("/displayMode", true); /*Added by Saptarshi on 22-Nov-2019*/
					this.getView().getModel("mModelSummary").refresh();
				}
			} else {
				MessageBox.error("You are not authorized to edit/view this RRF.");
				return;
			}

		},
		/*Start of change by Saptarshi on 8th-Nov-2019*/
		onPressEdit: function (oEvent) {

			this.getModel("mModelSummary").setProperty("/oEditable/visibleForEdit", true);
			this.getModel("mModelSummary").setProperty("/oEditable/visibleForDisply", false);

			var mModelSummary = this.getModel("mModelSummary");
			mModelSummary.setProperty("/oEditable/checkBox", true); /*Added on 27-Jan-2020*/
			var sButtonIndex = this.copaSelectIndexLast;
			var eObj = {};
			eObj.RrfCreator = this.getModel("mModelSummary").getProperty("/RRF_SH").RrfCreator;

			eObj.VendorName = this.getModel("mModelSummary").getProperty("/RRF_SH").VendorName;
			eObj.Kostl = this.getModel("mModelSummary").getProperty("/RRF_SH").Kostl;

			if (eObj.RrfCreator || eObj.VendorName || eObj.Kostl) {

				sap.ui.core.BusyIndicator.show(0);

				// 	if (eEnterValue) {
				// 	eEnterValue = eEnterValue.replace(/ +/g, "");

				// }

				var fnSuccess = jQuery.proxy(function (d) {
					sap.ui.core.BusyIndicator.hide();
					if (d.results.length === 0) {
						var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
						MessageBox.alert(
							"No results found.", {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}
						);
					} else {

						for (var i = 0; i < d.results.length; i++) {
							d.results[i].RrfCreationDate = formatter.formatRrfCreationDate(d.results[i].RrfCreationDate);
						}
						mModelSummary.setSizeLimit(d.results.length);
						mModelSummary.setProperty("/RRF_SH", d.results);
						mModelSummary.refresh(true);
						var fragmentId = this.getView().createId("rrfDetail");

						if (!this._oRrfDetail) {
							this._oRrfDetail = sap.ui.xmlfragment(fragmentId, "kgo.ARRecharge.view.rrfDetail", this);
							this.getView().addDependent(this._oRrfDetail);
						}
						var aText = this.getModel("i18n").getProperty("RRFNumber");
						this.getView().getModel("mModelSummary").setProperty("/setLiveSearchText", aText);
						this._oRrfDetail.open();

					}

				}, this);
				var fnError = jQuery.proxy(function (d) {
					var r = JSON.parse(JSON.stringify(d));
					sap.ui.core.BusyIndicator.hide();

					MessageToast.show(r.message, {
						autoClose: true,
						width: "20rem"

					});
				}, this);
				//var sPath = "/RRF_SHSet";
				var aFilter = [];

				var oFilterSerach;
				if (sButtonIndex === 2) {

					oFilterSerach = new sap.ui.model.Filter("RrfCreator", sap.ui.model.FilterOperator.EQ, eObj.RrfCreator);
					aFilter.push(oFilterSerach);

				}
				if (sButtonIndex === 3) {
					oFilterSerach = new sap.ui.model.Filter("VendorName", sap.ui.model.FilterOperator.EQ, eObj.VendorName);
					aFilter.push(oFilterSerach);
				}
				if (sButtonIndex === 4) {
					oFilterSerach = new sap.ui.model.Filter("Kostl", sap.ui.model.FilterOperator.EQ, eObj.Kostl);
					aFilter.push(oFilterSerach);
				}

				var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
					json: true
				});
				oModel1.read("/RRF_SHSet", {
					filters: aFilter,
					success: fnSuccess,
					error: fnError
				});
				/*R&D---end*/

				// var sParams = [];

				// var oObject = {};
				// oObject.Filter = aFilter;
				// oObject.Params = sParams;
				// oObject.successCallback = fnSuccess;
				// oObject.errorCallback = fnError;
				// oObject.sPath = sPath;
				// DataManagerARrecharge.getCoupaReqiNumberhelpValus(oObject);

			} else {
				var message = "Please enter correct details. ";
				MessageToast.show(message);
			}

		},
		/*End of change by Saptarshi on 8th-Nov-2019*/
		onPressNav: function (oEvent) {
			var that = this;
			var selectedRadio = this.copaSelectIndexLast;
			this.getCurrencySet();
			this.onMfSearchHelpValue();
			this.onMfLocValue(); /*Added by Satabdi Das on 17-Feb-2021 for SCTASK1919812*/
			var oAutho = this.getModel("mModelSummary").getProperty("/authoSet");
			if ((oAutho.GpEditDisplay)) {
				this.getModel("mModelSummary").setProperty("/oEditable/attachVisible", true);
				this.getModel("mModelSummary").setProperty("/oEditable/contractNbr", false);
				this.getView().getModel("mModelSummary").setProperty("/oEditable/entityName", false);

				this.getView().getModel("mModelSummary").setProperty("/filterSearch", "");
				var avlue = this.getModel("i18n").getProperty("editrrf");
				this.getView().getModel("mModelSummary").setProperty("/setDashBoardText", avlue);

				var arr = [];
				var arrHeaderPo = [];
				var arrPoLineItem = [];
				var AR_ATTSet = [];
				var arrAnswer = [];
				var oHeaderAttachmentList = [];
				var mModelSummary = this.getModel("mModelSummary");
				mModelSummary.setProperty("/displayMode", false); /*Added by Saptarshi on 22-Nov-2019*/

				this.getView().getModel("mModelSummary").setProperty("/oEditable/checkBox", true); /*Added on 27-Jan-2020*/
				var sRrfNo;
				if (oEvent && oAutho.GpEditDisplay === "E") {
					var oObjectData = oEvent.getSource().getBindingContext("mModelSummary").getObject();
					if (selectedRadio !== 4) {
						sRrfNo = oObjectData.RrfNo;
					} else if (selectedRadio === 4) {
						if (oObjectData.Kostl) {
							sRrfNo = oObjectData.RrfNo;
						} else {
							MessageBox.information("Please Select Cost Center .");
							return;

						}
					}

				} else if ((oAutho.GpEditDisplay === "D") || (oAutho.GpEditDisplay === "E")) {
					sRrfNo = this.getModel("mModelSummary").getProperty("/oDislayRRFNo");
				}
				if (sRrfNo != undefined) {
					var fnSuccess = jQuery.proxy(function (d) {
						sap.ui.core.BusyIndicator.hide(0);
						if (!d.results.length) {
							var msg2 = "Please enter correct details";
							MessageToast.show(msg2);
						}
						var sObj = {};
						for (var i = 0; i < d.results.length; i++) {
							sObj.CompanyCode = d.results[i].CompanyCode;
							sObj.CoupaRequisitionNumber = d.results[i].CoupaRequisitionNumber;
							sObj.CopInitiate = d.results[i].CopInitiate;
							sObj.LoaInitiate = d.results[i].LoaInitiate;
							sObj.ContrlName = d.results[i].ContrlName;
							sObj.ContrlEmail = d.results[i].ContrlEmail;
							sObj.ContarctStartDate = d.results[i].ContarctStartDate;
							sObj.ContarctEndDate = d.results[i].ContarctEndDate;
							sObj.SupplierAgreementDate = d.results[i].SupplierAgreementDate;
							sObj.RrfCreationDate = d.results[i].RrfCreationDate;
							sObj.RrfCreator = d.results[i].RrfCreator;
							sObj.RrfCreatorName = d.results[i].RrfCreatorName;
							sObj.ContractTerm = d.results[i].ContractTerm;
							sObj.AddlInfo = d.results[i].AddlInfo;
							sObj.GlAccount = d.results[i].GlAccount;
							sObj.RrfNo = d.results[i].RrfNo;
							sObj.Vendor = d.results[i].Vendor;
							sObj.VendorName = d.results[i].VendorName;
							sObj.RrfNo = d.results[i].RrfNo;
							sObj.RrfDesc = d.results[i].RrfDesc;
							sObj.CoupaRequisitionDate = d.results[i].CoupaRequisitionDate;
							sObj.TotalPoAmount = d.results[i].TotalPoAmount;
							sObj.CoupaReqCreatedBy = d.results[i].CoupaReqCreatedBy;
							sObj.Currency = d.results[i].Currency;
							sObj.SupplierVendorName = d.results[i].SupplierVendorName;
							sObj.PoNumber = d.results[i].PoNumber;
							sObj.PoDashboard = d.results[i].PoDashboard;
							sObj.PoDescription = d.results[i].PoDescription;
							sObj.EngManagerPartnerName = d.results[i].EngManagerPartnerName;
							sObj.GlobalCostCentre = d.results[i].GlobalCostCentre;
							sObj.Kostl = d.results[i].Kostl;
							sObj.Ltext = d.results[i].Ltext;
							sObj.ToDisplay = d.results[i].ToDisplay;
							sObj.RrfStatus = d.results[i].RrfStatus;
							sObj.GpEditDisplay = d.results[i].GpEditDisplay;
							sObj.RrfType = d.results[i].RrfType; /*Added by developer Satabdi Das on 26-Nov-2020*/
							sObj.Flag = d.results[i].Flag;
							sObj.Message = d.results[i].Message;
							arr = d.results[i].RRF_Line_itemSet;
							arrAnswer = d.results[i].RRF_AnswerSet;
							arrHeaderPo = d.results[i].RRF_HEADERPOSet;
							arrPoLineItem = d.results[i].RRF_LINEPOSet;
							AR_ATTSet = d.results[i].AR_ATTSet;
							arr = formatter.formatFromUTCforCoupaDate(arr);
							mModelSummary.setProperty("/CurrKeySet", sObj.Currency);
							mModelSummary.setProperty("/questionSetSubmit", arrAnswer.results);
							mModelSummary.setProperty("/PoTableSet", arrHeaderPo.results);
							mModelSummary.setProperty("/copPoTableSet", arrPoLineItem.results);
							mModelSummary.setProperty("/oLinePoTableSet", arrPoLineItem.results);
							mModelSummary.setProperty("/TableItemSet", arr);
							mModelSummary.setProperty("/HeaderData", sObj);

							for (var j = 0; j < AR_ATTSet.results.length; j++) {
								if (AR_ATTSet.results[j].CopLoa === "CON") {
									oHeaderAttachmentList.push(AR_ATTSet.results[j]);
								}
							}

							mModelSummary.setProperty("/FileHeaderSet", oHeaderAttachmentList);

							if (this.getView().getModel("mModelSummary").getProperty("/displayMode") === "false") {
								if (mModelSummary.getProperty("/FileHeaderSet").length < 1) {
									mModelSummary.setProperty("/oEditable/contractAttachEnable", false);
								} else {
									mModelSummary.setProperty("/oEditable/contractAttachEnable", true);
								}
							}
							/*End of change by Saptarshi on 13-Nov-2019*/

							var oRouter = UIComponent.getRouterFor(this);
							/*Start of change by Satabdi Das on 26-Dec-2019*/

							if (sObj.LoaInitiate === "X") {
								//Saptarshi on 24.01.2020	// this.getView().getModel("mModelSummary").setProperty("/oEditable/enableCOP", false);
								this.getView().getModel("mModelSummary").setProperty("/oEditable/enableLOA", true);
							} else {
								//Saptarshi on 24.01.2020  // this.getView().getModel("mModelSummary").setProperty("/oEditable/enableCOP", true);
								this.getView().getModel("mModelSummary").setProperty("/oEditable/enableLOA", false);
							}

							//Begin  Saptarshi on 24.01.2020
							if (sObj.CopInitiate === "X") {
								this.getView().getModel("mModelSummary").setProperty("/oEditable/enableCOP", true);
							} else {
								this.getView().getModel("mModelSummary").setProperty("/oEditable/enableCOP", false);
							}
							// End Saptarshi on 24.01.2020
							if ((!sObj.Flag) || (this.getView().getModel("mModelSummary").getProperty("/displayMode") === true)) {
								oRouter.navTo("RouteHomeView", {
									No: sObj.RrfNo

								});
							} else {
								MessageBox.error(sObj.Message);
							}

						}

					}, this);
					var fnError = jQuery.proxy(function (d) {
						var r = JSON.parse(JSON.stringify(d));
						sap.ui.core.BusyIndicator.hide();
						MessageToast.show(r.message, {
							autoClose: true,
							width: "20rem"
						});
					}, this);

					var sPath = "/RRF_HeaderSet";
					var aFilter = [];
					sRrfNo = formatter.formatValueToString(sRrfNo); /*Change added by developer Satabdi Das on 25-May-2021 for HTTP Error*/
					aFilter.push(new sap.ui.model.Filter("RrfNo", sap.ui.model.FilterOperator.EQ, sRrfNo));
					if (mModelSummary.getProperty("/checkDisplayPress") === true) {
						aFilter.push(new sap.ui.model.Filter("CompanyCode", sap.ui.model.FilterOperator.EQ, "D"));
					}

					var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
						json: true
					});
					oModel1.read("/RRF_HeaderSet", {
						filters: aFilter,
						urlParameters: {
							"$expand": "RRF_Line_itemSet,RRF_HEADERPOSet,RRF_LINEPOSet,AR_ATTSet,RRF_AnswerSet"
						},
						success: fnSuccess,
						error: fnError
					});
					/*R&D---end*/
				} else {
					var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
					MessageBox.error(
						"You are not authorized to edit/view this RRF.", {
							styleClass: bCompact ? "sapUiSizeCompact" : ""
						}
					);
				}
			} else {
				var msg2 = "You are not authorized to edit/view this RRF. ";
				MessageToast.show(msg2);
			}
		},

		/*Start of change by Satabdi Das on 17-Feb-2021 for SCTASK1919812*/
		onMfLocValue: function () {

			var mModelSummary = this.getModel("mModelSummary");

			sap.ui.core.BusyIndicator.show(0);

			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				mModelSummary = this.getModel("mModelSummary");
				mModelSummary.setSizeLimit(d.results.length);
				mModelSummary.setProperty("/RRF_Loc", d.results);
				// this.getView().getModel("mModelSummary").setProperty("/SelcKeySet", "");
				this.getView().getModel("mModelSummary").setProperty("/SelcKeySetLocServ", ""); /*Added on 28-Jan-2020*/
				mModelSummary.refresh(true);
			}, this);

			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();

				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"

				});
			}, this);

			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
				json: true
			});
			oModel1.read("/RRF_MFSet", {
				success: fnSuccess,
				error: fnError
			});
		},

		onMfSearchHelpValue: function () {

			var mModelSummary = this.getModel("mModelSummary");

			sap.ui.core.BusyIndicator.show(0);

			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				mModelSummary = this.getModel("mModelSummary");
				mModelSummary.setSizeLimit(d.results.length);
				mModelSummary.setProperty("/RRF_MF", d.results);
				this.getView().getModel("mModelSummary").setProperty("/SelcKeySet", "");
				// this.getView().getModel("mModelSummary").setProperty("/SelcKeySetLocServ", ""); /*Added on 28-Jan-2020*/
				mModelSummary.refresh(true);

			}, this);

			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();

				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"

				});
			}, this);

			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
				json: true
			});
			oModel1.read("/Member_FirmSet", {
				success: fnSuccess,
				error: fnError
			});

		},
		/*End of change by Satabdi Das on 17-Feb-2021 for SCTASK1919812*/

		onPressCancel: function (oEvent) {
			/*start of change by Saptarshi on 13-Nov-2019*/
			var fragId = this.getView().createId("rrfDetail");
			var SearchId = sap.ui.core.Fragment.byId(fragId, "creator");
			SearchId.setValue("");
			var aFilter = [];
			aFilter.push(new Filter("RrfCreator", FilterOperator.Contains, ""));
			aFilter.push(new Filter("RrfCreationDate", FilterOperator.Contains, ""));
			aFilter.push(new Filter("VendorName", FilterOperator.Contains, ""));
			var frag = this.getView().createId("rrfDetail");
			var table = sap.ui.core.Fragment.byId(frag, "rrfDetailTable");
			var oBinding = table.getBinding("items");
			oBinding.filter(aFilter, "Application");
			/*End of change by Saptarshi on 13-Nov-2019*/
			if (this._oRrfDetail.isOpen()) { /*Added by Saptarshi on 13-Nov-2019*/
				this._oRrfDetail.close();
			} /*Added by Saptarshi on 13-Nov-2019*/
		},
		handleDisplayPress: function (oEvent) {
			var oChackAutho = this.getModel("mModelSummary").getProperty("/authoSet");
			var mModelSummary = this.getView().getModel("mModelSummary");
			mModelSummary.setProperty("/checkDisplayPress", true);
			if ((oChackAutho.GpEditDisplay === "D") || (oChackAutho.GpEditDisplay === "E")) {
				var displayRowNum = oEvent.getSource().getBindingContext("mModelSummary").getObject();
				this.getModel("mModelSummary").setProperty("/oDislayRRFNo", displayRowNum.RrfNo);

				this.onPressNav();

				//set all Field Editable false
				this.getModel("mModelSummary").setProperty("/oEditable", {});
				// this.getView().getModel("mModelSummary").setProperty("/oEditable/entityName", false);
				mModelSummary.setProperty("/filterSearch", "");
				mModelSummary.setProperty("/oEditable/visibleForEdit", false);
				mModelSummary.setProperty("/oEditable/contractNbr", false);
				mModelSummary.setProperty("/oEditable/editHeaderItem", false);
				mModelSummary.setProperty("/oEditable/editInformationItem", false);
				mModelSummary.setProperty("/oEditable/editLineItemCop", false);
				mModelSummary.setProperty("/oEditable/editLineItemMF", false);
				mModelSummary.setProperty("/oEditable/editLineItemLOA", false);
				mModelSummary.setProperty("/oEditable/checkBox", false); /*Added on 27-Jan-2020*/
				mModelSummary.setProperty("/oEditable/entityName", false);
				mModelSummary.setProperty("/oEditable/editPercy", false);
				mModelSummary.setProperty("/oEditable/attachmentEnable", true);
				mModelSummary.setProperty("/oEditable/attachmentDelete", false);
				mModelSummary.setProperty("/oEditable/lastsrvDate", false);
				mModelSummary.setProperty("/oEditable/contractAttachEnable", true);
				this.getModel("mModelSummary").setProperty("/oEditable/suppEdit", false);

				/*Added on 28-Janb-2020*/
				var avlue = this.getModel("i18n").getProperty("display");
				this.getView().getModel("mModelSummary").setProperty("/setDashBoardText", avlue);
				this.getModel("mModelSummary").setProperty("/displayMode", true); /*Added by Saptarshi on 22-Nov-2019*/
				this.getView().getModel("mModelSummary").refresh();
			} else {
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				MessageBox.error(
					"You are not authorized to edit/view this RRF.", {
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					}
				);
			}

		},
		onIrfSelect: function (oEvent) {

			var mModelSummary = this.getModel("mModelSummary");
			var msg;
			var sIrfNum = oEvent.getSource().getBindingContext("mModelSummary").getObject().RrfNoGf;
			if (sIrfNum === "") {
				msg = "Please select IRF number";
				MessageToast.show(msg);
			} else {
				this.getView().getModel("mModelSummary").setProperty("/GF_SH/RrfNoGf", sIrfNum);
				/*Start of chnage by Saptarshi on 13-Nov-2019*/
				var fragId = this.getView().createId("helpIRFOne");
				var SearchId = sap.ui.core.Fragment.byId(fragId, "searchFieldIrf");
				SearchId.setValue("");
				var aFilter = [];
				aFilter.push(new Filter("RrfNoGf", FilterOperator.Contains, ""));
				var frag = this.getView().createId("helpIRFOne");
				var table = sap.ui.core.Fragment.byId(frag, "irfNumTbl");
				var oBinding = table.getBinding("items");
				oBinding.filter(aFilter, "Application");
				/*End of change by Saptarshi on 13-Nov-2019*/
				if (this._oHelpIRFOne.isOpen()) {
					this._oHelpIRFOne.close();
				}
			}

		},
		/*Changed start by Saptarshi on 14-Nov-2019*/
		editNonCoupa: function (oEvent) {
			var mModelSummary = this.getModel("mModelSummary");
			var oAutho = this.getModel("mModelSummary").getProperty("/authoSet");
			if (oAutho.GfEditDisplay) {
				mModelSummary.setProperty("/oEditableNC/attachVisibleNC", true);
				mModelSummary.setProperty("/oEditableNC/companyCodeEdit", false);

				mModelSummary.setProperty("/oEditableNC/editHeaderItem", true); /*Added on 21-Jan-2020*/
				mModelSummary.setProperty("/oEditableNC/visibleForEditGf", true);
				mModelSummary.setProperty("/oEditableNC/visibleForDisplyGf", false);

				this.getModel("mModelSummary").setProperty("/displayMode", false); /*Added by Saptarshi on 22-Nov-2019*/

				var iButtonNum = this.radioIndex;

				var sHdrLbl = this.getModel("i18n").getProperty("HDBarLblTxtEdit");
				var sPlaceHolder = this.getView().getModel("i18n").getProperty("searchbyrrf"); /*Added on 09-Jan-2020*/

				mModelSummary.setProperty("/NonCopaHdrLbl", sHdrLbl);
				mModelSummary.setProperty("/textSet", sPlaceHolder);
				var gfHeaderset = {};
				var msg;
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length; /*Added on 20-Jan-2020*/
				var irf = mModelSummary.getData().GF_SH.RrfNoGf;
				var Grf = this.getView().getModel("mModelSummary").getProperty("/HeaderDataNC").RrfNoGf;
				var sIrfCreator = mModelSummary.getData().GF_SH.CreatedBy; /*Addeed on 06-Jan-2020*/
				var aFilter = []; /*Addeed on 06-Jan-2020*/
				this.onMfSearchHelpNC(); //Added by Saptarshi on 20-Nov-2019
				this.onMfLocValueNC(); /*Added on 17-Feb-2021 for SCTASK1919812*/
				this.getModel("mModelSummary").setProperty("/NonCopaAppTitle", irf);
				if (iButtonNum === 1 || iButtonNum === 2) {
					/*Start of change on 06-Jan-2020 */
					if (sIrfCreator || irf) {
						sap.ui.core.BusyIndicator.show(0);
						var sPath = "";
						sPath = "/GF_SHSet";
						var fnSuccess = jQuery.proxy(function (d) {
							sap.ui.core.BusyIndicator.hide(0);
							if (d.results.length === 0) {
								var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
								MessageBox.alert(
									"No results found.", {
										styleClass: bCompact ? "sapUiSizeCompact" : ""
									}
								);
							} else {
								/*Start change on 02-Jan-2020*/
								for (var i = 0; i < d.results.length; i++) {
									d.results[i].CreatedOn = formatter.formatRrfCreationDate(d.results[i].CreatedOn);
								}
								/*End change on 02-Jan-2020*/
								mModelSummary.setProperty("/GF_SH", d.results);
								mModelSummary.refresh(true);
								var fragmentId = this.getView().createId("irfDetail");
								if (!this._oIrfDetail) {
									this._oIrfDetail = sap.ui.xmlfragment(fragmentId, "kgo.ARRecharge.view.irfDetail", this);
									this.getView().addDependent(this._oIrfDetail);
								}
								this._oIrfDetail.open();
							}
						}, this);
						var fnError = jQuery.proxy(function (d) {
							var r = JSON.parse(JSON.stringify(d));
							sap.ui.core.BusyIndicator.hide();
							MessageToast.show(r.message, {
								autoClose: true,
								width: "20rem"
							});
						}, this);
						if (iButtonNum === 1) {
							aFilter.push(new Filter("CreatedBy", FilterOperator.EQ, sIrfCreator));
						} else if (iButtonNum === 2) {
							aFilter.push(new Filter("Kostl", FilterOperator.EQ, sIrfCreator));
						}
						var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
							json: true
						});
						oModel1.read("/GF_SHSet", {
							filters: aFilter,
							success: fnSuccess,
							error: fnError
						});
						// var sParams = {};
						// var oObject = {};
						// oObject.Filter = aFilter;
						// oObject.Params = sParams;
						// oObject.successCallback = fnSuccess;
						// oObject.errorCallback = fnError;
						// oObject.sPath = sPath;
						// DataManagerARrecharge.getNonCoupaReqhelpValue(oObject);
					} else {
						if (iButtonNum === 1) {
							msg = this.getView().getModel("i18n").getProperty("errorCreated");
							MessageToast.show(msg);
							return;
						} else if (iButtonNum === 2) {
							var errMsg = this.getView().getModel("i18n").getProperty("errorCostCenter");
							MessageToast.show(errMsg);
						}
					}
					/*End of change on 06-Jan-2020*/
				}
				if (oEvent && oAutho.GfEditDisplay === "E") {
					gfHeaderset.RrfNoGf = irf;
				} else if (!oEvent && (oAutho.GfEditDisplay === "E" || oAutho.GfEditDisplay === "D")) {
					if (Grf) {
						gfHeaderset.RrfNoGf = Grf;
					} else {
						gfHeaderset.RrfNoGf = irf;
					}
				} else {
					var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
					MessageBox.error(
						"You are not authorized to edit/view this RRF.", {
							styleClass: bCompact ? "sapUiSizeCompact" : ""
						}
					);
					return true;
				}
				if (iButtonNum !== 1 && iButtonNum !== 2) { /*Start of Defect 63131 on 06-Feb-2020*/
					if (gfHeaderset.RrfNoGf || Grf) {
						var arr = [];
						var questionArrayNP = [];
						var fnSuccess = jQuery.proxy(function (d) {
							sap.ui.core.BusyIndicator.hide(0);
							if (!d.results.length) {
								var msg2 = "This RRF does not exist in the system.";
								MessageBox.error(msg2);

							}
							var sObj = {};

							for (var i = 0; i < d.results.length; i++) {

								sObj.BillScheFlg = d.results[i].BillScheFlg;
								sObj.CompanyCode = d.results[i].CompanyCode;
								sObj.ContrlName = d.results[i].ContrlName;
								sObj.ContrlEmail = d.results[i].ContrlEmail;
								sObj.CanNoticeDate = d.results[i].CanNoticeDate;
								sObj.TotalContractAmount = d.results[i].TotalContractAmount;
								sObj.GfDesc = d.results[i].GfDesc;
								sObj.RrfNoGf = d.results[i].RrfNoGf;
								sObj.CreatedOn = d.results[i].CreatedOn; /*Changed on 08-Jan-2020*/
								sObj.CreatedBy = d.results[i].CreatedBy;
								sObj.RrfCreatorName = d.results[i].RrfCreatorName;
								sObj.Currency = d.results[i].Currency;
								sObj.Kostl = d.results[i].Kostl; /*Added on 24-Dec-2019*/
								sObj.Ltext = d.results[i].Ltext; /*Added by Satabdi Das on 09-Jan-2020*/
								sObj.AddlInfo = d.results[i].AddlInfo; /*Added on 24-Dec-2019*/
								sObj.Background = d.results[i].Background; /*Added on 03-March-2020*/
								sObj.Activity = d.results[i].Activity; /*Added by Satabdi Das on 03-March-2020*/
								sObj.CoupaCc = d.results[i].CoupaCc;
								sObj.CoupaGl = d.results[i].CoupaGl;
								sObj.RrfStatus = d.results[i].RrfStatus;
								sObj.Flag = d.results[i].Flag;
								sObj.Message = d.results[i].Message;
								sObj.CopInitiate = d.results[i].CopInitiate; /*Saptarshi Added on 24-Jan-2020*/
								sObj.LoaInitiate = d.results[i].LoaInitiate; /*Saptarshi Added on 24-Jan-2020*/
								sObj.GfEditDisplay = d.results[i].GfEditDisplay; /*Added on 20-Jan-2020*/
								sObj.RrfType = d.results[i].RrfType; /*Added by developer Satabdi Das on 26-Nov-2020*/
								sObj.ToDisplay = d.results[i].ToDisplay;
								arr = d.results[i].GF_Lineitem_Set;
								arr = formatter.formatFromUTCforCoupaDate(arr);
								questionArrayNP = d.results[i].RRF_AnswerSet;
								mModelSummary.setProperty("/TableItemSetNC", arr);
								mModelSummary.setProperty("/HeaderDataNC", sObj);
								mModelSummary.setProperty("/nPQuestionSetSubmit", questionArrayNP.results);

								/*Start of change on 20-Jan-2020*/

								var oRouter = UIComponent.getRouterFor(this);

								//Begin  Saptarshi on 24.01.2020
								if (sObj.LoaInitiate === "X") {
									//Saptarshi on 24.01.2020	// this.getView().getModel("mModelSummary").setProperty("/oEditable/enableCOP", false);
									this.getView().getModel("mModelSummary").setProperty("/oEditableNC/enableLOA", true);
								} else {
									//Saptarshi on 24.01.2020	// this.getView().getModel("mModelSummary").setProperty("/oEditable/enableCOP", true);
									this.getView().getModel("mModelSummary").setProperty("/oEditableNC/enableLOA", false);
								}
								if (sObj.CopInitiate === "X") {
									this.getView().getModel("mModelSummary").setProperty("/oEditableNC/enableCOP", true);
								} else {
									this.getView().getModel("mModelSummary").setProperty("/oEditableNC/enableCOP", false);
								}
								// End Saptarshi on 24.01.2020
								//added by prashant 06.11.2020
								if (!sObj.Flag) {
									oRouter.navTo("NonCoupaRRF", {
										No: sObj.RrfNoGf
									});

								} else {
									MessageBox.error("This RRF does not exist in the system.");
								}

								if (!oEvent) {
									for (var i = 0; i < this.getView().getModel("mModelSummary").getProperty("/TableItemSetNC/results").length; i++) {
										var tbl = this.getView().byId('LineItemTab');

										var copInitiate = this.getView().getModel("mModelSummary").getProperty("/TableItemSetNC/results")[i].CopInitiate;
										if (copInitiate === "X") {
											var x = tbl.getAggregation("items")[i];
											x.getMultiSelectControl().setEnabled(false);
										}

									}
								}
							}
						}, this);
						var fnError = jQuery.proxy(function (d) {
							var r = JSON.parse(JSON.stringify(d));
							sap.ui.core.BusyIndicator.hide();
							MessageToast.show(r.message, {
								autoClose: true,
								width: "20rem"

							});

						}, this);
						// var sPath = "/GF_HeaderSet";
						var aFilter = [];
						if (gfHeaderset.RrfNoGf) {
							gfHeaderset.RrfNoGf = formatter.formatValueToString(gfHeaderset.RrfNoGf); /*Change added by developer Satabdi Das on 25-May-2021 for HTTP Error*/
							aFilter.push(new sap.ui.model.Filter("RrfNoGf", sap.ui.model.FilterOperator.EQ, gfHeaderset.RrfNoGf));
						} else if (Grf) {
							Grf = formatter.formatValueToString(Grf); /*Change added by developer Satabdi Das on 25-May-2021 for HTTP Error*/
							aFilter.push(new sap.ui.model.Filter("RrfNoGf", sap.ui.model.FilterOperator.EQ, Grf));
						}
						if (mModelSummary.getProperty("/checkDisplayPressNP") === true) {
							aFilter.push(new sap.ui.model.Filter("CompanyCode", sap.ui.model.FilterOperator.EQ, "D"));
						}
						var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
							json: true
						});
						oModel1.read("/GF_HeaderSet", {
							filters: aFilter,
							urlParameters: {
								"$expand": "GF_Lineitem_Set,RRF_AnswerSet"
							},
							success: fnSuccess,
							error: fnError
						});

						// var sParams = {};
						// var oObject = {};
						// oObject.Filter = aFilter;
						// oObject.Params = sParams;
						// oObject.successCallback = fnSuccess;
						// oObject.errorCallback = fnError;
						// oObject.sPath = sPath;
						// DataManagerARrecharge.getGFHeaderSetvalue(oObject);

					} else {
						var msg2 = this.getView().getModel("i18n").getProperty("ValidGFTxt");
						MessageToast.show(msg2);
					}
				} /*End of Defect 63131 on 06-Feb-2020*/
			} else {
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				MessageBox.error(
					"You are not authorized to edit/view this RRF", {
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					}
				);
			}
		},
		onIrfNav: function (oEvent) {

			var oAutho = this.getModel("mModelSummary").getProperty("/authoSet");
			if ((oAutho.GfEditDisplay)) {
				var mModelSummary = this.getModel("mModelSummary");
				mModelSummary.setProperty("/oEditableNC/attachVisibleNC", true);
				mModelSummary.setProperty("/oEditableNC/editHeaderItem", true); /*Added on 21-Jan-2020*/
				mModelSummary.setProperty("/oEditableNC/visibleForEditGf", true); /*Added on 17-Jan-2020*/
				mModelSummary.setProperty("/oEditableNC/visibleForDisplyGf", false); /*Added on 17-Jan-2020*/
				mModelSummary.setProperty("/displayMode", false); /*Added by Saptarshi on 22-Nov-2019*/
				mModelSummary.setProperty("/oEditableNC/companyCodeEdit", false); //added by prashant 14.08.2020

				var iButtonNum = this.radioIndex;
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length; /*Added on 20-Jan-2020*/
				var msg; /*Added on 20-Jan-2020*/
				var mModelSummary = this.getModel("mModelSummary");
				var sHdrLbl = this.getModel("i18n").getProperty("HDBarLblTxtEdit");

				mModelSummary.setProperty("/NonCopaHdrLbl", sHdrLbl);
				var gfHeaderset;
				this.getView().getModel("mModelSummary").setProperty("/oEditableNC/checkBox", true); /*Added on 21-Feb-2020*/
				var arr = [];
				var questionArrayNP = [];
				if (oEvent && oAutho.GfEditDisplay === "E") {
					gfHeaderset = oEvent.getSource().getBindingContext("mModelSummary").getObject().RrfNoGf; /*Changed by Saptarshi*/
				} else if (oAutho.GfEditDisplay === "D" || oAutho.GfEditDisplay === "E") {
					gfHeaderset = this.getModel("mModelSummary").getProperty("/oDislayRrfNoGf"); /*Changed by Saptarshi*/

				}
				this.onMfSearchHelpNC(); //Added by Saptarshi on 20-Nov-2019
				this.onMfLocValueNC(); /*Added on 17-Feb-2021 for SCTASK1919812*/
				// var irf = gfHeaderset.RrfNoGf;
				this.getModel("mModelSummary").setProperty("/NonCopaAppTitle", gfHeaderset);
				if (gfHeaderset != undefined) {
					var fnSuccess = jQuery.proxy(function (d) {
						sap.ui.core.BusyIndicator.hide(0);
						if (!d.results.length) {
							var msg2 = "Please enter correct details";
							MessageToast.show(msg2);
						}
						var sObj = {};
						for (var i = 0; i < d.results.length; i++) {

							sObj.BillScheFlg = d.results[i].BillScheFlg;
							sObj.CompanyCode = d.results[i].CompanyCode;
							sObj.ContrlName = d.results[i].ContrlName;
							sObj.ContrlEmail = d.results[i].ContrlEmail;
							sObj.CanNoticeDate = d.results[i].CanNoticeDate;
							sObj.TotalContractAmount = d.results[i].TotalContractAmount;
							sObj.GfDesc = d.results[i].GfDesc;
							sObj.RrfNoGf = d.results[i].RrfNoGf;
							sObj.CreatedOn = d.results[i].CreatedOn; /*Changed on 08-Jan-2020*/
							sObj.CreatedBy = d.results[i].CreatedBy;
							sObj.RrfCreatorName = d.results[i].RrfCreatorName;
							sObj.Currency = d.results[i].Currency;
							sObj.Kostl = d.results[i].Kostl; /*Added on 09-Jan-2020*/
							sObj.Ltext = d.results[i].Ltext; /*Added by Satabdi Das on 09-Jan-2020*/
							sObj.Background = d.results[i].Background; /*Added on 03-March-2020*/
							sObj.Activity = d.results[i].Activity; /*Added by Satabdi Das on 03-March-2020*/
							sObj.AddlInfo = d.results[i].AddlInfo; /*Added on 27-Jan-2020*/
							sObj.CoupaCc = d.results[i].CoupaCc;
							sObj.CoupaGl = d.results[i].CoupaGl;
							sObj.RrfStatus = d.results[i].RrfStatus;
							sObj.Flag = d.results[i].Flag;
							sObj.Message = d.results[i].Message;
							sObj.GfEditDisplay = d.results[i].GfEditDisplay; /*Added on 20-JAN-2020*/
							sObj.RrfType = d.results[i].RrfType; /*Added by developer Satabdi Das on 26-Nov-2020*/
							sObj.CopInitiate = d.results[i].CopInitiate; /*Saptarshi Added on 24-Jan-2020*/
							sObj.LoaInitiate = d.results[i].LoaInitiate; /*Saptarshi Added on 24-Jan-2020*/
							sObj.ToDisplay = d.results[i].ToDisplay;
							arr = d.results[i].GF_Lineitem_Set;
							arr = formatter.formatFromUTCforCoupaDate(arr);
							questionArrayNP = d.results[i].RRF_AnswerSet;
							mModelSummary.setProperty("/TableItemSetNC", arr);
							mModelSummary.setProperty("/HeaderDataNC", sObj);
							mModelSummary.setProperty("/nPQuestionSetSubmit", questionArrayNP.results);
							if (iButtonNum === 1 || iButtonNum === 2 || iButtonNum === 3) {
								var fragId = this.getView().createId("irfDetail");
								var SearchId = sap.ui.core.Fragment.byId(fragId, "seachBar");
								SearchId.setValue("");
								var aFilter = [];
								if (iButtonNum === 1) {
									aFilter.push(new Filter("CreatedBy", FilterOperator.Contains, ""));
								} else if (iButtonNum === 2) {
									aFilter.push(new Filter("CreatedOn", FilterOperator.Contains, ""));
								} else if (iButtonNum === 3) {
									aFilter.push(new Filter("CoupaCc", FilterOperator.Contains, ""));
								}
								var frag = this.getView().createId("irfDetail");
								var table = sap.ui.core.Fragment.byId(frag, "irfDetailTable");
								var oBinding = table.getBinding("items");
								oBinding.filter(aFilter, "Application");
								if (this._oIrfDetail.isOpen()) {
									this._oIrfDetail.close();
								}
							}
							/*Start of change on 17-Jan-2020*/
							if (iButtonNum === 0 || iButtonNum === undefined) {
								var fragId1 = this.getView().createId("helpIRFOne");
								var SearchId1 = sap.ui.core.Fragment.byId(fragId1, "searchFieldIrf");
								SearchId1.setValue("");
								var aFilter1 = [];
								aFilter1.push(new Filter("RrfNoGf", FilterOperator.Contains, ""));
								var frag1 = this.getView().createId("helpIRFOne");
								var table1 = sap.ui.core.Fragment.byId(frag1, "irfNumTbl");
								var oBinding1 = table1.getBinding("items");
								oBinding1.filter(aFilter, "Application");
								if (this._oHelpIRFOne.isOpen()) {
									this._oHelpIRFOne.close();
								}
							}

							/*End of change on 17-Jan-2020*/
							/*Start of change on 20-Jan-2020*/

							var oRouter = UIComponent.getRouterFor(this);
							/*Start of change by Satabdi Das on 26-Dec-2019*/

							if (sObj.CopInitiate === "X") {
								this.getView().getModel("mModelSummary").setProperty("/oEditableNC/enableCOP", true);
							} else {
								this.getView().getModel("mModelSummary").setProperty("/oEditableNC/enableCOP", false);
							}

							if (sObj.LoaInitiate === "X") {
								//Saptarshi on 24.01.2020	// this.getView().getModel("mModelSummary").setProperty("/oEditable/enableCOP", false);
								this.getView().getModel("mModelSummary").setProperty("/oEditableNC/enableLOA", true);
							} else {
								//Saptarshi on 24.01.2020	// this.getView().getModel("mModelSummary").setProperty("/oEditable/enableCOP", true);
								this.getView().getModel("mModelSummary").setProperty("/oEditableNC/enableLOA", false);
							}
							/*End of change by Satabdi Das on 26-Dec-2019*/
							if ((!sObj.Flag) || (mModelSummary.getProperty("/checkDisplayPressNP") === true)) {
								oRouter.navTo("NonCoupaRRF", {
									No: sObj.RrfNoGf

								});
							} else {
								MessageBox.error(sObj.Message);
							}

						}

					}, this);

					var fnError = jQuery.proxy(function (d) {
							var r = JSON.parse(JSON.stringify(d));
							sap.ui.core.BusyIndicator.hide();
							MessageToast.show(r.message, {
								autoClose: true,
								width: "20rem"

							});

						}, this

					);

					//var sPath = "/GF_HeaderSet";
					var aFilter = [];
					gfHeaderset = formatter.formatValueToString(gfHeaderset); /*Change added by developer Satabdi Das on 25-May-2021 for HTTP Error*/
					aFilter.push(new sap.ui.model.Filter("RrfNoGf", sap.ui.model.FilterOperator.EQ, gfHeaderset));
					if (mModelSummary.getProperty("/checkDisplayPressNP") === true) {
						aFilter.push(new sap.ui.model.Filter("CompanyCode", sap.ui.model.FilterOperator.EQ, "D"));
					}

					var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
						json: true
					});
					oModel1.read("/GF_HeaderSet", {
						filters: aFilter,
						urlParameters: {
							"$expand": "GF_Lineitem_Set,RRF_AnswerSet"
						},
						success: fnSuccess,
						error: fnError
					});

					// var sParams = {};
					// var oObject = {};
					// oObject.Filter = aFilter;
					// oObject.Params = sParams;
					// oObject.successCallback = fnSuccess;
					// oObject.errorCallback = fnError;
					// oObject.sPath = sPath;
					// DataManagerARrecharge.getGFHeaderSetvalue(oObject);

				} else {
					var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
					MessageBox.error(
						"You are not authorized to edit/view this RRF.", {
							styleClass: bCompact ? "sapUiSizeCompact" : ""
						}
					);
				}
			} else {
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				MessageBox.error(
					"You are not authorized to edit/view this RRF.", {
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					}
				);
			}

		},
		/*Changed end by Saptarshi on 14-Nov-2019*/
		onIrfCancel: function (oEvent) {
			/*start of change by Saptarshi on 13-Nov-2019*/
			var mModelSummary = this.getModel("mModelSummary");
			var fragId = this.getView().createId("irfDetail");
			var SearchId = sap.ui.core.Fragment.byId(fragId, "seachBar");
			mModelSummary.setProperty("/oEditableNC/costCenterEdit", true);
			SearchId.setValue("");
			var aFilter = [];
			var iButtonNum = this.radioIndex;
			if (iButtonNum === 1) {
				aFilter.push(new Filter("CreatedBy", FilterOperator.Contains, ""));
			} else if (iButtonNum === 2) {
				aFilter.push(new Filter("CreatedOn", FilterOperator.Contains, ""));
			} else if (iButtonNum === 3) {
				aFilter.push(new Filter("CoupaCc", FilterOperator.Contains, ""));
			}
			var frag = this.getView().createId("irfDetail");
			var table = sap.ui.core.Fragment.byId(frag, "irfDetailTable");
			var oBinding = table.getBinding("items");
			oBinding.filter(aFilter, "Application");
			/*End of change by Saptarshi on 13-Nov-2019*/
			if (this._oIrfDetail.isOpen()) { /*Added by Saptarshi on 13-Nov-2019*/
				this._oIrfDetail.close();
			} /*Added by Saptarshi on 13-Nov-2019*/
		},
		onDisplayNonCoup: function (oEvent) {
			var mModelSummary = this.getView().getModel("mModelSummary");
			mModelSummary.setProperty("/checkDisplayPressNP", true);
			var oAutho = this.getModel("mModelSummary").getProperty("/authoSet");
			if ((oAutho.GfEditDisplay === "E") || (oAutho.GfEditDisplay === "D")) {

				var displayRowNum = oEvent.getSource().getBindingContext("mModelSummary").getObject();
				this.getModel("mModelSummary").setProperty("/oDislayRrfNoGf", displayRowNum.RrfNoGf);
				this.onIrfNav();
				this.getModel("mModelSummary").setProperty("/oEditableNC", {});
				mModelSummary.setProperty("/oEditableNC/visibleForEditGf", false);
				mModelSummary.setProperty("/oEditableNC/visibleForDisplyGf", true);
				mModelSummary.setProperty("/oEditableNC/editHeaderItem", false);
				mModelSummary.setProperty("/oEditableNC/editInformationItem", false);
				mModelSummary.setProperty("/oEditableNC/editLineItemCop", false);
				mModelSummary.setProperty("/oEditableNC/editLineItemMF", false);
				mModelSummary.setProperty("/oEditableNC/editLineItemLOA", false);
				mModelSummary.setProperty("/oEditableNC/editLineItemBillSch", false);
				mModelSummary.setProperty("/oEditableNC/editLineItemAddInf", false);
				mModelSummary.setProperty("/oEditableNC/editLineItemAddInfJV", false);
				mModelSummary.setProperty("/oEditableNC/visibleforMF", false);
				mModelSummary.setProperty("/oEditableNC/visibleforBillSch", false);
				mModelSummary.setProperty("/oEditableNC/visibleforGF", false);
				mModelSummary.setProperty("/oEditableNC/lastservdateNP", false);
				mModelSummary.setProperty("/oEditableNC/entityName", false);
				mModelSummary.setProperty("/oEditableNC/companyCodeEdit", false); //added by prashant 14.08.2020

				this.getModel("mModelSummary").setProperty("/oEditableNC/editMode", false);
				this.getModel("mModelSummary").setProperty("/oEditableNC/Occurence", false);
				this.getModel("mModelSummary").setProperty("/oEditableNC/billFields", false); /*Added on 17-Jan-2020*/
				this.getModel("mModelSummary").setProperty("/oEditableNC/PercY", false); /*Added on 20-Jan-2020*/
				this.getView().getModel("mModelSummary").setProperty("/oEditableNC/checkBox", false); /*Added on 27-Jan-2020*/
				this.getView().getModel("mModelSummary").setProperty("/oEditableNC/entityName", false); /*Added on 28-Janb-2020*/
				this.getView().getModel("mModelSummary").setProperty("/oEditableNC/attachAddButton", true);
				this.getView().getModel("mModelSummary").setProperty("/oEditableNC/deleteBtnAttchment", false);
				/*Start of change by Saptarshi on 21-Nov-2019*/
				var avlue = this.getModel("i18n").getProperty("HDBarLblTxtDis");
				this.getModel("mModelSummary").setProperty("/NonCopaHdrLbl", avlue);
				this.getModel("mModelSummary").setProperty("/displayMode", true);
				var iButtonNum = this.radioIndex;
				if (iButtonNum === 0 || iButtonNum === undefined) {
					var fragId = this.getView().createId("helpIRFOne");
					var SearchId = sap.ui.core.Fragment.byId(fragId, "searchFieldIrf");
					SearchId.setValue("");
					var aFilter = [];
					aFilter.push(new Filter("RrfNoGf", FilterOperator.Contains, ""));
					var frag = this.getView().createId("helpIRFOne");
					var table = sap.ui.core.Fragment.byId(frag, "irfNumTbl");
					var oBinding = table.getBinding("items");
					oBinding.filter(aFilter, "Application");
				} else if (iButtonNum === 1) {
					var fragId1 = this.getView().createId("irfDetail");
					var SearchId1 = sap.ui.core.Fragment.byId(fragId1, "seachBar");
					SearchId1.setValue("");
					var aFilter1 = [];
					aFilter1.push(new Filter("CreatedBy", FilterOperator.Contains, ""));
					var frag1 = this.getView().createId("irfDetail");
					var table1 = sap.ui.core.Fragment.byId(frag1, "irfDetailTable");
					var oBinding1 = table1.getBinding("items");
					oBinding1.filter(aFilter, "Application");
				}
			}
		},
		onEditSearch: function (oEvent) {
			var mModelSummary = this.getModel("mModelSummary");
			var oLiveSaerchText = mModelSummary.getProperty("/textSet");
			var iButtonNum = this.radioIndex;
			var aFilter = [];
			var sQuery = oEvent.getSource().getValue();
			sQuery = sQuery.trim();
			if (sQuery && sQuery.length > 0) {
				if (iButtonNum === 1) {
					aFilter.push(new Filter("CreatedBy", FilterOperator.Contains, sQuery));
				} else if ((iButtonNum === 2) && (oLiveSaerchText !== "Cost Center")) {
					aFilter.push(new Filter("RrfNoGf", FilterOperator.Contains, sQuery));
				} else if ((oLiveSaerchText === "Cost Center") && (iButtonNum === 2)) {
					aFilter.push(new Filter("Kostl", FilterOperator.Contains, sQuery));
				}
			}
			var frag = this.getView().createId("irfDetail");
			var table = sap.ui.core.Fragment.byId(frag, "irfDetailTable");
			var oBinding = table.getBinding("items");
			oBinding.filter(aFilter, "Application");
		},
		onSearchIrf: function (oEvent) {
			var aFilter = [];
			var sQuery = oEvent.getSource().getValue();
			sQuery = sQuery.trim();
			if (sQuery && sQuery.length > 0) {
				aFilter.push(new Filter("RrfNoGf", FilterOperator.Contains, sQuery));
			}
			var frag = this.getView().createId("helpIRFOne");
			var table = sap.ui.core.Fragment.byId(frag, "irfNumTbl");
			var oBinding = table.getBinding("items");
			oBinding.filter(aFilter, "Application");
		},
		/*Start of change by Saptarshi on 19-Nov-2019*/
		handleDisplayforNC: function (oEvent) {
			var mModelSummary = this.getModel("mModelSummary");
			mModelSummary.setProperty("/checkDisplayPressNP", true);
			var iIndex = oEvent.getParameters().selectedIndex;
			var oAutho = this.getModel("mModelSummary").getProperty("/authoSet");
			if ((oAutho.GfEditDisplay === "E") || (oAutho.GfEditDisplay === "D")) {
				this.editNonCoupa();

				var sHdrLbl = this.getModel("i18n").getProperty("HDBarLblTxtDis");
				mModelSummary.setProperty("/NonCopaHdrLbl", sHdrLbl);

				this.getModel("mModelSummary").setProperty("/oEditableNC", {});
				this.getView().getModel("mModelSummary").setProperty("/oEditableNC/visibleForEditGf", false);
				this.getView().getModel("mModelSummary").setProperty("/oEditableNC/visibleForDisplyGf", true);
				this.getModel("mModelSummary").setProperty("/oEditableNC/editHeaderItem", false);
				this.getModel("mModelSummary").setProperty("/oEditableNC/editInformationItem", false);
				this.getModel("mModelSummary").setProperty("/oEditableNC/editLineItemCop", false);
				this.getModel("mModelSummary").setProperty("/oEditableNC/editLineItemMF", false);
				this.getModel("mModelSummary").setProperty("/oEditableNC/editLineItemLOA", false);
				this.getModel("mModelSummary").setProperty("/oEditableNC/editLineItemBillSch", false);
				this.getModel("mModelSummary").setProperty("/oEditableNC/editLineItemAddInf", false);
				this.getModel("mModelSummary").setProperty("/oEditableNC/editLineItemAddInfJV", false);
				this.getModel("mModelSummary").setProperty("/oEditableNC/visibleforMF", false);
				this.getModel("mModelSummary").setProperty("/oEditableNC/visibleforBillSch", false);
				this.getModel("mModelSummary").setProperty("/oEditableNC/visibleforGF", false);
				this.getModel("mModelSummary").setProperty("/oEditableNC/editMode", false);
				this.getModel("mModelSummary").setProperty("/oEditableNC/Occurence", false);
				this.getModel("mModelSummary").setProperty("/oEditableNC/billFields", false); /*Added on 17-Jan-2020*/
				mModelSummary.setProperty("/oEditableNC/PercY", false); /*Added on 20-Jan-2020*/
				mModelSummary.setProperty("/oEditableNC/checkBox", false); /*Added on 27-Jan-2020*/
				mModelSummary.setProperty("/oEditableNC/entityName", false); /*Added on 28-Janb-2020*/
				mModelSummary.setProperty("/oEditableNC/attachAddButton", true);
				mModelSummary.setProperty("/oEditableNC/deleteBtnAttchment", false);
				mModelSummary.setProperty("/oEditableNC/lastservdateNP", false);
				/*Start of change by Saptarshi on 21-Nov-2019*/
				mModelSummary.setProperty("/oEditableNC/companyCodeEdit", false); //added by prashant 14.08.2020
				var avlue = this.getModel("i18n").getProperty("HDBarLblTxtDis");
				this.getModel("mModelSummary").setProperty("/NonCopaHdrLbl", avlue);
				this.getModel("mModelSummary").setProperty("/displayMode", true); /*Added by Sapatrshi on 22-Nov-2019*/
				this.getModel("mModelSummary").refresh();
			} else {
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				MessageBox.error(
					"You are not authorized to edit/view this RRF.", {
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					}
				);
				return true;
			}
			/*End of change by Saptarshi on 21-Nov-2019*/
		},
		/*End of change by Saptarshi on 19-Nov-2019*/
		// Start of change by Saptarshi on 20-Nov-2019* To call country search help/
		/*Start of change by Satabdi Das on 17-Feb-2021 for SCTASK1919812*/
		onMfSearchHelpNC: function () {
			var mModelSummary = this.getModel("mModelSummary");
			// if (mModelSummary.getProperty("/HeaderDataNC/memberFirm")) {
			// 	var oMemberfirm = mModelSummary.getProperty("/HeaderDataNC/memberfirm");
			// } else {
			// 	oMemberfirm = "";
			// }
			// var sSrchVal = oMemberfirm;
			// var fragmentId = this.getView().createId("searchCoordinator");
			sap.ui.core.BusyIndicator.show(0);

			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				mModelSummary = this.getModel("mModelSummary");
				mModelSummary.setSizeLimit(d.results.length); /*Added on 31-Dec-2019*/
				mModelSummary.setProperty("/RRF_MFSet", d.results);
				this.getView().getModel("mModelSummary").setProperty("/SelcKeySet", ""); /*Added on 31-Dec-2019*/
				// this.getView().getModel("mModelSummary").setProperty("/updateRowDataNC/LocationOfTheServicesReq", ""); /*Added on 28-Jan-2020*/
				// this.getView().getModel("mModelSummary").setProperty("/SelcKeySetLocServNC", "");
				this.getView().getModel("mModelSummary").refresh(true); /*Added on 27-Jan-2020*/
				// mModelSummary.refresh(true);
			}, this);
			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();

				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"
				});
			}, this);

			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
				json: true
			});
			oModel1.read("/Member_FirmSet", {
				success: fnSuccess,
				error: fnError
			});

		},
		onMfLocValueNC: function () {
			var mModelSummary = this.getModel("mModelSummary");
			if (mModelSummary.getProperty("/HeaderDataNC/memberFirm")) {
				var oMemberfirm = mModelSummary.getProperty("/HeaderDataNC/memberfirm");
			} else {
				oMemberfirm = "";
			}
			var sSrchVal = oMemberfirm;
			// var fragmentId = this.getView().createId("searchCoordinator");
			sap.ui.core.BusyIndicator.show(0);

			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				mModelSummary = this.getModel("mModelSummary");
				mModelSummary.setSizeLimit(d.results.length); /*Added on 31-Dec-2019*/
				mModelSummary.setProperty("/RRF_Loc", d.results);
				// this.getView().getModel("mModelSummary").setProperty("/SelcKeySet", ""); /*Added on 31-Dec-2019*/
				this.getView().getModel("mModelSummary").setProperty("/updateRowDataNC/LocationOfTheServicesReq", ""); /*Added on 28-Jan-2020*/
				this.getView().getModel("mModelSummary").setProperty("/SelcKeySetLocServNC", "");
				this.getView().getModel("mModelSummary").refresh(true); /*Added on 27-Jan-2020*/
				// mModelSummary.refresh(true);
			}, this);
			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();

				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"
				});
			}, this);

			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
				json: true
			});
			oModel1.read("/RRF_MFSet", {
				success: fnSuccess,
				error: fnError
			});

		},
		/*End of change by Satabdi Das on 17-Feb-2021 for SCTASK1919812*/
		/*Start of change by Satabdi Das on 04-Dec-2019 */
		//  The following functions are common for both coupa and non-coupa
		onNameHelp: function (oEvent) {
			var mModelSummary = this.getModel("mModelSummary");
			var oCompanyCode;
			var sCustNo;
			var sName;
			/*Start of change on 09-Jan-2020*/
			var sReqMfGF = mModelSummary.getProperty("/updateRowDataNC/RequestingMf");
			var sReqMfGP = mModelSummary.getProperty("/updateRowData/RequestingMf");
			/* start of changes for company code 18.08.2020 by prashant*/

			oCompanyCode = mModelSummary.getProperty("/HeaderData").CompanyCode;
			if (!oCompanyCode) {
				oCompanyCode = mModelSummary.getProperty("/HeaderDataNC").CompanyCode;
			}

			/*End of change on 18.08.2020 */
			if (mModelSummary.getProperty("/EntitySet/Name1")) {
				sCustNo = mModelSummary.getProperty("/EntitySet/Kunnr");
				sName = mModelSummary.getProperty("/EntitySet/Name1");
			} else {
				sCustNo = "";
				sName = "";
			}
			sap.ui.core.BusyIndicator.show(0);
			var aFilter = [];
			//var sPath = "";
			//sPath = "/EntitySet";
			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				mModelSummary.setProperty("/EntitySet", d.results);
				var fragmentId = this.getView().createId("entityHelp");
				if (!this._oEntityHelp) {
					this._oEntityHelp = sap.ui.xmlfragment(fragmentId, "kgo.ARRecharge.view.entityHelp", this);
					this.getView().addDependent(this._oEntityHelp);
				}
				this._oEntityHelp.open();
			}, this);
			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();
				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"
				});
			}, this);
			/*Start of change on 18-august-2020 for company code changes*/

			var oFilterSerach;
			if (oCompanyCode) {
				oFilterSerach = new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.EQ, oCompanyCode);
				aFilter.push(oFilterSerach);
			}
			if (sReqMfGF !== undefined && sReqMfGF !== "") {
				oFilterSerach = new sap.ui.model.Filter("Land1", sap.ui.model.FilterOperator.EQ, sReqMfGF);
				aFilter.push(oFilterSerach);
				//aFilter.push(new sap.ui.model.Filter("Land1", sap.ui.model.FilterOperator.EQ, sReqMfGF));
			} else if (sReqMfGP !== undefined && sReqMfGP !== "") {
				oFilterSerach = new sap.ui.model.Filter("Land1", sap.ui.model.FilterOperator.EQ, sReqMfGP);
				aFilter.push(oFilterSerach);
				//aFilter.push(new sap.ui.model.Filter("Land1", sap.ui.model.FilterOperator.EQ, sReqMfGP));
			}

			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
				json: true
			});
			oModel1.read("/EntitySet", {
				filters: aFilter,
				success: fnSuccess,
				error: fnError
			});
			/*R&D---end*/

			/*End of change on 18-august-2020 */
			// var sParams = {};
			// var oObject = {};
			// oObject.Filter = aFilter;
			// oObject.Params = sParams;
			// oObject.successCallback = fnSuccess;
			// oObject.errorCallback = fnError;
			// oObject.sPath = sPath;
			// DataManagerARrecharge.getNonCoupaReqhelpValue(oObject);
		},
		onAddAttachmentofHeader: function (oEvent) {
			var uploadCollection = oEvent.getSource();
			var that = this;
			var collectionItemArr = uploadCollection.getItems();
			var files = oEvent.getParameter("files");
			var dupfile;

			for (var i = 0; i < collectionItemArr.length; i++) {
				if (collectionItemArr[i].getProperty("fileName") === files[0].name) {
					jQuery.sap.log.error("Duplicate file not allowed");
					sap.m.MessageBox.error("Duplicate filename not allowed", {
						title: "Error", // default
						onClose: null, // default
						styleClass: "", // default
						initialFocus: null, // default
						textDirection: sap.ui.core.TextDirection.Inherit // default
					});

					// UploadCollection.fireUploadTerminated(oEvent.getParameters());
					dupfile = true;
					break;

				}
			}
			if (files[0].size <= 0) {
				sap.m.MessageBox.error("Files with size 0kb not allowed to upload", {
					title: "Error", // default
					onClose: null, // default
					styleClass: "", // default
					initialFocus: null, // default
					textDirection: sap.ui.core.TextDirection.Inherit // default
				});
				oEvent.getSource().abortUpload(oEvent.getParameters());
				return;
			}

			if (dupfile === true) {
				oEvent.getSource().abortUpload(oEvent.getParameters());
				return;
			}

			var uploadUrl = "/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/AR_ATTSet";
			// var uploadUrl = "/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/AR_ATTSet(CompanyCode='" + sValue.CompanyCode + "',RrfNo='" + sValue.RrfNo +
			//  		"',RequestingMf='" + sMFGCC.RequestingMf + "',GlobalCc='" + sMFGCC.GlobalCc + "')";

			uploadCollection.setUploadUrl(uploadUrl);

			var mAttachments = this.getView().getModel();

			var token = "x-cs" + "rf-token";
			mAttachments.refreshSecurityToken();
			var T = mAttachments.getHeaders()[token];

			var csrfToken = new sap.m.UploadCollectionParameter({
				name: token,
				value: T
			});

			var reqType = new sap.m.UploadCollectionParameter({
				name: "X-Requested-With",
				value: "XMLHttpRequest"
			});

			uploadCollection.removeAllHeaderParameters();
			uploadCollection.addHeaderParameter(csrfToken);
			uploadCollection.addHeaderParameter(reqType);

		},
		onBeforeUploadStartsofHeaderAttachment: function (oEvent) {

			var AttachPanelID;
			/*End of change on 18-Feb-2020*/
			var sValue = this.getView().getModel("mModelSummary").getProperty("/HeaderData");
			var RequestingMf = "NA";
			AttachPanelID = "CON";
			var ProcessGrp = "NA";
			var GlobalCc = "NA";
			var MemberFirm = "";
			var CcShortDesc = "";
			var isSpecialChar = this.checkFileNameSepecialchar(oEvent.getParameter("fileName"));
			if (isSpecialChar) {
				var sMsg = this.getView().getModel("i18n").getProperty("specialcharFileNameMsg");
				MessageBox.error(sMsg);
				return;
			}

			var uPloadpar = oEvent.getParameter("fileName") + "|" + sValue.CompanyCode + "|" + sValue.RrfNo + "|" + RequestingMf + "|" +
				ProcessGrp + "|" + GlobalCc + "|" + AttachPanelID + "|" + MemberFirm + "|" +
				CcShortDesc; /*Added on 18-Feb-2020*/
			// Header Slug
			var oCustomerHeaderSlug = new sap.m.UploadCollectionParameter({
				name: "slug",
				value: uPloadpar
			});

			oEvent.getParameters().addHeaderParameter(oCustomerHeaderSlug);

		},
		checkFileNameSepecialchar: function (fileName) {
			var format = /[:%/?]+/;

			if (format.test(fileName)) {
				//	MessageBox.error("Special characters  % , / ,? can not be allowed in file name");
				return true;
			} else {
				return false;
			}
		},

		handleUploadCompleteofHeaderAttachment: function (oEvent) {
			this.fetchAttachmentListOfHeader();
		},

		handleTypeMissmatchofHeader: function (oEvent) {
			var aFileTypes = oEvent.getSource().getFileType();
			jQuery.each(aFileTypes, function (key, value) {
				aFileTypes[key] = "*." + value;
			});
			var sSupportedFileTypes = aFileTypes.join(", ");
			MessageToast.show("The file type *." + oEvent.getParameter("fileType") +
				" is not supported. Choose one of the following types: " +
				sSupportedFileTypes);
		},
		fetchAttachmentListOfHeader: function () {
			var that = this;
			var sValue = this.getView().getModel("mModelSummary").getProperty("/HeaderData");
			var RequestingMf = "NA";
			var GlobalCc = "NA";
			var ProcessGrp = "NA";
			var CON = "CON";
			var CcShortDesc = "";
			var MemberFirm = "";

			sap.ui.core.BusyIndicator.show(0);
			var fnSucces = jQuery.proxy(function (d) {
				var mModelSummary = that.getView().getModel("mModelSummary");
				sap.ui.core.BusyIndicator.hide(0);
				sap.ui.core.BusyIndicator.hide(0);

				var arrayCON = [];

				for (var i = 0; i < d.results.length; i++) {
					if (d.results[i].CopLoa === "CON") {
						arrayCON.push(d.results[i]);

					}
				}
				mModelSummary.setProperty("/FileHeaderSet", arrayCON);
				if (mModelSummary.getProperty("/FileHeaderSet").length < 1) {
					mModelSummary.setProperty("/oEditable/contractAttachEnable", false);
				} else {
					mModelSummary.setProperty("/oEditable/contractAttachEnable", true);
				}

				/*End of change on 18-Feb-2020*/
				this.getView().getModel("mModelSummary").refresh(true);

			}, this);

			var fnError = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
			}, this);

			var sPath1 = "/AR_ATTSet";

			/*	var sPath = "/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/AR_ATTSet(CompanyCode='" + sValue.CompanyCode + "',RrfNo='" + sValue.RrfNo +
					"',RequestingMf='" + sMFGCC.RequestingMf + "',GlobalCc='" + sMFGCC.GlobalCc + "',ProcessGrp='" + sMFGCC.ProcessGrp + "',CopLoa='" + "COP" + "')";*/

			var aFilterStr = [];
			var oFilterSerach;
			if (sValue.RrfNo) {
				oFilterSerach = new sap.ui.model.Filter("RrfNo", sap.ui.model.FilterOperator.EQ, sValue.RrfNo);
				aFilterStr.push(oFilterSerach);
				oFilterSerach = new sap.ui.model.Filter("CompanyCode", sap.ui.model.FilterOperator.EQ, sValue.CompanyCode);
				aFilterStr.push(oFilterSerach);
				oFilterSerach = new sap.ui.model.Filter("RequestingMf", sap.ui.model.FilterOperator.EQ, RequestingMf);
				aFilterStr.push(oFilterSerach);
				oFilterSerach = new sap.ui.model.Filter("GlobalCc", sap.ui.model.FilterOperator.EQ, GlobalCc);
				aFilterStr.push(oFilterSerach);
				oFilterSerach = new sap.ui.model.Filter("ProcessGrp", sap.ui.model.FilterOperator.EQ, ProcessGrp);
				aFilterStr.push(oFilterSerach);
				oFilterSerach = new sap.ui.model.Filter("CopLoa", sap.ui.model.FilterOperator.EQ, CON);
				aFilterStr.push(oFilterSerach);
				/*Start of change by Satabdi Das on 17-Feb-2021*/
				oFilterSerach = new sap.ui.model.Filter("MemberFirm", sap.ui.model.FilterOperator.EQ, MemberFirm);
				aFilterStr.push(oFilterSerach);
				oFilterSerach = new sap.ui.model.Filter("CcShortDesc", sap.ui.model.FilterOperator.EQ, CcShortDesc);
				aFilterStr.push(oFilterSerach);
				/*End of change by Satabdi Das on 17-Feb-2021*/

			}
			/*R&D---start*/
			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
				json: true
			});
			oModel1.read("/AR_ATTSet", {
				filters: aFilterStr,
				success: fnSucces,
				error: fnError
			});
			/*R&D---end*/

		},
		onPressEnName: function (oEvent) {
			var sEntity = oEvent.getSource().getBindingContext("mModelSummary").getObject();
			var sName = sEntity.Name1 + " " + sEntity.Name2;
			/*Start of change by developer Satabdi Das on 02-Nov-2020 for INC01227830*/
			// var sAddress = sEntity.Stras + "; " + sEntity.Regio + "; " + sEntity.Pstlz;
			var sAddress;
			if (sEntity.Street !== "") {
				sAddress = sEntity.Street + "; " + sEntity.StrSuppl1 + "; " + sEntity.StrSuppl2 + "; " + sEntity.StrSuppl3 + "; " + sEntity.Pstlz;
			} else {
				// sAddress = sEntity.StrSuppl1 + "; " + sEntity.StrSuppl2 + "; " + sEntity.StrSuppl3 + "; " + sEntity.Pstlz;
				sAddress = sEntity.Pstlz;
			}
			/*End of change by developer Satabdi Das on 02-Nov-2020 for INC01227830*/
			var sCustNo = sEntity.Kunnr;
			this.getView().getModel("mModelSummary").setProperty("/updateRowDataNC/EntityName", sName);
			this.getView().getModel("mModelSummary").setProperty("/updateRowDataNC/EntityAddress", sAddress);
			this.getView().getModel("mModelSummary").setProperty("/updateRowDataNC/SapCodeMf", sCustNo);
			this.getView().getModel("mModelSummary").setProperty("/updateRowData/EntityName", sName);
			this.getView().getModel("mModelSummary").setProperty("/updateRowData/EntityAddress", sAddress);
			this.getView().getModel("mModelSummary").setProperty("/updateRowData/SapCodeMf", sCustNo);
			this.getView().getModel("mModelSummary").setProperty("/updateRowData/VatId", sEntity.Stcd1);
			var fragId = this.getView().createId("entityHelp");
			var SearchId = sap.ui.core.Fragment.byId(fragId, "EnName");
			SearchId.setValue("");
			var aFilter = [];
			aFilter.push(new Filter("Name1", FilterOperator.Contains, ""));
			var frag = this.getView().createId("entityHelp");
			var table = sap.ui.core.Fragment.byId(frag, "entityName");
			var oBinding = table.getBinding("items");
			oBinding.filter(aFilter, "Application");
			if (this._oEntityHelp.isOpen()) {
				this._oEntityHelp.close();
			}
		},
		onSearchEnName: function (oEvent) {
			var aFilter = [];
			var sQuery = oEvent.getSource().getValue();
			sQuery = sQuery.trim();
			if (sQuery && sQuery.length > 0) {
				aFilter.push(new Filter("Name1", FilterOperator.Contains, sQuery));
			}
			var frag = this.getView().createId("entityHelp");
			var table = sap.ui.core.Fragment.byId(frag, "entityName");
			var oBinding = table.getBinding("items");
			oBinding.filter(aFilter, "Application");

		},
		onCloseEnName: function (oEvent) {
			var fragId = this.getView().createId("entityHelp");
			var SearchId = sap.ui.core.Fragment.byId(fragId, "EnName");
			SearchId.setValue("");
			var aFilter = [];
			aFilter.push(new Filter("Name1", FilterOperator.Contains, ""));
			var frag = this.getView().createId("entityHelp");
			var table = sap.ui.core.Fragment.byId(frag, "entityName");
			var oBinding = table.getBinding("items");
			oBinding.filter(aFilter, "Application");
			if (this._oEntityHelp.isOpen()) {
				this._oEntityHelp.close();
			}
		},
		/*End of change by Satabdi Das on 04-Dec-2019 */
		/*Start of change by Satabdi Das on 11-Dec-2019*/
		checkLineAmt: function (oEvent) {
			var strAmt = oEvent.getSource().getValue();
			var y = strAmt.split(".")[1];
			if (y !== undefined && y.length > 3) {
				oEvent.getSource().setValue("");
			} else if (isNaN(oEvent.getParameter("value")) === false && oEvent.getSource().getValue().length > 16) {

				strAmt = strAmt.substring(0, 16);
				oEvent.getSource().setValue("");
				oEvent.getSource().setValue(strAmt);
			}
		},
		/*End of change by Satabdi Das on 11-Dec-2019*/

		companyCodeDefaluValue: function (oEvent) {
			var mModelSummary = this.getModel("mModelSummary");

			// var fragmentId = this.getView().createId("searchCoordinator");
			sap.ui.core.BusyIndicator.show(0);

			var aFilter = [];
			//	var mArrayOut = [];

			//var oFilter;
			var sPath = "";
			var obj = {};
			sPath = "/RRF_DVSet"; // + Constant.CV_PV_LEAD_FIORI;

			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);

				mModelSummary.setProperty("/CurrKeySet", d.results[0].Currency);
				for (var i = 0; i < d.results.length; i++) {
					mModelSummary = this.getModel("mModelSummary");

					obj.CompanyCode = d.results[i].CompanyCode;
					obj.oDfaultCompanyCode = d.results[i].CompanyCode;
					obj.GpCreate = d.results[i].GpCreate;

					obj.Currency = d.results[i].Currency;
					mModelSummary.setProperty("/HeaderData", obj);

					if (obj.GpCreate === true) {

						var oRouter = UIComponent.getRouterFor(this);

						oRouter.navTo("RouteHomeView", {
							No: obj.CompanyCode
						});
					} else {
						var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
						MessageBox.error(
							"You are not authorized to create RRF.", {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}
						);
					}
				}

				mModelSummary.refresh(true);

			}, this);

			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();

				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"

				});
			}, this);

			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
				json: true
			});
			oModel1.read("/RRF_DVSet", {
				success: fnSuccess,
				error: fnError
			});
			/*R&D---end*/

			// var sParams = {};
			// var oObject = {};

			// oObject.Filter = aFilter;
			// oObject.Params = sParams;
			// oObject.successCallback = fnSuccess;
			// oObject.errorCallback = fnError;
			// oObject.sPath = sPath;
			// DataManagerARrecharge.getCoupaReqiNumberhelpValus(oObject);

		},
		getCurrencySet: function (oEvent) {

			var mModelSummary = this.getModel("mModelSummary");
			if (mModelSummary.getProperty("/HeaderData")) {
				var oCurrencyVal = mModelSummary.getProperty("/HeaderData").Currency;
			} else {
				oCurrencyVal = "";
			}

			var sSrchVal = oCurrencyVal;
			// var fragmentId = this.getView().createId("searchCoordinator");
			sap.ui.core.BusyIndicator.show(0);

			var aFilter = [];

			var sPath = "";

			sPath = "/CURRSet";

			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);

				mModelSummary.setSizeLimit(d.results.length);
				mModelSummary.setProperty("/CurrSet", d.results);
				/*Below code has been commented for defect 63860 by Satabdi Das on 19-March-2021*/
				// mModelSummary.setProperty("/CurrKeySet", "");
				mModelSummary.refresh(true);

			}, this);

			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();

				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"

				});
			}, this);
			var sParams = {};
			var oObject = {};

			// oObject.Filter = aFilter;
			// oObject.Params = sParams;
			// oObject.successCallback = fnSuccess;
			// oObject.errorCallback = fnError;
			// oObject.sPath = sPath;
			// DataManagerARrecharge.getCompanyCodeSearchHelpValues(oObject);
			/*R&D---start*/
			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
				json: true
			});
			oModel1.read("/CURRSet", {
				success: fnSuccess,
				error: fnError
			});
			/*R&D---end*/

		},

		onAttributePressCopNonCoupa: function (oEvent) {
			sap.ui.core.BusyIndicator.show(0);

			var ofileNameNC = oEvent.getSource().getParent("oParent").getProperty("fileName");
			var ofileName1 = ofileNameNC;
			var forwardslashFile = /[/]+/;
			if (forwardslashFile.test(ofileName1)) {
				ofileName1 = ofileName1.replace(/[/]/g, "|");
			}
			var qQuestionCharFile = /[?]+/;
			if (qQuestionCharFile.test(ofileName1)) {
				ofileName1 = ofileName1.replace(/[?]/g, "(");
			}
			var pPercentageFile = /[%]+/;
			if (pPercentageFile.test(ofileName1)) {
				ofileName1 = ofileName1.replace(/[%]/g, ")");
			}

			// var atttdownNC = oEvent.getParameter("id").split("--")[2].split("-")[0];
			var AttachPanelID = "LOA";

			var sValue = this.getView().getModel("mModelSummary").getProperty("/HeaderDataNC");
			var sMFGCC = this.getView().getModel("mModelSummary").getProperty("/updateRowDataNC");
			if ((sMFGCC.RequestingMf === "N/A") || (!sMFGCC.RequestingMf)) {
				sMFGCC.RequestingMf = "NA";
				sMFGCC.MemberFirm = ""; /*added for SCTASK1919812 on 17-Feb-2021*/
			}
			if ((sMFGCC.GlobalCc === "N/A") || (!sMFGCC.GlobalCc)) {
				sMFGCC.GlobalCc = "NA";
				sMFGCC.CcShortDesc = ""; /*added for SCTASK1895344 on 17-Feb-2021*/
				// sMFGCC.MemberFirm = sMFGCC.RequestingMf; /*added for SCTASK1919812 on 17-Feb-2021*/
			}

			/*Start of change for INC01584421 by developer Prashant kumar on 22-June-2021*/
			var sMf = sMFGCC.MemberFirm;
			var forwardslashMmfirm = /[/]+/;
			if (forwardslashMmfirm.test(sMf)) {
				sMf = sMf.replace(/[/]/g, "|");
			}
			var qQuestionCharMemFm = /[?]+/;
			if (qQuestionCharMemFm.test(sMf)) {
				sMf = sMf.replace(/[?]/g, "(");
			}
			var pPercentageMF = /[%]+/;
			if (pPercentageMF.test(sMf)) {
				sMf = sMf.replace(/[%]/g, ")");
			}

			if (!sMFGCC.ProcessGrp) {
				sMFGCC.ProcessGrp = "";
			}

			var sPrGrp = sMFGCC.ProcessGrp;
			/*Start of change for INC01584421 by developer Prashant kumar on 22-June-2021*/
			var forwardslash = /[/]+/;
			if (forwardslash.test(sPrGrp)) {
				sPrGrp = sPrGrp.replace(/[/]/g, "|");
			}
			var qQuestionChar = /[?]+/;
			if (qQuestionChar.test(sPrGrp)) {
				sPrGrp = sPrGrp.replace(/[?]/g, "(");
			}
			var pPercentage = /[%]+/;
			if (pPercentage.test(sPrGrp)) {
				sPrGrp = sPrGrp.replace(/[%]/g, ")");
			}

			var auxArray1 = new Array();
			var that = this;
			var pdfURL = null;
			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
				json: true
			});

			var oDataQuery2 = "/AR_ATTSet(CompanyCode='" + sValue.CompanyCode + "',RrfNo='" + sValue.RrfNoGf +
				"',RequestingMf='" + sMFGCC.RequestingMf + "',MemberFirm='" + sMf + "',GlobalCc='" + sMFGCC.GlobalCc +
				"',CcShortDesc='" + sMFGCC.CcShortDesc + "',Filename='" + ofileName1 + "',ProcessGrp='" + sPrGrp + "',CopLoa='" +
				AttachPanelID + "')/$value";

			oModel1.read(oDataQuery2, null,
				null,
				false,

				function (oData, oResponse) {
					sap.ui.core.BusyIndicator.hide();
					if (oResponse) {
						sap.ui.core.BusyIndicator.hide(0);
						auxArray1 = oData;
						pdfURL = oResponse.requestUri;
						// that.showFile(oResponse.body);
					} else {
						var e = oResponse.headers;

						if (e) {
							sap.ui.core.BusyIndicator.hide(0);
							MessageBox.error("Some error has occured.");

						}
					}
				},
				function readError(e) {
					sap.ui.core.BusyIndicator.hide(0);
					var r = JSON.parse(JSON.stringify(e));
					// sap.ui.core.BusyIndicator.hide();

					MessageToast.show('No document generated', {
						autoClose: true,
						width: "20rem"
					});

				}
			);
			if (pdfURL) {

				window.open(pdfURL, "_self");
				setTimeout(function () {
					sap.ui.core.BusyIndicator.hide(0);
				}, 10000);
			} else {

				setTimeout(function () {
					sap.ui.core.BusyIndicator.hide(0);
				}, 1000);
			}

			if (sMFGCC.RequestingMf === "NA") {
				sMFGCC.RequestingMf = "N/A";
			}
			if (sMFGCC.GlobalCc === "NA") {
				sMFGCC.GlobalCc = "N/A";
			}

		},

		/*Start of change for SCTASK1855604 - budget approvers by developer Satabdi Das on 19-May-2021*/
		onPressGetApprovers: function (oEvent) {
			var sId = oEvent.getSource().getId();
			var mModelSummary = this.getView().getModel("mModelSummary");
			var displayMode = mModelSummary.getProperty("/displayMode");
			var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
			var sErrorMsg = this.getView().getModel("i18n").getProperty("AmtCCMandtforBA");
			if (displayMode === false) {
				if (sId.indexOf("NP") >= 0) {
					var sUpdateValues = this.getView().getModel("mModelSummary").getProperty("/updateRowDataNC");
					var sAmt = sUpdateValues.Amount;
					var sKostl = sUpdateValues.GlobalCc;
					var sBukrs = mModelSummary.getProperty("/HeaderDataNC").CompanyCode;
					if (sAmt && sAmt !== "000000000000.000" && sAmt !== "0.00" && sKostl) {
						sap.ui.core.BusyIndicator.show(0);

						var fnSuccess = jQuery.proxy(function (d) {
							sap.ui.core.BusyIndicator.hide(0);

							if (d.BaName === "" && d.CooName !== "") {
								sUpdateValues.LoaContact = "";
								sUpdateValues.LoaEmail = "";
								sUpdateValues.AdlLoaContact = d.CooName;
								sUpdateValues.AdlLoaEmail = d.CooEmail;
								if (d.ErrorFlag === "X") {
									MessageBox.error(
										d.Message, {
											styleClass: bCompact ? "sapUiSizeCompact" : ""
										}
									);
								}
							} else if (d.BaName !== "" && d.CooName === "") {
								sUpdateValues.LoaContact = d.BaName;
								sUpdateValues.LoaEmail = d.BaEmail;
								sUpdateValues.AdlLoaContact = "";
								sUpdateValues.AdlLoaEmail = "";
								if (d.ErrorFlag === "X") {
									MessageBox.error(
										d.Message, {
											styleClass: bCompact ? "sapUiSizeCompact" : ""
										}
									);
								}
							} else if (d.BaName === "" && d.CooName === "" && d.ErrorFlag === "X") {
								sUpdateValues.LoaContact = "";
								sUpdateValues.LoaEmail = "";
								sUpdateValues.AdlLoaContact = "";
								sUpdateValues.AdlLoaEmail = "";
								MessageBox.error(
									d.Message, {
										styleClass: bCompact ? "sapUiSizeCompact" : ""
									}
								);

							} else {
								sUpdateValues.LoaContact = d.BaName;
								sUpdateValues.LoaEmail = d.BaEmail;
								sUpdateValues.AdlLoaContact = d.CooName;
								sUpdateValues.AdlLoaEmail = d.CooEmail;
							}
							mModelSummary.refresh();
						}, this);

						var fnError = jQuery.proxy(function (d) {
							var r = JSON.parse(JSON.stringify(d));
							sap.ui.core.BusyIndicator.hide();

							MessageToast.show(r.message, {
								autoClose: true,
								width: "20rem"

							});
						}, this);

						var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
							json: true
						});
						oModel1.callFunction('/fnBAName', {
							urlParameters: {
								Amount: sAmt,
								Bukrs: sBukrs,
								Kostl: sKostl
							},
							method: "GET",
							success: fnSuccess,
							error: fnError
						});

					} else {
						sUpdateValues.LoaContact = "";
						sUpdateValues.LoaEmail = "";
						sUpdateValues.AdlLoaContact = "";
						sUpdateValues.AdlLoaEmail = "";
						MessageBox.error(sErrorMsg, {
							styleClass: bCompact ? "sapUiSizeCompact" : ""
						});
						mModelSummary.refresh();
					}
				} else {
					var sUpdateValuesPO = mModelSummary.getProperty("/updateRowData");
					var sAmt = mModelSummary.getProperty("/TotalCSAmt");
					sAmt = sAmt.toString();
					var sKostl = sUpdateValuesPO.GlobalCc;
					var sBukrs = mModelSummary.getProperty("/HeaderData").CompanyCode;
					if (sAmt && sAmt !== "000000000000.000" && sAmt !== "0.00" && sKostl) {
						sap.ui.core.BusyIndicator.show(0);

						var fnSuccess = jQuery.proxy(function (d) {
							sap.ui.core.BusyIndicator.hide(0);

							if (d.BaName === "" && d.CooName !== "") {
								sUpdateValuesPO.AttenBrf = "";
								sUpdateValuesPO.AttenBrfEmail = "";
								sUpdateValuesPO.LoaContact = d.CooName;
								sUpdateValuesPO.LoaEmail = d.CooEmail;
								if (d.ErrorFlag === "X") {
									MessageBox.error(
										d.Message, {
											styleClass: bCompact ? "sapUiSizeCompact" : ""
										}
									);
								}
							} else if (d.BaName !== "" && d.CooName === "") {
								sUpdateValuesPO.AttenBrf = d.BaName;
								sUpdateValuesPO.AttenBrfEmail = d.BaEmail;
								sUpdateValuesPO.LoaContact = "";
								sUpdateValuesPO.LoaEmail = "";
								if (d.ErrorFlag === "X") {
									MessageBox.error(
										d.Message, {
											styleClass: bCompact ? "sapUiSizeCompact" : ""
										}
									);
								}
							} else if (d.BaName === "" && d.CooName === "" && d.ErrorFlag === "X") {
								sUpdateValuesPO.AttenBrf = "";
								sUpdateValuesPO.AttenBrfEmail = "";
								sUpdateValuesPO.LoaContact = "";
								sUpdateValuesPO.LoaEmail = "";
								MessageBox.error(
									d.Message, {
										styleClass: bCompact ? "sapUiSizeCompact" : ""
									}
								);

							} else {
								sUpdateValuesPO.AttenBrf = d.BaName;
								sUpdateValuesPO.AttenBrfEmail = d.BaEmail;
								sUpdateValuesPO.LoaContact = d.CooName;
								sUpdateValuesPO.LoaEmail = d.CooEmail;
							}
							mModelSummary.refresh();
						}, this);

						var fnError = jQuery.proxy(function (d) {
							var r = JSON.parse(JSON.stringify(d));
							sap.ui.core.BusyIndicator.hide();

							MessageToast.show(r.message, {
								autoClose: true,
								width: "20rem"

							});
						}, this);

						var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
							json: true
						});

						oModel1.callFunction('/fnBAName', {
							urlParameters: {
								Amount: sAmt,
								Bukrs: sBukrs,
								Kostl: sKostl
							},
							method: "GET",
							success: fnSuccess,
							error: fnError
						});

					} else {
						sUpdateValuesPO.AttenBrf = "";
						sUpdateValuesPO.AttenBrfEmail = "";
						sUpdateValuesPO.LoaContact = "";
						sUpdateValuesPO.LoaEmail = "";
						MessageBox.error(sErrorMsg, {
							styleClass: bCompact ? "sapUiSizeCompact" : ""
						});

						mModelSummary.refresh();
					}

				}

			}
		},
		/*End of change for SCTASK1855604 - budget approvers by developer Satabdi Das on 19-May-2021*/
		/*Start of change on 10-Feb-2020 for Initiate COP Button*/
		onInitiateCOP: function (oEvent) {
			var mModelSummary = this.getModel("mModelSummary");
			var displayMode = mModelSummary.getProperty("/displayMode");
			if (displayMode === false) {
				//for saving data before initiating cop and loa
				var sPoNum = mModelSummary.getData().HeaderData.RrfNo;
				var buttonClick = oEvent.getSource().getProperty("text");
				var oHeaderData = mModelSummary.getProperty("/HeaderData");
				var oHeaderdataNP = mModelSummary.getProperty("/HeaderDataNC");
				var sNonPoNum = mModelSummary.getData().HeaderDataNC.RrfNoGf;
				var oLineTbl = this.getView().byId("LineItemTab");
				var oTable = this.getView().byId("tableid");
				var arr = mModelSummary.getProperty("/TableItemSet"); /*Added on 20-Feb-2020*/
				var oTableDataNC = mModelSummary.getProperty("/TableItemSetNC");
				var bCOPButton = mModelSummary.getProperty("/oEditable/enableCOP"); /*Added on 20-Feb-2020*/
				var bLOAButton = mModelSummary.getProperty("/oEditable/enableLOA"); /*Added on 20-Feb-2020*/
				var bLOAButtonNC = mModelSummary.getProperty("/oEditableNC/enableLOA"); /*Added on 20-march-2020*/
				var bCopButtonNC = mModelSummary.getProperty("/oEditableNC/enableCOP"); /*Added on 20-march-2020*/
				var sAcontext;
				var ActionCOP = this.getView().getModel("i18n").getProperty("ActionCOP");
				var ActionLOA = this.getView().getModel("i18n").getProperty("ActionLOA"); /*Added on 20-Feb-2020*/
				var sAcontextPO;
				var TableData = [];
				var _answre = [];
				var objectOne = {};
				var that = this;
				var iPrevRow;
				var iPrevRowPO;
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				if (sNonPoNum && oLineTbl) {
					this.saveDataCopLoaInitiate();

					if ((bCopButtonNC === true) && (buttonClick === "Initiate COP")) {
						sAcontext = oLineTbl.getSelectedContextPaths();

						for (var k = 0; k < sAcontext.length; k++) {
							var oSelectedLine = mModelSummary.getProperty(sAcontext[k]);
							var _LineStatus = oSelectedLine.RrfStatus;
							var cancelNoticeDate = oHeaderdataNP.CanNoticeDate;
							if (!cancelNoticeDate) {
								var cancelMsg = this.getModel("i18n").getProperty("cancellationNoticeError");
								MessageBox.error(cancelMsg);
								return true;
							}

							if (_LineStatus === "COPDeclined") {
								MessageBox.warning("Data has been saved. Do you want to proceed?", {
									actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
									emphasizedAction: MessageBox.Action.OK,
									onClose: function (sAction) {
										if (sAction === "OK") {
											var oPayLoad = {
												RrfNo: sNonPoNum,
												Action: ActionCOP,
												Currency: mModelSummary.getProperty("/HeaderDataNC").Currency,
												RrfType: mModelSummary.getProperty("/HeaderDataNC").RrfType,
												CompanyCode: mModelSummary.getProperty("/HeaderDataNC").CompanyCode,
												Cop_LineSet: [],
												COP_AnswSet: []
											};
											for (var i = 0; i < sAcontext.length; i++) {
												var objRow = mModelSummary.getProperty(sAcontext[i]);
												if (objRow.RequestingMf && objRow.RequestingMf !== "N/A") {
													var sObj = {};
													sObj.RequestingMf = objRow.RequestingMf;
													sObj.GlobalCc = objRow.GlobalCc;
													sObj.RrfNo = sNonPoNum;
													sObj.ProcessGrp = objRow.ProcessGrp;
													sObj.MemberFirm = objRow.MemberFirm;
													sObj.CcShortDesc = "";
													sObj.ContactPCop = objRow.ContactPCop;
													sObj.CopEmailId = objRow.CopEmailId;
													sObj.AddlBillInfo = objRow.AddlBillInfo;
													sObj.DetailsDescriptionOfService = oHeaderdataNP.GfDesc;
													sObj.TotalCommAmount = objRow.Amount; /*Added for defect 63405*/
													TableData.push(sObj);
													/*Start of change by Satabdi Das on 12-Apr-2021 for Cop answer set*/
													var arrAnsware = [];
													arrAnsware = mModelSummary.getProperty("/nPQuestionSetSubmit");
													if (arrAnsware && arrAnsware.length !== 0) {
														for (var t = 0; t < arrAnsware.length; t++) {
															var objAns = {};
															objAns.GlobalCc = oHeaderdataNP.GlobalCc;
															objAns.MemberFirm = arrAnsware[t].MemberFirm;
															objAns.Question = arrAnsware[t].Question;
															objAns.RrfNo = sNonPoNum;
															objAns.RequestingMf = arrAnsware[t].RequestingMf;
															objAns.Answer = arrAnsware[t].Answer;
															objAns.InternalExternal = arrAnsware[t].InternalExternal;
															objAns.AnswerDesc = arrAnsware[t].AnswerDesc;
															objAns.ProcessGrp = arrAnsware[t].ProcessGrp;
															objAns.CompanyCode = oHeaderdataNP.CompanyCode;
															_answre.push(objAns);

														}
													}

													/*End of change by Satabdi Das on 12-Apr-2021 for Cop answer Set*/
												} else if (objRow.GlobalCc && objRow.GlobalCc !== "N/A") {
													var sObj = {};
													sObj.RequestingMf = objRow.RequestingMf;
													sObj.GlobalCc = objRow.GlobalCc;
													sObj.RrfNo = sNonPoNum;
													sObj.ProcessGrp = objRow.ProcessGrp;
													sObj.MemberFirm = objRow.MemberFirm;
													sObj.CcShortDesc = "";
													sObj.ContactPCop = objRow.ContactPCop;
													sObj.CopEmailId = objRow.CopEmailId;
													sObj.LoaContact = objRow.LoaContact;
													sObj.LoaEmail = objRow.LoaEmail;
													sObj.AdlLoaContact = objRow.AdlLoaContact;
													sObj.AdlLoaEmail = objRow.AdlLoaEmail;
													sObj.TotalCommAmount = objRow.Amount; /*Added for defect 63405*/
													sObj.DetailsDescriptionOfService = oHeaderdataNP.GfDesc;
													TableData.push(sObj);
												}

											}
											var fnSuccess = jQuery.proxy(function (d) {
												sap.ui.core.BusyIndicator.hide(0);
												if (d.Flag) {
													MessageBox.error(
														d.Message, {
															styleClass: bCompact ? "sapUiSizeCompact" : ""
														}
													);
													oLineTbl.removeSelections(true);
													return;
												} else {
													MessageBox.show(
														d.Message, {
															icon: MessageBox.Icon.SUCCESS,
															title: "Success",
															actions: [MessageBox.Action.OK],
															onClose: function (oAction) {
																that.editNonCoupa();

															}
														}
													);
													oLineTbl.removeSelections(true);
												}
											}, this);
											var fnError = jQuery.proxy(function (d) {
												var r = JSON.parse(JSON.stringify(d));
												sap.ui.core.BusyIndicator.hide();
												MessageToast.show(r.message, {
													autoClose: true,
													width: "20rem"
												});
											}, this);
											objectOne.successCallback = fnSuccess;
											objectOne.errorCallback = fnError;
											oPayLoad.Cop_LineSet = TableData;
											oPayLoad.COP_AnswSet = _answre;
											sap.ui.core.BusyIndicator.show(0);
											DataManagerARrecharge.CreateInitiateCOP(oPayLoad, objectOne);
										} else {
											oLineTbl.removeSelections(true);
										}
									}
								});

								return;

							}

						}

						if (sAcontext.length !== 0 && sNonPoNum !== undefined && sAcontext !== iPrevRow) {
							var oPayLoad = {
								RrfNo: sNonPoNum,
								Action: ActionCOP,
								Currency: oHeaderdataNP.Currency,
								RrfType: oHeaderdataNP.RrfType,
								/*Added by Satabdi Das on 26-Nov-2020*/
								CompanyCode: oHeaderdataNP.CompanyCode,
								Cop_LineSet: [],
								COP_AnswSet: []
							};
							for (var i = 0; i < sAcontext.length; i++) {
								var objRow = mModelSummary.getProperty(sAcontext[i]);
								if (objRow.RequestingMf && objRow.RequestingMf !== "N/A") {
									if (oHeaderdataNP.Kostl) {
										if (objRow.ContactPCop === undefined || objRow.CopEmailId === undefined || objRow.ContactPCop.length === 0 || objRow.CopEmailId
											.length === 0) {
											var ReqContry = objRow.RequestingMf;
											var processGroup = objRow.ProcessGrp;
											var COPBlankWarning = this.getView().getModel("i18n").getProperty("COPBlankWarning");
											MessageBox.error(
												(COPBlankWarning + ReqContry + " " + "and Processing Group: " + processGroup), {
													styleClass: bCompact ? "sapUiSizeCompact" : ""
												}
											);
											oLineTbl.removeSelections(true);
											return;
										} else if (!objRow.Amount || objRow.Amount === "000000000000.000" || objRow.Amount === "0.00") {
											/*Change add for INC01503380 on 21-Apr-2021*/
											var copTotalAmount = this.getView().getModel("i18n").getProperty("initateCopMessage");

											MessageBox.error(
												(copTotalAmount), {
													styleClass: bCompact ? "sapUiSizeCompact" : ""
												}
											);
											oLineTbl.removeSelections(true);
											return;
										} else {
											var sObj = {};
											sObj.RequestingMf = objRow.RequestingMf;
											sObj.GlobalCc = objRow.GlobalCc;
											sObj.MemberFirm = objRow.MemberFirm;
											sObj.CcShortDesc = "";
											sObj.RrfNo = sNonPoNum;
											sObj.ProcessGrp = objRow.ProcessGrp;
											sObj.ContactPCop = objRow.ContactPCop;
											sObj.CopEmailId = objRow.CopEmailId;
											sObj.AddlBillInfo = objRow.AddlBillInfo;
											sObj.DetailsDescriptionOfService = oHeaderdataNP.GfDesc;
											sObj.TotalCommAmount = objRow.Amount; /*Added for defect 63405*/
											TableData.push(sObj);
											/*Start of change by Satabdi Das on 12-Apr-2021 for Cop answer set*/
											var arrAnsware = [];
											arrAnsware = mModelSummary.getProperty("/nPQuestionSetSubmit");
											if (arrAnsware && arrAnsware.length !== 0) {
												for (var t = 0; t < arrAnsware.length; t++) {
													var objAns = {};
													objAns.GlobalCc = oHeaderdataNP.GlobalCc;
													objAns.MemberFirm = arrAnsware[t].MemberFirm;
													objAns.Question = arrAnsware[t].Question;
													objAns.RrfNo = sNonPoNum;
													objAns.RequestingMf = arrAnsware[t].RequestingMf;
													objAns.Answer = arrAnsware[t].Answer;
													objAns.InternalExternal = arrAnsware[t].InternalExternal;
													objAns.AnswerDesc = arrAnsware[t].AnswerDesc;
													objAns.ProcessGrp = arrAnsware[t].ProcessGrp;
													objAns.CompanyCode = oHeaderdataNP.CompanyCode;
													_answre.push(objAns);

												}
											}

											/*End of change by Satabdi Das on 12-Apr-2021 for Cop answer Set*/
										}
									} else {
										var CostCenterMad = this.getView().getModel("i18n").getProperty("CostCenterMad");
										MessageBox.error(
											(CostCenterMad), {
												styleClass: bCompact ? "sapUiSizeCompact" : ""
											}
										);
										oLineTbl.removeSelections(true);
										return;
									}
								} else if (objRow.GlobalCc && objRow.GlobalCc !== "N/A") {
									if (oHeaderdataNP.Kostl) {
										if (objRow.LoaContact === undefined || objRow.LoaEmail === undefined || objRow.AdlLoaContact === undefined || objRow.AdlLoaEmail ===
											undefined || objRow.ContactPCop === undefined || objRow.CopEmailId === undefined || objRow.LoaContact.length === 0 ||
											objRow
											.LoaEmail
											.length === 0 || objRow.AdlLoaContact.length === 0 || objRow.AdlLoaEmail
											.length === 0 || objRow.ContactPCop.length === 0 || objRow.CopEmailId.length === 0) {
											var GlobalCc = objRow.GlobalCc;

											var COPBlankWarningGFNP = this.getView().getModel("i18n").getProperty("COPBlankWarningGFNP");
											MessageBox.error(
												(COPBlankWarningGFNP + GlobalCc), {
													styleClass: bCompact ? "sapUiSizeCompact" : ""
												}
											);
											oLineTbl.removeSelections(true);
											return;
										} else if (!objRow.Amount || objRow.Amount === "000000000000.000" || objRow.Amount === "0.00") {
											/*Change added for INC01503380 on 21-Apr-2021*/
											var copTotalAmount = this.getView().getModel("i18n").getProperty("initateCopMessage");
											MessageBox.error(
												(copTotalAmount), {
													styleClass: bCompact ? "sapUiSizeCompact" : ""
												}
											);
											oLineTbl.removeSelections(true);
											return;
										} else {
											var sObj = {};
											sObj.RequestingMf = objRow.RequestingMf;
											sObj.GlobalCc = objRow.GlobalCc;
											sObj.RrfNo = sNonPoNum;
											sObj.ProcessGrp = objRow.ProcessGrp;
											sObj.MemberFirm = objRow.MemberFirm;
											sObj.CcShortDesc = "";
											sObj.ContactPCop = objRow.ContactPCop;
											sObj.CopEmailId = objRow.CopEmailId;
											sObj.LoaContact = objRow.LoaContact;
											sObj.LoaEmail = objRow.LoaEmail;
											sObj.AdlLoaContact = objRow.AdlLoaContact;
											sObj.AdlLoaEmail = objRow.AdlLoaEmail;
											sObj.TotalCommAmount = objRow.Amount; /*Added for defect 63405*/
											sObj.DetailsDescriptionOfService = oHeaderdataNP.GfDesc;
											TableData.push(sObj);
										}
									} else {
										var CostCenterMad = this.getView().getModel("i18n").getProperty("CostCenterMad");
										MessageBox.error(
											(CostCenterMad), {
												styleClass: bCompact ? "sapUiSizeCompact" : ""
											}
										);
										oLineTbl.removeSelections(true);
										return;
									}

								}
							}
							var fnSuccess = jQuery.proxy(function (d) {
								sap.ui.core.BusyIndicator.hide(0);
								if (d.Flag) {
									MessageBox.error(
										d.Message, {
											styleClass: bCompact ? "sapUiSizeCompact" : ""
										}
									);
									oLineTbl.removeSelections(true);
									return;
								} else {
									MessageBox.show(
										d.Message, {
											icon: MessageBox.Icon.SUCCESS,
											title: "Success",
											actions: [MessageBox.Action.OK],
											onClose: function (oAction) {
												that.editNonCoupa();
												// var oRouter = UIComponent.getRouterFor(that);
												// oRouter.navTo("TargetSelectionView");
											}
										}
									);
								}
							}, this);
							var fnError = jQuery.proxy(function (d) {
								var r = JSON.parse(JSON.stringify(d));
								sap.ui.core.BusyIndicator.hide();
								MessageToast.show(r.message, {
									autoClose: true,
									width: "20rem"
								});
							}, this);
							objectOne.successCallback = fnSuccess;
							objectOne.errorCallback = fnError;
							oPayLoad.Cop_LineSet = TableData;
							oPayLoad.COP_AnswSet = _answre;
							sap.ui.core.BusyIndicator.show(0);
							DataManagerARrecharge.CreateInitiateCOP(oPayLoad, objectOne);
						} else if (sAcontext.length === 0 || sAcontext === iPrevRow) {
							MessageBox.error(
								this.getView().getModel("i18n").getProperty("RowWarning"), {
									styleClass: bCompact ? "sapUiSizeCompact" : ""
								}
							);
							oLineTbl.removeSelections(true);
							return;
						}
						iPrevRow = sAcontext;
						oLineTbl.removeSelections(true);
					} else if ((buttonClick === "Initiate LOA") && (bLOAButtonNC === true)) {
						if (oTableDataNC) {
							var oPayLoad = {
								RrfNo: sNonPoNum,
								Action: ActionLOA,
								Currency: oHeaderdataNP.Currency,
								CompanyCode: oHeaderdataNP.CompanyCode,
								RrfType: oHeaderdataNP.RrfType,
								/*Added by Satabdi Das on 26-Nov-2020*/
								Cop_LineSet: [],
								COP_AnswSet: []
							};

							for (var i = 0; i < oTableDataNC.results.length; i++) {
								if ((oTableDataNC.results[i].CopInitiate === "X") && (oTableDataNC.results[i].RrfStatus === "COPConfirmed")) {
									var objRow = oTableDataNC.results[i];

									if (objRow.RequestingMf && objRow.RequestingMf !== "N/A") {
										// if (!objRow.SapCodeMf) {
										// 	var entityLoa = this.getView().getModel("i18n").getProperty("entityLoa");
										// 	MessageBox.error(
										// 		this.getView().getModel("i18n").getProperty(entityLoa + " " + objRow.RequestingMf + " " + "and processing group " +
										// 			objRow.ProcessGrp), {
										// 			styleClass: bCompact ? "sapUiSizeCompact" : ""
										// 		}
										// 	);

										// 	return;
										// }

										if (objRow.ContactPCop === undefined || objRow.CopEmailId === undefined || objRow.ContactPCop.length === 0 || objRow.CopEmailId
											.length === 0) {
											MessageBox.error(
												this.getView().getModel("i18n").getProperty("LOABlankWarning"), {
													styleClass: bCompact ? "sapUiSizeCompact" : ""
												}
											);

											return;
										} else {
											var sObj = {};
											sObj.RequestingMf = objRow.RequestingMf;
											sObj.GlobalCc = objRow.GlobalCc;
											sObj.RrfNo = sNonPoNum;
											sObj.ProcessGrp = objRow.ProcessGrp;
											sObj.ContactPCop = objRow.ContactPCop;
											sObj.CopEmailId = objRow.CopEmailId;
											sObj.MemberFirm = objRow.MemberFirm;
											sObj.CcShortDesc = "";
											// sObj.DetailsDescriptionOfService = oHeaderdataNP.GfDesc;
											sObj.LoaContact = objRow.LoaContact;
											sObj.LoaEmail = objRow.LoaEmail;
											sObj.AdlLoaContact = objRow.AdlLoaContact;
											sObj.AdlLoaEmail = objRow.AdlLoaEmail;
											sObj.SapCodeMf = objRow.SapCodeMf;
											sObj.TotalCommAmount = objRow.Amount; /*Added for defect 63405*/
											// sObj.LoaDesc = objRow.LoaDesc;
											TableData.push(sObj);
											/*Start of change by Satabdi Das on 12-Apr-2021 for Cop answer set*/
											var arrAnsware = [];
											arrAnsware = mModelSummary.getProperty("/nPQuestionSetSubmit");
											if (arrAnsware && arrAnsware.length !== 0) {
												for (var t = 0; t < arrAnsware.length; t++) {
													var objAns = {};
													objAns.GlobalCc = oHeaderdataNP.GlobalCc;
													objAns.MemberFirm = arrAnsware[t].MemberFirm;
													objAns.Question = arrAnsware[t].Question;
													objAns.RrfNo = sNonPoNum;
													objAns.RequestingMf = arrAnsware[t].RequestingMf;
													objAns.Answer = arrAnsware[t].Answer;
													objAns.InternalExternal = arrAnsware[t].InternalExternal;
													objAns.AnswerDesc = arrAnsware[t].AnswerDesc;
													objAns.ProcessGrp = arrAnsware[t].ProcessGrp;
													objAns.CompanyCode = oHeaderdataNP.CompanyCode;
													_answre.push(objAns);

												}
											}

											/*End of change by Satabdi Das on 12-Apr-2021 for Cop answer Set*/

										}
									} else if (objRow.GlobalCc && objRow.GlobalCc !== "N/A") {
										if (objRow.ContactPCop === undefined || objRow.CopEmailId === undefined) {
											MessageBox.error(
												this.getView().getModel("i18n").getProperty("LOABlankWarning"), {
													styleClass: bCompact ? "sapUiSizeCompact" : ""
												}
											);

											return;
										} else {
											var sObj = {};
											sObj.RequestingMf = objRow.RequestingMf;
											sObj.GlobalCc = objRow.GlobalCc;
											sObj.RrfNo = sNonPoNum;
											sObj.ProcessGrp = objRow.ProcessGrp;
											sObj.MemberFirm = objRow.MemberFirm;
											sObj.CcShortDesc = "";
											sObj.ContactPCop = objRow.ContactPCop;
											sObj.CopEmailId = objRow.CopEmailId;
											// sObj.DetailsDescriptionOfService = oHeaderdataNP.GfDesc;
											sObj.LoaContact = objRow.LoaContact;
											sObj.LoaEmail = objRow.LoaEmail;
											sObj.AdlLoaContact = objRow.AdlLoaContact;
											sObj.AdlLoaEmail = objRow.AdlLoaEmail;
											sObj.TotalCommAmount = objRow.Amount; /*Added for defect 63405*/
											// sObj.LoaDesc = objRow.LoaDesc;
											TableData.push(sObj);
										}
									}
								}
							}
							var fnSuccess1 = jQuery.proxy(function (d) {
								sap.ui.core.BusyIndicator.hide(0);
								if (d.Flag) {
									MessageBox.error(
										d.Message, {
											styleClass: bCompact ? "sapUiSizeCompact" : ""
										}
									);
									oTable.removeSelections(true);
									return;
								} else {
									MessageBox.show(
										d.Message, {
											icon: MessageBox.Icon.SUCCESS,
											title: "Success",
											actions: [MessageBox.Action.OK],
											onClose: function (oAction) {
												that.editNonCoupa();
												// var oRouter = UIComponent.getRouterFor(that);
												// oRouter.navTo("TargetSelectionView");
											}
										}
									);
								}
							}, this);
							var fnError1 = jQuery.proxy(function (d) {
								var r = JSON.parse(JSON.stringify(d));
								sap.ui.core.BusyIndicator.hide();
								MessageToast.show(r.message, {
									autoClose: true,
									width: "20rem"
								});
							}, this);
							objectOne.successCallback = fnSuccess1;
							objectOne.errorCallback = fnError1;
							oPayLoad.Cop_LineSet = TableData;
							oPayLoad.COP_AnswSet = _answre;
							sap.ui.core.BusyIndicator.show(0);
							DataManagerARrecharge.CreateInitiateCOP(oPayLoad, objectOne);

						}

					}
				} else if (sPoNum && oTable) {

					this.saveAfterCopLoaInitate();
					if ((bCOPButton === true) && (buttonClick === "Initiate COP")) {
						sAcontextPO = oTable.getSelectedContextPaths();
						//code for cop decline 
						for (var k = 0; k < sAcontextPO.length; k++) {
							var oSelectedLinePO = mModelSummary.getProperty(sAcontextPO[k]);
							var _LineStatusPO = oSelectedLinePO.RrfStatus;

							// if (!mModelSummary.getProperty("/copDeclineSetPO")) {
							// 	var _oDeclineValidPO = {};
							// 	_oDeclineValidPO.ContactPersonCoPEmail = oSelectedLinePO.CopEmailId;
							// 	mModelSummary.setProperty("/copDeclineSetPO", _oDeclineValidPO);

							// }
							// var oSavedDataForCOPLinePO = mModelSummary.getProperty("/copDeclineSetPO");

							if (_LineStatusPO === "COPDeclined") {
								MessageBox.warning("Data has been saved. Do you want to proceed?", {
									actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
									emphasizedAction: MessageBox.Action.OK,
									onClose: function (sAction) {
										if (sAction === "OK") {
											for (var i = 0; i < sAcontextPO.length; i++) {
												var objRow = mModelSummary.getProperty(sAcontextPO[i]);
												if (objRow.TotalCommAmount && objRow.TotalCommAmount !== "0.00") {
													var oPayLoad = {
														RrfNo: sPoNum,
														Action: ActionCOP,
														VendorName: oHeaderData.VendorName,
														Vendor: oHeaderData.Vendor,
														CompanyCode: oHeaderData.CompanyCode,
														Currency: oHeaderData.Currency,
														RrfType: oHeaderData.RrfType,
														//TotalCommAmount:objRow.TotalCommAmount,
														/*Added by Satabdi Das on 26-Nov-2020*/
														SupplierAgreementDate: oHeaderData.SupplierAgreementDate,
														/*Added on 02-March-2020*/
														Cop_LineSet: [],
														COP_AnswSet: []
													};
													if (objRow.RequestingMf && objRow.RequestingMf !== "N/A") {

														var sObj = {};
														sObj.RequestingMf = objRow.RequestingMf;
														sObj.GlobalCc = objRow.GlobalCc;
														sObj.RrfNo = sPoNum;
														sObj.ProcessGrp = objRow.ProcessGrp;
														sObj.MemberFirm = objRow.MemberFirm;
														sObj.CcShortDesc = "";
														sObj.AddlBillInfo = objRow.AddlBillInfo;
														sObj.ContactPCop = objRow.ContactPCop;
														sObj.CopEmailId = objRow.CopEmailId;
														sObj.TotalCommAmount = objRow.TotalCommAmount;
														sObj.DetailsDescriptionOfService = oHeaderData.RrfDesc;
														TableData.push(sObj);
														/*Start of change by Satabdi Das on 12-Apr-2021 for Cop answer set*/
														var arrAnsware = [];
														arrAnsware = mModelSummary.getProperty("/questionSetSubmit");
														if (arrAnsware && arrAnsware.length !== 0) {
															for (var t = 0; t < arrAnsware.length; t++) {
																var objAns = {};
																objAns.GlobalCc = oHeaderData.GlobalCc;
																objAns.MemberFirm = arrAnsware[t].MemberFirm;
																objAns.Question = arrAnsware[t].Question;
																objAns.RequestingMf = arrAnsware[t].RequestingMf;
																objAns.Answer = arrAnsware[t].Answer;
																objAns.InternalExternal = arrAnsware[t].InternalExternal;
																objAns.RrfNo = sPoNum;
																objAns.AnswerDesc = arrAnsware[t].AnswerDesc;
																objAns.ProcessGrp = arrAnsware[t].ProcessGrp;
																objAns.CompanyCode = oHeaderData.CompanyCode;
																_answre.push(objAns);

															}
														}

														/*End of change by Satabdi Das on 12-Apr-2021 for Cop answer Set*/

													} else if (objRow.GlobalCc && objRow.GlobalCc !== "N/A") {
														var sObj = {};
														sObj.RequestingMf = objRow.RequestingMf;
														sObj.GlobalCc = objRow.GlobalCc;
														sObj.MemberFirm = objRow.MemberFirm;
														sObj.CcShortDesc = "";
														sObj.RrfNo = sPoNum;
														sObj.ProcessGrp = objRow.ProcessGrp;
														sObj.TotalCommAmount = objRow.TotalCommAmount;
														sObj.ContactPCop = objRow.ContactPCop;
														sObj.CopEmailId = objRow.CopEmailId;
														sObj.DetailsDescriptionOfService = oHeaderData.RrfDesc;

														TableData.push(sObj);

													}

												} else {

													var copTotalCommerc = that.getView().getModel("i18n").getProperty("initateCopMessage");
													MessageBox.error(
														(copTotalCommerc), {
															styleClass: bCompact ? "sapUiSizeCompact" : ""
														}
													);
													oTable.removeSelections(true);
													return;
												}

											}
										} else {
											oTable.removeSelections(true);
										}
										var fnSuccess1 = jQuery.proxy(function (d) {

											sap.ui.core.BusyIndicator.hide(0);

											if (d.Flag) {
												MessageBox.error(
													d.Message, {
														styleClass: bCompact ? "sapUiSizeCompact" : ""
													}
												);
												oTable.removeSelections(true);
												return;
											} else {
												mModelSummary.setProperty("/oCopLoaSucesFlag", true);
												MessageBox.show(
													d.Message, {
														icon: MessageBox.Icon.SUCCESS,
														title: "Success",
														actions: [MessageBox.Action.OK],
														onClose: function (oAction) {
															that.handlePreBtnEdit();

														}
													}
												);
												oTable.removeSelections(true);
											}

										}, this);
										var fnError1 = jQuery.proxy(function (d) {
											var r = JSON.parse(JSON.stringify(d));
											sap.ui.core.BusyIndicator.hide();
											MessageToast.show(r.message, {
												autoClose: true,
												width: "20rem"
											});
										}, this);
										objectOne.successCallback = fnSuccess1;
										objectOne.errorCallback = fnError1;
										oPayLoad.Cop_LineSet = TableData;
										oPayLoad.COP_AnswSet = _answre;
										sap.ui.core.BusyIndicator.show(0);
										DataManagerARrecharge.CreateInitiateCOP(oPayLoad, objectOne);
									}

								});
								return;

							}

						}
						//

						if (sAcontextPO.length !== 0 && sPoNum !== undefined && sAcontextPO !== iPrevRowPO) {
							var oPayLoad = {
								RrfNo: sPoNum,
								Action: ActionCOP,
								VendorName: oHeaderData.VendorName,
								Vendor: oHeaderData.Vendor,
								CompanyCode: oHeaderData.CompanyCode,
								Currency: oHeaderData.Currency,
								RrfType: oHeaderData.RrfType,
								/*Added by Satabdi Das on 26-Nov-2020*/
								SupplierAgreementDate: oHeaderData.SupplierAgreementDate,
								/*Added on 02-March-2020*/
								Cop_LineSet: [],
								COP_AnswSet: []
							};
							for (var i = 0; i < sAcontextPO.length; i++) {
								var objRow = mModelSummary.getProperty(sAcontextPO[i]);
								if (objRow.RequestingMf && objRow.RequestingMf !== "N/A") {
									if (oHeaderData.Kostl) {
										if ((oHeaderData.VendorName && oHeaderData.RrfDesc)) {
											if (objRow.ContactPCop === undefined || objRow.CopEmailId === undefined || objRow.ContactPCop.length === 0 || objRow.CopEmailId
												.length === 0) {
												var ReqContry = objRow.RequestingMf;
												var processGroup = objRow.ProcessGrp;
												var COPBlankWarning = this.getView().getModel("i18n").getProperty("COPBlankWarning");
												MessageBox.error(
													(COPBlankWarning + ReqContry + " " + "and Processing Group: " + processGroup), {
														styleClass: bCompact ? "sapUiSizeCompact" : ""
													}
												);
												oTable.removeSelections(true);
												return;
											} else if (!objRow.AddlBillInfo && !objRow.LongText) {
												var ReqContry = objRow.RequestingMf;
												var processGroup = objRow.ProcessGrp;
												var AddlBillInfo = "Description to be included in invoice/Long Text field is missing for member firm ";
												MessageBox.error(
													(AddlBillInfo + ReqContry + " " + "and Processing Group: " + processGroup + " in member firm section"), {
														styleClass: bCompact ? "sapUiSizeCompact" : ""
													}
												);
												oTable.removeSelections(true);
												return;
											} else if (!objRow.TotalCommAmount || objRow.TotalCommAmount === "0.00" || objRow.TotalCommAmount === "000000000000.000") {
												/*Change add for INC01503380 on 21-Apr-2021*/
												var copTotalCommerc = this.getView().getModel("i18n").getProperty("initateCopMessage");
												MessageBox.error(
													(copTotalCommerc), {
														styleClass: bCompact ? "sapUiSizeCompact" : ""
													}
												);
												oTable.removeSelections(true);
												return;
											} else {
												var sObj = {};
												sObj.RequestingMf = objRow.RequestingMf;
												sObj.GlobalCc = objRow.GlobalCc;
												sObj.RrfNo = sPoNum;
												sObj.ProcessGrp = objRow.ProcessGrp;
												sObj.MemberFirm = objRow.MemberFirm;
												sObj.CcShortDesc = "";
												sObj.AddlBillInfo = objRow.AddlBillInfo;
												sObj.ContactPCop = objRow.ContactPCop;
												sObj.CopEmailId = objRow.CopEmailId;
												sObj.TotalCommAmount = objRow.TotalCommAmount;
												sObj.DetailsDescriptionOfService = oHeaderData.RrfDesc;

												TableData.push(sObj);
												/*Start of change by Satabdi Das on 12-Apr-2021 for Cop answer set*/
												var arrAnsware = [];
												arrAnsware = mModelSummary.getProperty("/questionSetSubmit");
												if (arrAnsware && arrAnsware.length !== 0) {
													for (var t = 0; t < arrAnsware.length; t++) {
														var objAns = {};
														objAns.GlobalCc = oHeaderData.GlobalCc;
														objAns.MemberFirm = arrAnsware[t].MemberFirm;
														objAns.Question = arrAnsware[t].Question;
														objAns.RequestingMf = arrAnsware[t].RequestingMf;
														objAns.Answer = arrAnsware[t].Answer;
														objAns.InternalExternal = arrAnsware[t].InternalExternal;
														objAns.RrfNo = sPoNum;
														objAns.AnswerDesc = arrAnsware[t].AnswerDesc;
														objAns.ProcessGrp = arrAnsware[t].ProcessGrp;
														objAns.CompanyCode = oHeaderData.CompanyCode;
														_answre.push(objAns);

													}
												}

												/*End of change by Satabdi Das on 12-Apr-2021 for Cop answer Set*/
											}
										} else {
											MessageBox.error(
												this.getView().getModel("i18n").getProperty("suupliermissingMessgage"), {
													styleClass: bCompact ? "sapUiSizeCompact" : ""
												}
											);
											oTable.removeSelections(true);
											return;
										}
									} else {
										var CostCenterMad = this.getView().getModel("i18n").getProperty("CostCenterMad");
										MessageBox.error(
											(CostCenterMad), {
												styleClass: bCompact ? "sapUiSizeCompact" : ""
											}
										);
										oTable.removeSelections(true);
										return;
									}
								} else if (objRow.GlobalCc && objRow.GlobalCc !== "N/A") {
									if (oHeaderData.Kostl) {
										if ((oHeaderData.VendorName && oHeaderData.RrfDesc)) {
											if (objRow.ContactPCop === undefined || objRow.CopEmailId === undefined || objRow.ContactPCop.length === 0 || objRow.CopEmailId
												.length === 0) {
												var GlobalCc = objRow.GlobalCc;
												var COPBlankWarningGF = this.getView().getModel("i18n").getProperty("COPBlankWarningGF");
												MessageBox.error(
													(COPBlankWarningGF + GlobalCc), {
														styleClass: bCompact ? "sapUiSizeCompact" : ""
													}
												);
												oTable.removeSelections(true);
												return;
											} else if (!objRow.TotalCommAmount || objRow.TotalCommAmount === "0.00" || objRow.TotalCommAmount === "000000000000.000") {
												/*Change add for INC01503380 on 21-Apr-2021*/
												var copTotalCommerc = this.getView().getModel("i18n").getProperty("initateCopMessage");
												MessageBox.error(
													(copTotalCommerc), {
														styleClass: bCompact ? "sapUiSizeCompact" : ""
													}
												);
												oTable.removeSelections(true);
												return;
											}
											/*Start of change for SCTASK1855604 - budget approvers by developer Satabdi Das on 19-May-2021*/
											else if (!objRow.AttenBrf || objRow.AttenBrf.length === 0 || !objRow.AttenBrfEmail || objRow.AttenBrfEmail.length === 0) {
												/*Change add for INC01503380 on 21-Apr-2021*/
												var sErrorMsg = this.getView().getModel("i18n").getProperty("BAMissingErrorMsg");
												MessageBox.error(
													(sErrorMsg), {
														styleClass: bCompact ? "sapUiSizeCompact" : ""
													}
												);
												oTable.removeSelections(true);
												return;
											}
											/*End of change for SCTASK1855604 - budget approvers by developer Satabdi Das on 19-May-2021*/
											else {
												var sObj = {};
												sObj.RequestingMf = objRow.RequestingMf;
												sObj.GlobalCc = objRow.GlobalCc;
												sObj.RrfNo = sPoNum;
												sObj.ProcessGrp = objRow.ProcessGrp;
												sObj.MemberFirm = objRow.MemberFirm;
												sObj.CcShortDesc = "";
												sObj.TotalCommAmount = objRow.TotalCommAmount;
												sObj.ContactPCop = objRow.ContactPCop;
												sObj.CopEmailId = objRow.CopEmailId;
												sObj.DetailsDescriptionOfService = oHeaderData.RrfDesc;

												TableData.push(sObj);
											}
										} else {
											MessageBox.error(
												this.getView().getModel("i18n").getProperty("suupliermissingMessgage"), {
													styleClass: bCompact ? "sapUiSizeCompact" : ""
												}
											);
											oTable.removeSelections(true);
											return;
										}
									} else {
										var CostCenterMad = this.getView().getModel("i18n").getProperty("CostCenterMad");
										MessageBox.error(
											(CostCenterMad), {
												styleClass: bCompact ? "sapUiSizeCompact" : ""
											}
										);
										oTable.removeSelections(true);
										return;
									}
								}
							}
							var fnSuccess1 = jQuery.proxy(function (d) {

								sap.ui.core.BusyIndicator.hide(0);

								if (d.Flag) {
									MessageBox.error(
										d.Message, {
											styleClass: bCompact ? "sapUiSizeCompact" : ""
										}
									);
									oTable.removeSelections(true);
									return;
								} else {
									mModelSummary.setProperty("/oCopLoaSucesFlag", true);
									MessageBox.show(
										d.Message, {
											icon: MessageBox.Icon.SUCCESS,
											title: "Success",
											actions: [MessageBox.Action.OK],
											onClose: function (oAction) {
												that.handlePreBtnEdit();

											}
										}
									);

								}

							}, this);
							var fnError1 = jQuery.proxy(function (d) {
								var r = JSON.parse(JSON.stringify(d));
								sap.ui.core.BusyIndicator.hide();
								MessageToast.show(r.message, {
									autoClose: true,
									width: "20rem"
								});
							}, this);
							objectOne.successCallback = fnSuccess1;
							objectOne.errorCallback = fnError1;
							oPayLoad.Cop_LineSet = TableData;
							oPayLoad.COP_AnswSet = _answre;
							sap.ui.core.BusyIndicator.show(0);
							DataManagerARrecharge.CreateInitiateCOP(oPayLoad, objectOne);
						} else if (sAcontextPO.length === 0 || sAcontextPO === iPrevRowPO) {
							MessageBox.error(
								this.getView().getModel("i18n").getProperty("RowWarning"), {
									styleClass: bCompact ? "sapUiSizeCompact" : ""
								}
							);
							oTable.removeSelections(true);
							return;
						}
						iPrevRowPO = sAcontextPO;
						oTable.removeSelections(true);

					} else if ((buttonClick === "Initiate LOA") && bLOAButton === true) {
						if (arr) {
							var oPayLoad = {
								RrfNo: sPoNum,
								Action: ActionLOA,
								Currency: oHeaderData.Currency,
								CompanyCode: oHeaderData.CompanyCode,
								VendorName: oHeaderData.VendorName,
								RrfType: oHeaderData.RrfType,
								/*Added by Satabdi Das on 26-Nov-2020*/
								SupplierAgreementDate: oHeaderData.SupplierAgreementDate,
								Cop_LineSet: [],
								COP_AnswSet: []
							};
							for (var i = 0; i < arr.results.length; i++) {
								if ((arr.results[i].CopInitiate === "X") && (arr.results[i].RrfStatus === "COPConfirmed")) {
									var objRow = arr.results[i];
									if (objRow.RequestingMf && objRow.RequestingMf !== "N/A") {
										if (!objRow.LoaDesc || !oHeaderData.SupplierAgreementDate || oHeaderData.SupplierAgreementDate === "00000000") {
											MessageBox.error(
												this.getView().getModel("i18n").getProperty("LOABlankWarning"), {
													styleClass: bCompact ? "sapUiSizeCompact" : ""
												}
											);
											oTable.removeSelections(true);
											return;
										} else {
											var sObj = {};
											sObj.RequestingMf = objRow.RequestingMf;
											sObj.GlobalCc = objRow.GlobalCc;
											sObj.ProcessGrp = objRow.ProcessGrp;
											sObj.MemberFirm = objRow.MemberFirm;
											sObj.CcShortDesc = "";
											sObj.LoaContact = objRow.LoaContact;
											sObj.LoaEmail = objRow.LoaEmail;
											sObj.RrfNo = sPoNum;
											sObj.AdlLoaContact = objRow.AdlLoaContact;
											sObj.AdlLoaEmail = objRow.AdlLoaEmail;
											sObj.ContactPCop = objRow.ContactPCop;
											sObj.CopEmailId = objRow.CopEmailId;
											sObj.LoaDesc = objRow.LoaDesc;
											sObj.SapCodeMf = objRow.SapCodeMf;
											TableData.push(sObj);
											/*Start of change by Satabdi Das on 12-Apr-2021 for Cop answer set*/
											var arrAnsware = [];
											arrAnsware = mModelSummary.getProperty("/questionSetSubmit");
											if (arrAnsware && arrAnsware.length !== 0) {
												for (var t = 0; t < arrAnsware.length; t++) {
													var objAns = {};
													objAns.GlobalCc = oHeaderData.GlobalCc;
													objAns.MemberFirm = arrAnsware[t].MemberFirm;
													objAns.Question = arrAnsware[t].Question;
													objAns.RequestingMf = arrAnsware[t].RequestingMf;
													objAns.Answer = arrAnsware[t].Answer;
													objAns.InternalExternal = arrAnsware[t].InternalExternal;
													objAns.RrfNo = sPoNum;
													objAns.AnswerDesc = arrAnsware[t].AnswerDesc;
													objAns.ProcessGrp = arrAnsware[t].ProcessGrp;
													objAns.CompanyCode = oHeaderData.CompanyCode;
													_answre.push(objAns);

												}
											}

											/*End of change by Satabdi Das on 12-Apr-2021 for Cop answer Set*/
										}
									} else if (objRow.GlobalCc && objRow.GlobalCc !== "N/A") {
										if (objRow.LoaDesc === undefined || objRow.LoaDesc.length === 0 || !oHeaderData.SupplierAgreementDate || oHeaderData.SupplierAgreementDate ===
											"00000000") {
											MessageBox.error(
												this.getView().getModel("i18n").getProperty("LOABlankWarning"), {
													styleClass: bCompact ? "sapUiSizeCompact" : ""
												}
											);
											oTable.removeSelections(true);
											return;
										} else {
											var sObj = {};
											sObj.RequestingMf = objRow.RequestingMf;
											sObj.GlobalCc = objRow.GlobalCc;
											sObj.ProcessGrp = objRow.ProcessGrp;
											sObj.MemberFirm = objRow.MemberFirm;
											sObj.CcShortDesc = "";
											sObj.LoaContact = objRow.LoaContact;
											sObj.LoaEmail = objRow.LoaEmail;
											sObj.RrfNo = sPoNum;
											sObj.AdlLoaContact = objRow.AdlLoaContact;
											sObj.AdlLoaEmail = objRow.AdlLoaEmail;
											sObj.ContactPCop = objRow.ContactPCop;
											sObj.CopEmailId = objRow.CopEmailId;
											sObj.LoaDesc = objRow.LoaDesc;
											sObj.TotalCommAmount = objRow.TotalCommAmount;

											TableData.push(sObj);
										}
									}
								}
								// else {
								// 	MessageBox.error(
								// 		this.getView().getModel("i18n").getProperty("LOAWarning"), {
								// 			styleClass: bCompact ? "sapUiSizeCompact" : ""
								// 		}
								// 	);
								// 	oTable.removeSelections(true);
								// 	return;
								// }
							}
							var fnSuccess1 = jQuery.proxy(function (d) {

								sap.ui.core.BusyIndicator.hide(0);
								if (d.Flag) {
									MessageBox.error(
										d.Message, {
											styleClass: bCompact ? "sapUiSizeCompact" : ""
										}
									);
									oTable.removeSelections(true);
									return;
								} else {
									MessageBox.show(
										d.Message, {
											icon: MessageBox.Icon.SUCCESS,
											title: "Success",
											actions: [MessageBox.Action.OK],
											onClose: function (oAction) {
												that.handlePreBtnEdit();
											}
										}
									);
								}
							}, this);
							var fnError1 = jQuery.proxy(function (d) {
								var r = JSON.parse(JSON.stringify(d));
								sap.ui.core.BusyIndicator.hide();
								MessageToast.show(r.message, {
									autoClose: true,
									width: "20rem"
								});
							}, this);
							objectOne.successCallback = fnSuccess1;
							objectOne.errorCallback = fnError1;
							oPayLoad.Cop_LineSet = TableData;
							oPayLoad.COP_AnswSet = _answre;
							sap.ui.core.BusyIndicator.show(0);
							DataManagerARrecharge.CreateInitiateCOP(oPayLoad, objectOne);
						} else if (!arr || arr.results.length === 0) {
							MessageBox.error(
								this.getView().getModel("i18n").getProperty("NoTableRowWarning"), {
									styleClass: bCompact ? "sapUiSizeCompact" : ""
								}
							);
							return;
						}
					}
					/*End of change on 20-Feb-2020*/

				}
			}
		},
		onReloadApp: function () {
			MessageBox.warning("The project schedule was last updated over a year ago.");
		},

		saveDataCopLoaInitiate: function (oEvent) {
			var headerData = this.getView().getModel("mModelSummary").getProperty("/HeaderDataNC");
			sap.ui.core.BusyIndicator.show(0);
			var TableData = [];
			var oPayLoad = {
				CompanyCode: headerData.CompanyCode,
				ContrlName: headerData.ContrlName,
				ContrlEmail: headerData.ContrlEmail,
				TotalContractAmount: headerData.TotalContractAmount,
				GfDesc: headerData.GfDesc,
				RrfNoGf: headerData.RrfNoGf,
				AddlInfo: headerData.AddlInfo,
				/*Added by Satabdi Das on 03-Dec-2019*/
				CreatedOn: headerData.CreatedOn,
				CreatedBy: headerData.CreatedBy,
				Currency: headerData.Currency,
				Kostl: headerData.Kostl,
				Ltext: headerData.Ltext,
				RrfType: headerData.RrfType,
				ToDisplay: headerData.ToDisplay,
				/*Added by Satabdi Das on 26-Nov-2020*/
				CanNoticeDate: headerData.CanNoticeDate,
				/*Added by Satabdi Das on 09-Jan-2020*/
				/*Start of change on 03-March-2020*/
				Background: headerData.Background,
				Activity: headerData.Activity,
				/*End of change on 03-March-2020*/
				RrfStatus: headerData.RrfStatus,
				flag: headerData.flag,
				BillScheFlg: headerData.BillSchFlg,
				GF_Lineitem_Set: []
			};

			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);

			}, this);
			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();
				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"

				});
			}, this);
			var arr = [];
			arr = this.getView().getModel("mModelSummary").getProperty("/TableItemSetNC");
			if (arr.length !== 0 || arr.results !== undefined) {
				arr = formatter.formatFromCoupaDateToYYYYMMDD(arr);
				for (var i in arr.results) {
					/*Start of change on 10-Jan-2020*/
					if (arr.results[i].Amount === "") {
						arr.results[i].Amount = "000000000000.000";
					}
					/*End of change on 10-Jan-2020*/
					var fields = Object.keys(arr.results[i]);
					var obj = {};
					for (var j = 0; j < fields.length; j++) {
						if (fields[j] !== "__metadata") {
							obj[fields[j]] = arr.results[i][fields[j]];
						}
					}
					TableData.push(obj);
				}
			}

			oPayLoad.GF_Lineitem_Set = TableData;
			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
				json: true
			});
			oModel1.create("/GF_HeaderSet", oPayLoad, {
				success: fnSuccess,
				error: fnError
			});

		},
		saveAfterCopLoaInitate: function (oEvent) {
			var mModelSummary = this.getView().getModel("mModelSummary");
			var hederData = mModelSummary.getProperty("/HeaderData");
			hederData.Currency = mModelSummary.getProperty("/CurrKeySet");
			sap.ui.core.BusyIndicator.show(0);
			var TableData = [];
			var PoHeaderData = [];
			var PoLineItemData = [];

			var oPayLoad = {
				CompanyCode: hederData.CompanyCode,
				ContractTerm: hederData.ContractTerm,
				ContarctStartDate: hederData.ContarctStartDate,
				ContarctEndDate: hederData.ContarctEndDate,
				SupplierAgreementDate: hederData.SupplierAgreementDate,
				AddlInfo: hederData.AddlInfo,
				CoupaRequisitionNumber: hederData.CoupaRequisitionNumber,
				CoupaRequisitionDate: hederData.CoupaRequisitionDate,
				CoupaReqCreatedBy: hederData.CoupaReqCreatedBy,
				TotalPoAmount: hederData.TotalPoAmount,
				Currency: hederData.Currency,
				VendorName: hederData.VendorName,
				Vendor: hederData.Vendor,
				RrfNo: hederData.RrfNo,
				RrfDesc: hederData.RrfDesc,
				ContrlName: hederData.ContrlName,
				ContrlEmail: hederData.ContrlEmail,
				PoNumber: hederData.PoNumber,
				PoDescription: hederData.PoDescription,
				GlobalCostCentre: hederData.GlobalCostCentre,
				Kostl: hederData.Kostl,
				Ltext: hederData.Ltext,
				RrfType: hederData.RrfType,
				ToDisplay: hederData.ToDisplay,
				/*Added by Satabdi Das on 26-Nov-2020*/
				PoDashboard: hederData.PoDashboard,

				RrfStatus: hederData.RrfStatus,
				GlobalCc: hederData.GlobalCc,

				GlAccount: hederData.GlAccount,
				RRF_Line_itemSet: [],
				RRF_HEADERPOSet: [],
				RRF_LINEPOSet: []

			};
			var that = this;
			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
			}, this);
			var fnError = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();
				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"

				});
			}, this);
			var arr = [];
			var arrPoHeader = [];
			var arrPoLineItem = [];
			arr = this.getView().getModel("mModelSummary").getProperty("/TableItemSet");
			arrPoHeader = this.getView().getModel("mModelSummary").getProperty("/PoTableSet");
			arrPoLineItem = this.getModel("mModelSummary").getProperty("/oLinePoTableSet");
			if (arrPoHeader.length > 0) {
				for (var i in arrPoHeader) {
					var fields = Object.keys(arrPoHeader[i]);
					var obj = {};
					for (var j = 0; j < fields.length; j++) {
						if (fields[j] !== "__metadata") {
							obj[fields[j]] = arrPoHeader[i][fields[j]];
						}
					}
					PoHeaderData.push(obj);
				}
				oPayLoad.RRF_HEADERPOSet = PoHeaderData;
			}
			if (arrPoLineItem.length > 0) {
				for (var i in arrPoLineItem) {
					fields = Object.keys(arrPoLineItem[i]);
					obj = {};
					for (var j = 0; j < fields.length; j++) {
						if (fields[j] !== "__metadata") {
							obj[fields[j]] = arrPoLineItem[i][fields[j]];
						}
					}
					PoLineItemData.push(obj);
				}
				oPayLoad.RRF_LINEPOSet = PoLineItemData;
			}

			for (var i in arr.results) {
				fields = Object.keys(arr.results[i]);
				obj = {};
				for (var j = 0; j < fields.length; j++) {
					if (fields[j] !== "__metadata") {
						obj[fields[j]] = arr.results[i][fields[j]];
					}
				}
				TableData.push(obj);
			}
			oPayLoad.RRF_Line_itemSet = TableData;
			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
				json: true
			});
			oModel1.create("/RRF_HeaderSet", oPayLoad, {
				success: fnSuccess,
				error: fnError
			});
			//DataManagerARrecharge.CreateData(oPayLoad, objectOne);

		},
		/*End of change on 10-Feb-2020*/
		/*Start - CR  Changed On 26-Aug-2021 By Prashant and Chhanda*/
		checkTotalMFAmountForSameMF: function (arrMF, rrfType) {
			var mModelSummary = this.getModel("mModelSummary");
			if (rrfType === "PO") {
				var _RRFItemSet = mModelSummary.getProperty("/TableItemSet");
			} else {
				var _RRFItemSet = mModelSummary.getProperty("/TableItemSetNC");
			}
			var _mMembeFirmData = [];
			var data = arrMF;
			var uniqueReqMF = [];
			for (var i = 0; i < data.length; i++) {
				if (data[i].RequestingMf && data[i].RequestingMf !== "N/A" && (data[i].RrfStatus === "RRF Initiated" || data[i].RrfStatus ===
						"COP Changed" || !data[i].RrfStatus))
				// considering RequestingMf and MemberFirm
					if (uniqueReqMF.indexOf(data[i].RequestingMf + "#" + data[i].MemberFirm) === -1) {
					uniqueReqMF.push(data[i].RequestingMf + "#" + data[i].MemberFirm);
					var objectMemFirm = {};
					objectMemFirm.RequestingMf = data[i].RequestingMf;
					objectMemFirm.MemberFirm = data[i].MemberFirm;
					_mMembeFirmData.push(objectMemFirm);

				}
			}
			var _arrTotalMFAmount = [];
			if (_mMembeFirmData.length > 0) {
				for (var d = 0; d < _mMembeFirmData.length; d++) {

					var otTotalLineAmt = 0;
					for (var k = 0; k < arrMF.length; k++) {
						if (_mMembeFirmData[d].RequestingMf === arrMF[k].RequestingMf && _mMembeFirmData[d].MemberFirm === arrMF[k].MemberFirm) {
							if (rrfType === "PO") {
								otTotalLineAmt = otTotalLineAmt + Number(arrMF[k].TotalCommAmount);
							} else { // for NonPO
								otTotalLineAmt = otTotalLineAmt + Number(arrMF[k].Amount);
							}
						}
					}

					var objectMemFirm1 = {};
					objectMemFirm1.RequestingMf = _mMembeFirmData[d].RequestingMf;
					objectMemFirm1.MemberFirm = _mMembeFirmData[d].MemberFirm;
					objectMemFirm1.TotalMFAmount = otTotalLineAmt;
					_arrTotalMFAmount.push(objectMemFirm1);
				}

			}

			if (_arrTotalMFAmount.length > 0) {
				var displayMsg = [];
				for (var i = 0; i < _arrTotalMFAmount.length; i++) {
					if (_arrTotalMFAmount[i].TotalMFAmount > 250000) {
						displayMsg.push(_arrTotalMFAmount[i].MemberFirm);
						// if (displayMsg !== "") {
						// 	displayMsg = displayMsg + ", " + _arrTotalMFAmount[i].MemberFirm;
						// } else {
						// 	displayMsg = _arrTotalMFAmount[i].MemberFirm;
						// }
						//update cooflag for same MF
						for (var p = 0; p < _RRFItemSet.results.length; p++) {
							if (_RRFItemSet.results[p].RequestingMf === _arrTotalMFAmount[i].RequestingMf && _RRFItemSet.results[p].MemberFirm ===
								_arrTotalMFAmount[i].MemberFirm) {
								_RRFItemSet.results[p].CooFlag = "X";
							}

						}
					}
				}
			}

			return displayMsg;
		},
		/*End - CR  Changed On 26-Aug-2021 By Prashant and Chhanda*/
		exit: function () {}
	});
});