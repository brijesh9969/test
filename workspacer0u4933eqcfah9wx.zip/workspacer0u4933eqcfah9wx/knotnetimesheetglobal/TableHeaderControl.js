sap.ui.define(["sap/ui/core/Control"], function(Control) {
	"use strict";
	return Control.extend("kno.tne.timesheet.newTimeSheet.lib.control.TableHeaderControl", {
		"metadata": {
			"properties": {
				"prop1": "string",
				"prop2": "string",
				"prop3": "string",
				"prop4": "string",
				"prop5": "string",
				"prop6": "string",
				"prop7": "string",
				"prop8": "string",
				"prop9": "string"
			},

			"aggregations": {

				"calendar": {
					type: "sap.ui.core.Icon",
					multiple: false
				}
			},
			"events": {
				"OnCalendarOpen": {}
			}
		},
		init: function() {
			var oControl = this;
			var oIcon = sap.ui.core.IconPool.createControlByURI({
				press: function(oEvent) {
					oControl.fireOnCalendarOpen({});
				},
				src: "sap-icon://per-diem"
			}, sap.m.Image);
			oIcon.setSize("2rem");
			oIcon.setColor("#753a3a");
			this.setAggregation("calendar", oIcon);
		},
		renderer: function(oRm, oControl) {
			// oRm.write("<div");
			// oRm.writeControlData(oControl);
			// oRm.addClass("kgotsRow");
			// oRm.writeClasses();
			// oRm.write(">");
			oRm.write("<div");
			oRm.addClass("kgosTableHeader");
			oRm.addClass("kgotsHead");
			oRm.writeClasses();
			oRm.write(">");
			oRm.write("<div");
			oRm.addClass("kgotsHeadCntDiv");
			oRm.addClass("kgotsHeadLeft");
			oRm.writeClasses();
			oRm.write(">");
			// Write the Header content

			oRm.write('<SPAN id="' + oControl.getId() + '-CalIcon" class="kgotsCalendar">');

			if (oControl.getAggregation("calendar")) {
				oRm.renderControl(oControl.getAggregation("calendar"));
			}
			oRm.write('</SPAN>');

			oRm.write("</div>");
			oRm.write("<div");
			oRm.addClass("kgotsHeadCntDiv");
			oRm.addClass("kgotsHeadRight");
			oRm.writeClasses();
			oRm.write(">");
			oRm.write("<div");
			oRm.addClass("kgotsHeadDay");
			oRm.writeClasses();
			oRm.write(">");
			oRm.write("<div");
			oRm.addClass("kgotsHeadDaytext");
			oRm.addClass("kgotsRightCnt");
			oRm.writeClasses();
			oRm.write(">");
			oRm.write("<span");
			oRm.write(">");
			oRm.writeEscaped(oControl.getProp1());
			oRm.write("</span>");
			oRm.write("</div>");
			oRm.write("</div>");
			oRm.write("<div");
			oRm.addClass("kgotsHeadDay");
			oRm.writeClasses();
			oRm.write(">");
			oRm.write("<div");
			oRm.addClass("kgotsHeadDaytext");
			oRm.addClass("kgotsRightCnt");
			oRm.writeClasses();
			oRm.write(">");
			oRm.write("<span");
			oRm.write(">");
			oRm.writeEscaped(oControl.getProp2());
			oRm.write("</span>");
			oRm.write("</div>");
			oRm.write("</div>");
			oRm.write("<div");
			oRm.addClass("kgotsHeadDay");
			oRm.writeClasses();
			oRm.write(">");
			oRm.write("<div");
			oRm.addClass("kgotsHeadDaytext");
			oRm.addClass("kgotsRightCnt");
			oRm.writeClasses();
			oRm.write(">");
			oRm.write("<span");
			oRm.write(">");
			oRm.writeEscaped(oControl.getProp3());
			oRm.write("</span>");
			oRm.write("</div>");
			oRm.write("</div>");
			oRm.write("<div");
			oRm.addClass("kgotsHeadDay");
			oRm.writeClasses();
			oRm.write(">");
			oRm.write("<div");
			oRm.addClass("kgotsHeadDaytext");
			oRm.addClass("kgotsRightCnt");
			oRm.writeClasses();
			oRm.write(">");
			oRm.write("<span");
			oRm.write(">");
			oRm.writeEscaped(oControl.getProp4());
			oRm.write("</span>");
			oRm.write("</div>");
			oRm.write("</div>");
			oRm.write("<div");
			oRm.addClass("kgotsHeadDay");
			oRm.writeClasses();
			oRm.write(">");
			oRm.write("<div");
			oRm.addClass("kgotsHeadDaytext");
			oRm.addClass("kgotsRightCnt");
			oRm.writeClasses();
			oRm.write(">");
			oRm.write("<span");
			oRm.write(">");
			oRm.writeEscaped(oControl.getProp5());
			oRm.write("</span>");
			oRm.write("</div>");
			oRm.write("</div>");
			oRm.write("<div");
			oRm.addClass("kgotsHeadDay");
			oRm.writeClasses();
			oRm.write(">");
			oRm.write("<div");
			oRm.addClass("kgotsHeadDaytext");
			oRm.addClass("kgotsRightCnt");
			oRm.writeClasses();
			oRm.write(">");
			oRm.write("<span");
			oRm.write(">");
			oRm.writeEscaped(oControl.getProp6());
			oRm.write("</span>");
			oRm.write("</div>");
			oRm.write("</div>");
			oRm.write("<div");
			oRm.addClass("kgotsHeadDay");
			oRm.writeClasses();
			oRm.write(">");
			oRm.write("<div");
			oRm.addClass("kgotsHeadDaytext");
			oRm.addClass("kgotsRightCnt");
			oRm.writeClasses();
			oRm.write(">");
			oRm.write("<span");
			oRm.write(">");
			oRm.writeEscaped(oControl.getProp7());
			oRm.write("</span>");
			oRm.write("</div>");
			oRm.write("</div>");
			oRm.write("<div");
			oRm.addClass("kgotsHeadDay");
			oRm.writeClasses();
			oRm.write(">");
			oRm.write("<div");
			oRm.addClass("kgotsHeadDaytext");
			oRm.addClass("kgotsRightCnt");
			oRm.writeClasses();
			oRm.write(">");
			oRm.write("<span");
			oRm.write(">");
			oRm.writeEscaped(oControl.getProp8());
			oRm.write("</span>");
			oRm.write("</div>");
			oRm.write("</div>");
			oRm.write("<div");
			oRm.addClass("kgotsHeadDay");
			oRm.writeClasses();
			oRm.write(">");
			oRm.write("<div");
			oRm.addClass("kgotsHeadDaytext");
			oRm.addClass("kgotsRightCnt");
			oRm.writeClasses();
			oRm.write(">");
			oRm.write("<span");
			oRm.write(">");
			oRm.writeEscaped(oControl.getProp9());
			oRm.write("</span>");
			oRm.write("</div>");
			oRm.write("</div>");
			oRm.write("</div>");
			oRm.write("</div>");

			// oRm.write("</div>");
		},
		onAfterRendering: function(evt) {}
			/*setProp1: function(value) {
				this.setProperty("prop1", value, true);
				return this;
			},
			setProp2: function(value) {
				this.setProperty("prop2", value, true);
				return this;
			},
			setProp3: function(value) {
				this.setProperty("prop3", value, true);
				return this;
			},
			setProp4: function(value) {
				this.setProperty("prop4", value, true);
				return this;
			},
			setProp5: function(value) {
				this.setProperty("prop5", value, true);
				return this;
			},
			setProp6: function(value) {
				this.setProperty("prop6", value, true);
				return this;
			},
			setProp7: function(value) {
				this.setProperty("prop7", value, true);
				return this;
			},
			setProp8: function(value) {
				this.setProperty("prop8", value, true);
				return this;
			},
			setProp9: function(value) {
				this.setProperty("prop9", value, true);
				return this;
			}*/
	});
});