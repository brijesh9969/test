var kno = kno || {};
jQuery.sap.require("kno.tne.timesheet.newTimeSheet.model.TimeSheet");
jQuery.sap.require("kno.tne.timesheet.newTimeSheet.lib.formatters.TimeSheetFormatter");
jQuery.sap.require("kno.tne.timesheet.newTimeSheet.lib.control.TimesheetListItem");
jQuery.sap.require("kno.tne.timesheet.newTimeSheet.lib.control.NumericFieldType");
jQuery.sap.require("sap.ui.unified.Calendar");
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"sap/ui/core/Fragment"
], function (Controller, MessageBox, Fragment) {
	"use strict";

	return Controller.extend("kno.tne.timesheet.newTimeSheet.controller.WeeklyView", {

		dataManager: {},

		onInit: function () {
			// initialize data manager 
			this.timeSheet = new kno.tne.timesheet.newTimeSheet.model.TimeSheet(this.getOwnerComponent()
				.getModel());
			this.registerTSModelEvents();
			var oModel = this.timeSheet.getTimesheetModel();
			// var oMessageModel = new sap.ui.model.json.JSONModel();
			this.getView()
				.setModel(oModel, "TimeSheetGrid");
			// this.getView()
			// 	.setModel(oMessageModel, "mMessageModel");
			this.i18n = this.getOwnerComponent()
				.getModel("i18n");
			//initialize Router and attach route matched event
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this); //this.getOwnerComponent().getRouter(); //sap.ui.core.UIComponent.getRouterFor(this);
			this.oRouter.attachRouteMatched(jQuery.proxy(this.handleRouteMatched, this));

			var eventBus = sap.ui.getCore()
				.getEventBus();
			eventBus.subscribe("channel1", "AddCode", this.onAddCode, this);
			eventBus.subscribe("addCodeGeneral", "AddCodeGeneral", this.onAddCodeGeneral, this);
			eventBus.subscribe("addCodeRec", "AddCodeRec", this.onAddCodeRec, this);
			eventBus.subscribe("CanCode", "CancelCode", this.onCancelCode, this);
			eventBus.subscribe("stopWatch", "AddTime", this.handlAddTime, this);
			eventBus.subscribe("CanStopWatch", "CancelWatch", this.onCancelWatch, this);
			eventBus.subscribe("CanExtHours", "CanExtraHours", this.onCanExtraHours, this);

			// var oVizFrame = this.oVizFrame = this.getView()
			// 	.byId("idVizFrame");
			// oVizFrame.setVizProperties({
			// 	title: {
			// 		visible: "Summary"
			// 	}
			// });
			// var dataModel = this.getOwnerComponent()
			// 	.getModel("mSummaryModel");

			// var dataModel = {
			// 	"items": [{
			// 		"Department": "R & D",
			// 		"EmployeeCount": "20"
			// 	}, {
			// 		"Department": "Syngenta",
			// 		"EmployeeCount": "30"
			// 	}, {
			// 		"Department": "Volvo",
			// 		"EmployeeCount": "35"
			// 	}, {
			// 		"Department": "NIKE",
			// 		"EmployeeCount": "60"
			// 	}, {
			// 		"Department": "ADIDAS",
			// 		"EmployeeCount": "70"
			// 	}]
			// };

			var oModelViz = this.getOwnerComponent()
				.getModel("mSummaryModel");
			// oVizFrame.setModel(oModelViz, "mSummaryModel");
			this.getView()
				.setModel(oModelViz, "mSummaryModel");

			var oDocVisitModel = new sap.ui.model.json.JSONModel();
			this.getView()
				.setModel(oDocVisitModel, "mDocVisitModel");

		},

		// onAfterRendering: function() {
		// 	var libraries = sap.ui.getVersionInfo()
		// 		.libraries || [];
		// 	var bSuiteAvailable = libraries.some(function(lib) {
		// 		return lib.name.indexOf("sap.suite.ui.commons") > -1;
		// 	});

		// 	var oView = this.getView();
		// 	if (bSuiteAvailable) {
		// 		jQuery.sap.require("sap/suite/ui/commons/ChartContainer");
		// 		var vizframe = oView.byId("idVizFrame");
		// 		var oChartContainerContent = new sap.suite.ui.commons.ChartContainerContent({
		// 			icon: "sap-icon://donut-chart",
		// 			title: "vizFrame Donut Chart Sample",
		// 			content: [vizframe]
		// 		});
		// 		var oChartContainer = new sap.suite.ui.commons.ChartContainer({
		// 			content: [oChartContainerContent]
		// 		});
		// 		oChartContainer.setShowFullScreen(true);
		// 		oChartContainer.setAutoAdjustHeight(true);
		// 		oChartContainer.setShowZoom(false);
		// 		this.getView()
		// 			.byId('chartFixFlex')
		// 			.setFlexContent(oChartContainer);
		// 	}
		// },

		// press: function(oEvent) {
		// 	MessageToast.show("The Interactive Donut Chart is pressed.");
		// },

		// /**
		//  * Creates a message for a selection change event on the chart
		//  *
		//  * @private
		//  */
		// onSelectionChanged: function(oEvent) {
		// 	var oSegment = oEvent.getParameter("segment");
		// 	MessageToast.show("The selection changed: " + oSegment.getLabel() + " " + ((oSegment.getSelected()) ? "selected" : "not selected"));
		// },

		handleRouteMatched: function (oEvent) {
			// get the delegate Set ...
			//this.dataManager.getDelegateSet(this, jQuery.proxy(this.onDelegateSetSuccess, this), jQuery.proxy(this.onoDataError, this));
			this.timeSheet.init();
			this.onShowDelegate();
			this.timeSheet.getRFCList();
			this.getView()
				.setBusy(true);
		},

		/* Methods to handle timesheet model registration
		and event handlers for model events*/
		registerTSModelEvents: function () {
			var aEvents = [this.timeSheet.evtInitialized,
				this.timeSheet.evtInitialInfosLoaded,
				this.timeSheet.evtWorkCalendarsLoaded,
				this.timeSheet.evtTimeDataListLoaded,
				this.timeSheet.evtProfileFieldsLoaded,
				this.timeSheet.evtDelegateSetLoaded,
				this.timeSheet.evtActivityCodesLoaded,
				this.timeSheet.evtAATypesLoaded,
				this.timeSheet.evtTSSaveComplete,
				this.timeSheet.evtTriggerMessage,
				this.timeSheet.evtDocVisitSuccess,
				this.timeSheet.evtRFCListLoaded,
				this.timeSheet.evtESUCheckSuccess,
				this.timeSheet.evtTimeLogLoaded,
				this.timeSheet.evtIOSaveSuccess,
				this.timeSheet.evtSANCheckSuccess,
				this.timeSheet.evtESUActionSuccess,
				this.timeSheet.evtDailyHoursChanged,
				//Added by santosh
				this.timeSheet.evtloadExistingTimeSucess,
				this.timeSheet.evtSaveTimeSheet
			];

			for (var i = 0; i < aEvents.length; i++) {
				this.timeSheet.attachEvent(aEvents[i], {}, this.onTsModelEvt, this);
			}
		},

		EnableStopWatch: function (oEvent) {
			var mParam = oEvent.getParameter("workCal");
			var sStopWatchEnabled = false;
			if (mParam && mParam.results) {
				if (mParam.results.length > 0) {
					for (var i = 0; i < mParam.results.length; i++) {

						if (mParam.results[i].Date === this.timeSheet.getSapDate()) {
							sStopWatchEnabled = true;
							break;
						}
					}

					this.getView()
						.getModel("mStopWatch")
						.setProperty("/Enabled", sStopWatchEnabled);
					// this.getView()
					// 	.getModel("mStopWatch")
					// 	.refresh(true);

				}
			}
		},

		onAddAllcationCode: function (oEvent) {

			// if (!this.searchDialogTimer) {
			this.oGenericComponentRec = sap.ui.getCore()
				.createComponent({
					name: "kno.tne.timesheet.newTimeSheet.components.Search",
					componentData: {
						startupParameters: {
							oParameters: {
								"type": "AddCodeFrmRecUsed",
								"RecentlyUsed": this.timeSheet.tsJSONModel.getProperty("/dropDowns/recentlyUsedCodes"),
								"AATypes": this.timeSheet.tsJSONModel.getProperty("/dropDowns/AATypes")
							}
						},
						oModel: this.timeSheet
					}
				});

			this.searchDialogRec = new sap.m.Dialog({
				contentWidth: "50%",
				contentHeight: "60%",
				resizable: true,
				showHeader: false,
				content: [new sap.ui.core.ComponentContainer({
						width: "100%",
						height: "100%"
					})
					.setComponent(this.oGenericComponentRec)
				]
			});
			// }
			this.searchDialogRec.open();

			this.oComboAlloc = oEvent.getSource();

		},

		onTsModelEvt: function (oEvent, b, c, d) {
			switch (oEvent.getId()) {
			case this.timeSheet.evtInitialized:
				this.handleTSModelInitialized();
				this.EnableStopWatch(oEvent);
				break;
			case this.timeSheet.evtInitialInfosLoaded:
				this.handleTsModelInitialInfos();
				break;
			case this.timeSheet.evtWorkCalendarsLoaded:
				this.handleTsModelWorkCalendars();
				break;
			case this.timeSheet.evtTimeDataListLoaded:
				this.handleTsModelTimeDataList();
				break;
			case this.timeSheet.evtProfileFieldsLoaded:
				this.handleTsModelProfileFields();
				break;
			case this.timeSheet.evtDelegateSetLoaded:
				this.handleDelegates(oEvent);
				break;
			case this.timeSheet.evtActivityCodesLoaded:
				this.handleTSModelactivityCodesLoaded(oEvent);
				// this.getView()
				// 	.getModel("TimeSheetGrid")
				// 	.refresh(true);
				break;
			case this.timeSheet.evtAATypesLoaded:
				this.handleTSModelAATypesLoaded(oEvent);
				break;
			case this.timeSheet.evtTSSaveComplete:
				this.handleTSSaveComplete(oEvent);
				this.getView()
					.setBusy(false);
				// this.getView()
				// 	.getModel("TimeSheetGrid")
				// 	.refresh(true);
				var oModel = this.getOwnerComponent()
					.getModel();

				this.timeSheet.getExistingTimeData(true);

				this.onDonutModelPopulate();

				// oModel.attachEventOnce("batchRequestCompleted", this.onDonutModelPopulate(), this);
				break;
			case this.timeSheet.evtTriggerMessage:
				this.getView()
					.setBusy(false);
				this.handleMessageTriggered(oEvent);

				// this.handleESUSuccess();
				this.onDonutModelPopulate();

				break;
			case this.timeSheet.evtDocVisitSuccess:
				this.handleDocVisit(oEvent);
				break;
			case this.timeSheet.evtRFCListLoaded:
				this.handleRFCListLoaded(oEvent);
				break;
			case this.timeSheet.evtESUCheckSuccess:
				this.handleESUSuccess(oEvent);
				break;

			case this.timeSheet.evtTimeLogLoaded:
				this.openTimeLog(oEvent);
				break;

			case this.timeSheet.evtIOSaveSuccess:
				this.CloseTimeLog(oEvent);
				break;

			case this.timeSheet.evtSANCheckSuccess:
				this.getView()
					.setBusy(false);
				this.openSanPopUp(oEvent);
				break;

			case this.timeSheet.evtESUActionSuccess:
				this.ESUActionSucces(oEvent);
				break;

			case this.timeSheet.evtDailyHoursChanged:
				this.onDonutModelPopulate();
				break;
				//Added by Santosh
			case this.timeSheet.evtloadExistingTimeSucess:
				this.timeMisMatchFound();
				break;
			case this.timeSheet.evtSaveTimeSheet:
				this.handleSave();
				break;

			default:
				break;
			}

		},

		CloseTimeLog: function (oEvet) {

			if (this._manageStartTime) {
				this._manageStartTime.close();
			}

			if (this._manageTime) {
				this._manageTime.close();
			}

		},

		openTimeLog: function (oEvet) {

			if (this._manageStartTime) {
				this._manageStartTime.open();
			}

			if (this._manageTime) {
				this._manageTime.close();
			}

		},

		onIOUpdate: function (oEvent) {
			this.timeSheet.saveIOTime();
		},

		openSanPopUp: function (oEvent) {
			var aResultString = oEvent.getParameter("SANResults");
			sap.m.MessageBox.warning(aResultString, {
				title: "Warning", // default
				textDirection: sap.ui.core.TextDirection.Inherit // default
			});

		},
		handleESUSuccess: function (oEvent) {

			var oData = this.getView()
				.getModel("TimeSheetGrid")
				.getProperty("/timeEntries/ESUCheck");

			var sString = "",
				sTxt;
			for (var j = 0; j <= 32; j++) {
				sTxt = "GV_TEXTLINE_" + j;
				if (j === 0 & oData[sTxt]) {
					sString = oData[sTxt] + ":" + " ";
				} else {
					if (oData[sTxt]) {
						sString = sString + oData[sTxt] + " ";
					}
				}
			}

			if (sString) {
				// if (!this.ESUDialog) {

				if (!this.indx) {
					this.indx = 0;
				}
				this.indx = this.indx + 1;

				var sId = "idDiag_" + this.indx;

				this.ESUDialog = new sap.m.Dialog({
					title: 'ESU Check',
					id: sId,
					// contentWidth: "50%",
					// contentHeight: "30%",
					content: new sap.m.HBox({
						items: [
							new sap.m.Text({
								text: sString,
							})
							.addStyleClass("knoDocTxt1")

						]
					}),
					buttons: []
				});

				//to get access to the global model
				this.getView()
					.addDependent(this.ESUDialog);

				if (oData.BUTTON1) {
					var oButton1 = new sap.m.Button({
						text: oData.BUTTON1,
						type: "Emphasized",
						width: "150px",
						tooltip: oData.BUTTON1,
						press: function (evt) {
							evt.getSource()
								.getParent()
								.close();
							evt.getSource()
								.getParent()
								.destroy();
							oData.ACTION = oData.BUTTON1;
							this.handleESUActionPress(oData);
							if (oData.BUTTON4 && oData.BUTTON4 === oData.BUTTON1) {
								this.openExtApps(oData.gv_url);
							}
						}.bind(this)
					});
					this.ESUDialog.addButton(oButton1);
				}

				if (oData.BUTTON2) {
					var oButton2 = new sap.m.Button({
						text: oData.BUTTON2,
						type: "Emphasized",
						width: "150px",
						tooltip: oData.BUTTON2,
						press: function (evt) {
							evt.getSource()
								.getParent()
								.close();
							evt.getSource()
								.getParent()
								.destroy();
							oData.ACTION = oData.BUTTON2;
							this.handleESUActionPress(oData);

							if (oData.BUTTON4 && oData.BUTTON4 === oData.BUTTON2) {
								this.openExtApps(oData.gv_url);
							}
						}.bind(this)
					});
					this.ESUDialog.addButton(oButton2);
				}

				if (oData.BUTTON3) {
					var oButton3 = new sap.m.Button({
						text: oData.BUTTON3,
						type: "Emphasized",
						width: "100px",
						tooltip: oData.BUTTON3,
						press: function (evt) {
							evt.getSource()
								.getParent()
								.close();
							evt.getSource()
								.getParent()
								.destroy();
							oData.ACTION = oData.BUTTON3;
							this.handleESUActionPress(oData);
						}.bind(this)
					});
					this.ESUDialog.addButton(oButton3);
				}

				if (oData.BUTTON4) {
					var oButton4 = new sap.m.Button({
						text: oData.BUTTON4,
						type: "Emphasized",
						press: function (evt) {
							evt.getSource()
								.getParent()
								.close();
							evt.getSource()
								.getParent()
								.destroy();
							oData.ACTION = oData.BUTTON4;
							if (oData.BUTTON4 !== oData.BUTTON2 && oData.BUTTON4 !== oData.BUTTON1 && oData.BUTTON4 !== oData.BUTTON3) {
								var timeEntries = this.timeSheet.prepareTimeEntriesforSave();
								this.getView()
									.setBusy(true);
								this.timeSheet.checkAndSave(timeEntries);
							}
						}.bind(this)
					});
					this.ESUDialog.addButton(oButton4);
				}

				this.ESUDialog.open();
			} else {

				// if (oData.BUTTON5 && oData.gv_url1) {
				// 	this.openExtApps(oData.gv_url1);
				// } else {

				var oModel = this.getOwnerComponent()
					.getModel();

				oModel.attachEventOnce("batchRequestCompleted", this.onBatchDeleteCompleteESU, this);
				// }

			}

		},

		onBatchDeleteCompleteESU: function () {
			var timeEntries = this.timeSheet.prepareTimeEntriesforSave();
			this.timeSheet.checkAndSave(timeEntries);
		},

		openExtApps: function (sURL) {
			window.open(sURL, "_blank",
				"directories=no, status=no, menubar=no, scrollbars=yes, resizable=yes,width=1100, height=620,top=0,left=0,titlebar=no");
		},

		handleESUActionPress: function (oData) {

			this.timeSheet.onESUActionHandle(oData);

		},

		ESUActionSucces: function (oEvent) {
			var oResult = oEvent.getParameter("ESUActionResult");

			if (oResult.gv_url1) {
				this.openExtApps(oResult.gv_url1);
			}
		},

		handleRFCListLoaded: function (oEvent) {
			var aRFCList = [];
			var aResults = oEvent.getParameter("rfcList");
			aResults.forEach(function (oResult, index) {
				var oRFCItem = {
					FieldId: oResult.FieldRelated,
					FieldName: "ZZCR_NUMBER",
					FieldValue: oResult.FieldValue.split('|')[1],
					FieldValue1: oResult.FieldValue.split('|')[0],
					FieldId1: oResult.FieldId
				};
				aRFCList.push(oRFCItem);
			}, this);
			this.timeSheet.tsJSONModel.setProperty("/dropDowns/rfcList", aRFCList);
		},
		handleDocVisit: function (oEvent) {

			if (!this._oDocOpen) {
				var fragmentId = this.getView()
					.createId("docVisit");
				this._oDocOpen = sap.ui.xmlfragment(fragmentId, "kno.tne.timesheet.newTimeSheet.view.docsVisit", this);
				this.getView()
					.addDependent(this._oDocOpen);
			}

			this._oDocOpen.open();

		},
		handleMessageTriggered: function (oEvent) {
			// if (!this.arrMessageModel) {
			this.arrMessageModel = [];
			var arrMessages = [];
			// var arrMsgModel;
			var oMessages;
			// }
			arrMessages = oEvent.getParameter("Messages");

			//.reduce((x, y) => x.findIndex(e => e.message == y.message) < 0 ? [...x, y] : x, []);

			var arrSheetMessages = [];

			if (arrMessages.length > 0) {
				arrMessages = this.removeDuplicates(arrMessages);

				if (arrMessages && arrMessages[0].type === "Success") {
					this.timeSheet.getDoctorsVisitDetails();
				}
				var sSheetErrorFlag = false;
				for (var j = 0; j < arrMessages.length; j++) {
					// oMessages = {
					// 	type: arrMessages[j].type,
					// 	message: arrMessages[j].message
					// };
					oMessages = arrMessages[j];

					if (arrMessages[j].target === "SHEET") {
						arrSheetMessages.push(oMessages);
						sSheetErrorFlag = true;
					} else {
						if (this.arrMessageModel.length > 0) {

							var isExists = false;
							this.arrMessageModel.forEach(function (msg, index) {

								if (msg.message === oMessages.message) {
									isExists = true;

								}

							}, this);

							if (!isExists) {
								this.arrMessageModel.push(oMessages);
							}

						} else {

							this.arrMessageModel.push(oMessages);

						}
					}
				}
			}

			// if (arrSheetMessages.length > 0) {
			// 	var eventBus = sap.ui.getCore()
			// 		.getEventBus();
			// 	eventBus.publish("DisPlaySMessages", "onDisPlaySMessages", {
			// 		sheetMessages: arrSheetMessages
			// 	});
			// }
			this.getView()
				.getModel("mMessageModel")
				.setProperty("/items", this.arrMessageModel);

			// this.getView()
			// 	.getModel("TimeSheetGrid")
			// 	.refresh(true);

			if (sSheetErrorFlag && this.arrMessageModel.length === 0) {
				if (!this.extraHoursDialog) {
					this.oAddHoursComponent = sap.ui.getCore()
						.createComponent({
							name: "kno.tne.timesheet.newTimeSheet.components.AdditionalHours",
							componentData: {
								oDataModel: this.getOwnerComponent()
									.getModel(),
								oModelTime: this.timeSheet,
								oMessageModel: arrSheetMessages
							}
						});

					this.extraHoursDialog = new sap.m.Dialog({
						contentWidth: "70%",
						contentHeight: "70%",
						showHeader: false,
						content: [new sap.ui.core.ComponentContainer({
								width: "100%",
								height: "100%"
							})
							.setComponent(this.oAddHoursComponent)
						]
					});
				} else {
					//Show messages on the dialog 
					//Trigger event on event but to notify that message model is updated
				}
				this.extraHoursDialog.open();
				var eventBus = sap.ui.getCore()
					.getEventBus();
				eventBus.publish("DisPlaySMessages", "onDisPlaySMessages", {
					sheetMessages: arrSheetMessages
				});
			}

		},
		handleTSModelInitialized: function () {
			//	this.timeSheet.getDelegateSet();
			this.getView()
				.setBusy(false);
		},
		handleTsModelInitialInfos: function () {

		},
		handleTsModelWorkCalendars: function () {
			var header = this.getView()
				.byId("header");
			header.rerender();
		},
		handleTsModelTimeDataList: function () {
			this.getView()
				.setBusy(false);
		},
		handleTsModelProfileFields: function () {

		},
		handleTSModelactivityCodesLoaded: function (evt) {
			this.getView()
				.setBusy(false);

		},
		handleTSModelAATypesLoaded: function (evt) {
			this.getView()
				.setBusy(false);

		},
		handleTSSaveComplete: function (evt) {
			this.getView()
				.setBusy(false);
		},
		// Data Error Handler
		onDataError: function (oError) {
			/*TODO: Error Handling when required */
		},
		/* Methods to handle weekly view ui events*/

		updateAllocationList: function (recUSedCodes) {
			var arrAllocationList = this.timeSheet.weeklyTable.allocationList;

			recUSedCodes.forEach(function (alloc, index) {

				var mAllocModel = {
					FieldId: alloc.FieldName + "|" + alloc.FieldId,
					FieldName: alloc.FieldId,
					FieldValue: alloc.FieldValue
				};

				arrAllocationList.push(mAllocModel);

			}, this);

			var arrUpdAllocList = this.removeDuplicatesAlloc(arrAllocationList);

			this.timeSheet.weeklyTable.allocationList = arrUpdAllocList;
			// this.getView()
			// 	.getModel("TimeSheetGrid")
			// 	.refresh(true);

		},

		removeDuplicatesAlloc: function (arr) {

			arr.sort(function (a, b) {
				return (a.FieldId > b.FieldId) ? 1 : ((b.FieldId > a.FieldId) ? -1 : 0);
			});
			for (var i = 1; i < arr.length;) {
				if (arr[i - 1].FieldId == arr[i].FieldId) {
					arr.splice(i, 1);
				} else {
					i++;
				}
			}
			return arr;

		},
		handleExpand: function (evt) {

			if (evt.getSource()
				.getStatus() !== "LOCK") {
				if (evt.getParameter("expand")) {
					this.getView()
						.setBusy(true);
					/* initiate call to get the list of secondary allocation dropdowns */
					this.timeSheet.getAcivityCodes(evt.getParameter("index"));

					this.timeSheet.getRfcCodes(evt.getParameter("index"));

					this.timeSheet.getAATypeCodes(evt.getParameter("index"));
					var arrRecUsedCoes = this.timeSheet.tsJSONModel.getData()
						.dropDowns.recentlyUsedCodes;
					this.updateAllocationList(arrRecUsedCoes);
				} else {
					/*Trigger Validation for the row data */
				}
			}
		},
		handleAsgmntChange: function (evt) {

			var ctxPath = evt.getSource()
				.getBindingInfo("selectedKey")
				.binding.getContext()
				.getPath();
			var path = evt.getSource()
				.getBinding("selectedKey")
				.getPath();
			var index = ctxPath.substr(ctxPath.lastIndexOf("/") + 1);
			var value = evt.getSource()
				.getSelectedKey();
			this.timeSheet.setRowChanged(ctxPath, path, "ASGNMT");
			this.timeSheet.tsJSONModel.setProperty("/timeEntries/rowTable/" + index + "/assignment/ZZ_ACTIVITY_ID", '');
			this.timeSheet.tsJSONModel.setProperty("/timeEntries/rowTable/" + index + "/assignment/ZZCR_NUMBER", '');
			this.timeSheet.tsJSONModel.setProperty("/timeEntries/rowTable/" + index + "/assignment/AWART", '');
			this.timeSheet.getAcivityCodes(index, value);
			this.timeSheet.getAATypeCodes(index);
			this.timeSheet.getRfcCodes(index, value);
			this.getView()
				.setBusy(true);

			// var sAllocationPath = ctxPath + "/allocationList";
			// var arrAllocationitems = this.getView()
			// 	.getModel("TimeSheetGrid")
			// 	.getProperty(sAllocationPath);

			// var sAllocationTxt;

			// for (var i = 0; i < arrAllocationitems.length; i++) {
			// 	if (value === arrAllocationitems[i].FieldId) {
			// 		sAllocationTxt = arrAllocationitems[i].FieldValue;
			// 		break;
			// 	}
			// }

			// var oWeeklyTable = this.getView()
			// 	.getModel("TimeSheetGrid")
			// 	.getProperty(ctxPath);

			// oWeeklyTable.assignment.allocDescr = sAllocationTxt;

			this.onDonutModelPopulate();

		},
		handleActivityChange: function (evt) {
			/* mark as changed */
			var contextPath = evt.getSource()
				.getBinding("selectedKey")
				.getContext()
				.getPath();
			var path = evt.getSource()
				.getBinding("selectedKey")
				.getPath();

			var sActText = evt.getSource()
				.getSelectedItem()
				.getProperty("text");
			var sPropPath = contextPath + "/workDays/0/timeEntry/ZZ_ACTIVITY_ID_Desc";
			this.getView()
				.getModel("TimeSheetGrid")
				.setProperty(sPropPath, sActText);
			// this.getView()
			// 	.getModel("TimeSheetGrid")
			// 	.refresh(true);
			this.timeSheet.setRowChanged(contextPath, path);
		},
		handleAWARTChange: function (evt) {
			/* mark as changed */
			var contextPath = evt.getSource()
				.getBinding("selectedKey")
				.getContext()
				.getPath();
			var path = evt.getSource()
				.getBinding("selectedKey")
				.getPath();
			this.timeSheet.setRowChanged(contextPath, path);

			var arrAwartItems = this.getView()
				.getModel("TimeSheetGrid")
				.getProperty("/dropDowns/AATypes");

			var sAwartTxt;
			var value = evt.getSource()
				.getSelectedKey();
			for (var i = 0; i < arrAwartItems.length; i++) {
				if (value === arrAwartItems[i].FieldId) {
					sAwartTxt = arrAwartItems[i].FieldValue;
					break;
				}
			}

			// contextPath = contextPath + "/assignment/AWART";
			// var oWeeklyTable = this.getView()
			// 	.getModel("TimeSheetGrid")
			// 	.setProperty(contextPath, sAwartTxt);

			// oWeeklyTable.assignment.AWART = sAwartTxt;
		},
		handleRFCChange: function (evt) {
			/* mark as changed */
			var contextPath = evt.getSource()
				.getBinding("selectedKey")
				.getContext()
				.getPath();
			var path = evt.getSource()
				.getBinding("selectedKey")
				.getPath();
			this.timeSheet.setRowChanged(contextPath, path);
		},
		handleHoursChanged: function (evt) {
			// /* mark as changed */
			// /* call totls recalculate */
			var contextPath = evt.getParameter("contextPath");
			var path = evt.getParameter("sPath");
			// var oModel = this.getView()
			// 	.getModel("TimeSheetGrid");
			// var hours = kno.tne.timesheet.newTimeSheet.lib.formatters.TimeSheetFormatter.formatHours(oModel.getProperty(contextPath + "/" +
			// 	path));
			// oModel.setProperty(contextPath + "/" + path, hours);

			// this.timeSheet.setTimeEntryChanged(contextPath, path);
			// this.timeSheet.calculateDailyTotals()
			this.timeSheet.setTimeEntryChanged(contextPath, path);
		},
		handleHoursFocused: function (evt) {

			// var arrContent = evt.getSource()
			// 	.getDayContent();

			var path = evt.getParameter("sPath");

			// for (var i = 0; i < arrContent.length; i++) {
			// 	if (parseInt(path.split("/")[1]) === i) {
			// 		arrContent[i].addStyleClass("knoCellColor");
			// 	} else {
			// 		arrContent[i].removeStyleClass("knoCellColor");
			// 	}
			// }

			var contextPath = evt.getParameter("contextPath");

			var timeEntryPath = path.substring(0, path.lastIndexOf('/'));
			var workDayPath = timeEntryPath.substring(0, timeEntryPath.lastIndexOf('/'));
			var index = parseInt(workDayPath.substring(workDayPath.lastIndexOf('/') + 1), 10 /*radix for Decimal is 10*/ );
			this.timeSheet.setDetailVisible(contextPath, index);
		},
		handleNotesChanged: function (evt) {
			var contextPath = evt.getSource()
				.getBinding("value")
				.getContext()
				.getPath();
			var path = evt.getSource()
				.getBinding("value")
				.getPath();
			this.timeSheet.setTimeEntryChanged(contextPath, path);
		},
		onCalendarDisplay: function (oEvent) {

			var sFdWeek = sap.ui.core.LocaleData.getInstance(sap.ui.getCore()
					.getConfiguration()
					.getFormatSettings()
					.getFormatLocale())
				.mData["weekData-firstDay"];

			if (!this._oCalendarPopup) {
				this._oCalendar = new sap.ui.unified.Calendar({
					select: jQuery.proxy(this.handleCalendarSelect, this),
					firstDayOfWeek: sFdWeek,
					singleSelection: true
				});
				this._oCalendarPopup = new sap.m.ResponsivePopover({
					content: [this._oCalendar],
					showTitle: false
				});
			}
			this._oCalendar.focusDate(kno.tne.timesheet.newTimeSheet.model.getJsDate(this.timeSheet.startDate));
			this._oCalendarPopup.openBy(oEvent.getSource());
		},
		handleCalendarSelect: function (oEvent) {

			this.getView()
				.setBusy(true);
			var timeEntries = this.timeSheet.prepareTimeEntriesforSave();
			this._oCalendarPopup.close();
			// if (timeEntries.length === 0) {
			// 	this.getView()
			// 		.setBusy(true);
			// 	this.timeSheet.moveToDate(this._oCalendar.getSelectedDates()[0].getStartDate());
			// }

			if (this.checkHasChanges()) {
				sap.m.MessageBox.show(
					"Unsaved data will be lost. Do you want to proceed?", {
						icon: sap.m.MessageBox.Icon.INFORMATION,
						title: "Warning",
						actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
						onClose: jQuery.proxy(function (oAction) {

							if (oAction === sap.m.MessageBox.Action.YES) {
								this.timeSheet.moveToDate(this._oCalendar.getSelectedDates()[0].getStartDate());
							}

							if (oAction === sap.m.MessageBox.Action.NO) {
								this.getView()
									.setBusy(false);
							}

						}, this)
					}
				);
			} else {
				this.timeSheet.moveToDate(this._oCalendar.getSelectedDates()[0].getStartDate());
			}

		},
		handleSave: function () {
			this.arrMessageModel = [];
			this.getView()
				.getModel("mMessageModel")
				.setProperty("/items", this.arrMessageModel);
			var timeEntries = this.timeSheet.prepareTimeEntriesforSave();
			if (timeEntries.length === 0) {
				sap.m.MessageBox.information(
					"No changes to Save.", {
						styleClass: "sapUiSizeCompact"
					}
				);
			} else {

				// this.timeSheet.CheckESU(timeEntries);

				var esuTimeEntries = this.prepareDataForESUCheck(timeEntries);

				if (esuTimeEntries.length > 0) {
					this.timeSheet.CheckESU(esuTimeEntries);
				} else {
					this.getView()
						.setBusy(true);
					this.timeSheet.checkAndSave(timeEntries);
				}

			}
		},

		handleIOTime: function () {
			var lv_entryTimeRequired = true;
			if (lv_entryTimeRequired) {
				if (!this._manageStartTime) {
					this._manageStartTime = sap.ui.xmlfragment(this.getView()
						.getId() + "ManageStartTime",
						"kno.tne.timesheet.newTimeSheet.view.ManageStartTime", this);

				}

				this.getView()
					.addDependent(this._manageStartTime);

				this.timeSheet.getTimeLogData();

			}
		},
		onClose: function () {
			if (this._manageStartTime) {
				this._manageStartTime.close();
			}
		},

		onCancel: function () {
			if (this._manageTime) {
				this._manageTime.close();
			}
		},
		handleRefresh: function () {
			// var timeEntries = this.timeSheet.prepareTimeEntriesforSave();
			// if (timeEntries.length === 0) {
			// 	this.getView()
			// 		.setBusy(true);
			// 	this.timeSheet.refresh();
			// }

			if (this.checkHasChanges()) {
				sap.m.MessageBox.show(
					"Unsaved data will be lost. Do you want to proceed?", {
						icon: sap.m.MessageBox.Icon.INFORMATION,
						title: "Warning",
						actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
						onClose: jQuery.proxy(function (oAction) {

							if (oAction === sap.m.MessageBox.Action.YES) {
								this.timeSheet.refresh();
							}

							if (oAction === sap.m.MessageBox.Action.NO) {
								this.getView()
									.setBusy(false);
							}

						}, this)
					}
				);
			} else {
				this.timeSheet.refresh();
			}
		},

		handleAddCode: function () {
			// if (!this.searchDialogTimer) {
			this.oGenericComponent = sap.ui.getCore()
				.createComponent({
					name: "kno.tne.timesheet.newTimeSheet.components.Search",
					componentData: {
						startupParameters: {
							oParameters: {
								"type": "AddCodeGeneral",
								"RecentlyUsed": this.timeSheet.tsJSONModel.getProperty("/dropDowns/recentlyUsedCodes"),
							}
						},
						oModel: this.timeSheet
					}
				});

			this.searchDialog = new sap.m.Dialog({
				contentWidth: "50%",
				contentHeight: "60%",
				resizable: true,
				showHeader: false,
				content: [new sap.ui.core.ComponentContainer({
						width: "100%",
						height: "100%"
					})
					.setComponent(this.oGenericComponent)
				]
			});
			// }
			this.searchDialog.open();
		},
		handleAddCodeTimer: function () {
			// if (!this.searchDialogTimer) {
			this.oGenericComponentTimer = sap.ui.getCore()
				.createComponent({
					name: "kno.tne.timesheet.newTimeSheet.components.Search",
					componentData: {
						startupParameters: {
							oParameters: {
								"type": "AddCode",
								"RecentlyUsed": this.timeSheet.tsJSONModel.getProperty("/dropDowns/recentlyUsedCodes"),
							}
						},
						oModel: this.timeSheet
					}
				});

			this.searchDialog = new sap.m.Dialog({
				contentWidth: "50%",
				contentHeight: "60%",
				resizable: true,
				showHeader: false,
				content: [new sap.ui.core.ComponentContainer({
						width: "100%",
						height: "100%"
					})
					.setComponent(this.oGenericComponentTimer)
				]
			});
			// }

			//calling execute search to populate the existing 

			var rowTable = this.timeSheet.tsJSONModel.getProperty("/timeEntries/rowTable");
			var tmpArr = [];
			for (var i in rowTable) {
				tmpArr.push(rowTable[i].AATypes[0]);
			}
			this.searchDialog.open();
		},
		handleNavNext: function (evt) {
			this.getView()
				.setBusy(true);

			if (this.checkHasChanges()) {
				sap.m.MessageBox.show(
					"Unsaved data will be lost. Do you want to proceed?", {
						icon: sap.m.MessageBox.Icon.INFORMATION,
						title: "Warning",
						actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
						onClose: jQuery.proxy(function (oAction) {

							if (oAction === sap.m.MessageBox.Action.YES) {
								this.timeSheet.moveFrame(7);
							}

							if (oAction === sap.m.MessageBox.Action.NO) {
								this.getView()
									.setBusy(false);
							}

						}, this)
					}
				);
			} else {
				this.timeSheet.moveFrame(7);
			}

		},

		checkHasChanges: function () {
			var arrRows = this.timeSheet.weeklyTable.rowTable;
			var oRow;
			var sReturn = false;
			for (var indx = 0; indx < arrRows.length; indx++) {
				oRow = arrRows[indx].workDays;

				oRow.forEach(function (wday, index) {
					if (wday.timeEntry.STATUS === "CHGD") {
						sReturn = true;
					}
				}, this);

			}

			return sReturn;
		},
		handleNavPrev: function (evt) {
			this.getView()
				.setBusy(true);

			if (this.checkHasChanges()) {
				sap.m.MessageBox.show(
					"Unsaved data will be lost. Do you want to proceed?", {
						icon: sap.m.MessageBox.Icon.INFORMATION,
						title: "Warning",
						actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
						onClose: jQuery.proxy(function (oAction) {

							if (oAction === sap.m.MessageBox.Action.YES) {
								this.timeSheet.moveFrame(-7);
							}

							if (oAction === sap.m.MessageBox.Action.NO) {
								this.getView()
									.setBusy(false);
							}

						}, this)
					}
				);
			} else {
				this.timeSheet.moveFrame(-7);
			}

			// this.timeSheet.moveFrame(-7);

		},
		handleNavCal: function (evt) {
			// this.timeSheet.movetoDate(evt.getSouce())	
		},
		openStopWatch: function () {
			if (!this.stopWatchDialog) {
				this.oStopWatchComponent = sap.ui.getCore()
					.createComponent({
						name: "kno.tne.timesheet.newTimeSheet.components.StopWatch",
					});

				this.stopWatchDialog = new sap.m.Dialog({
					contentWidth: "30%",
					contentHeight: "35%",
					resizable: true,
					showHeader: false,
					content: [new sap.ui.core.ComponentContainer({
							width: "100%",
							height: "100%"
						})
						.setComponent(this.oStopWatchComponent)
					]
				});
			} else {
				this.oStopWatchComponent.init();
			}
			this.stopWatchDialog.open();
		},

		onAddCode: function (sChannel, sEvent, sData) {
			var sData = sData.costObjects;
			var isAlredayAddedCostObject = false;
			if (this.searchDialog) {
				this.searchDialog.close();

				var arrRowTable = this.timeSheet.weeklyTable.rowTable;
				var currentDate = this.timeSheet.getSapDate();

				var arrWorkDays = [];

				arrRowTable.forEach(function (oTimeSheetRow, indx) {
					if (sData[0].FieldId === oTimeSheetRow.assignment.allocationId) {
						isAlredayAddedCostObject = true;
						arrWorkDays = oTimeSheetRow.workDays;

						for (var i = 0; i < arrWorkDays.length; i++) {

							if (arrWorkDays[i].timeEntry.WORKDATE === currentDate) {
								if (arrWorkDays[i].timeEntry.TIME) {
									arrWorkDays[i].timeEntry.TIME = parseFloat(arrWorkDays[i].timeEntry.TIME) + this.stopWatchTime;
								} else {
									arrWorkDays[i].timeEntry.TIME = this.stopWatchTime;
								}
							}
						}

					}
				}, this);

				var oItem_0 = this.getView()
					.byId("timesheetList")
					.getItems()[0];
				if (oItem_0) {
					oItem_0.expand();
				}

			}

			if (!isAlredayAddedCostObject) {
				this.timeSheet.addNewRows(sData, this.stopWatchTime);
			} else {
				// this.getView()
				// 	.getModel("TimeSheetGrid")
				// 	.refresh(true);
			}

			if (this.stopWatchDialog && this.stopWatchDialog.isOpen()) {
				this.stopWatchDialog.close();
			}

			this.onDonutModelPopulate();
		},

		onAddCodeGeneral: function (sChannel, sEvent, sData) {
			var sData = sData.costObjects;
			if (this.searchDialog) {
				this.searchDialog.close();
				this.timeSheet.addNewRows(sData);
				var oItem_0 = this.getView()
					.byId("timesheetList")
					.getItems()[0];
				if (oItem_0) {
					oItem_0.expand();
				}
				this.onDonutModelPopulate();
			}

		},

		onAddCodeRec: function (sChannel, sEvent, sData) {
			var sData = sData.costObjects;
			if (this.searchDialogRec) {
				this.searchDialogRec.close();
				this.selectedItem = this.oComboAlloc.getParent()
					.getParent();
				var ctxPath = this.selectedItem.getBindingContextPath();

				var path = "assignment/allocation";

				var index = ctxPath.substr(ctxPath.lastIndexOf("/") + 1);
				var value = sData[0].FieldName + "|" + sData[0].FieldId;
				if (sData[0].FieldName === "AWART") {
					// this.timeSheet.weeklyTable.rowTable[index].assignment.AWART = sData[0].FieldId;
					// this.timeSheet.weeklyTable.rowTable[index].assignment.allocation = "--";
					// this.timeSheet.weeklyTable.rowTable[index].assignment.allocationId = "--";
					// this.timeSheet.weeklyTable.rowTable[index].assignment.POSID = undefined;
					// this.timeSheet.weeklyTable.rowTable[index].assignment.RAUFNR = undefined;
					var aEntry = {};
					aEntry.AWART = sData[0].FieldId;
					aEntry.AWART_COST = "AWART";
					aEntry.AWART_DESCR = "AbsenceType";
					this.timeSheet.weeklyTable.rowTable[index].assignment = new kno.tne.timesheet.newTimeSheet.model.TSAssignment(aEntry);
					this.timeSheet.weeklyTable.rowTable[index].assignment.calculateAllocation(aEntry);
					this.timeSheet.weeklyTable.checkAddAllocation();
					this.timeSheet.tsJSONModel.setProperty('/timeEntries/rowTable/' + index, this.timeSheet.weeklyTable.rowTable[index]);
				} else {
					this.updateAllocationList(sData);
					this.oComboAlloc.setSelectedKey(value);
				}
				this.timeSheet.setRowChanged(ctxPath, path, "ASGNMT");
				this.timeSheet.getAcivityCodes(index, value);
				this.timeSheet.getAATypeCodes(index);
				this.timeSheet.getRfcCodes(index, value);
				this.getView()
					.setBusy(true);
			}

			this.onDonutModelPopulate();

		},

		onCancelCode: function () {

			// var sNewRow;
			if (this.searchDialog) {
				this.searchDialog.close();
			}
			if (this.searchDialogRec) {
				this.searchDialogRec.close();
			}

		},

		onCancelWatch: function () {

			if (this.stopWatchDialog && this.stopWatchDialog.isOpen()) {
				this.stopWatchDialog.close();
				// this.updateStopWatchTime(this.stopWatchTime);
			}

		},

		onCanExtraHours: function () {

			if (this.extraHoursDialog && this.extraHoursDialog.isOpen()) {
				this.extraHoursDialog.close();
			}

		},

		handlAddTime: function (sChannel, sEvent, sData) {
			this.stopWatchTime = sData.time;
			if (this.stopWatchDialog && this.stopWatchDialog.isOpen()) {
				this.stopWatchDialog.close();
				// this.updateStopWatchTime(this.stopWatchTime);
			}
			this.handleAddCodeTimer();
		},

		updateStopWatchTime: function () {
			var arrWorkingDays = this.timeSheet.workingDays;
			var sPath;
			for (var i = 0; i < arrWorkingDays.length; i++) {

				if (arrWorkingDays[i].date === this.timeSheet.getSapDate()) {
					sPath = "workDays/" + i + "/timeEntry/TIME";
					break;
				}

			}

			var contextPath = "/timeEntries/rowTable/0";
			this.timeSheet.setTimeEntryChanged(contextPath, sPath);

		},

		onShowDelegate: function () {
			this.timeSheet.getDelegateSet();
		},

		handleDelegates: function (oEvent) {
			var arrDelegateSet = oEvent.getParameter("Delegates");
			var arrDelegates = [];
			if (arrDelegateSet && arrDelegateSet.length > 0) {
				for (var i = 0; i < arrDelegateSet.length; i++) {
					var delegate = {
						Pernr: arrDelegateSet[i].DelegatePernr,
						fName: arrDelegateSet[i].FullName
					};

					if (arrDelegateSet[i].Default) {
						this.getView()
							.byId("idDelegates")
							.setSelectedItem(delegate);

						this.getView()
							.byId("idDelegates")
							.setSelectedKey(delegate.Pernr);
					}

					arrDelegates.push(delegate);
				}
			}

			this.getView()
				.getModel("mDelegate")
				.setProperty("/items", arrDelegates);
		},

		onChangeDelegate: function (oEvent) {
			var sPernr = oEvent.getSource()
				.getSelectedKey();
			this.timeSheet.init(sPernr);
		},

		onHelp: function () {
			var helpURL;

			helpURL = "http://portal01prd.amr.kworld.kpmg.com/sync/Lists/LearningCenter/TimeManagement.aspx";

			// window.open(helpURL, "_blank",
			// 	"directories=no, status=no, menubar=no, scrollbars=yes, resizable=yes,width=" + window.innerWidth+", height=" + window.innerHeight+",top=0,left=0,titlebar=no");
			//INC- 00340219 height,width changed
			window.open(helpURL, "_blank",
				"directories=no, status=no, menubar=no, scrollbars=yes, resizable=yes,width=1100, height=620,top=0,left=0,titlebar=no");
			//"directories=no, status=no, menubar=no, scrollbars=yes, resizable=yes,width=620, height=1100,top=0,left=0,titlebar=no");
		},

		confirmOnDelete: function (oEvent) {
			this.oEvent = jQuery.extend(true, {}, oEvent);
			sap.m.MessageBox.show(
				this.i18n.getProperty("DELETE_RECORD_MSG"), {
					icon: sap.m.MessageBox.Icon.INFORMATION,
					title: this.i18n.getProperty("DELETE_RECORD"),
					actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
					onClose: jQuery.proxy(function (oAction) {

						if (oAction === sap.m.MessageBox.Action.YES) {
							this.onDeleteRecord(this.oEvent);
						}

						if (oAction === sap.m.MessageBox.Action.NO) {
							this.getView()
								.setBusy(false);
						}

					}, this)
				}
			);

		},

		onDeleteRecord: function (oEvent) {
			this.arrMessageModel = [];
			this.getView()
				.getModel("mMessageModel")
				.setProperty("/items", this.arrMessageModel);

			var oSelectedIndx = oEvent.getSource()
				.getBindingContextPath()
				.split("/")
				.pop();

			var timeEntries = this.timeSheet.prepareTimeEntrieforDelete(oSelectedIndx);
			if (timeEntries.length === 0) {
				this.timeSheet.weeklyTable.rowTable.splice(oSelectedIndx, 1);
				this.timeSheet.tsJSONModel.setProperty("/timeEntries/rowTable", this.timeSheet.weeklyTable.rowTable);
			} else {
				this.getView()
					.setBusy(true);
				this.timeSheet.deleteTimeEntries(timeEntries);
			}

		},

		copyToCurrentWeek: function () {

			this.timeSheet.copyTimeSheet();

		},

		onCopy: function () {
			sap.m.MessageBox.show(
				"Copy chargeable/non-chargeable code from previous week to current week?", {
					icon: sap.m.MessageBox.Icon.INFORMATION,
					title: "Confirm Copy",
					actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
					onClose: jQuery.proxy(function (oAction) {

						if (oAction === sap.m.MessageBox.Action.YES) {
							this.copyToCurrentWeek();
						}

						if (oAction === sap.m.MessageBox.Action.NO) {
							this.getView()
								.setBusy(false);
						}

					}, this)
				}
			);

		},

		onCloseDocVisit: function () {
			if (this._oDocOpen) {
				this._oDocOpen.close();
			}
		},

		onDonutModelPopulate: function () {
			var mDonutModel = this.getView()
				.getModel("TimeSheetGrid")
				.getProperty("/timeEntries");

			var arrAllocList = mDonutModel.rowTable;
			var arrTimeSheetData = mDonutModel.rowTable;

			var sCostObj, sCostObjDesc;
			var arrCostSummary = [];
			var oCostAssign;

			for (var i = 0; i < arrAllocList.length; i++) {

				oCostAssign = arrAllocList[i].assignment;

				var sCostHours = 0;

				for (var j = 0; j < arrTimeSheetData.length; j++) {

					if (oCostAssign.RAUFNR) {
						if (arrTimeSheetData[j].assignment["RAUFNR"] && arrTimeSheetData[j].assignment["RAUFNR"] === oCostAssign.RAUFNR) {
							sCostObj = arrTimeSheetData[j].assignment["RAUFNR"];
							sCostObjDesc = oCostAssign.allocDescr;
							sCostHours = sCostHours + parseFloat(arrTimeSheetData[j].Total);
						}
					};

					if (oCostAssign.POSID) {
						if (arrTimeSheetData[j].assignment["POSID"] && arrTimeSheetData[j].assignment["POSID"] === oCostAssign.POSID) {
							sCostObj = arrTimeSheetData[j].assignment["POSID"];
							sCostObjDesc = oCostAssign.allocDescr;
							sCostHours = sCostHours + parseFloat(arrTimeSheetData[j].Total);

						} else {
							sCostObj = oCostAssign.POSID;
							sCostObjDesc = oCostAssign.allocDescr;
							// sCostHours = sCostHours + parseFloat(arrTimeSheetData[j].TIME);
						}

					};

					if (oCostAssign.AWART && !oCostAssign.RAUFNR && !oCostAssign.POSID) {

						if (!arrTimeSheetData[j].assignment["RAUFNR"] && !arrTimeSheetData[j].assignment["POSID"] && oCostAssign.AWART ===
							arrTimeSheetData[j].AWART) {
							sCostObj = arrTimeSheetData[j].assignment["AWART"];
							sCostObjDesc = arrTimeSheetData[j].assignment["AWART_Desc"];
							sCostHours = sCostHours + parseFloat(arrTimeSheetData[j].Total);
						}

					};

				}

				var mCostSummaryModel = {
					CostObj: sCostObj,
					CostDesc: sCostObjDesc,
					CostHours: sCostHours,
					CostColor: ""
				};

				arrCostSummary.push(mCostSummaryModel);

			}

			arrCostSummary.sort(function (a, b) {
				return (a.CostObj > b.CostObj) ? 1 : ((b.CostObj > a.CostObj) ? -1 : 0);
			});
			for (var i = 1; i < arrCostSummary.length;) {
				if (arrCostSummary[i - 1].CostObj === arrCostSummary[i].CostObj) {
					arrCostSummary.splice(i, 1);
				} else {
					i++;
				}
			}

			var arrClrPllet = this.getView()
				.byId("idVizFrame")
				.getVizProperties()
				.plotArea.colorPalette;

			for (var i = 0; i < arrCostSummary.length; i++) {
				arrCostSummary[i].CostColor = sap.ui.core.theming.Parameters.get(arrClrPllet[i]);
			}

			this.getView()
				.getModel("mSummaryModel")
				.setProperty("/items", arrCostSummary);

			// this.getView()
			// 	.getModel("mSummaryModel")
			// 	.refresh(true);

			var mSummaryModel = this.getView()
				.getModel("mSummaryModel");

			this.getView()
				.byId("idVizFrame")
				.setModel(mSummaryModel, "mSummaryModel");

		},

		prepareDataForESUCheck: function (timeEntries) {

			var ifExists, arrTimeEntries = [];

			if (timeEntries && timeEntries.length > 0) {
				var arrTimeSheetData = this.timeSheet.tsJSONModel.oData.timeEntries.timesheetData;

				for (var i = 0; i < timeEntries.length; i++) {

					ifExists = false;

					if (timeEntries[i].oRow.assignment.POSID) {
						arrTimeSheetData.forEach(function (oData, index) {

							if (oData.POSID === timeEntries[i].oRow.assignment.POSID) {

								ifExists = true;
								// break;
							}

						}, this);
						if (!ifExists) {

							arrTimeEntries.forEach(function (oEntry, index) {

								if (oEntry.oRow.assignment.POSID === timeEntries[i].oRow.assignment.POSID) {
									ifExists = true;
								}

							}, this);

							if (!ifExists) {
								/*change start on 17-May-201 by Satabdi Das*/
								var nBookedTime = timeEntries[i].timeEntry.TIME;
								if (nBookedTime > 24) {
									var msg = "Time booking should not exceed 24 hours";
									sap.m.MessageBox.error(msg, {
										title: "Error", // default
										textDirection: sap.ui.core.TextDirection.Inherit // default
									});
									return;
								} else {
									arrTimeEntries.push(timeEntries[i]);
								}
								/*Change end on 17 th May 2021 by Satabdi Das*/
							}
						}
					}

				}

				return arrTimeEntries;

			}
		},

		updateDonutChart: function () {
			// this.onDonutModelPopulate();
		},

		getRandomColor: function () {
			var letters = '0123456789ABCDEF';
			var color = '#';
			for (var i = 0; i < 6; i++) {
				color += letters[Math.floor(Math.random() * 16)];
			}
			return color;
		},

		removeDuplicates: function (arr) {

			arr.sort(function (a, b) {
				return (a.message > b.message) ? 1 : ((b.message > a.message) ? -1 : 0);
			});
			for (var i = 1; i < arr.length;) {
				if (arr[i - 1].message === arr[i].message && arr[i - 1].propertyRef === arr[i].propertyRef) {
					arr.splice(i, 1);
				} else {
					i++;
				}
			}
			return arr;

		},
		/*
		To validate time entry before saving them 
		*/

		readExistingTimeEntry: function (oEvent) {
			/*submit successfull message should not be displayed on save click */
			kno.tne.timesheet.newTimeSheet.model.KeyIsSubmitMsgShow = false;
			this.timeSheet.getExistingTimeData(oEvent);
		},
		timeMisMatchFound: function () {
			var fragmentId = this.getView()
				.createId("timeMisMatch");
			// this.getView()
			// 	.setBusy(true);
			if (!this._otimeMisMatch) {
				this._otimeMisMatch = sap.ui.xmlfragment(fragmentId, "kno.tne.timesheet.newTimeSheet.view.TimeEntryMisMatch", this);
				this.getView()
					.addDependent(this._otimeMisMatch);
				// this._otimeMisMatch.setModel(oModelSummary);
			}
			this._otimeMisMatch.open();
		},
		onSaveConflictTime: function (oEvent) {
			// this.timeSheet.getInitialData();
			var arrNCRows = this.getNonConflictingRows();
			var timeEntry = this.timeSheet.tsJSONModel.getProperty("/updatedTimeEntry");
			this.timeSheet.onTimeDataListSuccess(timeEntry);
			var arrRows = this.timeSheet.tsJSONModel.oData.timeEntries.rowTable;

			arrNCRows.forEach(function (oNCRow, index) {
				arrRows.push(oNCRow);
			}, this);

			this.timeSheet.calculateDailyTotals();

			// this.timeSheet.tsJSONModel.refresh(true);
			// this.getView()
			// 	.getModel("TimeSheetGrid")
			// 	.refresh(true);

			this._otimeMisMatch.close();

			this.handleSave();

		},
		getNonConflictingRows: function () {
			var arrConflicts = this.timeSheet.tsJSONModel.getProperty("/FrontEndConflicts");
			var timeEntries = this.timeSheet.prepareTimeEntriesforSave();
			var ncEntries = [];

			var conFlag = false;

			timeEntries.forEach(function (oTimeEntry, index) {

				conFlag = false;

				for (var i = 0; i < arrConflicts.length; i++) {
					if (arrConflicts[i].INDEX === index) {
						conFlag = true;
					}
				}

				if (!conFlag) {
					ncEntries.push(oTimeEntry);
				}

			}, this);

			var arrRows = this.timeSheet.tsJSONModel.oData.timeEntries.rowTable;
			var arrWorkDays = [];
			var rowValid = false;
			var arrIndx = [];

			arrRows.forEach(function (oRow, index) {

				rowValid = false;
				arrWorkDays = oRow.workDays;

				for (var j = 0; j < ncEntries.length; j++) {

					if (ncEntries[j].oRow.assignment["POSID"] && oRow.assignment["POSID"] === ncEntries[j].oRow.assignment["POSID"]) {

						rowValid = true;

						for (var i = 0; i < arrWorkDays.length; i++) {

							if (arrWorkDays[i].timeEntry.WORKDATE !== ncEntries[j].timeEntry.WORKDATE) {
								arrWorkDays[i].timeEntry.isEmpty = true;
								arrWorkDays[i].timeEntry.TIME = "";
							}
						}

					}
					if (ncEntries[j].oRow.assignment["RAUFNR"] && oRow.assignment["RAUFNR"] === ncEntries[j].oRow.assignment["RAUFNR"]) {

						rowValid = true;

						for (var i = 0; i < arrWorkDays.length; i++) {

							if (arrWorkDays[i].timeEntry.WORKDATE !== ncEntries[j].timeEntry.WORKDATE) {
								arrWorkDays[i].timeEntry.isEmpty = true;
								arrWorkDays[i].timeEntry.TIME = "";
							}
						}

					}
					if (ncEntries[j].oRow.assignment["AWART"] & !ncEntries[j].oRow.assignment["RAUFNR"] && !ncEntries[j].oRow.assignment[
							"POSID"] && oRow.assignment["AWART"] ===
						ncEntries[j].oRow.assignment["AWART"]) {

						rowValid = true;

						for (var i = 0; i < arrWorkDays.length; i++) {
							if (arrWorkDays[i].timeEntry.WORKDATE !== ncEntries[j].timeEntry.WORKDATE) {
								arrWorkDays[i].timeEntry.isEmpty = true;
								arrWorkDays[i].timeEntry.TIME = "";
							}
						}

					}

				}

				if (!rowValid) {
					arrIndx.push(index);
				}
			}, this);

			// arrIndx = arrIndx.sort(function(a, b) {
			// 	return b - a;
			// });

			var sFlag = false;
			var retArr = [];

			arrRows.forEach(function (oRow, index) { //splice not working
				sFlag = false;
				for (var i = 0; i < arrIndx.length; i++) {
					if (index === parseInt(arrIndx[i])) {
						sFlag = true;
					}
				}
				if (!sFlag) {
					retArr.push(oRow);
				}
			}, this);

			if (ncEntries.length > 0) {

			} else {
				retArr = [];
			}

			return retArr;

		},
		cancelConflictTime: function () {
			this._otimeMisMatch.close();
		},
		handleSaveTest: function (oEvent) {
			this.timeSheet.testEventfun(oEvent);
		},
		onSubmitPress: function (oEvent) {
			var submitDialog = this.getView()
				.createId("submitDialog");
			if (!this._submitDialog) {
				this._submitDialog = sap.ui.xmlfragment(this.getView()
					.getId() + submitDialog,
					"kno.tne.timesheet.newTimeSheet.view.submitDialog", this);

			}
			this.getView()
				.getModel("TimeSheetGrid")
				.setProperty("/SubmitBtnEnable", false);
			this.getView()
				.addDependent(this._submitDialog);

			// this.byId(sap.ui.core.Fragment.createId(submitDialog, "disclaimerCheck")).setSelectede(false);	
			this.getView()
				.getModel("TimeSheetGrid")
				.setProperty("/DisclaimerCheck", false);
			this._submitDialog.open();
		},
		onCheckTermsCondition: function (oEvent) {
			if (oEvent.getSource()
				.getSelected()) {
				this.getView()
					.getModel("TimeSheetGrid")
					.setProperty("/SubmitBtnEnable", true);
			} else {
				this.getView()
					.getModel("TimeSheetGrid")
					.setProperty("/SubmitBtnEnable", false);
			}
		},
		onSubmitConfirm: function (oEvent) {

			kno.tne.timesheet.newTimeSheet.model.KeyIsTimeToSubmit = true;
			this.timeSheet.getExistingTimeData(oEvent);
			if (this._submitDialog) {
				this._submitDialog.close();
			}
		
			kno.tne.timesheet.newTimeSheet.model.KeyIsSubmitMsgShow = false;
		},
		onSubmitCancel: function (oEvent) {
			if (this._submitDialog) {
				this._submitDialog.close();
			}
		}

	});
});