jQuery.sap.declare("kno.tne.timesheet.newTimeSheet.model.TSWeeklytable");
jQuery.sap.declare("kno.tne.timesheet.newTimeSheet.model.TSWorkDay");
jQuery.sap.declare("kno.tne.timesheet.newTimeSheet.model.TSAssignment");
jQuery.sap.declare("kno.tne.timesheet.newTimeSheet.model.TSRow");
jQuery.sap.declare("kno.tne.timesheet.newTimeSheet.model.TSCell");

var kno = kno || {};

kno.tne.timesheet.newTimeSheet.model.TSAssignment = function (timeEntry) {

	var aConfig = kno.tne.timesheet.newTimeSheet.model.TSAssignment.config.allocFields;

	aConfig.forEach(function (sField, indx) {
		if (timeEntry.hasOwnProperty(sField)) {
			this[sField] = timeEntry[sField];
		} else {
			this[sField] = undefined;
		}

	}, this);
	/* Apply default values */
	var aDefaults = kno.tne.timesheet.newTimeSheet.model.TSAssignment.config.defaults;
	// if (aDefaults) {
	// 	for (var j = 0; j < aDefaults.length; j++) {
	// 		var fieldName = aDefaults[j].fieldName;
	// 		var defaultValue = aDefaults[j].defaultValue;
	// 		if (!this[fieldName] || this[fieldName] === "") {
	// 			this[fieldName] = defaultValue;
	// 		}
	// 	}
	// }
	aConfig.forEach(function (sField, index) {
		if (aDefaults.hasOwnProperty(sField)) {
			if (!this[sField] || this[sField] === "") {
				this[sField] = aDefaults[sField];
			}
		}
	}, this);
	/*calculate the Allocation and Allocation Type  fields*/
	this.calculateAllocation(timeEntry);
};
kno.tne.timesheet.newTimeSheet.model.TSAssignment.prototype.calculateAllocation = function (timeEntry) {

	/* calcualte the ALLOCATION and ALLOCATION_TYPE field*/
	var oConfig = kno.tne.timesheet.newTimeSheet.model.TSAssignment.config;
	var aAllocTypes = oConfig.allocTypes;

	/* Check each Alloc Type and fit the time entry */
	for (var i = 0; i < aAllocTypes.length; i++) {
		var allocation = "";
		var allocationField = aAllocTypes[i].allocationField;
		var aAllocDescr = aAllocTypes[i].allocDescription;
		if (timeEntry[allocationField] && timeEntry[allocationField] !== "") {
			if (aAllocDescr.length === 0) {
				if (aAllocTypes[i].allocationType === "AWART") {
					this.allocation = "AWART|--";
					this.allocationType = aAllocTypes[i].allocationType;
					this.allocationId = "--";
					this.allocDescr = "Attendance / Absence Type";
				}
			} else {
				allocation = aAllocTypes[i].allocationType + "|" + timeEntry[allocationField];
				this.allocation = allocation;
				this.allocationType = aAllocTypes[i].allocationType;
				this.allocationId = timeEntry[allocationField];
				for (var k = 0; k < aAllocDescr.length; k++) {
					this.allocDescr = (this.allocDescr ? this.allocDescr + " - " : " ") + timeEntry[aAllocDescr[k]];
				}
			}
			break;
		}
	}
};
kno.tne.timesheet.newTimeSheet.model.TSAssignment.prototype.prepareTimeEntryToSave = function (oTimeEntry) {
	var oConfig = kno.tne.timesheet.newTimeSheet.model.TSAssignment.config;
	var aAllocTypes = oConfig.allocTypes;
	var aAssignmentFields = [];
	aAllocTypes.forEach(function (oAllocType, index) {
		if (oAllocType.allocationType === this.allocationType) {
			aAssignmentFields = oAllocType.assignmentFields;
		}
	}, this);

	aAssignmentFields.forEach(function (asgnField, index) {
		oTimeEntry[asgnField] = this[asgnField];
	}, this);

};

kno.tne.timesheet.newTimeSheet.model.TSAssignment.config = {
	allocFields: [
		'RKDAUF',
		'RKDPOS',
		'RAUFNR',
		'ZZTASK',
		'ZZLOCATION',
		'ZZACTIVITY',
		'AWART',
		'POSID',
		'ZZ_ACTIVITY_ID',
		'ZZCOUNTRYCODE',
		'ZZCR_NUMBER'
	],
	allocTypes: [{
		allocationType: "RAUFNR",
		allocationField: "RAUFNR",
		allocDescription: ["RAUFNR_Desc"],
		assignmentFields: ["RAUFNR", "AWART", "ZZCR_NUMBER", "ZZCOUNTRYCODE"]
	}, {
		allocationType: "POSID",
		allocationField: "POSID",
		allocDescription: ["POSID_Desc"],
		assignmentFields: ["POSID", "ZZ_ACTIVITY_ID", "AWART", "ZZCOUNTRYCODE"]
	}, {
		allocationType: "AWART",
		allocationField: "AWART",
		allocDescription: [],
		assignmentFields: ["AWART", "ZZCOUNTRYCODE"]
	}],
	defaults: {
		ZZCOUNTRYCODE: "DE",
	}
};
// static function
kno.tne.timesheet.newTimeSheet.model.TSAssignment.createTSAsgmnt = function (timeEntry) {
	return new kno.tne.timesheet.newTimeSheet.model.TSAssignment(timeEntry);
};
kno.tne.timesheet.newTimeSheet.model.TSAssignment.prototype.isEmpty = function () {

	var aConfig = kno.tne.timesheet.newTimeSheet.model.TSAssignment.config.allocFields;
	var oDefaults = kno.tne.timesheet.newTimeSheet.model.TSAssignment.config.defaults;
	var _isEmpty = true;
	var that = this;
	aConfig.forEach(function (sField, indx) {
		if ((that.hasOwnProperty(sField) && !(that[sField] === "" || that[sField] === undefined))) {
			/*check if it is a default value*/
			if (oDefaults.hasOwnProperty(sField) && that[sField] === oDefaults[sField]) {

			} else {
				_isEmpty = false;
				return;
			}
		}
	});
	return _isEmpty;
};
kno.tne.timesheet.newTimeSheet.model.TSAssignment.prototype.compare = function (tsAsgmnt) {

	var aConfig = kno.tne.timesheet.newTimeSheet.model.TSAssignment.config.allocFields;
	var _isEqual = true;
	var that = this;
	aConfig.forEach(function (sField, indx) {
		if (that[sField] !== tsAsgmnt[sField]) {
			_isEqual = false;
			return;
		}
	});
	return _isEqual;
};
kno.tne.timesheet.newTimeSheet.model.TSAssignment.prototype.clear = function () {
	var aConfig = kno.tne.timesheet.newTimeSheet.model.TSAssignment.config.allocFields;
	aConfig.forEach(function (sField, indx) {
		this[sField] = undefined;
	}, this);
};
/** Work Day */

kno.tne.timesheet.newTimeSheet.model.TSWorkDay = function (date, targetHours, workingDay) {

	this.date = date;
	this.targetHours = targetHours;
	this.workingDay = workingDay;
};

kno.tne.timesheet.newTimeSheet.model.KeyCounter = 0;
kno.tne.timesheet.newTimeSheet.model.GernerateKeyCounter = function () {
	kno.tne.timesheet.newTimeSheet.model.KeyCounter = kno.tne.timesheet.newTimeSheet.model.KeyCounter + 1;
	return 'NEW' + kno.tne.timesheet.newTimeSheet.model.KeyCounter;
};
/**Cell Object **/
kno.tne.timesheet.newTimeSheet.model.TSCell = function (oRow, workingDay, timeEntry, index) {
	this.key = kno.tne.timesheet.newTimeSheet.model.GernerateKeyCounter();
	this.Date = workingDay.date;
	this.detailVisible = false;
	this.timeEntry = timeEntry;
	this.feildName = "WORKDATE" + index;
	this.workingDay = workingDay.workingDay;
	this.index = index;
	this.oRow = oRow;
	this.MessageModel = [];
	this.Locked = workingDay.Locked;
	this.ValueState = sap.ui.core.ValueState.None;

};

kno.tne.timesheet.newTimeSheet.model.TSCell.prototype.setTimeEntryChanged = function () {
	var timeEntry = this.timeEntry;
	if (timeEntry.TIME > 0) {
		timeEntry.STATUS = "CHGD";
		timeEntry.isEmpty = false;
	} else if (!timeEntry.COUNTER || timeEntry.COUNTER === "" || timeEntry.COUNTER.search('NEW') >= 0) {
		timeEntry.STATUS = "";
		timeEntry.isEmpty = true;
	} else {
		timeEntry.STATUS = "CHGD";
	}
	//timeEntry.TIME = kno.tne.timesheet.newTimeSheet.lib.formatters.TimeSheetFormatter.formatHours(timeEntry.TIME);
	this.ValueState = sap.ui.core.ValueState.None;
};

kno.tne.timesheet.newTimeSheet.model.TSCell.prototype.isChanged = function () {
	return (this.timeEntry.STATUS === "CHGD" && !this.timeEntry.isEmpty) ? true : false;
};
//This function used only when timesheet is being submitted.
kno.tne.timesheet.newTimeSheet.model.TSCell.prototype.isTimeToBeSubmitted = function () {
	return ((this.timeEntry.STATUS === "CHGD" || this.timeEntry.STATUS === "MSAVE") && !this.timeEntry.isEmpty) ? true : false;
};

kno.tne.timesheet.newTimeSheet.model.TSCell.prototype.isDraft = function () {
	return (!this.timeEntry.COUNTER || this.timeEntry.COUNTER === "" || this.timeEntry.COUNTER.search('NEW') >= 0) ? true : false;
};

kno.tne.timesheet.newTimeSheet.model.TSCell.prototype.setMessages = function (mMessageModel) {
	if (!this.MessageModel) {
		this.MessageModel = [];
	}

	if (mMessageModel) {
		for (var i = 0; i < mMessageModel.length; i++) {
			this.MessageModel.push(mMessageModel[i]);
		}
	}
};

kno.tne.timesheet.newTimeSheet.model.TSCell.prototype.onSaveSuccess = function (oData, oResponse) {

	// var oData = oData;
	this.updateAfterSave(oData);
	this.ValueState = sap.ui.core.ValueState.None;
	var sAction = "C";
	var mMessageModel = kno.tne.timesheet.newTimeSheet.model.successMessageModel(oResponse, sAction);

	var arrMessageModel = [];

	if (!this.arrWorkDates) {
		this.arrWorkDates = [];
	}

	var alredyExists = false;
	

	// if (this.arrWorkDates.length === 0) {

	// } else {

	// 	for (var j = 0; j < this.arrWorkDates.length; j++) {

	// 		if (this.Date === this.arrWorkDates[j]) {
	// 			alredyExists = true;
	// 		}

	// 	}

	// }
	// if (!alredyExists) {
	// 	this.arrWorkDates.push(this.Date);

	var oEntry = this.prepareToSave();

	sap.ui.getCore()
		.timeSheet.checkSAN(this.Date, oEntry.TimeEntryDataFields);
	// }
	// //CR : App synchronization after lock released - Start
	// // resetting the intial data after every Save.
	// sap.ui.getCore()
	// 	.timeSheet.getExistingTimeData(true);
	// //CR : App synchronization after lock released - End
	if (mMessageModel) {
		arrMessageModel.push(mMessageModel);
		this.setMessages(arrMessageModel);
		this.oRow.setMessages(arrMessageModel);
	}

};

kno.tne.timesheet.newTimeSheet.model.TSCell.prototype.onDeleteSuccess = function (oData, oResponse) {

	var sAction = "D";
	var mMessageModel = kno.tne.timesheet.newTimeSheet.model.successMessageModel(oResponse, sAction);

	var arrMessageModel = [];

	if (mMessageModel) {
		arrMessageModel.push(mMessageModel);
		this.setMessages(mMessageModel);
		this.oRow.setMessages(mMessageModel);
	}

};
kno.tne.timesheet.newTimeSheet.model.TSCell.prototype.onSaveError = function (oResponse) {

	this.ValueState = sap.ui.core.ValueState.None;
	
	sap.ui.getCore().resetAllFlag(false);// reset all submit flag

	var mMessageModel = kno.tne.timesheet.newTimeSheet.model.errorMessageModel(oResponse);
	var mymessages = [];
	mMessageModel.forEach(function (oMessage, index) {
		if (oMessage.target === "CELL" && oMessage.propertyRef === this.key) {
			this.ValueState = sap.ui.core.ValueState.Error;
			mymessages.push(oMessage);
		}
	}, this);

	if (mMessageModel) {
		// if (mymessages) {
		this.setMessages(mMessageModel);
		this.oRow.setMessages(mMessageModel);
	}
};
kno.tne.timesheet.newTimeSheet.model.TSCell.prototype.prepareToSave = function () {
	var oAssignment = this.oRow.getAssignment();
	var oTimeEntry = {};
	oTimeEntry.TimeEntryDataFields = {};
	oTimeEntry.Pernr = this.timeEntry.Pernr;
	oAssignment.prepareTimeEntryToSave(oTimeEntry.TimeEntryDataFields);
	var time = isNaN(parseFloat(this.timeEntry.TIME)) ? '0' : this.timeEntry.TIME;
	oTimeEntry.TimeEntryDataFields.CATSHOURS = "" + time; //this.timeEntry.TIME;
	oTimeEntry.TimeEntryDataFields.CATSAMOUNT = "" + time; //this.timeEntry.TIME;
	if (this.timeEntry.NOTES && this.timeEntry.NOTES !== "") {
		oTimeEntry.TimeEntryDataFields.LONGTEXT = 'X';
		oTimeEntry.TimeEntryDataFields.LONGTEXT_DATA = this.timeEntry.NOTES;
	} else {
		oTimeEntry.TimeEntryDataFields.LONGTEXT = '';
		oTimeEntry.TimeEntryDataFields.LONGTEXT_DATA = '';
	}
	oTimeEntry.TimeEntryDataFields.WORKDATE = kno.tne.timesheet.newTimeSheet.model.getJsDate(this.timeEntry.WORKDATE);
	if (this.timeEntry.COUNTER) {
		oTimeEntry.Counter = this.timeEntry.COUNTER;
	} else {
		oTimeEntry.Counter = this.key;
	}
	oTimeEntry.TimeEntryDataFields.UNIT = "H";
	/*Flag to Decide whether timesheet change going to save or submit*/
	if (kno.tne.timesheet.newTimeSheet.model.KeyIsTimeToSubmit === true) { // SUBMIT
	kno.tne.timesheet.newTimeSheet.model.KeyIsSubmitMsgShow = true;// to show submit success message flag only
				oTimeEntry.TimeEntryRelease = "X";
	} else {
		oTimeEntry.TimeEntryRelease = ""; // Save
	}
	//kno.tne.timesheet.newTimeSheet.model.KeyIsTimeToSubmit = false;
	return oTimeEntry;
};
kno.tne.timesheet.newTimeSheet.model.TSCell.prototype.updateAfterSave = function (oTimeEntry) {
	// this.timeEntry.Pernr = oTimeEntry.Pernr;
	this.timeEntry.STATUS = '';
	this.timeEntry.COUNTER = oTimeEntry.Counter;
	if (oTimeEntry.Counter === '') {
		var othisTimeEntry = this.timeEntry;
		this.timeEntry = {
			isEmpty: true,
			WORKDATE: othisTimeEntry.WORKDATE,
			Pernr: othisTimeEntry.Pernr, // Locked: wDay.Locked
			TIME: ''
		};
	}
};
/** Row Object */
kno.tne.timesheet.newTimeSheet.model.TSRow = function (weeklyTable, workingDays, sTime) {

	this.days = workingDays;
	this.assignment = new kno.tne.timesheet.newTimeSheet.model.TSAssignment({});
	this.allocationList = [];
	this.activityCodes = [];
	this.AATypes = [];
	this.aaTypeVisible = false;
	this.activtyCodeVisible = false;
	this.rfcCodeVisible = false;
	this.weeklyTable = weeklyTable;
	var wDayCols = [];

	var dateIn = new Date();
	var year = dateIn.getFullYear();
	var month = (dateIn.getMonth() + 1)
		.toString()
		.padStart(2, "0");
	var sCurrDate = dateIn.getFullYear()
		.toString() //Year
		+ (dateIn.getMonth() + 1)
		.toString()
		.padStart(2, "0") // Month 
		+ dateIn.getDate()
		.toString()
		.padStart(2, "0"); // Date

	var sInDx;

	for (var i = 0; i < workingDays.length; i++) {

		if (workingDays[i].date === sCurrDate) {
			// sStopWatchEnabled = true;

			sInDx = i;
			break;
		}
	}

	workingDays.forEach(function (wDay, indx) {

		if (sInDx === indx && sTime > 0) {
			wDayCols.push(
				new kno.tne.timesheet.newTimeSheet.model.TSCell(this, wDay, {
					isEmpty: false,
					WORKDATE: wDay.date,
					TIME: sTime,
					Pernr: wDay.Pernr
				}, indx)
			);
		} else {
			// 
			wDayCols.push(
				new kno.tne.timesheet.newTimeSheet.model.TSCell(this, wDay, {
					isEmpty: true,
					WORKDATE: wDay.date,
					Pernr: wDay.Pernr
				}, indx)
			);

		}

	}, this);
	this.workDays = wDayCols;
};
kno.tne.timesheet.newTimeSheet.model.TSRow.prototype.calcualteTotal = function () {
	var aTimeEntries = this.workDays;
	this.Total = 0;
	aTimeEntries.forEach(function (oTimeEntry, index) {
		this.Total = this.Total + (parseFloat(oTimeEntry.timeEntry.TIME) ? parseFloat(oTimeEntry.timeEntry.TIME) : 0);
		//*this.Total = parseFloat(this.Total.toPrecision(2));
	}, this);

};

kno.tne.timesheet.newTimeSheet.model.TSRow.prototype.setMessages = function (mMessageModel) {
	var weeklyTable = this.weeklyTable;

	if (!weeklyTable.MessageModel) {
		weeklyTable.MessageModel = [];
	}

	if (mMessageModel) {

		for (var i = 0; i < mMessageModel.length; i++) {
			weeklyTable.MessageModel.push(mMessageModel[i]);
		}

	}

};

kno.tne.timesheet.newTimeSheet.model.TSRow.prototype.fitIntoRow = function (timeEntry) {

	var asgmnt = kno.tne.timesheet.newTimeSheet.model.TSAssignment.createTSAsgmnt(timeEntry);
	if (this.assignment.isEmpty()) {
		// new row - add current assignment
		this.assignment = asgmnt;
	}
	if (!this.assignment.compare(asgmnt)) {
		return false;
	}
	var fit = 0;
	var wdLocked;
	this.workDays.forEach(function (wDay, indx, wDayArr) {
		if (wDayArr[indx].Date === timeEntry.WORKDATE && wDayArr[indx].timeEntry.isEmpty) {
			wdLocked = wDayArr[indx].timeEntry.wdLocked;
			wDayArr[indx].timeEntry = timeEntry;
			wDayArr[indx].timeEntry.wdLocked = wdLocked;
			if (!(timeEntry.COUNTER && timeEntry.COUNTER !== "")) {
				timeEntry.isEmpty = true;
			} else {
				timeEntry.isEmpty = false;
				//				timeEntry.TIME = kno.tne.timesheet.newTimeSheet.lib.formatters.TimeSheetFormatter.formatHours(timeEntry.TIME);
			}
			fit = 1;

		}
	});
	if (fit === 1) {
		return true;
	} else {
		return false;
	}
};
kno.tne.timesheet.newTimeSheet.model.TSRow.prototype.setTimeEntryChanged = function (index) {
	var oCell = this.workDays[index];
	oCell.setTimeEntryChanged();
};
kno.tne.timesheet.newTimeSheet.model.TSRow.prototype.setRowChanged = function (fieldName) {
	// var oCell = this.workDays[index];
	// oCell.setTimeEntryChanged();
	this.changeAssignmentText(fieldName);
	this.workDays.forEach(function (oDay, index) {
		oDay.setTimeEntryChanged();
	}, this);
};
kno.tne.timesheet.newTimeSheet.model.TSRow.prototype.changeAssignmentText = function (fieldName) {
	//
	//var field = this.assingment[fieldName];
	/* if the assignment field is changed, for each dropdown, we will need to get the corresponding text from the list
	collection and assign it to the description/ text  of the corresponding field*/
	if (fieldName === 'ASGNMT') {
		if (!this.assignment.allocation || this.assignment.allocation === "") {
			this.assignment.clear();
			return;
		}
		var aAlloc = this.assignment.allocation.split('|');
		this.assignment.allocationType = aAlloc[0];
		this.assignment.allocationId = aAlloc[1];
		for (var i = 0; i < this.allocationList.length; i++) {
			if (this.assignment.allocation === this.allocationList[i].FieldId) {
				this.assignment.allocDescr = this.allocationList[i].FieldValue;
				break;
			}
		}
		if (this.assignment.allocationType === 'POSID') {
			this.assignment.POSID = this.assignment.allocationId;
		} else {
			this.assignment.RAUFNR = this.assignment.allocationId;
		}

	} else if (fieldName === 'CNTRY') {

	}
};
kno.tne.timesheet.newTimeSheet.model.TSRow.prototype.getAssignment = function () {
	return this.assignment;
};
// kno.tne.timesheet.newTimeSheet.model.TSCell = function(workDay, hours) {

// };
/** Weekly Table */
kno.tne.timesheet.newTimeSheet.model.TSWeeklytable = function (workingDays) {
	this.workingDays = workingDays;
	this.rowTable = [];
	this.allocationList = [];

	var wDayCols = [];
	workingDays.forEach(function (wDay, indx) {
		wDayCols.push({
			"dayName": kno.tne.timesheet.newTimeSheet.model.getDayName(wDay.date),
			"dayOfMonth": kno.tne.timesheet.newTimeSheet.model.getDayOfMonth(wDay.date),
			"FieldName": "WORKDATE" + indx,
			"date": wDay.date,
			"status": wDay.status,
			"targetHours": wDay.targetHours,
			"workingDay": wDay.workingDay,
			"Locked": wDay.Locked,
			"Total": 0
		});
	});
	this.workDays = wDayCols;
};

kno.tne.timesheet.newTimeSheet.model.TSWeeklytable.prototype.setTimeSheetData = function (tsdataArray) {
	// sort the timesheet data by workdate. 
	this.timesheetData = tsdataArray.sort(function (a, b) {
		return b.counter > a.counter;
	});
	for (var i = 0; i < tsdataArray.length; i++) {
		if (this.fitIntoRow(tsdataArray[i])) {
			return;
		}
	}
	/* calculate the Allocation List */
	this.checkAddAllocation();
	// this.calculateTotal();
	return this.renderTable();
};

kno.tne.timesheet.newTimeSheet.model.TSWeeklytable.prototype.addNewRows = function (sdata, sTime) {
	var arrRowsAdded = [];
	sdata.forEach(function (oSData, index) {
		var oRow = new kno.tne.timesheet.newTimeSheet.model.TSRow(this, this.workingDays, sTime);

		oRow.assignment = new kno.tne.timesheet.newTimeSheet.model.TSAssignment.createTSAsgmnt(oSData);
		this.rowTable.unshift(oRow);
		arrRowsAdded.unshift(oRow);
	}, this);
	this.checkAddAllocation();
	return arrRowsAdded;
};
kno.tne.timesheet.newTimeSheet.model.TSWeeklytable.prototype.clearTotals = function () {
	this.Total = 0;
	var aWorkDays = this.workingDays;
	aWorkDays.forEach(function (oDay, index) {
		oDay.Total = 0;
	}, this);
};
kno.tne.timesheet.newTimeSheet.model.TSWeeklytable.prototype.calculateTotal = function () {
	var aWorkDays = this.workingDays;
	var aRows = this.rowTable;
	// this.Total = 0;
	// aWorkDays.forEach(function(oDay, index) {
	// 	oDay.Total = 0;
	// }, this);
	aRows.forEach(function (oRow, index) {
		oRow.calcualteTotal();
		for (var i = 0; i < aWorkDays.length; i++) {
			// aWorkDays[i].Total = !(isNaN(aWorkDays[i].Total)) ? aWorkDays[i].Total : 0;
			aWorkDays[i].Total = aWorkDays[i].Total + (parseFloat(oRow.workDays[i].timeEntry.TIME) ? parseFloat(oRow.workDays[i].timeEntry
				.TIME) : 0);
			//*aWorkDays[i].Total = parseFloat(aWorkDays[i].Total.toPrecision(2));
			// aWorkDays[i].Total = kno.tne.timesheet.newTimeSheet.lib.formatters.TimeSheetFormatter.formatHours(aWorkDays[i].Total);
		}
		this.Total = this.Total + oRow.Total;
		//*this.Total = parseFloat(this.Total.toPrecision(2));
		// this.Total = kno.tne.timesheet.newTimeSheet.lib.formatters.TimeSheetFormatter.formatHours(this.Total);
	}, this);
	this.workingDays = aWorkDays;
};
kno.tne.timesheet.newTimeSheet.model.TSWeeklytable.prototype.fitIntoRow = function (timeEntry) {
	for (var i = 0; i < this.rowTable.length; i++) {
		var row = this.rowTable[i];
		if (row.fitIntoRow(timeEntry)) {
			return;
		}
	}
	var newRow = new kno.tne.timesheet.newTimeSheet.model.TSRow(this, this.workingDays);
	this.rowTable.push(newRow);
	newRow.fitIntoRow(timeEntry);
};

kno.tne.timesheet.newTimeSheet.model.TSWeeklytable.prototype.renderTable = function () {
	var tableData = [];
	var rowData = {};
	this.rowTable.forEach(function (row) {
		rowData = {};
		rowData.assignment = row.assignment;
		rowData.allocationList = this.allocationList;
		rowData.activityCodes = [];
		rowData.AATypes = [];
		rowData.aaTypeVisible = false;
		rowData.activtyCodeVisible = false;
		row.workDays.forEach(function (wrkDay, indx) {

			rowData["WORKDATE" + indx] = wrkDay.timeEntry;
		});
		tableData.push(rowData);
	}, this);
	return tableData;
};

kno.tne.timesheet.newTimeSheet.model.TSWeeklytable.prototype.checkAddAllocation = function () {
	var that = this;
	this.rowTable.forEach(function (row) {
		var oAllocation = {};
		oAllocation.FieldId = row.assignment.allocation;
		oAllocation.FieldName = row.assignment.allocationId;
		oAllocation.FieldValue = row.assignment.allocDescr;
		this.allocationList.push(oAllocation);
	}, this);
	/*distribute the allocation list to all the rows in the table*/
	this.rowTable.forEach(function (row, indx) {
		row.allocationList = this.allocationList;
	}, this);
	/* include code for additional dropdowns also like ACTIVITY AWART etc...*/
};

/* Utility Methods for managing Dates */

kno.tne.timesheet.newTimeSheet.model.getDayName = function (sapDate) {
	// return '';
	var sDate = this.getJsDate(sapDate);

	var sDayName = sDate.toLocaleDateString(sap.ui.getCore()
		.getConfiguration()
		.getLocale(), {
			weekday: 'short'
		});

	return sDayName.toUpperCase();
};
kno.tne.timesheet.newTimeSheet.model.getDayOfMonth = function (sapDate) {
	return sapDate.substr(6, 2);
};

kno.tne.timesheet.newTimeSheet.model.getJsDate = function (sapDate) {
	var vDate = new Date();
	vDate.setYear(parseInt(sapDate.substr(0, 4)));
	vDate.setMonth(parseInt(sapDate.substr(4, 2)) - 1);
	vDate.setDate(parseInt(sapDate.substr(6, 2)));

	return vDate;
};

kno.tne.timesheet.newTimeSheet.model.successMessageModel = function (oData, sAction) {
	if (!this.arrMessageModel) {
		this.arrMessageModel = [];
	}
	var sMessage;

	// var oResponse = JSON.parse(oData.responseText);
	// if (oResponse) {
	// 	if (oResponse.error && oResponse.error.message && oResponse.error.message.value) {
	// 		sMessage = oResponse.error.message.value;
	// 	}
	// }

	var sMessage;
	switch (sAction) {
	case 'C':
		if (kno.tne.timesheet.newTimeSheet.model.KeyIsSubmitMsgShow === true) {
			sMessage = "TimeSheet submitted successfully";
		} else {
			sMessage = "TimeSheet saved successfully";
		}
		break;
	case 'D':
		sMessage = "TimeSheet deleted successfully";
		break;
	default:
	}
	
	var oMessages = {
		code: "",
		type: "Success",
		message: sMessage,
		target: "",
		propertyRef: ""
	};

	// this.arrMessageModel.push(oMessages);
	return oMessages;
};

kno.tne.timesheet.newTimeSheet.model.errorMessageModel = function (oData) {

	var sMessage;
	var arrMessge = [];

	var arrMessages = [];
	var oResponse = JSON.parse(oData.responseText);
	if (oResponse) {
		if (oResponse.error && oResponse.error.message && oResponse.error.message.value) {
			sMessage = oResponse.error.message.value;
			arrMessge = oResponse.error.innererror.errordetails;
		}
	}

	// var sCode;
	if (arrMessge.length > 0) {
		for (var i = 0; i < arrMessge.length; i++) {
			if (arrMessge[i].code !== "/IWBEP/CX_MGW_BUSI_EXCEPTION") {

				//	sCode = arrMessge[i].code.split("/")
				var oMessages = {
					id: arrMessge[i].code.split("/")[1],
					class: arrMessge[i].code.split("/")[0],
					code: arrMessge[i].code,
					type: "Error",
					message: arrMessge[i].message,
					target: arrMessge[i].target,
					propertyRef: arrMessge[i].propertyref
				};
				// oMessages.message = 
				// oMessages.target = 
				arrMessages.push(oMessages);
			}
		}
	}

	// this.arrMessageModel.push(oMessages);
	return arrMessages;
};
kno.tne.timesheet.newTimeSheet.model.KeyIsTimeToSubmit = false;// First time initialised
kno.tne.timesheet.newTimeSheet.model.KeyIsSubmitMsgShow = false;// First time initialised
