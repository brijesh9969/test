var kno = kno || {};
jQuery.sap.require("kno.tne.timesheet.newTimeSheet.model.WeeklyTable");
sap.ui.define([
	"sap/ui/base/EventProvider"
], function (EventProvider) {

	"use strict";
	// Strin prototype change.
	if (!String.prototype.padStart) {
		String.prototype.padStart = function padStart(targetLength, padString) {
			targetLength = targetLength >> 0; //truncate if number or convert non-number to 0;
			padString = String((typeof padString !== 'undefined' ? padString : ' '));
			if (this.length > targetLength) {
				return String(this);
			} else {
				targetLength = targetLength - this.length;
				if (targetLength > padString.length) {
					padString += padString.repeat(targetLength / padString.length); //append to original to ensure we are longer than needed
				}
				return padString.slice(0, targetLength) + String(this);
			}
		};
	}

	var TimeSheet = EventProvider.extend("kno.tne.timesheet.newTimeSheet.model.TimeSheet", {
		evtTimeDataListLoaded: 'timeDataListLoaded',
		evtInitialized: 'initialized',
		evtWorkCalendarsLoaded: 'workCalendarsLoaded',
		evtInitialInfosLoaded: 'initialInfosLoaded',
		evtProfileFieldsLoaded: 'profileFieldsLoaded',
		evtDelegateSetLoaded: 'delegateSetLoaded',
		evtActivityCodesLoaded: 'activityCodesLoaded',
		evtAATypesLoaded: 'AATypesLoaded',
		evtTSSaveComplete: 'saveCompleted',
		evtTriggerMessage: 'TriggerMessage',
		evtExtraTimeJustification: 'ExtraTimeJustificationLoaded',
		evtTimeLogLoaded: 'TimeLogLoaded',
		evtDocVisitSuccess: 'DocVisitSuccess',
		evtRFCListLoaded: 'RFCListLoaded',
		evtESUCheckSuccess: 'ESUCheckSuccess',
		evtIOSaveSuccess: 'IOSaveSuccess',
		evtSANCheckSuccess: 'SANCheckSuccess',
		evtESUActionSuccess: 'ESUActionSuccess',
		evtDailyHoursChanged: 'DailyHoursChanged',
		//CR : App synchronization after lock released - Start
		evtloadExistingTimeSucess: 'ExistingTimeSucess',
		evtSaveTimeSheet: 'SaveTimeSheet',
		//CR : App synchronization after lock released - End
		metadata: {
			publicMethods: ["init", "getTimeDataWeekTable"],
			events: {
				initialized: {},
				timeDataListLoaded: {},
				initialInfosLoaded: {},
				workCalendarsLoaded: {},
				profileFieldsLoaded: {},
				delegateSetLoaded: {},
				saveCompleted: {},
				TriggerMessage: {}
			}
		},
		constructor: function (oDataModel) {
			EventProvider.call(this);
			this.oDataModel = oDataModel;
			this.selectedIndx = null;
			this.tsJSONModel = new sap.ui.model.json.JSONModel()
				.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
			this.tsJSONModel.setSizeLimit(10000);
			this.tsJSONModel.setProperty('/timeEntries', {});
			this.tsJSONModel.setProperty('/dropDowns', {});
			this.tsJSONModel.attachPropertyChange({}, this.modelDataChanged, this);
		},
		init: function (pernr, startDate, endDate) {
			this.pernr = this.startDate = this.endDate = '';
			if (pernr && pernr !== "") {
				this.pernr = pernr;
			}
			this.pernr = pernr ? pernr : '00000000';
			this.startDate = startDate ? startDate : this.getSapDate();
			this.endDate = endDate ? endDate : '00000000';
			// initiate oData call to get the details of the employee and week 
			//this.getDropDownValues();
			this.getInitialData();

		},
		getTimesheetModel: function () {
			return this.tsJSONModel;
		},
		// getDropDownValues: function() {
		// 	/* 1. Attendence and Abscence Types 
		// 	   2. Country Codes 
		// 	   3. Recently used 
		// 	   */
		// 	this.getCountryCodes();
		// 	this.getAATypeCodes();
		// 	this.getRecentlyUsedCodes();
		// },
		// getCountryCodes: function() {
		// 	//var referenceValue = this.tsJSONModel.getProperty("/timeEntries/" + rowIndex + "/assignment/POSID");
		// 	var aFilters = [];
		// 	var oFilter = new sap.ui.model.Filter("FieldName", sap.ui.model.FilterOperator.EQ, 'ZZCOUNTRYCODE');
		// 	aFilters.push(oFilter);
		// 	this.oDataModel.read("/ValueHelpList", {
		// 		urlParameters: {},
		// 		filters: aFilters,
		// 		success: jQuery.proxy(this.onCountryCodesSuccess, this, {}),
		// 		error: jQuery.proxy(this.onError, this)
		// 	});
		// },
		// getRecentlyUsedCodes: function() {
		// 	//var referenceValue = this.tsJSONModel.getProperty("/timeEntries/" + rowIndex + "/assignment/POSID");
		// 	// var aFilters = [];
		// 	// var oFilter = new sap.ui.model.Filter("FieldName", sap.ui.model.FilterOperator.EQ, 'AWART');
		// 	// aFilters.push(oFilter);
		// 	// this.oDataModel.read("/ValueHelpList", {
		// 	// 	urlParameters: {},
		// 	// 	filters: aFilters,
		// 	// 	success: jQuery.proxy(this.onAATypeSuccess, this, {
		// 	// 		index: rowIndex
		// 	// 	}),
		// 	// 	error: jQuery.proxy(this.onError, this)
		// 	// });
		// },
		getInitialData: function () {
			this.oDataModel.read(
				"/TSInitDataSet(Pernr='" + this.pernr + "',StartDate='" + this.startDate + "',EndDate='" + this.endDate + "')", {
					urlParameters: {
						"$expand": "InitialInfos,WorkCalendars,TimeDataList,AATypes,Countries,RecentlyUsedCodes"
					},
					success: jQuery.proxy(this.onInitialDataDSuccess, this),
					error: jQuery.proxy(this.onInitialDataError, this)

				});
		},

		copyTimeSheet: function () {
			var sDate = this.convertSapDate(this.startDate, -7);
			var eDate = this.convertSapDate(this.endDate, -7);
			// var sDate = parseInt(this.startDate) - 7;
			// var eDate = parseInt(this.endDate) - 7;
			this.oDataModel.read(
				"/TSInitDataSet(Pernr='" + this.pernr + "',StartDate='" + sDate + "',EndDate='" + eDate + "')", {
					urlParameters: {
						"$expand": "TimeDataList"
					},
					success: jQuery.proxy(this.onCopyDataDSuccess, this),
					error: jQuery.proxy(this.onCopyDataError, this)
				});
		},

		onCopyDataDSuccess: function (oData) {

			if (oData) {
				this.onTimeDataLisCopytSuccess(oData.TimeDataList);

			}
		},

		onTimeDataLisCopytSuccess: function (oData) {
			// process time sheet data and convert into grid format
			if (oData && oData.results) {
				var aTimeDataList = oData.results;

				// if (this.isCopy) {

				// 	for (var x = 0; x < aTimeDataList.length; x++) {

				// 		for (var y = 0; y < this.aTimeDataList.length; y++) {
				// 			if (this.aTimeDataList[y].RecordNumber === aTimeDataList[x].RecordNumber && aTimeDataList[x].FieldName === "WORKDATE") {
				// 				aTimeDataList[x].FieldValue = this.aTimeDataList[y].FieldValue;
				// 				break;
				// 			}

				// 		}

				// 	}

				// }
				this.splitTimeDataList(aTimeDataList);
				this.aTimeEntries = this.convertTimeDataList(this.aTimeDataList);

				this.aTimeEntries = this.removeDuplicates(this.aTimeEntries);

				// if (this.aTimeEntriesOrg && this.aTimeEntriesOrg.length > 0) {
				for (var i = 0; i < this.aTimeEntries.length; i++) {
					this.aTimeEntriesOrg.push(this.aTimeEntries[i]);
				}
				// }

				this.aTimeEntries = this.aTimeEntriesOrg;
				// this.aAbsenceEntries = this.convertTimeDataList(this.aAbsenceDataList);
				//this.oTimeEntriesTable = this.convertTimeEntriestoGrid();
				this.convertTimeEntriestoGrid();
				this.tsJSONModel.setProperty("/timeEntries", this.weeklyTable);
				this.tsJSONModel.setProperty("/timeEntries/workingDays", this.weeklyTable.workingDays);

			}
			//this.calculateDailyTotals();
			this.fireEvent(this.evtTimeDataListLoaded, {}, true, true);
		},

		removeDuplicates: function (arr) {

			var newArrRaufnr = [];
			var newArrPosId = [];
			var newAwart = [];

			for (var i = 0; i < arr.length - 1; i++) {
				if (arr[i]["RAUFNR"]) {
					newArrRaufnr.push(arr[i]);
				}

				if (arr[i]["POSID"]) {
					newArrPosId.push(arr[i]);
				}

				if (!arr[i]["POSID"] && !arr[i]["RAUFNR"] && arr[i]["AWART"]) {
					newAwart.push(arr[i]);
				}
			}

			var returnArrRauf = [];

			arr = [];
			returnArrRauf = this.removeDuplicatesRaufnr(newArrRaufnr);

			for (var j = 0; j < returnArrRauf.length; j++) {
				arr.push(returnArrRauf[j]);
			}

			var returnArrPosid = this.removeDuplicatesPOSNR(newArrPosId);

			for (var j = 0; j < returnArrPosid.length; j++) {
				arr.push(returnArrPosid[j]);
			}

			var returnArrAwart = this.removeDuplicatesAwart(newAwart);
			for (var j = 0; j < returnArrAwart.length; j++) {
				arr.push(returnArrAwart[j]);
			}

			return arr;

		},

		removeDuplicatesRaufnr: function (arr) {

			arr.sort(function (a, b) {
				if (a["RAUFNR"] && b["RAUFNR"])
					return (a.RAUFNR > b.RAUFNR) ? 1 : ((b.RAUFNR > a.RAUFNR) ? -1 : 0);
			});
			for (var i = 1; i < arr.length;) {
				if (arr[i - 1].RAUFNR === arr[i].RAUFNR) {
					arr.splice(i, 1);
				} else {
					i++;
				}
			}
			return arr;

		},

		removeDuplicatesPOSNR: function (arr) {

			arr.sort(function (a, b) {
				if (a["POSID"] && b["POSID"])
					return (a.POSID > b.POSID) ? 1 : ((b.POSID > a.POSID) ? -1 : 0);
			});
			for (var i = 1; i < arr.length;) {
				if (arr[i - 1].POSID === arr[i].POSID) {
					arr.splice(i, 1);
				} else {
					i++;
				}
			}
			return arr;

		},

		removeDuplicatesAwart: function (arr) {

			arr.sort(function (a, b) {
				if (a["AWART"] && b["AWART"])
					return (a.AWART > b.AWART) ? 1 : ((b.AWART > a.AWART) ? -1 : 0);
			});
			for (var i = 1; i < arr.length;) {
				if (arr[i - 1].AWART === arr[i].AWART) {
					arr.splice(i, 1);
				} else {
					i++;
				}
			}
			return arr;

		},

		onInitialDataError: function (oResponse) {

			var mMessageModel = kno.tne.timesheet.newTimeSheet.model.errorMessageModel(oResponse);
			// var arrMessages = [];
			// arrMessages.push(mMessageModel);
			this.onMessageEvtTrigered(mMessageModel);
			this.tsJSONModel.setProperty('/timeEntries', {});
		},

		onInitialDataDSuccess: function (oData) {

			if (oData) {
				this.pernr = oData.Pernr;
				this.startDate = oData.StartDate;
				this.endDate = oData.EndDate;
				this.periodType = oData.PeriodType;
				this.fireEvent(this.evtInitialized, {
					workCal: oData.WorkCalendars
				}, true, true);
				//process initialInfos 

				// process work calendars by calling the calendar data process function module
				this.onAATypeSuccess(oData.AATypes);
				this.onCountryCodesSuccess(oData.Countries);
				this.onRecentlyUsedCodesSuccess(oData.RecentlyUsedCodes);
				this.onWorkCalendarsSuccess(oData.WorkCalendars);
				this.onTimeDataListSuccess(oData.TimeDataList);
				this.onInitialInfosSuccess(oData.InitialInfos);
				this.onMessageEvtTrigered([]);
			}
		},

		onError: function (oError) {

		},

		onDelegateSetError: function (oError) {
			this.fireEvent(this.evtDelegateSetLoaded, {}, true, true);
		},
		getDelegateSet: function () {

			var aFilter = [];
			aFilter.push(new sap.ui.model.Filter("Pernr", 'EQ', this.pernr));

			if (!this.delegateSet) {

				var mParameters = {
					filters: aFilter,
					success: jQuery.proxy(this.onDelegateSetSuccess, this),
					error: jQuery.proxy(this.onDelegateSetError, this)
				};

				this.oDataModel.read(
					"/TimeDelegates", mParameters);
			} else {
				this.fireEvent(this.evtDelegateSetLoaded, {}, true, true);
			}
		},
		getRFCList: function () {

			var oFilter = {};
			oFilter = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("FieldName", sap.ui.model.FilterOperator.EQ, 'ZZCR_NUMBER'),
					new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.EQ, this.pernr),
					new sap.ui.model.Filter("StartDate", sap.ui.model.FilterOperator.EQ, this.startDate),
					new sap.ui.model.Filter("EndDate", sap.ui.model.FilterOperator.EQ, this.endDate)
				],
				and: true
			});
			var aFilter = [];
			aFilter.push(oFilter);
			var mParameters = {
				filters: aFilter,
				success: jQuery.proxy(this.onRFCListSuccess, this),
				error: jQuery.proxy(this.onRFCListError, this)
			};

			this.oDataModel.read(
				"/ValueHelpList", mParameters);
		},
		onRFCListSuccess: function (oData) {
			// this.rfcList = oData.results;
			this.fireEvent(this.evtRFCListLoaded, {
				rfcList: oData.results
			}, true, true);
		},
		onRFCListError: function (oError) {

		},
		onDelegateSetSuccess: function (oData) {
			this.delegateSet = oData.results;
			this.fireEvent(this.evtDelegateSetLoaded, {
				Delegates: oData.results
			}, true, true);
		},

		getExtraTimeJustifications: function () {

			var oFilter = {};
			oFilter = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.EQ, this.pernr),
					new sap.ui.model.Filter("StartDate", sap.ui.model.FilterOperator.EQ, this.startDate),
					new sap.ui.model.Filter("EndDate", sap.ui.model.FilterOperator.EQ, this.endDate)
				],
				and: true
			});
			var aFilter = [];
			aFilter.push(oFilter);
			var mParameters = {
				filters: aFilter,
				success: jQuery.proxy(this.onExtraTimeJustSuccess, this),
				error: jQuery.proxy(this.onError, this)
			};

			this.oDataModel.read(
				"/ExtraTimeJustifications", mParameters);
		},
		onExtraTimeJustSuccess: function (oData, oResponse) {
			this.tsJSONModel.setProperty("/timeEntries/extraTimeJustifications", oData.results);
			this.fireEvent(this.evtExtraTimeJustification, {
				ExtraHours: oData.results
			}, true, true);
		},
		getTimeLogData: function () {
			var oFilter = {};
			oFilter = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.EQ, this.pernr),
					new sap.ui.model.Filter("StartDate", sap.ui.model.FilterOperator.EQ, this.startDate),
					new sap.ui.model.Filter("EndDate", sap.ui.model.FilterOperator.EQ, this.endDate)
				],
				and: true
			});
			var aFilter = [];
			aFilter.push(oFilter);
			var mParameters = {
				filters: aFilter,
				success: jQuery.proxy(this.onTimeLogDataSuccess, this),
				error: jQuery.proxy(this.onError, this)
			};

			this.oDataModel.read(
				"/InOutLogEntries", mParameters);
		},
		onTimeLogDataSuccess: function (oData, oResponse) {
			this.tsJSONModel.setProperty("/timeEntries/timeLog", oData.results);
			this.fireEvent(this.evtTimeLogLoaded, {
				timeLog: oData.results
			}, true, true);
		},

		saveIOTime: function () {

			var arrTimeLogEntries = this.tsJSONModel.getProperty("/timeEntries/timeLog");

			if (arrTimeLogEntries && arrTimeLogEntries.length > 0) {

				for (var i = 0; i < arrTimeLogEntries.length; i++) {

					arrTimeLogEntries[i].inTime = this.formatTimeString(arrTimeLogEntries[i].inTime);
					arrTimeLogEntries[i].outTime = this.formatTimeString(arrTimeLogEntries[i].outTime);

					this.oDataModel.create("/InOutLogEntries", arrTimeLogEntries[i], {
						success: jQuery.proxy(this.onIOSaveSuccess, this),
						error: jQuery.proxy(this.onIOSaveError, this),
						changeSetId: 'changeSet'
					});
				}
			}

		},

		formatTimeString: function (t) {
			if (t.lastIndexOf(":") >= 0) {
				return t.split(":")[0] + t.split(":")[1] + t.split(":")[2];
			} else {
				return t;
			}
		},

		onIOSaveSuccess: function (oData, oResponse) {
			this.fireEvent(this.evtIOSaveSuccess, {
				timeLog: oData.results
			}, true, true);

		},
		getTimesheetData: function (startDate, endDate) {
			// Prepare filters for time data list 
			var aFilters = [];
			var oFilter = {};
			var vStartDate, vEndDate;
			vStartDate = startDate ? startDate : this.startDate;
			vEndDate = endDate ? endDate : this.endDate; // should change to startDate + 7 ??
			oFilter = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.EQ, this.pernr),
					new sap.ui.model.Filter("StartDate", sap.ui.model.FilterOperator.EQ, vStartDate),
					new sap.ui.model.Filter("EndDate", sap.ui.model.FilterOperator.EQ, vEndDate)
				],
				and: true
			});
			aFilters.push(oFilter);
			this.oDataModel.read(
				"/TimeDataList", {
					filters: aFilters,
					success: jQuery.proxy(this.onTimeDataListSuccess, this),
					error: jQuery.proxy(this.onError, this)
				}
			);
		},
		refresh: function () {
			this.getTimesheetData();
		},

		getAcivityCodes: function (rowIndex, value) {
			var referenceValue = this.tsJSONModel.getProperty("/timeEntries/rowTable/" + rowIndex + "/assignment/allocationId");
			var aFilters = [];
			var oFilter = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("FieldName", sap.ui.model.FilterOperator.EQ, 'ACTIVITY_ID'),
					new sap.ui.model.Filter("FieldRelated", sap.ui.model.FilterOperator.EQ, referenceValue)
				],
				and: true
			});
			aFilters.push(oFilter);
			this.oDataModel.read("/ValueHelpList", {
				urlParameters: {},
				filters: aFilters,
				success: jQuery.proxy(this.onActivitCodesSuccess, this, {
					index: rowIndex
				}),
				error: jQuery.proxy(this.onError, this)
			});
		},

		getRfcCodes: function (rowIndex, value) {
			var aRfcList = this.tsJSONModel.getProperty("/dropDowns/rfcList");
			var referenceValue = this.tsJSONModel.getProperty("/timeEntries/rowTable/" + rowIndex + "/assignment/allocationId");
			var allocationType = this.tsJSONModel.getProperty("/timeEntries/rowTable/" + rowIndex + "/assignment/allocationType");
			var aRfcDropDown = [];
			if (allocationType === "RAUFNR") {
				aRfcList.forEach(function (oRfc, index) {
					if (oRfc.FieldId === referenceValue) {
						var oRfcval = {
							FieldId: oRfc.FieldId1,
							FieldValue: oRfc.FieldValue1
						};
						aRfcDropDown.push(oRfcval);
					}
				}, this);
			}
			this.onRfcCodesSuccess(rowIndex, aRfcDropDown, {});
		},

		getAATypeCodes: function (rowIndex) {
			var referenceValue = this.tsJSONModel.getProperty("/timeEntries/rowTable/" + rowIndex + "/assignment/allocation");
			var aFilters = [];
			var refVal = '';
			// clear the value from assignment value
			if (referenceValue !== "--") {

				refVal = referenceValue;
			}
			var oFilter = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.EQ, this.pernr),
					new sap.ui.model.Filter("StartDate", sap.ui.model.FilterOperator.EQ, this.startDate),
					new sap.ui.model.Filter("EndDate", sap.ui.model.FilterOperator.EQ, this.endDate),
					new sap.ui.model.Filter("FieldName", sap.ui.model.FilterOperator.EQ, 'AWART'),
					new sap.ui.model.Filter("FieldRelated", sap.ui.model.FilterOperator.EQ, refVal)
				],
				and: true
			});
			aFilters.push(oFilter);
			this.oDataModel.read("/ValueHelpList", {
				urlParameters: {},
				filters: aFilters,
				success: jQuery.proxy(this.onAATypeSuccessRow, this, {
					index: rowIndex
				}),
				error: jQuery.proxy(this.onError, this)
			});
		},

		onInitialInfosSuccess: function (oData) {
			this.tsJSONModel.setProperty("/timeEntries/IsMyLogEmp", oData.results[0].IsMyLogEmp);
			this.fireEvent(this.evtInitialInfosLoaded, {
				// IniInfos: oData.results
			}, true, true);
		},

		onWorkCalendarsSuccess: function (oData) {

			this.fireEvent(this.evtWorkCalendarsLoaded, {}, true, true);
			var aWorkingDays = [];
			var sEditFlag;

			oData.results.forEach(function (wday, indx) {
				var workingday = {
					date: wday.Date,
					workingDay: wday.WorkingDay,
					targetHours: wday.TargetHours,
					status: wday.Status,
					Pernr: this.pernr,
					Locked: (wday.Locked === 'TRUE') ? true : false,
					Total: 0,
					dayName: kno.tne.timesheet.newTimeSheet.model.getDayName(wday.Date),
					dayOfMonth: kno.tne.timesheet.newTimeSheet.model.getDayOfMonth(wday.Date)
				};
				aWorkingDays.push(workingday);

			}, this);

			this.workingDays = aWorkingDays;

			this.tsJSONModel.setProperty("/timeEntries/workingDays", this.workingDays);

			var arr = this.workingDays;

			// var mTotal = {
			// 	day: "",
			// 	date: "",
			// 	TotalHrs: "Total",
			// 	ActualHrs: "Hours"
			// };

			// arr.push(mTotal);

			var mWeekDays = new sap.ui.model.json.JSONModel({
				items: arr
			});

			// this.getView()
			// 	.setModel(mWeekDays, "mWeekDays");
		},

		onTimeDataListSuccess: function (oData) {
			// process time sheet data and convert into grid format
			if (oData && oData.results) {
				var aTimeDataList = oData.results;

				// if (this.isCopy) {

				// 	for (var x = 0; x < aTimeDataList.length; x++) {

				// 		for (var y = 0; y < this.aTimeDataList.length; y++) {
				// 			if (this.aTimeDataList[y].RecordNumber === aTimeDataList[x].RecordNumber && aTimeDataList[x].FieldName === "WORKDATE") {
				// 				aTimeDataList[x].FieldValue = this.aTimeDataList[y].FieldValue;
				// 				break;
				// 			}

				// 		}

				// 	}

				// }
				this.splitTimeDataList(aTimeDataList);
				this.aTimeEntries = this.convertTimeDataList(this.aTimeDataList);
				this.aTimeEntriesOrg = this.aTimeEntries;
				this.aAbsenceEntries = this.convertTimeDataList(this.aAbsenceDataList);
				//this.oTimeEntriesTable = this.convertTimeEntriestoGrid();
				this.convertTimeEntriestoGrid();
				// this.tsJSONModel.setProperty("/timeEntries", this.weeklyTable);
				// this.tsJSONModel.setProperty("/timeEntries/workingDays", this.weeklyTable.workingDays);

				var tmpPresentTimeData = jQuery.extend(true, [], this.aTimeEntries);
				var tmpAbsTimeData = jQuery.extend(true, [], this.aAbsenceEntries);
				var totalTimeData = tmpPresentTimeData.concat(tmpAbsTimeData);
				//defect fix for Total hours for absense
				var calenderTotalHrs = 0;
				for (var i in totalTimeData) {
					calenderTotalHrs = calenderTotalHrs + parseFloat(totalTimeData[i].TIME);
				}
				// totalTimeData.each(function(obj, index) {

				// });

				this.weeklyTable.Total = calenderTotalHrs;
				this.tsJSONModel.setProperty("/timeEntries", this.weeklyTable);
				this.tsJSONModel.setProperty("/timeEntries/workingDays", this.weeklyTable.workingDays);
				this.tsJSONModel.setProperty("/timeEntries/localcopyTimeData", totalTimeData);

			}
			//this.calculateDailyTotals();
			this.fireEvent(this.evtTimeDataListLoaded, {}, true, true);
		},
		splitTimeDataList: function (aTimeDataList) {
			this.aTimeDataList = [];
			this.aAbsenceDataList = [];
			aTimeDataList.forEach(function (aTimeDataEntry, index) {
				if (aTimeDataEntry.Counter.substring(0, 1) === 'A') {
					this.aAbsenceDataList.push(aTimeDataEntry);
				} else {
					this.aTimeDataList.push(aTimeDataEntry);
				}
			}, this);
		},
		onActivitCodesSuccess: function (rowIndex, oData, resp) {
			if (oData && oData.results && oData.results.length > 0) {
				var aActivityCodes = oData.results;
				this.tsJSONModel.setProperty("/timeEntries/rowTable/" + rowIndex.index + "/activtyCodes", aActivityCodes);
				this.tsJSONModel.setProperty("/timeEntries/rowTable/" + rowIndex.index + "/activtyCodeVisible", true);
			} else {
				this.tsJSONModel.setProperty("/timeEntries/rowTable/" + rowIndex.index + "/activtyCodes", []);
				this.tsJSONModel.setProperty("/timeEntries/rowTable/" + rowIndex.index + "/activtyCodeVisible", false);
			}
			this.fireEvent(this.evtActivityCodesLoaded, {
				"index": rowIndex.index
			}, true, true);
		},

		onRfcCodesSuccess: function (rowIndex, oData, resp) {
			if (oData && oData.length > 0) {
				this.tsJSONModel.setProperty("/timeEntries/rowTable/" + rowIndex + "/rfcCodes", oData);
				this.tsJSONModel.setProperty("/timeEntries/rowTable/" + rowIndex + "/rfcCodeVisible", true);
			} else {
				this.tsJSONModel.setProperty("/timeEntries/rowTable/" + rowIndex + "/rfcCodes", []);
				this.tsJSONModel.setProperty("/timeEntries/rowTable/" + rowIndex + "/rfcCodeVisible", false);
			}
			// this.fireEvent(this.evtActivityCodesLoaded, {
			// 	"index": rowIndex.index
			// }, true, true);
		},

		onAATypeSuccessRow: function (rowIndex, oData, resp) {
			// this.tsJSONModel.setProperty("/dropDowns/AATypes", oData.results);
			if (oData && oData.results && oData.results.length >= 0) {
				var aActivityCodes = oData.results;
				this.tsJSONModel.setProperty("/timeEntries/rowTable/" + rowIndex.index + "/AATypes", aActivityCodes);
				this.tsJSONModel.setProperty("/timeEntries/rowTable/" + rowIndex.index + "/aaTypeVisible", true);
				if (oData.results.length === 1) {
					var row = this.tsJSONModel.getProperty("/timeEntries/rowTable/" + rowIndex.index);
					row.assignment.AWART = oData.results[0].FieldId;
					this.tsJSONModel.setProperty("/timeEntries/rowTable/" + rowIndex.index, row);
				}

			} else {
				this.tsJSONModel.setProperty("/timeEntries/rowTable/" + rowIndex.index + "/AATypes", []);
				this.tsJSONModel.setProperty("/timeEntries/rowTable/" + rowIndex.index + "/aaTypeVisible", false);
			}
			this.fireEvent(this.evtAATypesLoaded, {
				"index": rowIndex.index
			}, true, true);
		},

		onAATypeSuccess: function (oData, resp) {
			this.tsJSONModel.setProperty("/dropDowns/AATypes", oData.results);
		},

		onRecentlyUsedCodesSuccess: function (oData) {
			var aResults = [];
			oData.results.forEach(function (oResult, index) {
				if (oResult.FieldName === 'POSID') {
					oResult.FieldText = 'Chargeable Code';
				} else {
					oResult.FieldText = 'Non-Chargeable Code';
				}
				aResults.push(oResult);

			}, this);

			this.tsJSONModel.setProperty("/dropDowns/recentlyUsedCodes", aResults);
		},
		onCountryCodesSuccess: function (oData) {
			this.tsJSONModel.setProperty("/dropDowns/countryCodes", oData.results);
		},
		// conversion methods 
		convertTimeDataList: function (aTimeDataList) {
			var timeEntry = {
				Pernr: this.pernr
			};
			var aTimeEntries = [];
			if (!(aTimeDataList && aTimeDataList.length > 0)) {
				return aTimeEntries;
			}
			aTimeDataList.forEach(function (oTimeData) {
				if (timeEntry.Counter !== undefined && oTimeData.Counter !== timeEntry.Counter) {
					aTimeEntries.push(timeEntry);
					timeEntry = {
						Pernr: this.pernr
					};
				}
				timeEntry.Counter = oTimeData.Counter;
				timeEntry[oTimeData.FieldName] = oTimeData.FieldValue;
				timeEntry[oTimeData.FieldName + '_Text'] = oTimeData.FieldText;
				timeEntry[oTimeData.FieldName + '_Desc'] = oTimeData.FieldValueText;
			}, this);
			aTimeEntries.push(timeEntry);
			return aTimeEntries;
		},
		calculateDailyTotals: function () {
			this.weeklyTable.clearTotals();
			this.weeklyTable.calculateTotal();
			this.absenceTable.calculateTotal();
		},
		setTimeEntryChanged: function (context, path) {
			var oRow = this.tsJSONModel.getProperty(context);
			var parts = path.split("/");
			var index = parseInt(parts[1]);
			oRow.setTimeEntryChanged(index);
			this.calculateDailyTotals();
			this.tsJSONModel.setProperty("/timeEntries", this.weeklyTable);
			this.fireEvent(this.evtDailyHoursChanged, {}, true, true);
		},
		setDetailVisible: function (context, index) {
			var oRow = this.tsJSONModel.getProperty(context);
			oRow.workDays.forEach(function (workDay, idx) {
				if (idx !== index) {
					workDay.detailVisible = false;
				} else {
					workDay.detailVisible = true;
				}
			}, this);
			this.tsJSONModel.setProperty(context, oRow);
		},
		setRowChanged: function (context, path, fieldName) {
			var oRow = this.tsJSONModel.getProperty(context);
			//oRow.setAllocationChanged(context, subPath);
			// oRow.workDays.forEach(function(oWorkDay, index) {
			// var subPath = "workDays/" + index + "/timeEntry/COUNTER";
			// 	this.setTimeEntryChanged(context, subPath);
			// }, this);	
			// // var statusPath = "";
			// // for (var i = 0; i < 7; i++) {
			// // 	statusPath = context + "/" + "WORKDATE" + i + "/STATUS";
			// // 	this.tsJSONModel.setProperty(statusPath, "CHGD");
			// // }
			oRow.setRowChanged(fieldName);
			this.tsJSONModel.setProperty("/timeEntries", this.weeklyTable);
			// this.tsJSONModel.refresh(true);
		},
		convertTimeEntriestoGrid: function () {
			this.weeklyTable = new kno.tne.timesheet.newTimeSheet.model.TSWeeklytable(this.workingDays);
			this.absenceTable = new kno.tne.timesheet.newTimeSheet.model.TSWeeklytable(this.workingDays);
			this.tsJSONModel.setProperty("/timeEntries", this.weeklyTable);
			this.tsJSONModel.setProperty("/absences", this.absenceTable);
			if (this.aAbsenceEntries && this.aAbsenceEntries.length > 0) {
				this.tsJSONModel.setProperty("/absencesExist", true);
			} else {
				this.tsJSONModel.setProperty("/absencesExist", false);
			}
			this.weeklyTable.setTimeSheetData(this.aTimeEntries);
			this.absenceTable.setTimeSheetData(this.aAbsenceEntries);
			this.calculateDailyTotals();
			//return weeklyTable;
		},

		//utility method to be moved later

		getSapDate: function (oDate) {
			var dateIn = oDate || new Date();
			var year = dateIn.getFullYear();
			var month = (dateIn.getMonth() + 1)
				.toString()
				.padStart(2, "0");
			return dateIn.getFullYear()
				.toString() //Year
				+ (dateIn.getMonth() + 1)
				.toString()
				.padStart(2, "0") // Month 
				+ dateIn.getDate()
				.toString()
				.padStart(2, "0"); // Date
		},
		prepareTimeEntrieforDelete: function (indx) {

			this.selectedIndx = indx;
			var aSelectedRow = this.weeklyTable.rowTable[indx];
			var aTimeEntriesToDelete = [];
			for (var i = 0; i < aSelectedRow.workDays.length; i++) {
				var oCell = aSelectedRow.workDays[i];
				if (!oCell.isDraft())
					aTimeEntriesToDelete.push(oCell);
			}

			return aTimeEntriesToDelete;
		},
		prepareTimeEntriesforSave: function () {
			var aRows = this.weeklyTable.rowTable;
			var aTimeEntriesToSave = [];
			if (aRows && aRows.length > 0) {
				aRows.forEach(function (oRow, index) {
					for (var i = 0; i < oRow.workDays.length; i++) {
						var oCell = oRow.workDays[i];
						if (kno.tne.timesheet.newTimeSheet.model.KeyIsTimeToSubmit) { // For submit only
							if (oCell.isTimeToBeSubmitted()) {
								aTimeEntriesToSave.push(oCell);
							}
						} else { //for other
							if (oCell.isChanged()) {
								aTimeEntriesToSave.push(oCell);
							}
						}
					}
				}, this);
			}
			return aTimeEntriesToSave;
		},
		modelDataChanged: function (evt) {

		},
		moveFrame: function (offset, flag) {
			var vStartDate = this.startDate,
				vEndDate = this.endDate;
			var dStartDate = this.convertSapDate(vStartDate, offset),
				dEndDate = this.convertSapDate(vEndDate, offset);

			this.init(this.pernr, dStartDate, dEndDate, flag);
		},
		moveToDate: function (sDate) {
			this.startDate = this.getSapDate(sDate);
			this.endDate = '00000000';
			this.init(this.pernr, this.startDate, this.endDate);
		},
		convertSapDate: function (sapDate, offset) {
			// var vDate = new Date();
			// vDate.setYear(parseInt(sapDate.substr(0, 4)));
			// vDate.setMonth(parseInt(sapDate.substr(4, 2)) - 1);
			// vDate.setDate(parseInt(sapDate.substr(6, 2)));
			// vDate.setDate(vDate.getDate() + offset);

			var vDate = new Date(parseInt(sapDate.substr(0, 4)), parseInt(sapDate.substr(4, 2)) - 1, parseInt(sapDate.substr(6, 2)) + offset);
			return this.getSapDate(vDate);
		},
		addNewRows: function (sData, sTime) {
			var aEntries = [];
			var aRows = [];
			sData.forEach(function (oSData, indes) {
				var aEntry = {};
				if (oSData.FieldName === "POSID") {
					aEntry.POSID = oSData.FieldId;
					aEntry.POSID_Desc = oSData.FieldValue;
					aEntries.push(aEntry);
				} else if (oSData.FieldName === "RAUFNR") {
					aEntry.RAUFNR = oSData.FieldId;
					aEntry.RAUFNR_Desc = oSData.FieldValue;
					aEntries.push(aEntry);
				} else if (oSData.FieldName === "AWART") {
					aEntry.AWART = oSData.FieldId;
					aEntry.AWART_COST = "AWART";
					aEntry.AWART_DESCR = "AbsenceType";
					aEntries.push(aEntry);
				} else if (oSData.FieldName === "ZZCR_NUMBER") {
					aEntry.RAUFNR = oSData.FieldId;
					aEntry.RAUFNR_Desc = oSData.FieldValue;
					aEntry.ZZCR_NUMBER = oSData.FieldId1;
					aEntry.ZZCR_NUMBER_Desc = oSData.FieldValue1;
					aEntries.push(aEntry);
				}
			}, this);
			aRows = this.weeklyTable.addNewRows(aEntries, sTime);
			this.weeklyTable.checkAddAllocation();
			this.tsJSONModel.setProperty("/timeEntries", this.weeklyTable);
		},
		checkAndSave: function (timeEntries, calledFromextraTime) {

			//CR : App synchronization after lock released - Start
			// calledFromextraTime argument added to identify if this method is being called from Additional hours save.

			/* tirgger the check function import to get all checks that have failed */
			/* if there are no errors returned - call the save function */
			this.saveTimeEntries(timeEntries, calledFromextraTime);
		},

		deleteTimeEntries: function (timeEntries) {

			this.weeklyTable.MessageModel = [];

			timeEntries.forEach(function (oTimeEntry, index) {
				var oTimeEntryToSave = oTimeEntry.prepareToSave();

				oTimeEntryToSave.TimeEntryOperation = 'D';
				// this.createTimeEntry(oTimeEntryToSave, oTimeEntry);
				this.removeTimeEntry(oTimeEntryToSave, oTimeEntry);

			}, this);
			/* tirgger submit all changes to send the updates to the sever 
				in the call back, link the responses to each time entry and show error if any
			*/
			// this.oDataModel.attachBatchRequestCompleted(this.onBatchRequestComplete, this);
			this.oDataModel.attachEventOnce("batchRequestCompleted", this.onBatchDeleteComplete, this);
			this.oDataModel.attachEventOnce("batchRequestFailed", this.onBatchDeleteFailed, this);

		},
		saveTimeEntries: function (timeEntries, calledFromextraTime) {
			//CR : App synchronization after lock released - Start
			// calledFromextraTime argument added to identify if this method is being called from Additional hours save.
			//creating deffered group on the basis of flag calledFromextraTime
			if (!calledFromextraTime) {
				this.oDataModel.setDeferredGroups(["createTime"]);
			}
			this.weeklyTable.MessageModel = [];
			timeEntries.forEach(function (oTimeEntry, index) {
				var oTimeEntryToSave = oTimeEntry.prepareToSave();
				if (!oTimeEntryToSave.Counter || oTimeEntryToSave.Counter === "" || oTimeEntryToSave.Counter.search('NEW') >= 0) {
					oTimeEntryToSave.TimeEntryOperation = 'C';
					this.createTimeEntry(oTimeEntryToSave, oTimeEntry);
				} else if (oTimeEntryToSave.TimeEntryDataFields.CATSHOURS > 0) {
					oTimeEntryToSave.TimeEntryOperation = 'U';
					this.createTimeEntry(oTimeEntryToSave, oTimeEntry);
					// this.updateTimeEntry(oTimeEntryToSave, oTimeEntry);
				} else {
					oTimeEntryToSave.TimeEntryOperation = 'D';
					this.createTimeEntry(oTimeEntryToSave, oTimeEntry);
					// this.removeTimeEntry(oTimeEntryToSave, oTimeEntry);
				}
				/* prepare the data to tbe saved for each time entry. 
					if counter is not empty and hour eq 0 
						trigger remove
					else if counter is not empty and hours is not 0 
						trigger update 
					else if counter is empty and hours is not 0 
						trigger create*/
			}, this);
			/* tirgger submit all changes to send the updates to the sever 
				in the call back, link the responses to each time entry and show error if any
			*/
			// // this.oDataModel.attachBatchRequestCompleted(this.onBatchRequestComplete, this);
			// this.oDataModel.attachEventOnce("batchRequestCompleted", this.onBatchRequestComplete, this);
			// this.oDataModel.attachEventOnce("batchRequestFailed", this.onBatchRequestComplete, this);

			//CR : App synchronization after lock released - Start
			//submitting the requests in batch with groupId 'createTime'
			this.oDataModel.setUseBatch(true);
			this.oDataModel.submitChanges({
				groupId: "createTime",
				changeSetId: 'changeSet',
				success: jQuery.proxy(this.onBatchRequestComplete, this),
				error: jQuery.proxy(this.onBatchRequestComplete, this)
			});
			//CR : App synchronization after lock released - End

		},
		createTimeEntry: function (oTimeEntry, oTSCell) {

			sap.ui.getCore()
				.timeSheet = this;

			this.oDataModel.create("/TimeEntries", oTimeEntry, {
				"success": jQuery.proxy(oTSCell.onSaveSuccess, oTSCell),
				"error": jQuery.proxy(oTSCell.onSaveError, oTSCell),
				changeSetId: 'changeSet', //+ Math.random()
				//CR : App synchronization after lock released - Start
				//Added groupId createTime and adding this request in Batch
				groupId: 'createTime'
					//CR : App synchronization after lock released - End
			});
		},

		checkSAN: function (sDate, otimeEntry) {

			var oSanModel = {
				PERNR: this.pernr,
				WORKDAY: sDate,
				dataline: otimeEntry
			};

			this.oDataModel.create("/SANCheckSet", oSanModel, {
				"success": jQuery.proxy(this.onSanCheckSuccess, this),
				// "error": jQuery.proxy(oTimeEntry.onSaveError, oTimeEntry),
				changeSetId: 'changeSet' //+ Math.random()
			});
		},

		onSanCheckSuccess: function (oData, oResponse) {
			if (oData.GV_TXT1 || oData.GV_TXT2 || oData.GV_TXT3 || oData.GV_TXT4 || oData.GV_TXT5 || oData.GV_TXT6 || oData.GV_TXT7 || oData.GV_TXT8) {
				var sString = oData.GV_TXT1 + " " + oData.GV_TXT2 + " " + oData.GV_TXT3 + " " + oData.GV_TXT4 + " " + oData.GV_TXT5 + " " +
					oData.GV_TXT6 + " " + oData.GV_TXT7 + " " + oData.GV_TXT8;
				if (sString) {
					this.fireEvent(this.evtSANCheckSuccess, {
						SANResults: sString
					}, true, true);
				}
			}

			// debugger;
		},

		CheckESU: function (timeEntries) {

			timeEntries.forEach(function (oTimeEntry, index) {

				var oTimeEntryToSave = oTimeEntry.prepareToSave();

				var oESUCheckModel = {
					PERNR: oTimeEntryToSave.Pernr,
					COUNTER: oTimeEntryToSave.Counter,
					STARTDATE: this.startDate,
					ENDDATE: this.endDate,
					DATALINE: oTimeEntryToSave.TimeEntryDataFields
				};

				this.oDataModel.create("/ESUCHECK_ENTITYSET", oESUCheckModel, {
					"success": jQuery.proxy(this.onESUCheckSuccess, this),
					"error": jQuery.proxy(oTimeEntry.onSaveError, oTimeEntry),
					changeSetId: 'changeSet' //+ Math.random()
				});

			}, this);

		},

		onESUActionHandle: function (oData) {
			this.oDataModel.create("/ESUCHECK_ENTITYSET", oData, {
				"success": jQuery.proxy(this.onESUActionSuccess, this),
				// "error": jQuery.proxy(this.oTSCell.onSaveError, this.oTSCell),
				changeSetId: 'changeSet' //+ Math.random()
			});
		},

		onESUActionSuccess: function (oData, oResponse) {

			this.fireEvent(this.evtESUActionSuccess, {
				ESUActionResult: oData
			}, true, true);

		},

		onESUCheckSuccess: function (oData, oResponse) {

			var sString = "",
				sTxt;
			for (var j = 0; j <= 32; j++) {
				sTxt = "GV_TEXTLINE_" + j;
				sString = sString + oData[sTxt];
			}

			this.tsJSONModel.setProperty("/timeEntries/ESUCheck", oData);
			this.fireEvent(this.evtESUCheckSuccess, {
				ESUResults: sString
			}, true, true);

		},

		getDoctorsVisitDetails: function (oTimeEntry, oTSCell) {

			var aFilters = [];

			var oFilter = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("pernr", sap.ui.model.FilterOperator.EQ, this.pernr),
					new sap.ui.model.Filter("startdate", sap.ui.model.FilterOperator.EQ, this.startDate),
					new sap.ui.model.Filter("enddate", sap.ui.model.FilterOperator.EQ, this.endDate)
				],
				and: true
			});

			aFilters.push(oFilter);

			this.oDataModel.read(
				"/DoctorVisitEntitySet", {
					filters: aFilters,
					success: jQuery.proxy(this.onDocVisitSuccess, this),
					error: jQuery.proxy(this.onDocVisitError, this)
				});
		},

		onDocVisitSuccess: function (oData, oResponse) {

			this.tsJSONModel.setProperty("/timeEntries/docVisit", oData.results);
			if (oData.results.length > 0) {
				this.fireEvent(this.evtDocVisitSuccess, {
					DocResults: oData.results
				}, true, true);
			}
		},

		removeTimeEntry: function (oTimeEntry, oTSCell) {

			this.oDataModel.create("/TimeEntries", oTimeEntry, {
				"success": jQuery.proxy(oTSCell.onDeleteSuccess, oTSCell),
				"error": jQuery.proxy(oTSCell.onSaveError, oTSCell),
				changeSetId: 'changeSet' // + Math.random()
			});
		},

		onBatchRequestComplete: function (oResponse) {
			this.resetAllFlag(true);
			this.fireEvent(this.evtTSSaveComplete, {}, true, true);
			this.onMessageEvtTrigered(this.weeklyTable.MessageModel);
			//CR : App synchronization after lock released - Start
			// resetting the intial data after every Save.
			//CR : App synchronization after lock released - End
		},
		resetAllFlag: function (reloadTS) {
			if (reloadTS) {
				this.getTimesheetData(); //reload timesheet after save and submit.
			}
			kno.tne.timesheet.newTimeSheet.model.KeyIsTimeToSubmit = false;
			kno.tne.timesheet.newTimeSheet.model.KeyIsSubmitMsgShow = false;
		},

		onBatchDeleteComplete: function (oResponse) {
			if (!(this.weeklyTable.MessageModel && this.weeklyTable.MessageModel.length > 0)) {
				this.weeklyTable.rowTable.splice(this.selectedIndx, 1);
				this.tsJSONModel.setProperty("/timeEntries/rowTable", this.weeklyTable.rowTable);
			}
			this.fireEvent(this.evtTSSaveComplete, {}, true, true);
			this.onMessageEvtTrigered(this.weeklyTable.MessageModel);
		},

		onMessageEvtTrigered: function (mMessageModel) {
			this.fireEvent(this.evtTriggerMessage, {
				Messages: mMessageModel
			}, true, true);
		},
		//CR : App synchronization after lock released - Start
		getExistingTimeData: function (afterSave) {
			var expand, fnSuccess, fnError;
			expand = "TimeDataList";
			fnSuccess = jQuery.proxy(this.onExistingDataDSuccess, this);
			//added this check to fetch the updated data after user save the timesheet.
			if (afterSave === true) {
				fnSuccess = jQuery.proxy(this.onUpdateAftrSave, this);
			}

			fnError = jQuery.proxy(this.onExistingDataError, this);
			this.oDataModel.read(
				"/TSInitDataSet(Pernr='" + this.pernr + "',StartDate='" + this.startDate + "',EndDate='" + this.endDate + "')", {
					urlParameters: {
						"$expand": expand
					},
					success: fnSuccess,
					error: fnError,
					// async: false,
					// changeSetId: 'changeSet'
				});
			// this.oDataModel.attachEventOnce("batchRequestCompleted", this.onBatchDeleteComplete, this);
			// this.oDataModel.attachEventOnce("batchRequestFailed", this.onBatchDeleteFailed, this);
		},
		onExistingDataDSuccess: function (oData) {
			var currentCATSData = this.convertTimeDataList(oData.TimeDataList.results);
			var startData = this.tsJSONModel.getProperty("/timeEntries/localcopyTimeData");
			// var appStrtdData = this.tsJSONModel.getProperty("/timeEntries/timesheetData");
			var arrTimeMisMatch = [];
			var initialCATSData = jQuery.extend(true, [], startData);
			// var arrTimeMisMatch = [],
			var msgArr = [];

			this.tsJSONModel.setProperty("/updatedTimeEntry", jQuery.extend(true, [], oData.TimeDataList));

			currentCATSData = currentCATSData.sort(this.sortArray);
			initialCATSData = initialCATSData.sort(this.sortArray);
			var isExist = false;

			for (var i = 0; i < currentCATSData.length; i++) {

				isExist = false;

				initialCATSData.forEach(function (oTimeData, index) {

					if (currentCATSData[i].REFCOUNTER === oTimeData.COUNTER) { // Means Data has been changed in backend

						if (parseFloat(currentCATSData[i].TIME)
							.toFixed(2) !== parseFloat(oTimeData.TIME)
							.toFixed(2)) {

							currentCATSData[i].mode = "Updated";
							arrTimeMisMatch.push(currentCATSData[i]);

							isExist = true; // This flag determies if the record exits

						}
					} else {
						if (currentCATSData[i].COUNTER === oTimeData.COUNTER) {
							isExist = true; // This flag determies if the record exits
						}
					}

				}, this);

				if (isExist === false) { // Record is added in frontend
					currentCATSData[i].mode = "Created";
					arrTimeMisMatch.push(currentCATSData[i]);

				}

			};

			for (var i = 0; i < initialCATSData.length; i++) { // Check for deletion

				isExist = false;

				currentCATSData.forEach(function (oTimeData, index) {

					if (initialCATSData[i].COUNTER === oTimeData.REFCOUNTER || initialCATSData[i].COUNTER === oTimeData.COUNTER) { // Means Data has been changed in backend

						isExist = true; // This flag determies if the record exits

					}

				}, this);

				if (isExist === false) { // Record is Deleted in backend
					initialCATSData[i].mode = "Deleted";
					arrTimeMisMatch.push(initialCATSData[i]);

				}

			}

			// debugger;

			// this.tsJSONModel.setProperty("/ConflictTime", msgArr);
			this.tsJSONModel.setProperty("/ConflictedTimeSheet", arrTimeMisMatch);

			var arrTimeMisMatchFE = [];

			var timeEntries = this.prepareTimeEntriesforSave();

			var oTimeEntryToSave, oTimeEntryDataFields;

			currentCATSData = arrTimeMisMatch;

			timeEntries.forEach(function (oTimeEntry, index) {

				isExist = true;
				oTimeEntryToSave = oTimeEntry.prepareToSave();

				if (oTimeEntryToSave.Counter.indexOf("NEW") > -1) {
					isExist = true;
					for (var i = 0; i < currentCATSData.length; i++) {
						if (currentCATSData[i].WORKDATE === this.getSapDate(oTimeEntryToSave.TimeEntryDataFields.WORKDATE) && !currentCATSData[i].REFCOUNTER &&
							currentCATSData[i].COUNTER) {
							if (oTimeEntryToSave.TimeEntryDataFields["POSID"] && currentCATSData[i]["POSID"] === oTimeEntryToSave.TimeEntryDataFields[
									"POSID"] || currentCATSData[i]["RAUFNR"] ===
								oTimeEntryToSave.TimeEntryDataFields["RAUFNR"] && oTimeEntryToSave.TimeEntryDataFields["RAUFNR"] ||
								(!currentCATSData[i]["POSID"] && !currentCATSData[i]["RAUFNR"] && !oTimeEntryToSave.TimeEntryDataFields["POSID"] && !
									oTimeEntryToSave.TimeEntryDataFields["RAUFNR"] &&
									currentCATSData[i]["AWART"] === oTimeEntryToSave.TimeEntryDataFields["AWART"])
							) {
								isExist = false;
							}
						}
					}
				} else {
					for (var i = 0; i < currentCATSData.length; i++) {
						if (oTimeEntryToSave.Counter === currentCATSData[i].REFCOUNTER) {

							// currentCATSData[i].TIME = parseFloat(oTimeEntryToSave.TimeEntryDataFields.CATSHOURS)
							// 	.toFixed(2);
							// oTimeEntryDataFields.INDEX = index;
							// arrTimeMisMatchFE.push(oTimeEntryDataFields);

							isExist = false;
							break;

						}
						// else {
						// 	if (oTimeEntryToSave.Counter === currentCATSData[i].REFCOUNTER) {
						// 		isExist = true;
						// 	}
						// }
					}

				}

				if (isExist === false) { // Record is deleted from frontend
					oTimeEntryDataFields = oTimeEntryToSave.TimeEntryDataFields;
					oTimeEntryDataFields.PERNR = oTimeEntryToSave.Pernr;
					oTimeEntryDataFields.COUNTER = oTimeEntryToSave.Counter;
					oTimeEntryDataFields.TIME = oTimeEntryDataFields.CATSHOURS;
					oTimeEntryDataFields.WORKDATE = this.getSapDate(oTimeEntryDataFields.WORKDATE);
					oTimeEntryDataFields.INDEX = index;
					arrTimeMisMatchFE.push(oTimeEntryDataFields);

				}

			}, this);

			this.tsJSONModel.setProperty("/FrontEndConflicts", arrTimeMisMatchFE);

			if (arrTimeMisMatch.length > 0) {
				this.fireEvent(this.evtloadExistingTimeSucess, {}, true, true);
			} else {

				this.fireEvent(this.evtSaveTimeSheet, {}, true, true);

			}
		},
		sortArray: function (a, b) {
			if (a.COUNTER < b.COUNTER)
				return -1;
			if (a.COUNTER > b.COUNTER)
				return 1;
			return 0;
		},
		onUpdateAftrSave: function (oData) {
			var timesheetData = this.convertTimeDataList(oData.TimeDataList.results); //this.tsJSONModel.getProperty("/timeEntries/timesheetData");
			this.tsJSONModel.setProperty("/timeEntries/localcopyTimeData", jQuery.extend(true, [], timesheetData));
		},
		//CR : App synchronization after lock released - End

	});
	return TimeSheet;
});