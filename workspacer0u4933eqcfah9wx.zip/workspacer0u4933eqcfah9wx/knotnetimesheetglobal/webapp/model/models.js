sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device"
], function(JSONModel, Device) {
	"use strict";

	return {

		createDeviceModel: function() {
			var oModel = new JSONModel(Device);
			oModel.setDefaultBindingMode("OneWay");
			return oModel;
		},

		// getDayName: function(sDate) {

		// 	var vDate = new Date();
		// 	vDate.setYear(parseInt(sapDate.substr(0, 4)));
		// 	vDate.setMonth(parseInt(sapDate.substr(4, 2)) - 1);
		// 	vDate.setDate(parseInt(sapDate.substr(6, 2)));

		// },

		getDayOfMonth: function(sDate) {
			return sDate.substr(6, 2);

		}

	};
});