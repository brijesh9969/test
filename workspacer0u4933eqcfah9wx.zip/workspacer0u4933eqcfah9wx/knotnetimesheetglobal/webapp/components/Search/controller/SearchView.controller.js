var kno = kno || {};
jQuery.sap.require("kno.tne.timesheet.newTimeSheet.model.TimeSheet");
jQuery.sap.require("kno.tne.timesheet.newTimeSheet.components.Search.model.SearchModel");
jQuery.sap.require("kno.tne.timesheet.newTimeSheet.lib.control.TimesheetListItem");
sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("kno.tne.timesheet.newTimeSheet.components.Search.controller.SearchView", {

		costObjects: [],

		onInit: function() {

			this.oDataModel = this.getOwnerComponent()
				.getModel();
			this.searchModel = new kno.tne.timesheet.newTimeSheet.components.Search.model.SearchModel(this.oDataModel);
			this.getView()
				.setModel(this.searchModel.SearchJSONModel, "SearchModel");
			this.searchModel.attachEvent(this.searchModel.evtSearchResultsLoaded, {}, this.handleSearchResultsLoaded, this);
			var oComponentData = this.getOwnerComponent()
				.getComponentData();
			if (oComponentData && oComponentData.startupParameters.oParameters.type === "AddCode") {
				var arrTimeEntries = oComponentData.oModel.aTimeEntries;
				var arrCostObjModel = [];
				var sCostId, sCostDesc, sCostTyp;
				for (var i = 0; i < arrTimeEntries.length; i++) {

					if (arrTimeEntries[i].POSID) {

						sCostId = arrTimeEntries[i].POSID;
						sCostDesc = arrTimeEntries[i].POSID_Desc;
						sCostTyp = "POSID";
					}

					var oModel = {
						EndDate: "",
						FieldId: sCostId,
						FieldName: sCostTyp,
						FieldRelated: "",
						FieldValue: sCostDesc,
						Pernr: "",
						StartDate: ""
					};

					arrCostObjModel.push(oModel);

				}

				var arrCostObjModelNew = this.removeDuplicates(arrCostObjModel);

				this.getView()
					.getModel("SearchModel")
					.setProperty("/searchResults", arrCostObjModelNew);

				// this.getView()
				// 	.getModel("SearchModel")
				// 	.refresh(true);

			}
			this.aatypes = [];
			this.rfcList = [];
			if (oComponentData && oComponentData.oModel && oComponentData.oModel.tsJSONModel) {
				this.aatypes = oComponentData.oModel.tsJSONModel.getProperty("/dropDowns/AATypes");
				this.getView()
					.getModel("SearchModel")
					.setProperty("/AATypes", this.aatypes);
				this.rfcList = oComponentData.oModel.tsJSONModel.getProperty("/dropDowns/rfcList");
				this.getView()
					.getModel("SearchModel")
					.setProperty("/rfcList", this.rfcList);
			}
			this.costObjects = [];
			this.searchModel.SearchJSONModel.setProperty("/searchResults", oComponentData.startupParameters.oParameters.RecentlyUsed);

			//Added by Santosh for Stop watch issue - Start
			if (oComponentData.startupParameters.oParameters.type === "AddCode") {
				var rowTable = oComponentData.oModel.tsJSONModel.getProperty("/timeEntries/rowTable");
				var tmpArr = [];
				for (var i in rowTable) {
					tmpArr[rowTable[i].assignment.POSID] = rowTable[i].assignment;
				}
				var recentUsed = oComponentData.startupParameters.oParameters.RecentlyUsed;
				var arrCostObjModel = [];
				for (var j in recentUsed) {
					if (tmpArr[recentUsed[j].FieldId]) {
						arrCostObjModel.push(recentUsed[j]);
					}
				}
				this.searchModel.SearchJSONModel.setProperty("/searchResults", arrCostObjModel);
			}
			//Added by Santosh for Stop watch issue - End
		},
		onSearch: function(evt) {
			this.getView()
				.setBusy(true);
			this.searchModel.executeSearch();
		},
		onFilterAATypes: function(oEvt) {
			var oModel = this.getView()
				.getModel("SearchModel");
			var vFilter = oEvt.getParameters("newValue"); //oModel.getProperty("/AATypesFilterValue"); //oEvt.getParameters("newValue"); //oModel.getProperty("/AATypesFilterValue");
			var oList = this.getView()
				.byId("idAttAbsTypes");
			var aItems = oList.getItems();
			aItems.forEach(function(oItem, index) {
				var oContextPath = oItem.getBindingContextPath();
				if (oContextPath) {
					var oEntry = oModel.getProperty(oContextPath);
					if ((oEntry.FieldId && oEntry.FieldId.toUpperCase()
							.search(vFilter.newValue.toUpperCase()) >= 0) ||
						(oEntry.FieldValue && oEntry.FieldValue.toUpperCase()
							.search(vFilter.newValue.toUpperCase()) >= 0)) {
						oItem.setVisible(true);
					} else {
						oItem.setVisible(false);
					}
				}
			}, this);
		},

		onFilterRfcList: function(oEvt) {
			var oModel = this.getView()
				.getModel("SearchModel");
			var vFilter = oEvt.getParameters("newValue"); //oModel.getProperty("/AATypesFilterValue"); //oEvt.getParameters("newValue"); //oModel.getProperty("/AATypesFilterValue");
			var oList = this.getView()
				.byId("idRFCCodes");
			var aItems = oList.getItems();
			aItems.forEach(function(oItem, index) {
				var oContextPath = oItem.getBindingContextPath();
				if (oContextPath) {
					var oEntry = oModel.getProperty(oContextPath);
					if ((oEntry.FieldId && oEntry.FieldId.toUpperCase()
							.search(vFilter.newValue.toUpperCase()) >= 0) ||
						(oEntry.FieldValue && oEntry.FieldValue.toUpperCase()
							.search(vFilter.newValue.toUpperCase()) >= 0) || (oEntry.FieldValue1 && oEntry.FieldValue1.toUpperCase()
							.search(vFilter.newValue.toUpperCase()) >= 0) || (oEntry.FieldId1 && oEntry.FieldId1.toUpperCase()
							.search(vFilter.newValue.toUpperCase()) >= 0)) {
						oItem.setVisible(true);
					} else {
						oItem.setVisible(false);
					}
				}
			}, this);
		},
		onFilterRecentList: function(oEvt) {
			var oModel = this.getView()
				.getModel("SearchModel");
			var vFilter = oEvt.getParameters("newValue"); //oModel.getProperty("/AATypesFilterValue"); //oEvt.getParameters("newValue"); //oModel.getProperty("/AATypesFilterValue");
			var oList = this.getView()
				.byId("idCostObjTable");
			var aItems = oList.getItems();
			aItems.forEach(function(oItem, index) {
				var oContextPath = oItem.getBindingContextPath();
				if (oContextPath) {
					var oEntry = oModel.getProperty(oContextPath);
					if ((oEntry.FieldId && oEntry.FieldId.toUpperCase()
							.search(vFilter.newValue.toUpperCase()) >= 0) ||
						(oEntry.FieldValue && oEntry.FieldValue.toUpperCase()
							.search(vFilter.newValue.toUpperCase()) >= 0) || (oEntry.FieldValue1 && oEntry.FieldValue1.toUpperCase()
							.search(vFilter.newValue.toUpperCase()) >= 0) || (oEntry.FieldId1 && oEntry.FieldId1.toUpperCase()
							.search(vFilter.newValue.toUpperCase()) >= 0)) {
						oItem.setVisible(true);
					} else {
						oItem.setVisible(false);
					}
				}
			}, this);
		},
		handleSearchResultsLoaded: function() {
			this.getView()
				.setBusy(false);
		},

		onAfterRendering: function() {
			var oComponentData = this.getOwnerComponent()
				.getComponentData();
			if (oComponentData && oComponentData.startupParameters.oParameters.type === "AddCodeFrmRecUsed") {
				this.getView()
					.byId("idCostObjTable")
					.setMode("SingleSelectLeft");

			}
		},

		onActionAddCode: function(oEvent) {
			var oComponentData = this.getOwnerComponent()
				.getComponentData();
			var eventBus = sap.ui.getCore()
				.getEventBus();

			var oModel = this.getView()
				.getModel("SearchModel");
			var mSelectedItem, sPath;

			var oCostObjTable = this.getView()
				.byId("idCostObjTable");
			var oAATypesTable = this.getView()
				.byId("idAttAbsTypes");
			var arrSelectedItems = [];
			var oRFCTable = this.getView()
				.byId('idRFCCodes');
			arrSelectedItems = arrSelectedItems.concat(oCostObjTable.getSelectedItems());
			arrSelectedItems = arrSelectedItems.concat(oAATypesTable.getSelectedItems());
			arrSelectedItems = arrSelectedItems.concat(oRFCTable.getSelectedItems());

			for (var i = 0; i < arrSelectedItems.length; i++) {
				sPath = arrSelectedItems[i].getBindingContextPath();
				mSelectedItem = oModel.getProperty(sPath);
				var mCostObjects = {
					FieldId: mSelectedItem.FieldId,
					FieldName: mSelectedItem.FieldName,
					FieldValue: mSelectedItem.FieldValue,
					FieldValue1: mSelectedItem.FieldValue1,
					FieldId1: mSelectedItem.FieldId1
				};
				this.costObjects.push(mCostObjects);
			}

			if (oComponentData && oComponentData.startupParameters.oParameters.type === "AddCode") {
				eventBus.publish("channel1", "AddCode", {
					costObjects: this.costObjects
				});
			} else {
				if (oComponentData && oComponentData.startupParameters.oParameters.type === "AddCodeFrmRecUsed") {
					eventBus.publish("addCodeRec", "AddCodeRec", {
						costObjects: this.costObjects
					});
				} else {
					eventBus.publish("addCodeGeneral", "AddCodeGeneral", {
						costObjects: this.costObjects
					});
				}

			}
		},

		onChangeSelection: function(oEvent) {
			// var sPath = oEvent.getParameter("listItem")
			// 	.getBindingContextPath();
			// var oModel = this.getView()
			// 	.getModel("SearchModel");
			// var mSelectedItem = oModel.getProperty(sPath);

			// var mCostObjects = {
			// 	FieldId: mSelectedItem.FieldId,
			// 	FieldName: mSelectedItem.FieldName,
			// 	FieldValue: mSelectedItem.FieldValue
			// };
			// this.costObjects.push(mCostObjects);
		},
		removeDuplicates: function(arr) {

			arr.sort(function(a, b) {
				return (a.FieldId > b.FieldId) ? 1 : ((b.FieldId > a.FieldId) ? -1 : 0);
			});
			for (var i = 1; i < arr.length;) {
				if (arr[i - 1].FieldId === arr[i].FieldId && arr[i - 1].FieldValue === arr[i].FieldValue) {
					arr.splice(i, 1);
				} else {
					i++;
				}
			}
			return arr;

		},
		onActionCancelCode: function(oEvent) {
			var eventBus = sap.ui.getCore()
				.getEventBus();
			eventBus.publish("CanCode", "CancelCode", {
				costObjects: this.costObjects
			});
		}
	});
});