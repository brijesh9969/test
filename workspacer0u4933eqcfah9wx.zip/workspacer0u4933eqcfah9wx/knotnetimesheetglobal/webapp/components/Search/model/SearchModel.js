var kno = kno || {};
sap.ui.define([
	"sap/ui/base/EventProvider"
], function(EventProvider) {
	"use strict";

	var TimeSheet = EventProvider.extend("kno.tne.timesheet.newTimeSheet.components.Search.model.SearchModel", {
		evtsearchResultsLoaded: 'searchResultsLoaded',
		// evtInitialized: 'initialized',
		// evtWorkCalendarsLoaded: 'workCalendarsLoaded',
		// evtInitialInfosLoaded: 'initialInfosLoaded',
		// evtProfileFieldsLoaded: 'profileFieldsLoaded',
		// evtDelegateSetLoaded: 'delegateSetLoaded',
		// evtActivityCodesLoaded: 'activityCodesLoaded',
		evtAATypesLoaded: 'AATypesLoaded',
		evtRFCCodesLoaded: 'RFCCodesLoaded',
		metadata: {
			events: {
				searchResultsLoaded: {},
				AATypesLoaded: {},
				RFCCodesLoaded: {}
			}
		},
		constructor: function(oDataModel) {
			EventProvider.call(this);
			this.oDataModel = oDataModel;
			this.SearchJSONModel = new sap.ui.model.json.JSONModel()
				.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
			this.SearchJSONModel.setSizeLimit(10000);
			this.SearchJSONModel.setProperty('/searchValue', "");
			this.SearchJSONModel.setProperty('/searchResults', []);
			// this.tsJSONModel.attachPropertyChange({}, this.modelDataChanged, this);
		},
		init: function() {

		},
		executeSearch: function() {
			var SearchTerm = this.SearchJSONModel.getProperty("/searchValue");
			this.SearchJSONModel.setProperty("/searchResults", []);
			// Prepare filters for time data list 
			var aFilters = [];
			var oFilter = {};
			oFilter = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("FieldName", sap.ui.model.FilterOperator.EQ, 'POSID'),
					new sap.ui.model.Filter("FieldValue", sap.ui.model.FilterOperator.Contains, SearchTerm)
				],
				and: true
			});
			aFilters.push(oFilter);
			this.oDataModel.read(
				"/ValueHelpList", {
					filters: aFilters,
					success: jQuery.proxy(this.onSearchSuccess, this),
					error: jQuery.proxy(this.onError, this)
				}
			);
			aFilters = [];
			oFilter = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("FieldName", sap.ui.model.FilterOperator.EQ, 'RAUFNR'),
					new sap.ui.model.Filter("FieldValue", sap.ui.model.FilterOperator.Contains, SearchTerm)
				],
				and: true
			});
			aFilters.push(oFilter);
			this.oDataModel.read(
				"/ValueHelpList", {
					filters: aFilters,
					success: jQuery.proxy(this.onSearchSuccess, this),
					error: jQuery.proxy(this.onError, this)
				}
			);
		},
		onSearchSuccess: function(oData) {
			var arrResults = this.SearchJSONModel.getProperty("/searchResults");

			oData.results.forEach(function(oRes, indx) {
				if (oRes.FieldName === 'POSID') {
					oRes.FieldText = 'Chargeable Code';
				} else {
					oRes.FieldText = 'Non Chargeable Code';
				}
			}, this);
			arrResults = arrResults.concat(oData.results);
			this.SearchJSONModel.setProperty("/searchResults", arrResults);
			this.fireEvent(this.evtSearchResultsLoaded, {}, true, true);
		},
		onError: function() {

		}
	});
	return TimeSheet;
});