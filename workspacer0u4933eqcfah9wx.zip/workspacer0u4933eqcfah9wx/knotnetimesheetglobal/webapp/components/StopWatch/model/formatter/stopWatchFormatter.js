(function() {
	'use strict';
	jQuery.sap.declare("kno.tne.timesheet.newTimeSheet.components.StopWatch.model.formatter.stopWatchFormatter");
	// var kno = kno || {};
	kno.tne.timesheet.newTimeSheet.components.StopWatch.model.formatter.stopWatchFormatter = {};
	kno.tne.timesheet.newTimeSheet.components.StopWatch.model.formatter.stopWatchFormatter.formatTimer = function(t) {
		if (!t) {
			t = 0;
		}
		var v = Math.round((t / 60) / 60);
		return (v < 10) ? '0' + v : v;
	};

	kno.tne.timesheet.newTimeSheet.components.StopWatch.model.formatter.stopWatchFormatter.formatTime = function(t) {
		if (!t) {
			t = 0;
		}
		var v = t % 60;
		return (v < 10) ? '0' + v : v;
	};
	kno.tne.timesheet.newTimeSheet.components.StopWatch.model.formatter.stopWatchFormatter.start = function(t) {
		return !t;
	};

})();