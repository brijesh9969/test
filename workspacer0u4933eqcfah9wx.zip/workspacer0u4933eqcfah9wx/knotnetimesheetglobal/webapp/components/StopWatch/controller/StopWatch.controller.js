var kno = kno || {};
// jQuery.sap.require("kno.tne.timesheet.newTimeSheet.model.TimeSheet");
// jQuery.sap.require("kno.tne.timesheet.newTimeSheet.components.Search.model.StopWat");
// jQuery.sap.require("kno.tne.timesheet.newTimeSheet.lib.control.TimesheetListItem");
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"kno/tne/timesheet/newTimeSheet/components/StopWatch/model/formatter/stopWatchFormatter"
], function(Controller, formatter) {
	"use strict";

	return Controller.extend("kno.tne.timesheet.newTimeSheet.components.StopWatch.controller.StopWatch", {

		// costObjects: [],
		formatter: formatter,
		reinit: function() {
			var oBtnAdd = this.getView()
				.byId("addCodes");
			oBtnAdd.setEnabled(false);
		},
		onInit: function() {
			// this.oDataModel = this.getOwnerComponent()
			// 	.getModel();
			// this.searchModel = new kno.tne.timesheet.newTimeSheet.components.Search.model.SearchModel(this.oDataModel);
			// this.getView()
			// 	.setModel(this.searchModel.SearchJSONModel, "SearchModel");
			// this.searchModel.attachEvent(this.searchModel.evtSearchResultsLoaded, {}, this.handleSearchResultsLoaded, this);
			var model = new sap.ui.model.json.JSONModel({
				timer: 0,
				start: false,
				hours: 0,
				minutes: 0,
				seconds: 0
			});

			this.getView()
				.setModel(model);
			this.timer = 0;

		},
		onStartTimer: function() {

			var m = this.getView()
				.getModel();
			m.setProperty('/start', true);
			var min, minutes, hours;
			this.timer = setInterval(function() {
				m.setProperty('/timer', m.getProperty('/timer') + 1);
				if (m.getProperty('/timer') > 60) {
					min = m.getProperty('/timer');
					minutes = Math.floor(min / 60);
					m.setProperty('/minutes', minutes);
					m.refresh(true);
				}

				if (m.getProperty('/timer') > 3600) {
					hours = Math.floor(m.getProperty('/timer') / 3600);
					m.setProperty('/hours', hours);
					m.refresh(true);
				}
			}, 1000);
			var oBtnAdd = this.getView()
				.byId("addCodes");
			oBtnAdd.setEnabled(false);

		},

		onPauseTimer: function() {

			clearInterval(this.timer);
			var m = this.getView()
				.getModel();
			m.setProperty('/start', false);
			var oBtnAdd = this.getView()
				.byId("addCodes");
			oBtnAdd.setEnabled(true);
		},

		onRestartTimer: function() {

			if (this.timer) {
				clearInterval(this.timer);
				this.timer = null;
			}
			var m = this.getView()
				.getModel();
			m.setProperty('/start', false);
			m.setProperty('/timer', 0);
			m.setProperty('/minutes', 0);
			m.setProperty('/hours', 0);
			var oBtnAdd = this.getView()
				.byId("addCodes");
			oBtnAdd.setEnabled(false);

		},

		onAddCode: function() {

			var eventBus = sap.ui.getCore()
				.getEventBus();

			this.timer = 0;
			var m = this.getView()
				.getModel();
			var sHour1 = m.getProperty('/hours');
			var sHour2 = m.getProperty('/minutes') / 60;
			var sHour3 = m.getProperty('/timer') / 3600;

			var sTotalHours = sHour1 + sHour2 + sHour3;

			sTotalHours = parseFloat(sTotalHours)
				.toFixed(2);

			if (sTotalHours < 0.01) {
				sTotalHours = 0.01;
			}

			eventBus.publish("stopWatch", "AddTime", {
				time: sTotalHours
			});

			// m.setProperty('/timer', 0);
			// m.setProperty('/minutes', 0);
			// m.setProperty('/hours', 0);

			var model = new sap.ui.model.json.JSONModel({
				timer: 0,
				start: false,
				hours: 0,
				minutes: 0,
				seconds: 0
			});

			this.getView()
				.setModel(model);
			this.timer = 0;

		},

		cancelStopWatch: function() {
			var eventBus = sap.ui.getCore()
				.getEventBus();
			eventBus.publish("CanStopWatch", "CancelWatch", {
				costObjects: this.costObjects
			});
		},

		onExit: function() {

			var model = new sap.ui.model.json.JSONModel({
				timer: 0,
				start: false,
				hours: 0,
				minutes: 0,
				seconds: 0
			});

			this.getView()
				.setModel(model);
			this.timer = 0;

			this.destroy();

		}

	});
});