(function() {
	'use strict';
	jQuery.sap.declare("kno.tne.timesheet.newTimeSheet.components.AdditionalHours.model.formatter.stopWatchFormatter");
	// var kno = kno || {};
	kno.tne.timesheet.newTimeSheet.components.AdditionalHours.model.formatter.extraHoursFormatter = {};
	kno.tne.timesheet.newTimeSheet.components.AdditionalHours.model.formatter.extraHoursFormatter.formatTimer = function(t) {
		if (!t) {
			t = 0;
		}
		var v = Math.round((t / 60) / 60);
		return (v < 10) ? '0' + v : v;
	};

	kno.tne.timesheet.newTimeSheet.components.AdditionalHours.model.formatter.extraHoursFormatter.formatDate = function(t) {

		return t.slice(6, 8) + "/" + t.slice(4, 6) + "/" + t.slice(0, 4);
	};
	kno.tne.timesheet.newTimeSheet.components.AdditionalHours.model.formatter.extraHoursFormatter.formatHours = function(str) {
		if (!str) {
			str = 0;
		}
		return parseFloat(str)
			.toFixed(2);
	};

})();