var kno = kno || {};
// jQuery.sap.require("kno.tne.timesheet.newTimeSheet.model.TimeSheet");
// jQuery.sap.require("kno.tne.timesheet.newTimeSheet.components.Search.model.StopWat");
// jQuery.sap.require("kno.tne.timesheet.newTimeSheet.lib.control.TimesheetListItem");
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"kno/tne/timesheet/newTimeSheet/components/AdditionalHours/model/formatter/extraHoursFormatter"
], function(Controller, formatter) {
	"use strict";

	return Controller.extend("kno.tne.timesheet.newTimeSheet.components.AdditionalHours.controller.AdditionalHours", {

		// costObjects: [],
		formatter: formatter,
		oIssues: {
			extraHours: [],
			esuCheck: [],
			timelog: []
		},

		onInit: function() {
			var oComponentData = this.getOwnerComponent()
				.getComponentData();

			var oModel = this.oTimeSheetModel = oComponentData.oModelTime;
			this.getView()
				.setModel(oModel.tsJSONModel, "TimeSheetGrid");
			this.registerTSModelEvents();
			this.oDataModel = oComponentData.oDataModel;
			this.oMessageModel = oComponentData.oMessageModel;
			var eventBus = sap.ui.getCore()
				.getEventBus();
			eventBus.subscribe("DisPlaySMessages", "onDisPlaySMessages", this.processMessages, this);

			var mExtraHoursModel = new sap.ui.model.json.JSONModel({
				items: []
			});

			this.getView()
				.setModel(mExtraHoursModel, "mExtraHoursModel");

			// var mInOutTime = this.getView()
			// 	.getModel("TimeSheetGrid")
			// 	.getProperty("/timeEntries/timeLog");

			// var oIcnTab = this.getView()
			// 	.byId("idIconTabBar");

			// if (mInOutTime) {
			// 	oIcnTab.getItems()[1].setVisible(true);
			// } else {
			// 	oIcnTab.getItems()[1].setVisible(false);
			// }
			this.getReasonCodes();
		},

		// loadData: function() {
		// 	this.oTimeSheetModel.getExtraTimeJustifications();
		// 	this.getReasonCodes();
		// },
		loadAdditionalHoursData: function() {
			var vCount = this.oIssues.extraHours.length;
			if (vCount > 0) {
				this.oTimeSheetModel.getExtraTimeJustifications();
				// this.getReasonCodes();
			}
		},
		loadTimeLogData: function() {
			var vCount = this.oIssues.timelog.length;
			if (vCount > 0) {
				this.oTimeSheetModel.getTimeLogData();
				//this.oTimeSheetModel.getExtraTimeJustifications();
				//this.getReasonCodes();
			}
		},
		loadEsuCheckData: function() {
			var vCount = this.oIssues.esuCheck.length;
			if (vCount > 0) {

				//this.oTimeSheetModel.getExtraTimeJustifications();
				//this.getReasonCodes();
			}
		},
		processMessages: function(sChannel, sEvent, sData) {
			var sMessages = sData.sheetMessages;
			var oIssues = {
				extraHours: [],
				esuCheck: [],
				timelog: []
			};
			/* group messages based on message number */
			sMessages.forEach(function(sMessage, index) {
				//sMessage.message
				if (sMessage.id === '068' || sMessage.id === '068') {
					oIssues.extraHours.push(sMessage);
					// oIssues.timelog.push(sMessage);

				} else if (sMessage.id === '091') {
					oIssues.timelog.push(sMessage);

				} else if (sMessage.id === '102') {
					oIssues.esuCheck.push(sMessage);
				}
			}, this);
			this.oIssues = oIssues;
			this.oMessageModel = sData.sheetMessages;
			this.updateUI();
		},
		updateUI: function() {
			this.displayMessages();
			var oIcnTab = this.getView()
				.byId("idIconTabBar");
			if (this.oIssues.extraHours && this.oIssues.extraHours.length > 0) {
				oIcnTab.getItems()[0].setVisible(true);
			} else {
				oIcnTab.getItems()[0].setVisible(false);
			}
			if (this.oIssues.timelog && this.oIssues.timelog.length > 0) {
				oIcnTab.getItems()[1].setVisible(true);
			} else {
				oIcnTab.getItems()[1].setVisible(false);
			}
			/* proess Additional Hours */
			this.loadAdditionalHoursData();
			/* process In out Time Log */
			this.loadTimeLogData();
			/* process esu check */
			this.loadEsuCheckData();
		},
		displayMessages: function( /*sChannel, sEvent, sData*/ ) {
			//this.loadData();
			// var sMessages = sData.sheetMessages;
			var sMessages = this.oMessageModel;
			this.getView()
				.getModel("mMessageModel")
				.setProperty("/items", sMessages);
			this.oMessageModel = sMessages;
			// this.getView()
			// 	.getModel("mMessageModel")
			// 	.refresh(true);

		},

		onExit: function() {
			this.destroy();
		},

		cancelExtraHours: function() {

			var arrOldModel = this.getView()
				.getModel("TimeSheetGrid")
				.getProperty("/timeEntries/timeLog");

			if (arrOldModel && arrOldModel.length > 0) {

				for (var i = 0; i < arrOldModel.length; i++) {

					arrOldModel[i].inTime = "";
					arrOldModel[i].outTime = "";

				}

				this.getView()
					.getModel("TimeSheetGrid")
					.setProperty("/timeEntries/timeLog", arrOldModel);

			}

			var eventBus = sap.ui.getCore()
				.getEventBus();
			eventBus.publish("CanExtHours", "CanExtraHours");
		},

		updateExtraHours: function(oEvent) {
			var sHours = oEvent.getParameter("value");
			if (!sHours) {
				sHours = 0;
			}
			// sHours = parseFloat(sHours)
			// 	.toFixed(2);
			var contextObj = oEvent.getSource()
				.getParent()
				.getParent()
				.getBindingContext("mExtraHoursModel")
				.getObject();
			sHours = parseFloat(contextObj.ReasonHours)
				.toFixed(2);

			var sPath = oEvent.getSource()
				.getParent()
				.getParent()
				.getBindingContextPath();

			// var contextObj = oEvent.getSource()
			// 	.getParent()
			// 	.getParent()
			// 	.getBindingContext("mExtraHoursModel")
			// 	.getObject();
			var catsHours = contextObj.Hours;
			var ReasonHours = contextObj.ReasonHours;
			if (ReasonHours > catsHours) {
				// oEvent.getSource()
				// 	.setValueState("Error");
				// oEvent.getSource()
				// 	.setValueStateText("Passive hours can not be greater than CATS hours");
				// // return;
				var sMsg = "Passive hours can not be greater than CATS hours";
				sap.m.MessageBox.error(sMsg, {
					title: "Error", // default
					onClose: null, // default
					initialFocus: null, // default
					textDirection: sap.ui.core.TextDirection.Inherit // default
				});
				return;

			}
			this.getView()
				.getModel("mExtraHoursModel")
				.setProperty(sPath + "/ReasonHours", sHours);

			var sActualHours = this.getView()
				.getModel("mExtraHoursModel")
				.getProperty(sPath + "/Hours");

			if (sActualHours > parseFloat(oEvent.getParameter("value")) + parseFloat("10")) {
				this.getView()
					.getModel("mExtraHoursModel")
					.setProperty(sPath + "/ExtraHoursReasonEdit", true);
			} else {
				this.getView()
					.getModel("mExtraHoursModel")
					.setProperty(sPath + "/ExtraHoursReasonEdit", false);

				this.getView()
					.getModel("mExtraHoursModel")
					.setProperty(sPath + "/ExtraHoursReason", "");

			}

		},

		onReasonChange: function(oEvent) {
			// var sPath = oEvent.getSource()
			// 	.getBinding("selectedKey")
			// 	.getContext()
			// 	.getPath() + "/FieldRelated";

			var sIndx = oEvent.getSource()
				.getSelectedItem()
				.getId()
				.split("-")[oEvent.getSource()
					.getSelectedItem()
					.getId()
					.split("-")
					.length - 1];

			// var fieldReleted = this.getView()
			// 	.getModel("mExtraReason")
			// 	.getProperty(sPath);

			var sPath = oEvent.getSource()
				.getSelectedItem()
				.getBindingContext("mExtraHoursModel")
				.getPath();

			var fieldReleted = this.getView()
				.getModel("mExtraHoursModel")
				.getProperty(sPath)
				.FIELD_RELATED;

			var mExtraHours = this.getView()
				.getModel("mExtraHoursModel");
			var sPathFreeTxtVis = oEvent.getSource()
				.getParent()
				.getParent()
				.getBindingContextPath() + "/FreeTxtVis";

			var sExtraHoursEdit = oEvent.getSource()
				.getParent()
				.getParent()
				.getBindingContextPath() + "/ExtraHoursEdit";

			//Begin of change Extra hours reason for sunday working free text visibility
			var sExtraHoursReasonEdit = oEvent.getSource()
				.getParent()
				.getParent()
				.getBindingContextPath() + "/ExtraHoursReasonEdit";
			//End of change Extra hours reason for sunday working free text visibility

			if (fieldReleted.split("|")[2] === 'X') {

				mExtraHours.setProperty(sPathFreeTxtVis, true);

			} else {
				mExtraHours.setProperty(sPathFreeTxtVis, false);
			}

			if (fieldReleted.split("|")[0] === 'X') {

				mExtraHours.setProperty(sExtraHoursEdit, true);

			} else {
				mExtraHours.setProperty(sExtraHoursEdit, false);
			}

			////Begin of change Extra hours reason for sunday working free text visibility
			if (fieldReleted.split("|")[4] === 'X') {

				mExtraHours.setProperty(sExtraHoursReasonEdit, true);
				mExtraHours.setProperty(sExtraHoursEdit, true);

			} else {
				mExtraHours.setProperty(sExtraHoursReasonEdit, false);

				if (fieldReleted.split("|")[0] === 'X') {

					mExtraHours.setProperty(sExtraHoursEdit, true);

				} else {
					mExtraHours.setProperty(sExtraHoursEdit, false);
				}
			}
			//End of change Extra hours reason for sunday working free text visibility
		},
		onReasonCodeSuccess: function(oData, oResponse) {

			// var arrExtraHoursReason = [];

			// var mExtraHoursModel = new sap.ui.model.json.JSONModel({
			// 	items: arrExtraHoursReason
			// });

			// this.getView()
			// 	.setModel(mExtraHoursModel, "mExtraHoursModel");

		},

		onReasonCodeError: function(oResponse) {
			// var mExtraHoursModel = new sap.ui.model.json.JSONModel({
			// 	items: []
			// });

			// this.getView()
			// 	.setModel(mExtraHoursModel, "mExtraHoursModel");
		},
		getReasonCodes: function() {
			var aFilters = [];
			var oFilter = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("FieldName", sap.ui.model.FilterOperator.EQ, 'OVERTIME')
				],
				and: true
			});
			aFilters.push(oFilter);

			var fnReasonCodeSuccess = jQuery.proxy(function(oData, response) {
					// var arrExtraHoursReason = [];

					var mExtraReason = new sap.ui.model.json.JSONModel({
						items: oData.results
					});

					this.getView()
						.setModel(mExtraReason, "mExtraReason");
				},
				this);

			var fnReasonCodeError = jQuery.proxy(function(oData, response) {

				var mExtraReason = new sap.ui.model.json.JSONModel({
					items: []
				});

				this.getView()
					.setModel(mExtraReason, "mExtraReason");
			}, this);

			this.oDataModel.read("/ValueHelpList", {
				urlParameters: {},
				filters: aFilters,
				success: fnReasonCodeSuccess,
				error: fnReasonCodeError
			});
		},

		getReasonCodeModel: function(sDate, sFreeDay, sAwart47) {

			var fnReasonModelSuccess = jQuery.proxy(function(oData, response) {
					var mExtraHoursModel = this.getView()
						.getModel("mExtraHoursModel");
					var arrExtraHoursModel = mExtraHoursModel.getData()
						.items;

					arrExtraHoursModel.forEach(function(oReason, index) {

						if (oData.results.length > 0) {
							for (var i = 0; i < oData.results.length; i++) {
								if (oData.results[i].WORKDAY === oReason.Date) {
									oReason.mReasons.push(oData.results[i]);
								}
							}
						}

					}, this);

					mExtraHoursModel.setProperty("/items", arrExtraHoursModel);
					mExtraHoursModel.refresh(true);
					this.getView()
						.setModel(mExtraHoursModel, "mExtraHoursModel");
					this.getView()
						.setBusy(false);

				},
				this);

			var fnReasonModelError = jQuery.proxy(function(oData, response) {

				this.getView()
					.setBusy(false);

			}, this);

			this.getView()
				.setBusy(true);

			this.oDataModel.callFunction('/valuehelp_getlist', {
				urlParameters: {
					DAY_0047: sAwart47,
					FREEDAY: sFreeDay,
					WORKDAY: sDate

				},

				method: "GET",
				success: fnReasonModelSuccess,
				error: fnReasonModelError
			});

			// this.oDataModel.read("/ValueHelpList", {
			// 	urlParameters: {},
			// 	filters: aFilters,
			// 	success: fnReasonModelSuccess,
			// 	error: fnReasonModelError
			// });
		},

		onTsExtraTime: function(oEvent) {
			// var sEvtName = oEvent.sId;
			var sEvtName = oEvent.getSource().getId();
			this.displayMessages();

			switch (sEvtName) {
				case 'ExtraTimeJustificationLoaded':

					var arrRowTable = this.oTimeSheetModel.weeklyTable.workingDays;
					var sTargetHours;

					var arrExtraHours = oEvent.getParameter("ExtraHours");
					var arrExtraHoursFinal = [];
					var mExtraHours;
					var isExists = false;
					var sFreeTxtVis = false;

					var sReasonTxt;

					var arrMsgModel = this.oIssues.extraHours;

					for (var i = 0; i < arrRowTable.length; i++) {
						mExtraHours = undefined;
						sTargetHours = parseFloat(arrRowTable[i].targetHours);

						arrExtraHours.forEach(function(arrExtraHour, index) {
							if (arrExtraHour.WORKDATE === arrRowTable[i].date) {

								if (arrExtraHour.FREITEXT_REAS1 === "X") {
									sFreeTxtVis = true;
									sReasonTxt = "- Free text field -";
								} else {
									sFreeTxtVis = false;
									sReasonTxt = arrExtraHour.REASON;
								}

								var arrReasons = this.getView()
									.getModel("mExtraReason")
									.getData()
									.items;

								var ExtraHoursEdit = false;
								for (var x = 0; x < arrReasons.length; x++) {
									if (sReasonTxt && arrReasons[x].FieldId == sReasonTxt) {
										if (arrReasons[x].FieldRelated.split("|")[0] === 'X') {
											ExtraHoursEdit = true;
											break;
										}
									}
								}

								mExtraHours = {
									Day: arrRowTable[i].dayName,
									Date: arrRowTable[i].date,
									Holidays: "NA",
									Hours: arrRowTable[i].Total,
									Reason: sReasonTxt,
									ReasonEdit: false,
									ReasonHours: arrExtraHour.ZPASS_HOURS,
									FreeTxtVis: sFreeTxtVis,
									FreeTxtReason: arrExtraHour.REASON,
									ExtraHoursEdit: ExtraHoursEdit,
									ExtraHoursReasonEdit: false,
									ExtraHoursReason: arrExtraHour.REASON2,
									mReasons: []

								};
								arrExtraHoursFinal.push(mExtraHours);

							}
						}, this);
						if (!mExtraHours) {
							arrMsgModel.forEach(function(oMessage, ind) {
								if (arrRowTable[i].date === oMessage.propertyRef) {
									mExtraHours = {
										Day: arrRowTable[i].dayName,
										Date: arrRowTable[i].date,
										Holidays: "NA",
										Hours: arrRowTable[i].Total,
										Reason: "",
										ReasonEdit: true,
										ReasonHours: "",
										FreeTxtVis: false,
										FreeTxtReason: "",
										ExtraHoursEdit: false,
										ExtraHoursReasonEdit: false,
										ExtraHoursReason: "",
										mReasons: []
									};
									arrExtraHoursFinal.push(mExtraHours);
								}

							}, this);
						}

					}

					var mExtraHoursModel = this.getView()
						.getModel("mExtraHoursModel");

					mExtraHoursModel.setProperty("/items", arrExtraHoursFinal);

					var sAwart = "",
						sWorkDate = "",
						sFreeDay = "";

					arrExtraHoursFinal.forEach(function(mExtraHour, index) {

						var arrRows = this.oTimeSheetModel.tsJSONModel.oData.timeEntries.rowTable;

						var ifAwart0047 = "N";

						for (var idx = 0; idx < arrRows.length; idx++) {

							var arrWorkDays = arrRows[idx].workDays;

							for (var indx = 0; indx < arrWorkDays.length; indx++) {

								if (arrWorkDays[indx].Date === mExtraHour.Date && !arrWorkDays[indx].timeEntry.isEmpty &&
									arrWorkDays[indx].timeEntry.AWART === "0047") {

									ifAwart0047 = "Y";

								}

							}

						};

						sAwart = ifAwart0047 + "|" + sAwart;
						sWorkDate = mExtraHour.Date + "|" + sWorkDate;

						var arrWrkDays = this.oTimeSheetModel.tsJSONModel.oData.timeEntries.workDays;

						var ifFreeDay = "N";

						for (var x = 0; x < arrWrkDays.length; x++) {
							if (mExtraHour.Date === arrWrkDays[x].date && arrWrkDays[x].workingDay !== "TRUE") {
								ifFreeDay = "Y";
							}
						}

						sFreeDay = ifFreeDay + "|" + sFreeDay;

					}, this);

					this.getReasonCodeModel(sWorkDate, sFreeDay, sAwart);

					break;
				default:
			}

		},

		registerTSModelEvents: function() {
			// var aEvents = [this.oTimeSheetModel.evtExtraTimeJustification,];
			// for (var i = 0; i < aEvents.length; i++) {
			this.oTimeSheetModel.attachEvent(this.oTimeSheetModel.evtExtraTimeJustification, {}, this.onTsExtraTime, this);
			// }
			this.oTimeSheetModel.attachEvent(this.oTimeSheetModel.evtTimeLogLoaded, {}, this.onTSTimeLogLoaded, this);
		},
		onTSTimeLogLoaded: function(oEvent) {
			this.displayMessages();
			var arrOldModel = this.getView()
				.getModel("TimeSheetGrid")
				.getProperty("/timeEntries/timeLog");
			var arrNewModel = oEvent.getParameter("timeLog");

			if (arrOldModel && arrOldModel.length > 0 && arrNewModel && arrNewModel.length > 0) {
				for (var i = 0; i < arrOldModel.length; i++) {

					if (arrOldModel[i].Pernr === arrNewModel[i].Pernr && arrOldModel[i].workdate === arrNewModel[i].workdate) {

						if (arrOldModel[i].inTime) {
							arrNewModel[i].inTime = arrOldModel[i].inTime;
						}

						if (arrOldModel[i].outTime) {
							arrNewModel[i].outTime = arrOldModel[i].outTime;
						}

					}

				}
			}
			this.oTimeSheetModel.tsJSONModel.setProperty("/timeEntries/timeLog", arrNewModel);
		},

		onSaveSuccess: function(d, r) {

		},

		onSaveExtraTimeSuccess: function(d, r) {

			if (!this.extraTimeSuccess) {
				var eventBus = sap.ui.getCore()
					.getEventBus();
				eventBus.publish("CanExtHours", "CanExtraHours");
				this.extraTimeSuccess = true;
				// Save Time Entries from the main screen

			}

		},

		onSaveError: function(r) {

		},
		saveExtraTimeJustifications: function() {
			var arrExtraTimeJustification = this.getView()
				.getModel("mExtraHoursModel")
				.getProperty("/items");
			this.oDataModel.setDeferredGroups(["createTime"]);
			var mExtraTimeJustifications;
			var oExtraTimeJustifications = [];

			var sMeinh, sPernr, sCatsHr, sReason, sPassHours, sDeltaHours, sFreeTxtFlag;

			for (var i = 0; i < arrExtraTimeJustification.length; i++) {

				var sHoursReq = "";
				sMeinh = 'H';
				sPernr = this.oTimeSheetModel.pernr;
				sCatsHr = arrExtraTimeJustification[i].Hours;
				if (arrExtraTimeJustification[i].FreeTxtVis) {
					sReason = arrExtraTimeJustification[i].FreeTxtReason;
					sFreeTxtFlag = "X";
				} else {
					sReason = arrExtraTimeJustification[i].Reason;
					sFreeTxtFlag = "";
				}

				if (!arrExtraTimeJustification[i].ReasonHours) {
					arrExtraTimeJustification[i].ReasonHours = "0";
				}
				sPassHours = parseFloat(arrExtraTimeJustification[i].ReasonHours)
					.toFixed(2);
				if (parseFloat(arrExtraTimeJustification[i].ReasonHours) < parseFloat(sCatsHr)) {
					sDeltaHours = parseFloat(sCatsHr) - parseFloat(arrExtraTimeJustification[i].ReasonHours);
					sDeltaHours = parseFloat(sDeltaHours)
						.toFixed(2);

					if (arrExtraTimeJustification[i].ExtraHoursEdit) {
						sHoursReq = "X";
					} else {

						var arrReasons = this.getView()
							.getModel("mExtraReason")
							.getData()
							.items;

						for (var x = 0; x < arrReasons.length; x++) {
							if (sReason && arrReasons[x].FieldId == sReason) {
								if (arrReasons[x].FieldRelated.split("|")[0] === 'X') {
									sHoursReq = "X";
									break;
								}
							}
						}

					}
				}

				if (sHoursReq && parseFloat(sDeltaHours) > 10 && !arrExtraTimeJustification[i].ExtraHoursReason) {
					var sMsg;

					var sWDate = arrExtraTimeJustification[i].Date.substr(6, 2) + "/" +
						arrExtraTimeJustification[i].Date.substr(4, 2) + "/" +
						arrExtraTimeJustification[i].Date.substr(0, 4);

					sMsg = "Passive hours reason is mandatory for date " + sWDate + ".";

					sap.m.MessageBox.error(sMsg, {
						title: "Error", // default
						onClose: null, // default
						initialFocus: null, // default
						textDirection: sap.ui.core.TextDirection.Inherit // default
					});

					this.extraHoursErr = true;
					return;

				}

			}

			if (!this.extraHoursErr) {
				for (var i = 0; i < arrExtraTimeJustification.length; i++) {

					var sHoursReq = "";

					// arrTimeSheetData.forEach(function(arrTimeData, index) {
					// 	if (arrTimeData.WORKDATE === arrExtraTimeJustification[i].Date) {
					// 		sMeinh = arrTimeData.MEINH;
					// 		sPernr = arrTimeData.Pernr;

					// 	}
					// }, this);
					sMeinh = 'H';
					sPernr = this.oTimeSheetModel.pernr;
					sCatsHr = arrExtraTimeJustification[i].Hours;
					if (arrExtraTimeJustification[i].FreeTxtVis) {
						sReason = arrExtraTimeJustification[i].FreeTxtReason;
						sFreeTxtFlag = "X";
					} else {
						sReason = arrExtraTimeJustification[i].Reason;
						sFreeTxtFlag = "";
					}

					// if (arrExtraTimeJustification[i].ExtraHoursEdit) {

					// P_HOURS_REQUIRED
					if (!arrExtraTimeJustification[i].ReasonHours) {
						arrExtraTimeJustification[i].ReasonHours = "0";
					}
					sPassHours = parseFloat(arrExtraTimeJustification[i].ReasonHours)
						.toFixed(2);
					if (parseFloat(arrExtraTimeJustification[i].ReasonHours) < parseFloat(sCatsHr)) {
						sDeltaHours = parseFloat(sCatsHr) - parseFloat(arrExtraTimeJustification[i].ReasonHours);
						sDeltaHours = parseFloat(sDeltaHours)
							.toFixed(2);

						if (arrExtraTimeJustification[i].ExtraHoursEdit) {
							sHoursReq = "X";
						} else {

							var arrReasons = this.getView()
								.getModel("mExtraReason")
								.getData()
								.items;

							for (var x = 0; x < arrReasons.length; x++) {
								if (sReason && arrReasons[x].FieldId == sReason) {
									if (arrReasons[x].FieldRelated.split("|")[0] === 'X') {
										sHoursReq = "X";
										break;
									}
								}
							}

						}
					}

					// var arrRows = this.oTimeSheetModel.tsJSONModel.oData.timeEntries.rowTable;

					// arrRows.forEach(function(oRow, index) {

					// 	if (arrRows.assignment.AWART === "0047" ) {

					// 	}

					// }, this);

					mExtraTimeJustifications = {
						Pernr: sPernr,
						StartDate: arrExtraTimeJustification[i].Date,
						EndDate: arrExtraTimeJustification[i].Date,
						WORKDATE: arrExtraTimeJustification[i].Date,
						CATSHOURS: parseFloat(sCatsHr)
							.toFixed(2),
						MEINH: sMeinh,
						REASON: sReason,
						FREITEXT_REAS1: sFreeTxtFlag,
						ZPASS_HOURS: sPassHours,
						ZDELTA_HOURS: sDeltaHours,
						P_HOURS_REQUIRED: sHoursReq,
						REASON2: arrExtraTimeJustification[i].ExtraHoursReason

					};

					this.oDataModel.create("/ExtraTimeJustifications", mExtraTimeJustifications, {
						"success": jQuery.proxy(this.onSaveExtraTimeSuccess, this),
						"error": jQuery.proxy(this.onSaveError, this),
						changeSetId: 'changeSet',
						groupId: 'createTime' //+ Math.random()	
					});

					// oExtraTimeJustifications.push(mExtraTimeJustifications);
				}
			}
		},
		saveTimeLogEntries: function() {
			var arrTimeLogEntries = this.oTimeSheetModel.tsJSONModel.getProperty("/timeEntries/timeLog");

			if (arrTimeLogEntries && arrTimeLogEntries.length > 0) {

				for (var i = 0; i < arrTimeLogEntries.length; i++) {

					arrTimeLogEntries[i].inTime = this.oTimeSheetModel.formatTimeString(arrTimeLogEntries[i].inTime);
					arrTimeLogEntries[i].outTime = this.oTimeSheetModel.formatTimeString(arrTimeLogEntries[i].outTime);

					this.oDataModel.create("/InOutLogEntries", arrTimeLogEntries[i], {
						success: jQuery.proxy(this.onSaveSuccess, this),
						error: jQuery.proxy(this.onSaveError, this),
						changeSetId: 'changeSet'

					});
				}
			}

		},
		onSaveTimeEntry: function() {

			//Save all tabs

			var arrExtraTimeJustification = this.getView()
				.getModel("mExtraHoursModel")
				.getProperty("/items");

			for (var j = 0; j < arrExtraTimeJustification.length; j++) {

				if ((!arrExtraTimeJustification[j].Reason && arrExtraTimeJustification[j].ReasonEdit) ||
					(arrExtraTimeJustification[j].FreeTxtVis && !arrExtraTimeJustification[j].FreeTxtReason)) {
					sap.m.MessageBox.error("Please provide justification for additional hours.", {
						title: "Error", // default
						textDirection: sap.ui.core.TextDirection.Inherit // default
					});
					return;
				}
				// check for passive hour > booked hours
				if (arrExtraTimeJustification[j].Hours < arrExtraTimeJustification[j].ReasonHours) {
					sap.m.MessageBox.error("Passive hours can not be greater than CATS hours", {
						title: "Error", // default
						textDirection: sap.ui.core.TextDirection.Inherit // default
					});
					return;
				}
			}

			for (var i = 0; i < arrExtraTimeJustification.length; i++) {

				if (arrExtraTimeJustification[i].FreeTxtReason && arrExtraTimeJustification[i].ReasonEdit) {

					sap.m.MessageBox.show(
						this.getOwnerComponent()
						.getModel("i18n")
						.getResourceBundle()
						.getText("freeTxtMsg"), {
							icon: sap.m.MessageBox.Icon.INFORMATION,
							title: "Warning",
							actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL],
							onClose: jQuery.proxy(function(oAction) {

								if (oAction === sap.m.MessageBox.Action.OK) {
									this.onContinueSave();
								}

								if (oAction === sap.m.MessageBox.Action.CANCEL) {

								}

							}, this)
						}
					);
					return;

				}

			};

			this.onContinueSave();

		},

		onContinueSave: function() {
			this.extraTimeSuccess = false;
			this.extraHoursErr = false;
			this.saveExtraTimeJustifications();
			if (!this.extraHoursErr) {
				this.saveTimeLogEntries();
				// var arrTimeSheetData = this.oTimeSheetModel.weeklyTable.timesheetData;
				var timeEntries = this.oTimeSheetModel.prepareTimeEntriesforSave();
				// this.oTimeSheetModel.checkAndSave(timeEntries);
				//CR : App synchronization after lock released - Start
				//Added true parameter so that the request will remain in 1 batch.
				this.oTimeSheetModel.checkAndSave(timeEntries, true);
				//CR : App synchronization after lock released - End
			}
		}

	});
});