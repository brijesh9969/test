sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"kgo/ARRecharge/util/ConstantARrecharge"
], function (JSONModel, ConstantARrecharge) {
	"use strict";

	var _modelBase = null;
	var createOppRef;
	var aUpdRef = [];
	return {

		init: function (oObject) {

			// Getting model instance
			_modelBase = oObject.OData;

		},

		_getODataARRecharge: function (sPath, filter, oUrlParams, successCallback, errorCallback) {

			_modelBase.read(sPath, {
				filters: filter,
				success: successCallback,
				error: errorCallback,
				urlParameters: oUrlParams
			});

		},
		_postODataARRecharge: function (sPath, filter, oUrlParams, successCallback, errorCallback) {

			_modelBase.create(sPath, {
				filters: filter,
				success: successCallback,
				error: errorCallback,
				urlParameters: oUrlParams
			});

		},
		getcallAttDownload:function(sPath,   successCallback, errorCallback){
			_modelBase.read(sPath, {
			
				success: successCallback,
				error: errorCallback,
			
			});
			
		},
		getContrlEmailValue: function (oObject) {
			var sFilter = oObject.Filter;
			var sParam = oObject.Params;
			var fnSuccess = oObject.successCallback;
			var fnError = oObject.errorCallback;
			var sPath = oObject.sPath;
			this._getODataARRecharge(sPath, sFilter, sParam, fnSuccess, fnError);
		},
		getCompanyCodeSearchHelpValues: function (oObject) {

			var sFilter = oObject.Filter;
			var sParam = oObject.Params;
			var fnSuccess = oObject.successCallback;
			var fnError = oObject.errorCallback;
			var sPath = oObject.sPath;
			this._getODataARRecharge(sPath, sFilter, sParam, fnSuccess, fnError);
		},
		getCoupaPoSearchHelpValues: function (oObject) {
			var sFilter = oObject.Filter;
			var sParam = oObject.Params;
			var fnSuccess = oObject.successCallback;
			var fnError = oObject.errorCallback;
			var sPath = oObject.sPath;
			this._getODataARRecharge(sPath, sFilter, sParam, fnSuccess, fnError);
		},
		getCoupaReqiNumberhelpValus: function (oObject) {
			var sFilter = oObject.Filter;
			var sParam = oObject.Params;
			var fnSuccess = oObject.successCallback;
			var fnError = oObject.errorCallback;
			var sPath = oObject.sPath;
			this._getODataARRecharge(sPath, sFilter, sParam, fnSuccess, fnError);
		},
		getRRFHeaderSetvalue: function (oObject) {
			var sFilter = oObject.Filter;
			//	var sParam = oObject.Params;
			var sParam = {
				"$expand": "RRF_Line_itemSet,RRF_HEADERPOSet,RRF_LINEPOSet,RRF_AnswerSet"
			};

			var fnSuccess = oObject.successCallback;
			var fnError = oObject.errorCallback;
			var sPath = oObject.sPath;
			this._getODataARRecharge(sPath, sFilter, sParam, fnSuccess, fnError);
		},

		CreateData: function (oPayload, oObject) {
			_modelBase.create("/RRF_HeaderSet", oPayload, {
				success: oObject.successCallback,
				error: oObject.errorCallback
			});
		},
		_deleteOData: function (_oObject) {
			_modelBase.remove(_oObject.sPath, {
				success: _oObject.successCallback,
				error: _oObject.errorCallback
			});
		},
		handleDeleteRowDta: function (oObject) {
			_modelBase.remove(oObject.sPath, {
				success: oObject.successCallback,
				error: oObject.errorCallback

			});
		},
		setBatchOperationQueue: function (sPath, fnSuccess, fnError, oParams) {

			var oModel = _modelBase; //this.getOwnerComponent().getModel(); //controllerRef.getOwnerComponent().getModel();
			oModel.setUseBatch(true);
			oModel.setDeferredGroups(["editServicet"]);
			//	this.aUpdRef = [];
			var changeSet = (aUpdRef) ? "changeSet" + aUpdRef.length : "changeSet";
			var mParams = {
				"groupId": "editServicet",
				"changeSetId": changeSet,
				"success": fnSuccess,
				"error": fnError
			};
			var oUpdRef;
			oUpdRef = oModel.remove(sPath, oParams, mParams);
			aUpdRef.push(oUpdRef);

		},
		_submitBatchOperation: function (fnUpdSuccess, fnUpdError) {
			var _modelBaseObj = _modelBase;
			_modelBaseObj.submitChanges({
				groupId: "editServicet",
				success: fnUpdSuccess,
				error: fnUpdError
			});

		},
		CallFunction: function (oObject) {

			var _modelBaseObj = _modelBase;
			_modelBaseObj.callFunction(
				oObject.spath, {
					method: oObject.method,
					urlParameters: oObject.urlParameters,
					success: oObject.success,
					error: oObject.error
				});
		},
		getNonCoupaReqhelpValue: function (oObject) {
			var sFilter = oObject.Filter;
			var sParam = oObject.Params;
			var fnSuccess = oObject.successCallback;
			var fnError = oObject.errorCallback;
			var sPath = oObject.sPath;
			this._getODataARRecharge(sPath, sFilter, sParam, fnSuccess, fnError);
		},
		getGFHeaderSetvalue: function (oObject) {
			var sFilter = oObject.Filter;
			//	var sParam = oObject.Params;
			var sParam = {
				"$expand": "GF_Lineitem_Set"
			};
			var fnSuccess = oObject.successCallback;
			var fnError = oObject.errorCallback;
			var sPath = oObject.sPath;
			this._getODataARRecharge(sPath, sFilter, sParam, fnSuccess, fnError);
		},
		// Start of change by Debraj on 11/8/2019
		CreateDataNonCoupa: function (oPayload, oObject) {
			_modelBase.create("/GF_HeaderSet", oPayload, {
				success: oObject.successCallback,
				error: oObject.errorCallback
			});
		},
		// End of change by Debraj on 11/8/2019
		// Start of change by Debraj on 11/11/2019
		CreateBillSchedule: function (oPayload, oObject) {
			_modelBase.create("/GF_BillshSet", oPayload, {
				success: oObject.successCallback,
				error: oObject.errorCallback
			});
		},
		// End of change by Debraj on 11/11/2019
		// Start of change by Saptarshi on 12-Nov-2019
		CreateDataBillSH: function (oPayload, oObject) {
			_modelBase.create("/GF_BHSet", oPayload, {
				success: oObject.successCallback,
				error: oObject.errorCallback
			});
		},
		// End of change by Saptarshi on 12-Nov-2019
		/*Start of inititate COP on 12-Feb-2020*/
		CreateInitiateCOP: function (oPayload, oObject) {
			_modelBase.create("/Cop_HeaderSet", oPayload, {
				success: oObject.successCallback,
				error: oObject.errorCallback
			});
		},

		/*End of initiate COP*/

	};
});