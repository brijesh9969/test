jQuery.sap.declare("kgo.ARRecharge.util.UIGlobal");

kgo.ARRecharge.util.UIGlobal = (function () {

	var _LongTextCharLimit = 70;

	return {
		getLongTextCharLimit: function () {
			return _LongTextCharLimit;
		}
	};
}());