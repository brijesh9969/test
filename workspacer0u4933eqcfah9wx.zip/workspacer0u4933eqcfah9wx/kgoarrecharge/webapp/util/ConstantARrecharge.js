sap.ui.define([], function () {
	"use strict";
	var oConstantARrecharge = {};
	
	oConstantARrecharge.NavServices ="RRF_Line_itemSet";

});