jQuery.sap.declare("kgo.ARRecharge.formatter.formatter");
sap.ui.define([], function () {
	"use strict";
	return {
		formatFromUTC: function (dateValue) {
			// var oStateCreate = this.getView().getModel("mModelSummary").getProperty("/inputdata/CreateForm");
			if (dateValue) {
				var vUTCDate = dateValue.getUTCDate();
				var vUTCMonth = dateValue.getUTCMonth() + 1;
				var vUTCDay = dateValue.getUTCFullYear();
				var vDate = vUTCMonth + '-' + vUTCDate + '-' + vUTCDay;
				return vDate;
			} else {
				return dateValue;

			}
		},

		formateFrromSelectionDate: function (dateValue) {
			var oDate = dateValue;
			var oMonth, oDay;
			if (oDate) {

				if (oDate.getMonth() < 9) {
					oMonth = "0" + (oDate.getMonth() + 1);
				} else {
					oMonth = oDate.getMonth() + 1;
				}
				if (oDate.getDate() && oDate.getDate() <= 9) {
					oDay = "0" + oDate.getDate();
				} else {
					oDay = oDate.getDate();
				}
				return oDate.getFullYear().toString() + oMonth.toString() + oDay.toString();
			} else {
				return dateValue;
			}
		},
		formateFromCreateNewCoupaDate: function (dateValue) {
			if (dateValue) {

				var vUTCDate = dateValue.split("-")[0];
				var vUTCMonth = dateValue.split("-")[1];
				var vUTCDay = dateValue.split("-")[2];
				var vDate = vUTCDay + "," + vUTCMonth + "," + vUTCDate;
				var CoupaRequisitionDate = new Date(vDate);
				return CoupaRequisitionDate;
			} else {
				return dateValue;
			}
		},
		formatFromUTCforCoupaDate: function (arr) {

			for (var i = 0; i < arr.results.length; i++) {
				if (arr.results[i].CoupaRequisitionDate) {

					var vUTCyear = arr.results[i].CoupaRequisitionDate.slice(0, 4);
					var vUTCMonth = arr.results[i].CoupaRequisitionDate.slice(4, 6);
					var vUTCDay = arr.results[i].CoupaRequisitionDate.slice(6, 8);
					var vDate = vUTCDay + '-' + vUTCMonth + '-' + vUTCyear;
					arr.results[i].CoupaRequisitionDate = vDate;
				}
			}
			return arr;
		},
		formatFromUTCforTableRowNew: function (arr) {
			for (var i = 0; i < arr.results.length; i++) {
				if (arr.results[i].LastDateSrv) {
					var vUTCDate = arr.results[i].LastDateSrv.getUTCDate();
					var vUTCMonth = arr.results[i].LastDateSrv.getUTCMonth() + 1;
					var vUTCDay = arr.results[i].LastDateSrv.getUTCFullYear();
					var vDate = vUTCDate + '-' + vUTCMonth + '-' + vUTCDay;
					arr.results[i].LastDateSrv = vDate;
				}
			}
			return arr;
		},
		formatFromRRFfrgToTable: function (coupaDate) {
			if (coupaDate) {
				var vUTCyear = coupaDate.slice(0, 4);
				var vUTCMonth = coupaDate.slice(4, 6);
				var vUTCDay = coupaDate.slice(6, 8);
				var vDate = vUTCDay + '-' + vUTCMonth + '-' + vUTCyear;

			}
			return vDate;
		},

		formatFromCoupaDateToYYYYMMDD: function (arrPoLineItem) {
			for (var i = 0; i < arrPoLineItem.length; i++) {
				if (arrPoLineItem[i].PoStartDate) {
					var v = arrPoLineItem[i].PoStartDate;
					var vUTCDate = v.split("-")[0];
					var vUTCMonth = v.split("-")[1];
					var vUTCDay = v.split("-")[2];
					var sDate = String(vUTCDay) + String(vUTCMonth) + String(vUTCDate);

					arrPoLineItem[i].PoStartDate = sDate;
				}
				if (arrPoLineItem[i].PoEndDate) {
					var v1 = arrPoLineItem[i].PoEndDate;
					var vUTCDate1 = v1.split("-")[0];
					var vUTCMonth1 = v1.split("-")[1];
					var vUTCDay1 = v1.split("-")[2];
					var sDate1 = String(vUTCDay1) + String(vUTCMonth1) + String(vUTCDate1);
					arrPoLineItem[i].PoEndDate = sDate1;
				}
			}
			return arrPoLineItem;
		},
		getAttachmentDetail: function (date, time, name) {
			if (date) {
				var dateString = date;
				var year = dateString.substring(0, 4);
				var month = dateString.substring(4, 6);
				var day = dateString.substring(6, 8);
			}
			if (time) {
				var timeString = time;
				var hour = timeString.substring(0, 2);
				var minute = timeString.substring(2, 4);
				var second = timeString.substring(4, 6);
			}

			if (date && time) {
				var jsDate = new Date(year, month - 1, day, hour, minute, second);

				var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "MMMM d,YYYY hh:mm a"
				});
			} else if (date || time) {
				if (date) {
					var jsDate = new Date(year, month - 1, day);
					var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
						pattern: "MMMM d,YYYY"
					});
				}
			}

			if (jsDate && oDateFormat) {
				var formattedDate = oDateFormat.format(jsDate);
			}
			if (name && formattedDate) {
				var attachmentDetail = name + " - " + formattedDate;
				return attachmentDetail;
			} else if (name || formattedDate) {
				if (name) {
					var value = name;
				} else if (formattedDate) {
					value = formattedDate;
				}
			}
			return value;

		},
		checkStatus: function (currentStatus) {
			//Check Pricing Tabs display status
			if (currentStatus === 'PricingEditable') {
				return true; //Pricing Editable
			} else {
				return false; //Pricing Display only
			}
		},

		CoupaDateToYYYYMMDDfor: function (datevalue) {

			var v = datevalue;
			var vUTCDate = v.split("-")[0];
			var vUTCMonth = v.split("-")[1];
			var vUTCDay = v.split("-")[2];
			datevalue = String(vUTCDay) + String(vUTCMonth) + String(vUTCDate);

			return datevalue;
		},
		/*Start of change on 02-Jan-2020*/
		formatRrfCreationDate: function (dateValue) {
			if (dateValue) {
				for (var i = 0; i < dateValue.length; i++) {
					var vUTCyear = dateValue.slice(0, 4);
					var vUTCMonth = dateValue.slice(4, 6);
					var vUTCDay = dateValue.slice(6, 8);
					var vDate = vUTCMonth + '-' + vUTCDay + '-' + vUTCyear; /*Changed on 03-Jan-2020*/
				}
				return vDate;
			} else {
				return dateValue;
			}

		},
		/*End of change on 02-Jan-2020*/

		/*Start of change by developer Satabdi Das on 25-May-2021 for string converison  of the filter value*/
		formatValueToString: function (value) {
			if (value) {
				value = value.toString();
				return value;
			} else {
				return value;
			}
		},
		/*End of change by developer Satabdi Das on 25-May-2021 for string converison  of the filter value*/
		getRemainingChar: function (value, maxLength) {
			var remainingLength = maxLength;
			if (value && value !== "") {
				var charLength = value.length;
				remainingLength = maxLength - charLength;
			}
			return remainingLength + " characters remaining";
		}
	};
});