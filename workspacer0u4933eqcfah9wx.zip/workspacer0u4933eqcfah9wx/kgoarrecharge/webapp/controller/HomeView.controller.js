sap.ui.define([
	"kgo/ARRecharge/controller/BaseController",
	'sap/ui/model/json/JSONModel',
	'sap/ui/core/routing/History',
	'sap/ui/core/UIComponent',
	'sap/ui/core/Fragment',
	"kgo/ARRecharge/formatter/formatter",
	"kgo/ARRecharge/util/DataManagerARrecharge",
	'sap/m/MessageBox',
	"sap/ui/model/FilterOperator",
	"sap/ui/model/Filter",
	"sap/m/MessageToast",
	"sap/ui/model/resource/ResourceModel",
	"kgo/ARRecharge/util/UIGlobal",

], function (BaseController, JSONModel, History, UIComponent, Fragment, formatter, DataManagerARrecharge, MessageBox, FilterOperator,
	Filter, MessageToast, ResourceModel, UIGlobal) {
	"use strict";

	return BaseController.extend("kgo.ARRecharge.controller.HomeView", {

		formatter: formatter,
		onInit: function () {

			var oModel1 = new JSONModel();
			this.getView().setModel(oModel1, "mModel");
			oModel1.setProperty("/inputdata", {});
			oModel1.setProperty("/inputdatadtatable", []);
			this.oRouter = UIComponent.getRouterFor(this);
			this.oRouter.attachRouteMatched(this.onRouteMatched, this);
			// set i18n model on view
			var i18nModel = new ResourceModel({
				bundleName: "kgo.ARRecharge.i18n.i18n"
			});
			this.getView().setModel(i18nModel, "i18n");

		},
		onRouteMatched: function (oEvent) {

			if (oEvent.getParameter("name") === "RouteHomeView") {
				//only invoke if a pernr has been selected
				this.firstInitialData();
				this.contractDateDisable();
				//only invoke if a pernr has been selected

			}
		},
		firstInitialData: function () {
			var mModelSummary = this.getModel("mModelSummary");
			var oSupplierFlag;
			var grandtotalAmt = 0;
			var tbl = this.getView().byId('tableid');
			var HeaderData = this.getModel("mModelSummary").getData().HeaderData;
			var displayMode = mModelSummary.getProperty("/displayMode");
			if (HeaderData.ToDisplay === "X" && displayMode != true) {
				this.getView().byId("trfownerID").setProperty("enabled", true);
			} else {
				this.getView().byId("trfownerID").setProperty("enabled", false);
			}

			for (var i = 0; i < tbl.getItems().length; i++) {
				var copInitiate = tbl.getBindingInfo("items").binding.oList[i].CopInitiate;
				var TotalCommAmount = tbl.getBindingInfo("items").binding.oList[i].TotalCommAmount;

				if (copInitiate === "X") {
					oSupplierFlag = true;
					var x = tbl.getAggregation("items")[i];
					x.getMultiSelectControl().setEnabled(false);

				}

				if (TotalCommAmount) {
					grandtotalAmt = grandtotalAmt + Number(TotalCommAmount);
				} else {
					grandtotalAmt = grandtotalAmt.toString();

				}

			}
			//SCTASK1886857 changes by Prashant kumar
			grandtotalAmt = grandtotalAmt.toString();
			mModelSummary.setProperty("/totalLineItemAmt", grandtotalAmt);
			if (oSupplierFlag === true) {
				this.getModel("mModelSummary").setProperty("/oEditable/suppEdit", false);
			}

			/*Start of change for developer Satabdi Das on 26-Nov-2020*/
			var sCompCode = this.getView().getModel("mModelSummary").getProperty("/HeaderData/CompanyCode");
			if (sCompCode === "9921") {
				this.getView().getModel("mModelSummary").setProperty("/Bukrs9921", true);
				this.getView().getModel("mModelSummary").setProperty("/Bukrs9901", false);
				jQuery.sap.delayedCall(1000, this, function () {
					var oRrfType = this.getView().byId("PORrfType");
					if (oRrfType) {
						var obj = oRrfType.getDomRef();
						if (obj) {
							obj.firstElementChild.firstChild.setAttribute("readonly", true);
							//obj.children[1].setAttribute("readonly", true);
							//	obj.children[2].setAttribute("readonly", true);
						}
					}
				});
			} else if (sCompCode !== "9921") {
				this.getView().getModel("mModelSummary").setProperty("/Bukrs9921", false);
				this.getView().getModel("mModelSummary").setProperty("/Bukrs9901", true);
			}
			/*End of change for developer Satabdi Das on 26-Nov-2020*/
		},

		contractDateDisable: function () {
			jQuery.sap.delayedCall(1000, this, function () {
				var oDatePicker1 = this.getView().byId("contractStdate");
				if (oDatePicker1) {
					var objDate1 = oDatePicker1.getDomRef();
					if (objDate1) {
						objDate1.firstElementChild.firstChild.setAttribute("readonly", true);
					}
				}
				var oDatePicker2 = this.getView().byId("contractEndDate");
				if (oDatePicker2) {
					var objDate2 = oDatePicker2.getDomRef();
					if (objDate2) {
						objDate2.firstElementChild.firstChild.setAttribute("readonly", true);
					}
				}

				var oDatePicker3 = this.getView().byId("supplierdDate");
				if (oDatePicker3) {
					var objDate3 = oDatePicker3.getDomRef();
					if (objDate3) {
						objDate3.firstElementChild.firstChild.setAttribute("readonly", true);
					}
				}

				//companyCode drowpdown changes by prashant 14.08.2020
				var companyCode = this.getView().byId("CompCoodeDropdown");
				if (companyCode) {
					var objNature = companyCode.getDomRef();
					if (objNature) {
						objNature.firstElementChild.firstChild.setAttribute("readonly", true);
					}
				}

			});
		},
		onChangeSupplierdDate: function (oEvent) {
			jQuery.sap.delayedCall(500, this, function () {
				var oDatePicker3 = this.getView().byId("supplierdDate");
				if (oDatePicker3) {
					var objDate3 = oDatePicker3.getDomRef();
					if (objDate3) {
						objDate3.firstElementChild.firstChild.setAttribute("readonly", true);
					}
				}
			});
		},

		onSlcHeaderStatus: function (oEvent) {
			var comboxKey = oEvent.getParameters().selectedItem.getKey();
			this.getView().getModel("mModelSummary").setProperty("/RRFHeaderStatus", comboxKey);
			this.getView().getModel("mModelSummary").refresh();
		},
		onSlcLineItemStatus: function (oEvent) {
			var comboxLineItemKey = oEvent.getParameters().selectedItem.getKey();
			this.getView().getModel("mModelSummary").setProperty("/lineItemStatus", comboxLineItemKey);
			this.getView().getModel("mModelSummary").refresh();
		},
		//Company code change added by prashant 14.10.2020
		onChangeCompanyCode: function (oEvent) {
			var that = this;
			var event = oEvent.getSource();
			var mModelSummary = this.getView().getModel("mModelSummary");
			var oHeaderData = mModelSummary.getProperty("/HeaderData");
			var oSelectedCompanyCode = mModelSummary.getProperty("/HeaderData").CompanyCode;
			this.oDfaultCompanyCode = mModelSummary.getProperty("/HeaderData").oDfaultCompanyCode;

			if (oSelectedCompanyCode !== this.oDfaultCompanyCode) {
				if (oHeaderData.VendorName || oHeaderData.Vendor || oHeaderData.Kostl || mModelSummary.getProperty("/PoTableSet").length > 0) {
					var messageText = this.getModel("i18n").getProperty("companycodechangeMessage");
					MessageBox.information(messageText, {
						actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
						emphasizedAction: MessageBox.Action.OK,
						onClose: function (sAction) {
							if (sAction === "CANCEL") {
								mModelSummary.setProperty("/HeaderData/CompanyCode", that.oDfaultCompanyCode);

							} else {
								that.oDfaultCompanyCode = oSelectedCompanyCode;
								mModelSummary.setProperty("/HeaderData/oDfaultCompanyCode", oSelectedCompanyCode);

								if (oHeaderData.VendorName) {
									mModelSummary.setProperty("/HeaderData/VendorName");
									mModelSummary.setProperty("/HeaderData/Vendor");

								}
								if (oHeaderData.Kostl) {
									mModelSummary.setProperty("/HeaderData/Kostl");
									mModelSummary.setProperty("/HeaderData/Ltext");
								}
								if (mModelSummary.getProperty("/PoTableSet").length > 0) {
									mModelSummary.setProperty("/PoTableSet", []);
								}

							}
						}
					});
				} else {
					this.oDfaultCompanyCode = oSelectedCompanyCode;
					mModelSummary.setProperty("/HeaderData/oDfaultCompanyCode", oSelectedCompanyCode);
				}
			}
			/*Start of change for developer Satabdi Das on 26-Nov-2020*/
			if (oSelectedCompanyCode === "9921") {
				mModelSummary.setProperty("/Bukrs9921", true);
				mModelSummary.setProperty("/Bukrs9901", false);
				jQuery.sap.delayedCall(1000, this, function () {
					var oRrfType = this.getView().byId("PORrfType");
					if (oRrfType) {
						var obj = oRrfType.getDomRef();
						if (obj) {
							obj.firstElementChild.firstChild.setAttribute("readonly", true);
							// obj.children[1].setAttribute("readonly", true);
							// obj.children[2].setAttribute("readonly", true);
						}
					}
				});
			} else if (oSelectedCompanyCode !== "9921") {
				mModelSummary.setProperty("/Bukrs9921", false);
				mModelSummary.setProperty("/Bukrs9901", true);
			}
			/*End of change for developer Satabdi Das on 26-Nov-2020*/

		},

		/*Start of chnage by developer Satabdi Das on 26-Nov-2020 for RrfType*/
		onSlcTypeOfRRF: function (oEvent) {
			var sComboBoxItemText = oEvent.getParameter("value");
			this.getView().getModel("mModelSummary").setProperty("/HeaderData/RrfType", sComboBoxItemText);
		},
		/*End of chnage by developer Satabdi Das on 26-Nov-2020 for RrfType*/
		saveRRFPO: function () {
			this.getModel("mModelSummary").setProperty("/oDislayRRFNo");
			var displayMode = this.getModel("mModelSummary").getProperty("/displayMode"); /*Added by Saptarshi on 22-Nov-2019*/
			if (displayMode === false) { /*Added by Saptarshi on 22-Nov-2019*/
				var mModelSummary = this.getView().getModel("mModelSummary");
				var hederData = mModelSummary.getProperty("/HeaderData");
				hederData.Currency = mModelSummary.getProperty("/CurrKeySet");
				if (hederData.ContrlName && hederData.ContrlEmail && hederData.RrfDesc) {
					//hederData.RrfStatus = this.getView().getModel("mModelSummary").getProperty("/RRFHeaderStatus");

					sap.ui.core.BusyIndicator.show(0);
					var TableData = [];
					var PoHeaderData = [];
					var PoLineItemData = [];

					var oPayLoad = {
						CompanyCode: hederData.CompanyCode,
						ContractTerm: hederData.ContractTerm,
						ContarctStartDate: hederData.ContarctStartDate,
						ContarctEndDate: hederData.ContarctEndDate,
						SupplierAgreementDate: hederData.SupplierAgreementDate,
						AddlInfo: hederData.AddlInfo,
						CoupaRequisitionNumber: hederData.CoupaRequisitionNumber,
						CoupaRequisitionDate: hederData.CoupaRequisitionDate,
						CoupaReqCreatedBy: hederData.CoupaReqCreatedBy,
						RrfCreatorName: hederData.RrfCreatorName,
						TotalPoAmount: hederData.TotalPoAmount,
						Currency: hederData.Currency,
						VendorName: hederData.VendorName,
						Vendor: hederData.Vendor,
						RrfNo: hederData.RrfNo,
						RrfDesc: hederData.RrfDesc,
						ContrlName: hederData.ContrlName,
						ContrlEmail: hederData.ContrlEmail,
						PoNumber: hederData.PoNumber,
						PoDescription: hederData.PoDescription,
						GlobalCostCentre: hederData.GlobalCostCentre,
						Kostl: hederData.Kostl,
						Ltext: hederData.Ltext,
						RrfType: hederData.RrfType,
						ToDisplay: hederData.ToDisplay,
						/*Added by Satabdi Das on 26-Nov-2020*/
						PoDashboard: hederData.PoDashboard,

						RrfStatus: hederData.RrfStatus,
						GlobalCc: hederData.GlobalCc,

						GlAccount: hederData.GlAccount,
						RRF_Line_itemSet: [],
						RRF_HEADERPOSet: [],
						RRF_LINEPOSet: [],
						RRF_AnswerSet: []

					};
					var that = this;
					var fnSuccess = jQuery.proxy(function (d) {
						sap.ui.core.BusyIndicator.hide(0);
						mModelSummary.setProperty("/HeaderData/RrfNo", d.RrfNo);
						var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
						if (d.Flag) {
							var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
							MessageBox.error(
								d.Message, {
									styleClass: bCompact ? "sapUiSizeCompact" : ""
								}
							);
						} else {
							MessageBox.show(
								d.Message, {
									icon: MessageBox.Icon.SUCCESS,
									title: "Success",
									actions: [MessageBox.Action.OK],
									onClose: function (oAction) {

										that.handlePreBtnEdit();

										// var oRouter = UIComponent.getRouterFor(that);
										// oRouter.navTo("TargetSelectionView");

									}
								}
							);
							this.getModel("mModelSummary").setProperty("/updateRowData/RequestingMf", ""); /*Chnage added on 09-Jan-2020*/
							/*Start of chnage for defect 63096 on 31-Jan-2020*/
							var oTable = that.getView().byId("tableid");
							oTable.removeSelections(true);
							/*End of chnage for defect 63096 on 31-Jan-2020*/
						}

					}, this);
					var fnError = jQuery.proxy(function (d) {
						sap.ui.core.BusyIndicator.hide(0);
						var r = JSON.parse(JSON.stringify(d));
						sap.ui.core.BusyIndicator.hide();
						MessageToast.show(r.message, {
							autoClose: true,
							width: "20rem"

						});
					}, this);

					//	var object = {};
					var objectOne = {};
					var arr = [];
					var arrPoHeader = [];
					var arrPoLineItem = [];
					var arrAnsware = [];
					var _answre = [];
					objectOne.successCallback = fnSuccess;
					objectOne.errorCallback = fnError;
					// this.getView().getModel("mModelSummary").getProperty("/TableItemSet").results[0].RrfStatus = this.getView().getModel(
					// 	"mModelSummary").getProperty("/lineItemStatus").RrfStatus;
					/*Start - CR  Changed On 26-Aug-2021 By Prashant and Chhanda*/

					arrPoHeader = this.getView().getModel("mModelSummary").getProperty("/PoTableSet");
					arr = mModelSummary.getProperty("/TableItemSet");
					// arrPoLineItem = this.getView().getModel("mModelSummary").getProperty("/copPoTableSet");
					arrPoLineItem = this.getModel("mModelSummary").getProperty("/oLinePoTableSet");
					arrAnsware = this.getModel("mModelSummary").getProperty("/questionSetSubmit");
					for (var t = 0; t < arrAnsware.length; t++) {
						var objAns = {};
						objAns.GlobalCc = hederData.GlobalCc;
						objAns.MemberFirm = arrAnsware[t].MemberFirm;
						objAns.Question = arrAnsware[t].Question;
						objAns.RequestingMf = arrAnsware[t].RequestingMf;
						objAns.Answer = arrAnsware[t].Answer;
						objAns.InternalExternal = arrAnsware[t].InternalExternal;
						objAns.AnswerDesc = arrAnsware[t].AnswerDesc;
						objAns.ProcessGrp = arrAnsware[t].ProcessGrp;
						objAns.CompanyCode = hederData.CompanyCode;
						_answre.push(objAns);

					}
					oPayLoad.RRF_AnswerSet = _answre;

					//arrPoLineItem = formatter.formatFromCoupaDateToYYYYMMDD(arrPoLineItem);
					//removing metadata for Po Header Field 
					if (arrPoHeader.length > 0) {
						for (var i in arrPoHeader) {
							var fields = Object.keys(arrPoHeader[i]);
							var obj = {};
							for (var j = 0; j < fields.length; j++) {
								if (fields[j] !== "__metadata") {
									obj[fields[j]] = arrPoHeader[i][fields[j]];
								}
							}
							PoHeaderData.push(obj);
						}
						oPayLoad.RRF_HEADERPOSet = PoHeaderData;
					}

					//removing metadata for Po Field LineItem
					if (arrPoLineItem.length > 0) {
						for (var i in arrPoLineItem) {
							fields = Object.keys(arrPoLineItem[i]);
							obj = {};
							for (var j = 0; j < fields.length; j++) {
								if (fields[j] !== "__metadata") {
									obj[fields[j]] = arrPoLineItem[i][fields[j]];
								}
							}
							PoLineItemData.push(obj);
						}
						oPayLoad.RRF_LINEPOSet = PoLineItemData;
					}

					// 	if (arrAnsware.length > 0) {
					// 	// for (var i in arrAnsware) {
					// 	// 	fields = Object.keys(arrAnsware[i]);
					// 	// 	obj = {};
					// 	// 	for (var j = 0; j < fields.length; j++) {
					// 	// 		if (fields[j] !== "__metadata") {
					// 	// 			obj[fields[j]] = arrAnsware[i][fields[j]];
					// 	// 		}
					// 	// 	}
					// 	// 	PoLineItemData.push(obj);
					// 	// }
					// 	oPayLoad.RRF_LINEPOSet = arrAnsware;
					// }

					//validation for LineItem  start

					// if (!arr.results) {
					// 	sap.ui.core.BusyIndicator.hide(0);
					// 	MessageBox.alert(

					// 		"Please Enter atleast one Line Item.", {
					// 			styleClass: bCompact ? "sapUiSizeCompact" : ""
					// 		}
					// 	);
					// } else if (arr.results.length === 0) {
					// 	sap.ui.core.BusyIndicator.hide();
					// 	var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
					// 	MessageBox.alert(
					// 		"Please Enter atleast one Line Item.", {
					// 			styleClass: bCompact ? "sapUiSizeCompact" : ""
					// 		}
					// 	);
					// } 

					//arr = formatter.formatFromCoupaDateToYYYYMMDD(arr);

					for (var i in arr.results) {
						fields = Object.keys(arr.results[i]);
						obj = {};
						// if (arr.results[i] === "ConsolidatedLoa") {
						// 	arr.splice(x, 1);
						// }
						for (var j = 0; j < fields.length; j++) {
							if (fields[j] !== "__metadata") {
								obj[fields[j]] = arr.results[i][fields[j]];
							}

						}
						TableData.push(obj);
					}
					oPayLoad.RRF_Line_itemSet = TableData;
					DataManagerARrecharge.CreateData(oPayLoad, objectOne);
				} else {
					var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
					MessageBox.alert(
						"Please enter mandatory fields.", {
							styleClass: bCompact ? "sapUiSizeCompact" : ""
						}
					);
				}
			}
			/*Added by Saptarshi on 22-Nov-2019*/
		},
		handlePressLinkSubmit: function (oEvent) {
			var arr = [];
			var displayMsg;
			var mModelSummary = this.getModel("mModelSummary");
			mModelSummary.setProperty("/oDislayRRFNo");
			var displayMode = this.getModel("mModelSummary").getProperty("/displayMode"); /*Added by Saptarshi on 22-Nov-2019*/
			if (displayMode === false) { /*Added by Saptarshi on 22-Nov-2019*/
				arr = mModelSummary.getProperty("/TableItemSet");
				var totalAmount = mModelSummary.getProperty("/totalLineItemAmt");
				var hederData = mModelSummary.getProperty("/HeaderData");
				if (hederData.ContrlName && hederData.ContrlEmail && hederData.RrfDesc) {
					if (arr.results && arr.results.length > 0) {
						//SCTASK1886857 changes by prashant 
						if (Number(totalAmount) > Number(hederData.TotalPoAmount) || (totalAmount && !hederData.TotalPoAmount)) {
							displayMsg = true;
						} else {
							displayMsg = false;
						}

						var that = this;
						//	var displayMsg = this.checkTotalMFAmountForSameMF(arr.results, "PO");
						//As per requirement 250k msg is not required now 18.11.2021
						var savecheckmessage = "";
						if (displayMsg === true) {
							// read msg from i18n model
							var oBundle = this.getView().getModel("i18n").getResourceBundle();
							// for (var i = 0; i < displayMsg.length; i++) {
							// 	savecheckmessage = savecheckmessage + oBundle.getText("savecheckmessage", [displayMsg[i]]) + "\n";
							// }
							// savecheckmessage = savecheckmessage + oBundle.getText("savecheckmessage2");

							// savecheckmessage = oBundle.getText("savecheckmessage");

							// var displayMF = "";
							// for (var i = 0; i < displayMsg.length; i++) {
							// 	displayMF = displayMF + "\n" + displayMsg[i];
							// }
							// savecheckmessage = savecheckmessage + displayMF;
							var contractAmountmsg = oBundle.getText("contractAmountmsg");
							var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
							MessageBox.alert(contractAmountmsg, {
								actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
								styleClass: bCompact ? "sapUiSizeCompact" : "",
								onClose: function (sAction) {
									if (sAction === "OK") {
										that.saveRRFPO(); // Save RRF data
									}
								}
							});
						} else {
							this.saveRRFPO();
						}
					} else {
						this.saveRRFPO();
					}
					// if (!hederData.RrfNo && arr.length === 0) {
					// 	this.saveRRFPO();
					// } else if (hederData.RrfNo && arr.results.length === 0) {
					// 	this.saveRRFPO();
					// }
				} else {
					var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
					MessageBox.alert(
						"Please enter mandatory fields.", {
							styleClass: bCompact ? "sapUiSizeCompact" : ""
						}
					);
					return;
				}

				// if (arr.results && arr.results.length > 0) {
				// 	var that = this;
				// 	var displayMsg = this.checkTotalMFAmountForSameMF(arr.results, "PO");
				// 	var savecheckmessage = "";
				// 	if (displayMsg && displayMsg.length > 0) {
				// 		// read msg from i18n model
				// 		var oBundle = this.getView().getModel("i18n").getResourceBundle();
				// 		for (var i = 0; i < displayMsg.length; i++) {
				// 			savecheckmessage = savecheckmessage + oBundle.getText("savecheckmessage", [displayMsg[i]]) + "\n";
				// 		}
				// 		savecheckmessage = savecheckmessage + oBundle.getText("savecheckmessage2");
				// 		var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				// 		MessageBox.information(savecheckmessage, {
				// 			actions: [MessageBox.Action.OK],
				// 			styleClass: bCompact ? "sapUiSizeCompact" : "",
				// 			onClose: function (sAction) {
				// 				if (sAction === "OK") {
				// 					that.saveRRFPO(); // Save RRF data
				// 				}
				// 			}
				// 		});
				// 	} else {
				// 		this.saveRRFPO();
				// 	}
				// }
			}

		},

		handlePressLinkAdd: function (oEvent) {
			var mModelSummary = this.getView().getModel("mModelSummary");
			this.getView().getModel("mModelSummary").setProperty("/copPoTableSet", []);
			var oModelAttachmentsLast = this.getView().getModel("mModelSummary").getProperty("/FileNameSet");
			if (oModelAttachmentsLast) {
				this.getView().getModel("mModelSummary").setProperty("/FileNameSet", null);
			}
			/*Start of change on 18-Feb-2020*/
			var oModelLoaAttach = this.getView().getModel("mModelSummary").getProperty("/FileNameLoaSet");
			if (oModelLoaAttach) {
				this.getView().getModel("mModelSummary").setProperty("/FileNameLoaSet", null);
			}
			/*End of change on 18-Feb-2020*/
			var displayMode = this.getModel("mModelSummary").getProperty("/displayMode"); /*Added by Saptarshi on 22-Nov-2019*/
			if (displayMode === false) { /*Added by Saptarshi on 22-Nov-2019*/
				sap.ui.core.BusyIndicator.show(0);
				this.onMfSearchHelpValue();
				this.onMfLocValue(); /*Added by Satabdi Das on 17-Feb-2021 for SCTASK1919812*/
				var avlueText = this.getModel("i18n").getProperty("addmemberfirm");
				mModelSummary.setProperty("/setLineItemText", avlueText);
				mModelSummary.setProperty("/TextForLineItemEmailSrch", avlueText);
				var sPanelName = this.getModel("i18n").getProperty("MemberfirmSec");
				this.getView().getModel("mModelSummary").setProperty("/setPanelText", sPanelName);
				mModelSummary.setProperty("/updateRowData", []);
				mModelSummary.setProperty("/oLinePoTableSetTemp", []);
				mModelSummary.setProperty("/DeleteCommercialRow", "");
				mModelSummary.setProperty("/SrNo", "");
				mModelSummary.setProperty("/oEditable/lastsrvDate", false);
				mModelSummary.setProperty("/oEditable/lastDateOfServLabel", false);
				mModelSummary.setProperty("/oEditable/checkBox", true); /*Added on 29-Jan-2020*/
				mModelSummary.setProperty("/oEditable/entityName", false); /*Added on 29-Janb-2020*/
				mModelSummary.setProperty("/oEditable/entityAddress", true); /*Added on 29-Janb-2020*/
				this.getModel("mModelSummary").setProperty("/oEditable/editMode", true); /*Chnage added by Saptarshi on 20-Nov-2019*/
				var oMadtory = mModelSummary.getProperty("/HeaderData");
				mModelSummary.setProperty("/oEditable/questionPnVisiblePO", false);
				mModelSummary.setProperty("/oEditable/gpDetailEdit", true);
				mModelSummary.setProperty("/oEditable/editLineItemCop", true);
				//Changes for NEW cR 13.08.2021
				mModelSummary.setProperty("/oEditable/reSetButtonEnable", false);
				mModelSummary.setProperty("/oEditable/serviceRenderBox", false);
				this.getView().getModel("mModelSummary").setProperty("/oEditable/attchmentExpnded", false);

				var oTooltipText = this.getModel("i18n").getProperty("supplierToolTip");
				if (oMadtory.ContrlName && oMadtory.ContrlEmail && oMadtory.RrfDesc && oMadtory.CompanyCode) {
					var rrfTablefragment = this.getView().createId("rrfTablefragment");
					if (!this.rrfTablefragment) {
						this.rrfTablefragment = sap.ui.xmlfragment(rrfTablefragment, "kgo.ARRecharge.view.createLineItem", this);
						// this.rrfTablefragment = sap.ui.xmlfragment(rrfTablefragment, "kgo.ARRecharge.view.RRFTable", this);
						this.getView().addDependent(this.rrfTablefragment);
					}
					if (this.rrfTablefragment.isOpen()) {
						this.rrfTablefragment.close();
					} else {
						sap.ui.core.BusyIndicator.hide(0);
						this.byId(sap.ui.core.Fragment.createId(rrfTablefragment, "idselectok")).setVisible(true);
						this.byId(sap.ui.core.Fragment.createId(rrfTablefragment, "idselectEdit")).setVisible(false);
						this.byId(sap.ui.core.Fragment.createId(rrfTablefragment, "contrylebelId")).setVisible(true);
						//	this.byId(sap.ui.core.Fragment.createId(rrfTablefragment, "contryDrdwId")).setVisible(true);
						mModelSummary.setProperty("/oEditable/rmdropDown", true);
						mModelSummary.setProperty("/oEditable/requMfvisible", false);
						mModelSummary.setProperty("/SelcKeySet", "");
						this.byId(sap.ui.core.Fragment.createId(rrfTablefragment, "commercialPanelId")).oIconCollapsed.setAggregation("tooltip",
							oTooltipText);
						sap.ui.core.Fragment.byId(rrfTablefragment, "descriptionForMF").setVisible(true);
						sap.ui.core.Fragment.byId(rrfTablefragment, "descriptionGF").setVisible(false);
						this.getView().getModel("mModelSummary").setProperty("/oEditable/additionalFieldBrf", true);

						this.byId(sap.ui.core.Fragment.createId(rrfTablefragment, "globalcostcenterId")).setVisible(false);
						this.byId(sap.ui.core.Fragment.createId(rrfTablefragment, "GlobalCC")).setVisible(false);
						this.getView().getModel("mModelSummary").setProperty("/oEditable/visibleforGF", false);
						this.getView().getModel("mModelSummary").setProperty("/oEditable/visibleforMF", true);
						/*Start - CR  Changed On 26-Aug-2021 By Prashant and Chhanda*/
						// sap.ui.core.Fragment.byId(rrfTablefragment, "ContactPersonLOAId").setEditable(false);
						sap.ui.core.Fragment.byId(rrfTablefragment, "ContactPersonLOAId").setEditable(true);
						this.byId(sap.ui.core.Fragment.createId(rrfTablefragment, "UpdateAuthId")).setSelected(false);
						sap.ui.core.Fragment.byId(rrfTablefragment, "updateCooID").setEnabled(false);
						/*End - CR  Changed On 26-Aug-2021 By Prashant and Chhanda*/

						var fiscalDate = this.byId(sap.ui.core.Fragment.createId(rrfTablefragment, "fiscalYear"));
						fiscalDate.addEventDelegate({
							onAfterRendering: function () {
								var oYear = this.$().find('.sapMInputBaseInner');
								var oID = oYear[0].id;
								$('#' + oID).attr("disabled", "disabled");
							}
						}, fiscalDate);

						var oDatePicker = this.byId(sap.ui.core.Fragment.createId(rrfTablefragment, "comercialDatePickerId"));
						oDatePicker.addEventDelegate({
							onAfterRendering: function () {
								var oDateInner = this.$().find('.sapMInputBaseInner');
								var oID = oDateInner[0].id;
								$('#' + oID).attr("disabled", "disabled");
							}
						}, oDatePicker);

						var oDatePicker = this.byId(sap.ui.core.Fragment.createId(rrfTablefragment, "PoendDate"));
						oDatePicker.addEventDelegate({
							onAfterRendering: function () {
								var oDateInner = this.$().find('.sapMInputBaseInner');
								var oID = oDateInner[0].id;
								$('#' + oID).attr("disabled", "disabled");
							}
						}, oDatePicker);

						var oWhTaxCombo = this.byId(sap.ui.core.Fragment.createId(rrfTablefragment, "WhTaxCombo"));
						oWhTaxCombo.addEventDelegate({
							onAfterRendering: function () {
								var oDateInner = this.$().find('.sapMInputBaseInner');
								var oID = oDateInner[0].id;
								$('#' + oID).attr("disabled", "disabled");
							}
						}, oWhTaxCombo);

						// var oDatePicker = this.byId(sap.ui.core.Fragment.createId(rrfTablefragment, "thirdPartyDateId"));
						// oDatePicker.addEventDelegate({
						// 	onAfterRendering: function () {
						// 		var oDateInner = this.$().find('.sapMInputBaseInner');
						// 		var oID = oDateInner[0].id;
						// 		$('#' + oID).attr("disabled", "disabled");
						// 	}
						// }, oDatePicker);

						//date Picker
						var oPoEndDate = this.byId(sap.ui.core.Fragment.createId(rrfTablefragment, "lastservdate"));
						oPoEndDate.addEventDelegate({
							onAfterRendering: function () {
								var oDateInner = this.$().find('.sapMInputBaseInner');
								var oID = oDateInner[0].id;
								$('#' + oID).attr("disabled", "disabled");
							}
						}, oPoEndDate);

						//End of date pickerfor last service date
						// var oQdropDown = this.byId(sap.ui.core.Fragment.createId(rrfTablefragment, "comboIdTable"));
						// if (oQdropDown) {
						// 	var oDroD = oQdropDown.getDomRef();
						// 	if (oDroD) {
						// 		oDroD.firstElementChild.setAttribute("readonly", true);
						// 	}
						// }

						var oQdropDown = this.byId(sap.ui.core.Fragment.createId(rrfTablefragment, "comboIdTable1"));
						oQdropDown.addEventDelegate({
							onAfterRendering: function () {
								var oQdropDown = this.$().find('.sapMInputBaseInner');
								var oID = oQdropDown[0].id;
								$('#' + oID).attr("disabled", "disabled");
							}
						}, oQdropDown);

						this.rrfTablefragment.open();

						var oNatureField = this.byId(sap.ui.core.Fragment.createId(rrfTablefragment, "natureField"));
						if (oNatureField) {
							var objNature = oNatureField.getDomRef();
							if (objNature) {
								//	objNature.firstElementChild.setAttribute("readonly", true);
								objNature.firstElementChild.firstChild.setAttribute("readonly", true);
							}
						}
						var oGpdetailDropDown = this.byId(sap.ui.core.Fragment.createId(rrfTablefragment, "commitmentDrp"));
						if (oGpdetailDropDown) {
							var Gpdrpdwn = oGpdetailDropDown.getDomRef();
							if (Gpdrpdwn) {
								//	Gpdrpdwn.firstElementChild.setAttribute("readonly", true);
								Gpdrpdwn.firstElementChild.firstChild.setAttribute("readonly", true);
							}
						}

						/*Start of change for defect 63871 on 19-March-2021 by developer Satabdi Das*/
						var oReqCountry = this.byId(sap.ui.core.Fragment.createId(rrfTablefragment, "contryDrdwId"));
						oReqCountry.addEventDelegate({
							onAfterRendering: function () {
								var oReqCountryInner = this.$().find('.sapMInputBaseInner');
								var oID = oReqCountryInner[0].id;
								$('#' + oID).attr("disabled", "disabled");
							}
						}, oReqCountry);
						/*End of change for defect 63871 on 19-March-2021 by developer Satabdi Das*/

						/*Start of change on 21-Feb-2020*/
						//typing disable for questionnaire dropdown
						var oQdropDown = this.byId(sap.ui.core.Fragment.createId(rrfTablefragment, "comboIdTable"));
						oQdropDown.addEventDelegate({
							onAfterRendering: function () {
								var oQdropDown = this.$().find('.sapMInputBaseInner');
								var oID = oQdropDown[0].id;
								$('#' + oID).attr("disabled", "disabled");
							}
						}, oQdropDown);

					}

				} else {
					sap.ui.core.BusyIndicator.hide(0);
					var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
					MessageBox.alert(
						"Please enter mandatory fields .", {
							styleClass: bCompact ? "sapUiSizeCompact" : ""
						}
					);
					this.getView().getModel("mModelSummary").setProperty("/TextForLineItemEmailSrch");

				}
			} /*Added by SAptarshi on 22-Nov-2019*/
		},
		handlePressLinkAddforGf: function (oEveent) {
			var mModelSummary = this.getView().getModel("mModelSummary");
			mModelSummary.setProperty("/copPoTableSet", []);
			mModelSummary.setProperty("/questionSet", []);
			mModelSummary.setProperty("/TotalCSAmt", ""); /*Added for SCTASK1855604 - budget approvers by developer Satabdi Das on 19-May-2021*/
			var oModelAttachmentsLast = this.getView().getModel("mModelSummary").getProperty("/FileNameSet");
			if (oModelAttachmentsLast) {
				this.getView().getModel("mModelSummary").setProperty("/FileNameSet", null);
			}
			/*Start of change on 18-Feb-2020*/
			var oModelLoaAttach = this.getView().getModel("mModelSummary").getProperty("/FileNameLoaSet");
			if (oModelLoaAttach) {
				this.getView().getModel("mModelSummary").setProperty("/FileNameLoaSet", null);
			}
			/*End of change on 18-Feb-2020*/
			var displayMode = this.getModel("mModelSummary").getProperty("/displayMode"); /*Chnage added by Saptarshi on 22-Nov-2019*/
			if (displayMode === false) { /*Chnage added by Saptarshi on 22-Nov-2019*/
				sap.ui.core.BusyIndicator.show(0);
				var avlueText = this.getModel("i18n").getProperty("addGlobalFunction");
				mModelSummary.setProperty("/setLineItemText", avlueText);
				this.getView().getModel("mModelSummary").setProperty("/TextForLineItemEmailSrch", avlueText);
				var sPanelName = this.getModel("i18n").getProperty("GFSEC");
				var oTooltipText = this.getModel("i18n").getProperty("supplierToolTip");
				mModelSummary.setProperty("/setPanelText", sPanelName);
				mModelSummary.setProperty("/updateRowData", []);
				mModelSummary.setProperty("/oLinePoTableSetTemp", []);
				mModelSummary.setProperty("/DeleteCommercialRow", "");
				mModelSummary.setProperty("/SrNo", "");
				mModelSummary.setProperty("/oEditable/lastsrvDate", false);
				mModelSummary.setProperty("/oEditable/lastDateOfServLabel", false);
				this.getView().getModel("mModelSummary").setProperty("/oEditable/attchmentExpnded", false);
				mModelSummary.setProperty("/oEditable/questionPnVisiblePO", false);
				mModelSummary.setProperty("/oEditable/editLineItemCop", true);
				//Changes for new CR CopRESET 13.08.2021
				mModelSummary.setProperty("/oEditable/reSetButtonEnable", false);
				mModelSummary.setProperty("/oEditable/editMode", true); /*Chnage added by Saptarshi on 20-Nov-2019*/
				var oMadtory = mModelSummary.getProperty("/HeaderData");
				mModelSummary.setProperty("/oEditable/serviceRenderBox", false);
				if (oMadtory.ContrlName && oMadtory.ContrlEmail && oMadtory.RrfDesc && oMadtory.CompanyCode) {
					var rrfTablefragment = this.getView().createId("rrfTablefragment");
					if (!this.rrfTablefragment) {
						this.rrfTablefragment = sap.ui.xmlfragment(rrfTablefragment, "kgo.ARRecharge.view.createLineItem", this);
						// this.rrfTablefragment = sap.ui.xmlfragment(rrfTablefragment, "kgo.ARRecharge.view.RRFTable", this);
						this.getView().addDependent(this.rrfTablefragment);
					}
					if (this.rrfTablefragment.isOpen()) {
						this.rrfTablefragment.close();
					} else {
						sap.ui.core.BusyIndicator.hide(0);
						this.byId(sap.ui.core.Fragment.createId(rrfTablefragment, "idselectok")).setVisible(true);
						this.byId(sap.ui.core.Fragment.createId(rrfTablefragment, "idselectEdit")).setVisible(false);
						this.byId(sap.ui.core.Fragment.createId(rrfTablefragment, "commercialPanelId")).oIconCollapsed.setAggregation("tooltip",
							oTooltipText);
						this.byId(sap.ui.core.Fragment.createId(rrfTablefragment, "contrylebelId")).setVisible(false);
						// this.byId(sap.ui.core.Fragment.createId(rrfTablefragment, "contryDrdwId")).setVisible(false);
						mModelSummary.setProperty("/oEditable/rmdropDown", false);
						mModelSummary.setProperty("/oEditable/requMfvisible", false);
						sap.ui.core.Fragment.byId(rrfTablefragment, "descriptionForMF").setVisible(false);
						sap.ui.core.Fragment.byId(rrfTablefragment, "descriptionGF").setVisible(true);
						this.byId(sap.ui.core.Fragment.createId(rrfTablefragment, "globalcostcenterId")).setVisible(true);
						this.byId(sap.ui.core.Fragment.createId(rrfTablefragment, "GlobalCC")).setVisible(true);
						mModelSummary.setProperty("/oEditable/visibleforMF", true);
						mModelSummary.setProperty("/oEditable/visibleforGF", true);
						this.getView().getModel("mModelSummary").setProperty("/oEditable/additionalFieldBrf", false);
						sap.ui.core.Fragment.byId(rrfTablefragment, "ContactPersonLOAId").setEditable(false);

						//date Picker
						var oDatePicker = this.byId(sap.ui.core.Fragment.createId(rrfTablefragment, "comercialDatePickerId"));
						oDatePicker.addEventDelegate({
							onAfterRendering: function () {
								var oDateInner = this.$().find('.sapMInputBaseInner');
								var oID = oDateInner[0].id;
								$('#' + oID).attr("disabled", "disabled");
							}
						}, oDatePicker);

						var oDatePicker = this.byId(sap.ui.core.Fragment.createId(rrfTablefragment, "PoendDate"));
						oDatePicker.addEventDelegate({
							onAfterRendering: function () {
								var oDateInner = this.$().find('.sapMInputBaseInner');
								var oID = oDateInner[0].id;
								$('#' + oID).attr("disabled", "disabled");
							}
						}, oDatePicker);

						// oDatePicker = this.byId(sap.ui.core.Fragment.createId(rrfTablefragment, "thirdPartyDateForGF"));
						// oDatePicker.addEventDelegate({
						// 	onAfterRendering: function () {
						// 		var oDateInner = this.$().find('.sapMInputBaseInner');
						// 		var oID = oDateInner[0].id;
						// 		$('#' + oID).attr("disabled", "disabled");
						// 	}
						// }, oDatePicker);

						// oDatePicker = this.byId(sap.ui.core.Fragment.createId(rrfTablefragment, "lastServForGf"));
						// oDatePicker.addEventDelegate({
						// 	onAfterRendering: function () {
						// 		var oDateInner = this.$().find('.sapMInputBaseInner');
						// 		var oID = oDateInner[0].id;
						// 		$('#' + oID).attr("disabled", "disabled");
						// 	}
						// }, oDatePicker);

						//End of date pickerfor last service date

						this.rrfTablefragment.open();

					}

				} else {
					sap.ui.core.BusyIndicator.hide(0);
					var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
					MessageBox.alert(
						"Please enter mandatory fields.", {
							styleClass: bCompact ? "sapUiSizeCompact" : ""
						}
					);
					this.getView().getModel("mModelSummary").setProperty("/TextForLineItemEmailSrch");

				}
			} /*Chnage added by Saptarshi on 22-Nov-2019*/
		},
		onPressScTask: function (oEvent) {
			var sLinItemLink = oEvent.getSource().getBindingContext("mModelSummary").getObject();
			var sId = oEvent.getSource().getId().split("--")[2].split("-")[0];
			if (sId === "ServicenowId") {
				window.open(sLinItemLink.CopSctaskLink, '_blank');
			} else if (sId === "SnowNoLoaId") {
				window.open(sLinItemLink.LoaSctaskLink, '_blank');
			}
		},

		onSelectingMf: function (oEvent) {
			var mModelSummary = this.getView().getModel("mModelSummary");
			var id = oEvent.getSource().getId(); /*Added on 28-Jan-2020*/
			var format = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/;
			var oKeepInstance = oEvent.getParameter("selectedItem");
			var that = this;
			if (id.indexOf("contryDrdwId") > 0) { /*Added on 28-Jan-2020*/
				if (mModelSummary.getProperty("/updateRowData").RequestingMf) {
					var messageText = this.getModel("i18n").getProperty("requestingMfchangedmsg");
					MessageBox.information(messageText, {
						actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
						emphasizedAction: MessageBox.Action.OK,
						onClose: function (sAction) {
							if (sAction === "CANCEL") {
								var reqConty = mModelSummary.getProperty("/updateRowData").RequestingMf;
								mModelSummary.setProperty("/SelcKeySet", reqConty);

							} else {

								if (oKeepInstance.getProperty("text").split(":")[0]) {
									var RequestingcountryName = oKeepInstance.getProperty("text").split(":")[1];
									var contrycode = oKeepInstance.getProperty("text").split(":")[0];
									if (format.test(contrycode)) {
										var specialcharmsgForMf = that.getModel("i18n").getProperty("specialcharmsgForMf");
										MessageBox.error(specialcharmsgForMf);
										return true;
									}

								}

								var oMemberFirm = oKeepInstance.getProperty("additionalText");
								//special character message check
								if (format.test(oMemberFirm)) {
									var specialcharmsgForMemberfirm = that.getModel("i18n").getProperty("specialcharmsgForMemberfirm");
									MessageBox.error(specialcharmsgForMemberfirm);
									return true;

								}
								mModelSummary.setProperty("/SelcKeySet", contrycode);
								var key = oKeepInstance.getProperty("key");
								mModelSummary.setProperty("/SelcKeySet", key);
								mModelSummary.setProperty("/updateRowData/MemberFirm", oMemberFirm);
								mModelSummary.setProperty("/updateRowData/Landx", RequestingcountryName);
								mModelSummary.setProperty("/updateRowData/EntityName", "");
								mModelSummary.setProperty("/updateRowData/EntityAddress", "");
								mModelSummary.setProperty("/updateRowData/RequestingMf", key);

								//mModelSummary.setProperty("/updateRowDataNC/")
								//questionCall
								that.questionaCall();
								mModelSummary.setProperty("/SelcKeySet", key);

							}
						}
					});
				} else {
					var countryName = oEvent.getParameter("selectedItem").getProperty("additionalText");
					if (oEvent.getParameter("selectedItem").getProperty("text").split(":")[0]) {
						var RequestingcountryName = oEvent.getParameter("selectedItem").getProperty("text").split(":")[1];
						var contrycode = oEvent.getParameter("selectedItem").getProperty("text").split(":")[0];
						//special character message check
						if (format.test(contrycode)) {
							var specialcharmsgForMf = this.getModel("i18n").getProperty("specialcharmsgForMf");
							MessageBox.error(specialcharmsgForMf);
							return true;
						}

					}

					if (format.test(countryName)) {
						var specialcharmsgForMemberfirm = this.getModel("i18n").getProperty("specialcharmsgForMemberfirm");
						MessageBox.error(specialcharmsgForMemberfirm);
						return true;

					}
					this.getView().getModel("mModelSummary").setProperty("/updateRowData/RequestingMf", key);

					var key = oEvent.getParameter("selectedItem").getProperty("key");
					this.getView().getModel("mModelSummary").setProperty("/SelcKeySet", contrycode);
					this.getView().getModel("mModelSummary").setProperty("/SelcKeySet", key);
					this.getView().getModel("mModelSummary").setProperty("/updateRowData/MemberFirm", countryName);
					this.getView().getModel("mModelSummary").setProperty("/updateRowData/Landx", RequestingcountryName);
					this.getView().getModel("mModelSummary").setProperty("/updateRowData/RequestingMf", key);

					this.getView().getModel("mModelSummary").refresh(true);
					this.questionaCall();

					/*Start of change  on 28-Jan-2020*/

				}
			} else if (id.indexOf("LocationOfTheServicesReq") > 0) {
				/*Start of defect 63359*/
				if (oEvent.getParameter("selectedItem") !== null) {
					var key = oEvent.getParameter("selectedItem").getProperty("key");
					mModelSummary.setProperty("/updateRowData/LocationOfTheServicesReq", key);
					// if (key === "US") {
					// 	mModelSummary.setProperty("/oEditable/serviceRenderBox", true);
					// } else {
					// 	mModelSummary.setProperty("/oEditable/serviceRenderBox", false);
					// 	mModelSummary.setProperty("/updateRowData/LocOfRenderingUs", "");
					// }
				} else if (oEvent.getParameter("selectedItem") === null) {
					mModelSummary.setProperty("/updateRowData/LocationOfTheServicesReq", "");
					// mModelSummary.setProperty("/oEditable/serviceRenderBox", false);
					// mModelSummary.setProperty("/updateRowData/LocOfRenderingUs", "");
				}
				/*End of defect 63359*/
			}
			/*End of change on 28-Jan-2020*/
			mModelSummary.setProperty("/SelcKeySet", mModelSummary.getProperty("/updateRowData").RequestingMf);
		},
		// onSelectingServiceRenderv: function (oEvent) {
		// 	var mModelSummary = this.getView().getModel("mModelSummary");
		// 	var selectedKey = oEvent.getParameter("selectedItem").getProperty("key");
		// 	mModelSummary.setProperty("/updateRowData/LocOfRenderingUs", selectedKey);
		// },
		questionaCall: function () {
			var mModelSummary = this.getModel("mModelSummary");
			var contrycode = mModelSummary.getProperty("/updateRowData").RequestingMf;
			var firstQuestion = this.getModel("i18n").getProperty("firstQuestionOfQuestionnaire");
			mModelSummary.setProperty("/oEditable/questionPnVisiblePO", false);
			mModelSummary.setProperty("/questionSet", []);
			mModelSummary.setProperty("/firstQuestionSet", []);
			sap.ui.core.BusyIndicator.show(0);
			var aFilter = [];
			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				var questionArr = [];
				var firstQuestionArrey = [];
				var dataColl = [];
				if (d.results.length > 0) {
					for (var i = 0; i < d.results.length; i++) {
						var object = {};
						object.LineNo = d.results[i].LineNo;
						object.CompanyCode = d.results[i].CompanyCode;
						object.Mandatory = d.results[i].Mandatory;
						object.MemberFirm = d.results[i].MemberFirm;
						object.Question = d.results[i].Question;
						object.InternalExternal = d.results[i].InternalExternal;
						object.RequestingMf = d.results[i].RequestingMf;
						object.Answer = "";
						object.AnswerOther = "";
						object.ProcessGrp = "";
						questionArr.push(object);
						// if (i == 0) {
						// 	firstQuestionArrey.push(object);
						// 	// mModelSummary.setProperty("/firstQuestionSet",object );

						// } else {
						// 	questionArr.push(object);
						// }
					}
					mModelSummary.setProperty("/questionSet", questionArr);
					if (questionArr.length > 0) {
						var objectFirst = {};
						objectFirst.LineNo = "01";
						objectFirst.CompanyCode = object.CompanyCode;
						objectFirst.Mandatory = "";
						objectFirst.MemberFirm = object.MemberFirm;
						objectFirst.Question = firstQuestion;
						objectFirst.InternalExternal = "";
						objectFirst.RequestingMf = object.RequestingMf;
						objectFirst.Answer = "";
						objectFirst.AnswerOther = "";
						objectFirst.ProcessGrp = "";
						firstQuestionArrey.push(objectFirst);
					}

					mModelSummary.setProperty("/firstQuestionSet", firstQuestionArrey);

					mModelSummary.setProperty("/oEditable/questionPnVisiblePO", true);
					mModelSummary.refresh(true);
				} else {
					mModelSummary.setProperty("/oEditable/questionPnVisiblePO", false);
				}
				jQuery.sap.delayedCall(300, this, function () {
					mModelSummary.setProperty("/SelcKeySet", contrycode);
				});
				//	return mModelSummary.setProperty("/SelcKeySet", contrycode);

			}, this);

			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();

				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"

				});
			}, this);

			aFilter.push(new Filter("RequestingMf", FilterOperator.EQ, mModelSummary.getProperty("/updateRowData").RequestingMf));
			aFilter.push(new Filter("MemberFirm", FilterOperator.EQ, mModelSummary.getProperty("/updateRowData").MemberFirm));
			aFilter.push(new Filter("CompanyCode", FilterOperator.EQ, mModelSummary.getProperty("/HeaderData").CompanyCode));
			var sPath = "/RRF_QuestionSet";
			var oObject = {};
			oObject.Filter = aFilter;
			//oObject.Params = sParams;
			oObject.successCallback = fnSuccess;
			oObject.errorCallback = fnError;
			oObject.sPath = sPath;
			DataManagerARrecharge.getCoupaReqiNumberhelpValus(oObject);

		},

		onEnterProcessGroup: function (oEvent) {
			var format = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/;
			if (format.test(oEvent.getParameter("value"))) {
				var specialMsg = this.getModel("i18n").getProperty("specialchMsg");
				MessageBox.error(specialMsg);
				return true;
			} else {
				return false;
			}
		},

		// onSelectingAnsware: function (oEvent) {
		// 	var oSelectedAnsw = oEvent.getSource().getProperty("selectedIndex");
		// 	var rowPath = oEvent.getSource().getParent().getBindingContextPath();
		// 	var rrfTablefragment = this.getView().createId("rrfTablefragment");
		// 	var tbl = sap.ui.core.Fragment.byId(rrfTablefragment, "QuestionTable");
		// 	for (var i = 0; i < tbl.getAggregation("items").length; i++) {
		// 		var showInputField = tbl.getAggregation("items")[i].getBindingContext("mModelSummary").sPath;
		// 		if ((showInputField === rowPath)) {
		// 			for (var k = 0; k < tbl.getAggregation("items")[i].getCells().length; k++) {
		// 				if (k === 3) {
		// 					if (oSelectedAnsw === 3) {
		// 						tbl.getAggregation("items")[i].getCells()[3].setProperty("visible", true);

		// 					} else {
		// 						tbl.getAggregation("items")[i].getCells()[3].setProperty("visible", false);
		// 					}
		// 				}
		// 			}
		// 		}

		// 	}

		// },

		onSelectingFirstAns: function (oEvent) {
			var EditFlag = this.getModel("mModelSummary").getProperty("/oEditable").rmdropDown;
			var val = oEvent.getParameter("value");
			var questionTableData = this.getModel("mModelSummary").getProperty("/questionSet");
			var tbl;
			var showInputField;
			if (EditFlag === true) {
				var rrfTablefragment = this.getView().createId("rrfTablefragment");
				tbl = sap.ui.core.Fragment.byId(rrfTablefragment, "QuestionTable2");
			} else {
				var oLineItemfrg = this.getView().createId("fragmentId");
				tbl = sap.ui.core.Fragment.byId(oLineItemfrg, "QuestionTable2");
			}

			for (var interExt = 0; interExt < questionTableData.length; interExt++) {
				if (val === "Service from KPMGI") {
					if (questionTableData[interExt].InternalExternal === "EXTERNAL") {
						questionTableData[interExt].Answer = "N/A";
						questionTableData[interExt].AnswerDesc = " ";
						tbl.getAggregation("items")[interExt].getCells()[3].setProperty("visible", false);
						tbl.getAggregation("items")[interExt].getCells()[2].setProperty("editable", false);
					} else {
						questionTableData[interExt].Answer = " ";
						questionTableData[interExt].AnswerDesc = " ";
						tbl.getAggregation("items")[interExt].getCells()[2].setProperty("editable", true);
						tbl.getAggregation("items")[interExt].getCells()[3].setProperty("visible", false);
					}
				}
				if (val === "Service from external supplier") {
					if (questionTableData[interExt].InternalExternal === "INTERNAL") {
						questionTableData[interExt].Answer = "N/A";
						questionTableData[interExt].AnswerDesc = " ";
						tbl.getAggregation("items")[interExt].getCells()[3].setProperty("visible", false);
						tbl.getAggregation("items")[interExt].getCells()[2].setProperty("editable", false);
					} else {
						questionTableData[interExt].Answer = " ";
						questionTableData[interExt].AnswerDesc = " ";
						tbl.getAggregation("items")[interExt].getCells()[2].setProperty("editable", true);
						tbl.getAggregation("items")[interExt].getCells()[3].setProperty("visible", false);
					}
				}

			}
			// for (var i = 0; i <questionTableData.length; i++) {
			// 	showInputField = tbl.getAggregation("items")[i].getBindingContext("mModelSummary").sPath;
			// 	if ((showInputField === rowPath)) {
			// 		for (var k = 0; k < tbl.getAggregation("items")[i].getCells().length; k++) {
			// 			if (k === 3) {
			// 				if (val === "") {
			// 					tbl.getAggregation("items")[i].getCells()[3].setProperty("visible", true);
			// 					mModelSummary.getProperty("/questionSet")[i].AnswerDesc = "";
			// 					//tbl.getAggregation("items")[i].getCells()[3].setProperty("value", "");

			// 				} else if (val === "NO") {
			// 					tbl.getAggregation("items")[i].getCells()[3].setProperty("visible", true);
			// 					//tbl.getAggregation("items")[i].getCells()[3].setProperty("value", "");
			// 					mModelSummary.getProperty("/questionSet")[i].AnswerDesc = "";
			// 				} else if (val === "Other") {
			// 					tbl.getAggregation("items")[i].getCells()[3].setProperty("visible", true);
			// 					mModelSummary.getProperty("/questionSet")[i].AnswerDesc = "";
			// 					//tbl.getAggregation("items")[i].getCells()[3].setProperty("value", "");
			// 				} else {
			// 					tbl.getAggregation("items")[i].getCells()[3].setProperty("visible", false);
			// 					mModelSummary.getProperty("/questionSet")[i].AnswerDesc = "";
			// 				}
			// 			}
			// 		}
			// 	}

			// }

		},
		onSelectingAns1: function (oEvent) {
			var val = oEvent.getParameter("selectedItem").getProperty("text");
			var mModelSummary = this.getView().getModel("mModelSummary");
			var rowPath = oEvent.getSource().getParent().getBindingContextPath();
			var tbl;
			var showInputField;
			var EditFlag = this.getModel("mModelSummary").getProperty("/oEditable").rmdropDown;
			if (EditFlag === true) {
				var rrfTablefragment = this.getView().createId("rrfTablefragment");
				tbl = sap.ui.core.Fragment.byId(rrfTablefragment, "QuestionTable2");
			} else {
				var oLineItemfrg = this.getView().createId("fragmentId");
				tbl = sap.ui.core.Fragment.byId(oLineItemfrg, "QuestionTable2");
			}

			for (var i = 0; i < tbl.getAggregation("items").length; i++) {
				showInputField = tbl.getAggregation("items")[i].getBindingContext("mModelSummary").sPath;
				if ((showInputField === rowPath)) {
					for (var k = 0; k < tbl.getAggregation("items")[i].getCells().length; k++) {
						if (k === 3) {
							if (val === "YES") {
								tbl.getAggregation("items")[i].getCells()[3].setProperty("visible", true);
								mModelSummary.getProperty("/questionSet")[i].AnswerDesc = "";
								//tbl.getAggregation("items")[i].getCells()[3].setProperty("value", "");

							} else if (val === "NO") {
								tbl.getAggregation("items")[i].getCells()[3].setProperty("visible", true);
								//tbl.getAggregation("items")[i].getCells()[3].setProperty("value", "");
								mModelSummary.getProperty("/questionSet")[i].AnswerDesc = "";
							} else if (val === "Other") {
								tbl.getAggregation("items")[i].getCells()[3].setProperty("visible", true);
								mModelSummary.getProperty("/questionSet")[i].AnswerDesc = "";
								//tbl.getAggregation("items")[i].getCells()[3].setProperty("value", "");
							} else {
								tbl.getAggregation("items")[i].getCells()[3].setProperty("visible", false);
								mModelSummary.getProperty("/questionSet")[i].AnswerDesc = "";
							}
						}
					}
				}

			}

		},
		onEnterDropDownAnswer: function (oEvent) {
			var newval = oEvent.getParameter("newValue");
			if (newval !== "YES" && newval !== "N/A" && newval !== "NO" && newval !== "Other") {
				oEvent.getSource().setValue("");
				oEvent.getSource().setValueState("Error");
			} else {
				oEvent.getSource().setValueState("None");
			}
		},

		onCheckMF: function (oEvent) {

			var checkString = oEvent.getParameter("value");
			if (checkString === "GB:UNITED KINGDOM") {
				this.getView().getModel("mModelSummary").setProperty("/SelcKeySet", "GB");
				this.getView().getModel("mModelSummary").setProperty("/updateRowData/Landx", "UNITED KINGDOM");
			}
			if (checkString != "" && checkString !== "GB:UNITED KINGDOM") {
				if (/[^A-Za-z\d]/.test(checkString) || isNaN(oEvent.getParameter("value")) === false || /\d/.test(checkString)) {
					this.getView().getModel("mModelSummary").setProperty("/SelcKeySet", "");
					this.getView().getModel("mModelSummary").setProperty("/updateRowData/MemberFirm", "");
					this.getView().getModel("mModelSummary").setProperty("/updateRowData/Landx", "");
				}
			}

		},
		onLocationServEnter: function (oEvent) {
			var checkString = oEvent.getParameter("value");
			if (checkString != "") {
				if (/[^A-Za-z\d]/.test(checkString) || isNaN(oEvent.getParameter("value")) === false || /\d/.test(checkString)) {
					this.getView().getModel("mModelSummary").setProperty("/updateRowData/LocationOfTheServicesReq", "");
				}
			}
		},
		onSelectingCurrency: function (oEvent) {

			var currencyKey = oEvent.getParameter("selectedItem").getProperty("key");

			this.getView().getModel("mModelSummary").setProperty("/HeaderData/Currency", currencyKey);
		},

		pressLinkClose: function () {
			var mModelSummary = this.getModel("mModelSummary");
			mModelSummary.setProperty("/oEditable/attchmentExpnded", false);
			var displayMode = this.getModel("mModelSummary").getProperty("/displayMode");
			this.oRestVal = false;
			if (displayMode === false) {
				this.getView().getModel("mModelSummary").setProperty("/oEditable/editLineItemCop", true);
				this.getView().getModel("mModelSummary").setProperty("/oEditable/editLineItemMF", true);
				this.getView().getModel("mModelSummary").setProperty("/oEditable/editLineItemLOA", true);
			}

			if (this.rrfTablefragment) {
				this.getModel("mModelSummary").setProperty("/GblFuncName", false);
				this.rrfTablefragment.close();

			}
			jQuery.sap.delayedCall(500, this,
				function () {
					if (this.oLineItemfrg) {
						this.getModel("mModelSummary").setProperty("/GblFuncName", false);
						var tbl = this.getView().byId('tableid');
						var lLineItemTable = this.getView().getModel("mModelSummary").getProperty("/TableItemSet/results");
						for (var i = 0; i < lLineItemTable.length; i++) {
							var CopInitiate = lLineItemTable[i].CopInitiate;
							if (CopInitiate === "X") {
								var x = tbl.getAggregation("items")[i];
								x.getMultiSelectControl().setEnabled(false);
							}
							if (mModelSummary.getProperty("/updateRowData_Old")) {
								mModelSummary.setProperty("/updateRowData", mModelSummary.getProperty("/updateRowData_Old"));
								if ((lLineItemTable[i].RequestingMf === mModelSummary.getProperty("/updateRowData").RequestingMf && lLineItemTable[i].ProcessGrp ===
										mModelSummary.getProperty("/updateRowData").ProcessGrp && lLineItemTable[i].Ltext === mModelSummary.getProperty(
											"/updateRowData").Ltext && lLineItemTable[i].MemberFirm === mModelSummary.getProperty("/updateRowData").MemberFirm)) {
									mModelSummary.getProperty("/TableItemSet").results[i] = mModelSummary.getProperty("/updateRowData");

								}
							}
						}
						mModelSummary.setProperty("/updateRowData_Old", undefined);
						this.oLineItemfrg.close();
						var oValue = this.getModel("mModelSummary").getProperty("/oLinePoTableSet");
						this.getModel("mModelSummary").setProperty("/copPoTableSet", oValue);

					}
				});

			mModelSummary.setProperty("/copPoLineItemSet", []);
			mModelSummary.setProperty("/oLinePoTableSetTemp", []);
			mModelSummary.setProperty("/TextForLineItemEmailSrch");
			/*Start - CR  Changed On 26-Aug-2021 By Prashant and Chhanda*/

			// if (mModelSummary.getProperty("/updateRowData/ConfYn_old")) {
			// 	mModelSummary.setProperty("/updateRowData/ConfYn", mModelSummary.getProperty("/updateRowData/ConfYn_old"));
			// }

			// if (mModelSummary.getProperty("/updateRowData/CopYesDate_old")) {
			// 	mModelSummary.setProperty("/updateRowData/CopYesDate", mModelSummary.getProperty("/updateRowData/CopYesDate_old"));
			// }
			// if (mModelSummary.getProperty("/updateRowData/ServNowCop_old")) {
			// 	mModelSummary.setProperty("/updateRowData/ServNowCop", mModelSummary.getProperty("/updateRowData/ServNowCop_old"));

			// }
			// if (mModelSummary.getProperty("/updateRowData/ServNowStatus_old")) {
			// 	mModelSummary.setProperty("/updateRowData/ServNowStatus", mModelSummary.getProperty("/updateRowData/ServNowStatus_old"));
			// }
			// mModelSummary.setProperty("/updateRowData/ConfYn_old", undefined);
			// mModelSummary.setProperty("/updateRowData/CopYesDate_old", undefined);
			// mModelSummary.setProperty("/updateRowData/ServNowCop_old", undefined);
			// mModelSummary.setProperty("/updateRowData/ServNowStatus_old", undefined);

			/*End - CR  Changed On 26-Aug-2021 By Prashant and Chhanda*/
		},
		handlePressLinkclose: function (oEvent) {
			var mModelSummary = this.getView().getModel("mModelSummary");
			mModelSummary.setProperty("/oEditable/lastsrvDate", false);
			if (this.oLineItemfrg.isOpen()) {
				var oNatureField = this.byId(sap.ui.core.Fragment.createId(this.oLineItemfrg, "natureField"));

				this.oLineItemfrg.close();

			}
		},

		handlePressBtnBack: function (oEvent) {

			this.getModel("mModelSummary").setProperty("/oDislayRRFNo");

			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();
			/*Start of change on 14-Jan-2020*/
			var that = this;
			var displayMode = this.getModel("mModelSummary").getProperty("/displayMode");
			if (displayMode === false) {

				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				MessageBox.warning(
					"Are you sure you want to go back? Change(s) made if any will be discarded!", {
						actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
						styleClass: bCompact ? "sapUiSizeCompact" : "",
						onClose: function (sAction) {
							if (sAction === "OK") {
								//added by prashant on 06.11.2020
								that.handleUnLockConcuurentUser();
								that.getView().getModel("mModelSummary").setProperty("/HeaderData", []);
								that.getView().getModel("mModelSummary").setProperty("/TableItemSet/results", []);
								if (sPreviousHash !== undefined) {
									var oRouter = UIComponent.getRouterFor(that);
									oRouter.navTo("TargetSelectionView", {}, true);

									//	window.history.go(-1);
								} else {
									oRouter = UIComponent.getRouterFor(that);
									oRouter.navTo("TargetSelectionView", {}, true);
								}
								that.getModel("mModelSummary").setProperty("/oEditable", {});
								that.getModel("mModelSummary").setProperty("/updateRowData/RequestingMf", ""); /*Chnage added on 09-Jan-2020*/
								/*Start of chnage for defect 63096 on 31-Jan-2020*/
								var oTable = that.getView().byId("tableid");
								oTable.removeSelections(true);
								/*End of chnage for defect 63096 on 31-Jan-2020*/

							}
						}
					}, this);

			} else {
				this.getView().getModel("mModelSummary").setProperty("/HeaderData", []);
				this.getView().getModel("mModelSummary").setProperty("/TableItemSet/results", []);
				if (sPreviousHash !== undefined) {
					window.history.go(-1);
				} else {
					var oRouter = UIComponent.getRouterFor(that);
					oRouter.navTo("selectionScreen", {}, true);
				}
				/*Start of chnage for defect 63096 on 04-Feb-2020*/
				var oTable = that.getView().byId("tableid");
				oTable.removeSelections(true);
				/*End of chnage for defect 63096 on 04-Feb-2020*/

				//added by prashant kumar
				//this.handleUnLockConcuurentUser();
			}
			/*End of change on 14-Jan-2020*/
		},

		handleUnLockConcuurentUser: function (oEvent) {
			var mModelSummary = this.getModel("mModelSummary");
			var oFilterData = mModelSummary.getProperty("/HeaderData");
			var aFilter = [];
			if (oFilterData.RrfNo && oFilterData.CompanyCode) {
				aFilter.push(new sap.ui.model.Filter("RrfNo", sap.ui.model.FilterOperator.EQ, oFilterData.RrfNo));
				aFilter.push(new sap.ui.model.Filter("CompanyCode", sap.ui.model.FilterOperator.EQ, oFilterData.CompanyCode));
			}
			sap.ui.core.BusyIndicator.show(0);
			var functionSucess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
			}, this);

			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();
				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"

				});
			}, this);
			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
				json: true
			});
			oModel1.read("/RRF_LockSet", {
				filters: aFilter,
				success: functionSucess,
				error: fnError
			});

		},

		handlePressLinkOK: function (oEvent) {
			var mModelSummary = this.getView().getModel("mModelSummary");
			mModelSummary.setProperty("/TextForLineItemEmailSrch");
			mModelSummary.setProperty("/oEditable/attchmentExpnded", false);
			mModelSummary.setProperty("/copPoLineItemSet", []);
			var sVales = mModelSummary.getProperty("/TableItemSet/results");
			var sUpdateValues = mModelSummary.getProperty("/updateRowData");
			var locaSrv = mModelSummary.getProperty("/SelcKeySetLocServ");
			var requmf = mModelSummary.getProperty("/SelcKeySet");
			var questionTable = mModelSummary.getProperty("/questionSet");
			var _qfirstQuestionData = mModelSummary.getProperty("/firstQuestionSet");
			var questionMess = false;
			var dupiLicateFlag = false;
			var sArray = [];
			var sObj = {};
			var adhocFlagPo;
			var oTblBRF = this.getView().byId('tableid');
			var format = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/;
			if (sUpdateValues.ProcessGrp) {
				if (format.test(sUpdateValues.ProcessGrp)) {
					var specialMsg = this.getModel("i18n").getProperty("specialchMsg");
					MessageBox.error(specialMsg);
					return true;
				}

			}
			if (sUpdateValues.ProcessGrp && questionTable.length > 0 && _qfirstQuestionData.length > 0) {
				mModelSummary.getProperty("/firstQuestionSet")[0].ProcessGrp = sUpdateValues.ProcessGrp;
				for (var i = 0; i < questionTable.length; i++) {
					if ((!mModelSummary.getProperty("/questionSet")[i].Answer || mModelSummary.getProperty("/questionSet")[i].Answer === " ") || (!
							_qfirstQuestionData[0].Answer || _qfirstQuestionData[0].Answer === " ")) {
						questionMess = true;
						break;
					}
					if (mModelSummary.getProperty("/questionSet")[i].Answer === "Other" && !mModelSummary.getProperty("/questionSet")[i].AnswerDesc) {
						var questionMess2 = true;
						break;
					} else {
						mModelSummary.getProperty("/questionSet")[i].ProcessGrp = sUpdateValues.ProcessGrp;
						questionMess2 = false;
						questionMess = false;
					}
				}
			}

			if (questionMess === true) {
				var questionnaDetailMissing = this.getModel("i18n").getProperty("questionnaDetailMissing");
				MessageBox.alert(questionnaDetailMissing);
				return true;
			}
			if (questionMess2 === true) {

				var questionnaDetailMissing2 = this.getModel("i18n").getProperty("questionnaDetailMissing2");
				MessageBox.alert(questionnaDetailMissing2);
				return true;
			}

			if (!requmf && !sUpdateValues.GlobalCc) {
				sUpdateValues.RequestingMf = "";
			}

			if ((sUpdateValues.RequestingMf && sUpdateValues.ProcessGrp && sUpdateValues.NatureOfService && (sUpdateValues.AddlBillInfo ||
					sUpdateValues.LongText) && sUpdateValues.ContactPCop) ||
				(sUpdateValues.GlobalCc && sUpdateValues.Ltext && sUpdateValues.GfLineDesc)) {
				if (this.rrfTablefragment) {
					this.getModel("mModelSummary").setProperty("/GblFuncName", false); /*Added on 22-APR-2020*/
					var oValue = mModelSummary.getProperty("/oLinePoTableSet");
					var arreyTemp = mModelSummary.getProperty("/oLinePoTableSetTemp");
					var oCommercialtableLength = mModelSummary.getProperty("/copPoTableSet");
					if (arreyTemp.length > 0) {
						for (var temp = 0; temp < arreyTemp.length; temp++) {
							var objectTemp = {};
							objectTemp.PoStartDate = arreyTemp[temp].PoStartDate;
							objectTemp.PoEndDate = arreyTemp[temp].PoEndDate;
							objectTemp.PoYear = arreyTemp[temp].PoYear;
							objectTemp.PoAmount = arreyTemp[temp].PoAmount;
							objectTemp.SrvChrg = arreyTemp[temp].SrvChrg;
							objectTemp.OutlineText = arreyTemp[temp].OutlineText;
							objectTemp.RrfNo = arreyTemp[temp].RrfNo;
							objectTemp.CompanyCode = arreyTemp[temp].CompanyCode;
							objectTemp.CoupaContractNo = arreyTemp[temp].CoupaRequisitionNumber;
							objectTemp.RequestingMf = arreyTemp[temp].RequestingMf;
							objectTemp.MemberFirm = arreyTemp[temp].MemberFirm;
							objectTemp.CcShortDesc = arreyTemp[temp].CcShortDesc;
							objectTemp.GlobalCc = arreyTemp[temp].GlobalCc;
							objectTemp.ProcessGrp = arreyTemp[temp].ProcessGrp;
							objectTemp.SerialNo = arreyTemp[temp].SerialNo;
							mModelSummary.getProperty("/oLinePoTableSet").push(objectTemp);
						}

					}
					mModelSummary.setProperty("/oLinePoTableSetTemp", []);

					if (oCommercialtableLength.length > 0) {
						var i = 0;
						var totalAmt = 0;
						while (i < oCommercialtableLength.length) {
							if (oCommercialtableLength[i].SrvChrg) {
								totalAmt = totalAmt + Number(oCommercialtableLength[i].PoAmount) + Number(oCommercialtableLength[i].SrvChrg);
							} else {
								totalAmt = totalAmt + Number(oCommercialtableLength[i].PoAmount);
							}

							i++;
						}
						totalAmt = totalAmt.toString();
					}

					// this.getView().getModel("mModelSummary").setProperty("/copPoTableSet", []);

					/*Start of change for SCTASK1855604 - budget approvers by developer Satabdi Das on 19-May-2021*/
					if (sUpdateValues.GlobalCc && sUpdateValues.GlobalCc !== "" && sUpdateValues.GlobalCc !== "N/A") {
						if (!sUpdateValues.AttenBrf || sUpdateValues.AttenBrf === "" || !sUpdateValues.AttenBrfEmail || sUpdateValues.AttenBrfEmail ===
							"") {
							var sErrorMsg = this.getView().getModel("i18n").getProperty("BAMissingErrorMsg");
							MessageBox.error(sErrorMsg, {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							});
							return;
						}
					}
					/*End of change for SCTASK1855604 - budget approvers by developer Satabdi Das on 19-May-2021*/

					if ((sUpdateValues.NatureOfService === "Adhoc/One-Off") && (!sUpdateValues.LastDateSrv)) {
						adhocFlagPo = "true";
						var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
						MessageBox.alert(
							"Please enter mandatory field.", {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}
						);
						mModelSummary.setProperty("/SelcKeySet", sUpdateValues.RequestingMf);
						return;

					} else {
						adhocFlagPo = "false";

						//processing group duplicate changes  developed by prashant kumar 14.05.2021
						if (!sUpdateValues.GlobalCc && sUpdateValues.RequestingMf) {
							for (var k = 0; k < oTblBRF.getItems().length; k++) {
								var oTableData = oTblBRF.getBindingInfo("items").binding.oList[k];
								if (oTableData.RequestingMf === sUpdateValues.RequestingMf && oTableData.MemberFirm === sUpdateValues.MemberFirm &&
									oTableData
									.ProcessGrp ===
									sUpdateValues.ProcessGrp) {
									dupiLicateFlag = true;
									break;
								}
							}
							if (dupiLicateFlag === true) {
								var duplicateMessage = this.getView().getModel("i18n").getProperty("duplicateFieldMesg");
								MessageBox.alert(duplicateMessage + sUpdateValues.RequestingMf + " " + "Member Firm : " + sUpdateValues.MemberFirm +
									" and Processing group: " + sUpdateValues.ProcessGrp + "  already exists.");
								return true;
							}
						}
						this.rrfTablefragment.close();
						this.getModel("mModelSummary").setProperty("/copPoTableSet", oValue);
						if (questionTable.length > 0 && _qfirstQuestionData.length > 0) { /*added for 63937*/
							mModelSummary.getProperty("/questionSetSubmit").push(_qfirstQuestionData[0]);
							mModelSummary.setProperty("/firstQuestionSet", []);
							if (mModelSummary.getProperty("/questionSet").length > 0) {
								for (var i = 0; i < mModelSummary.getProperty("/questionSet").length; i++) {

									mModelSummary.getProperty("/questionSetSubmit").push(mModelSummary.getProperty("/questionSet")[i]);
								}

								mModelSummary.setProperty("/questionSet", []);
							}
						}
					}

				}

				if (!sUpdateValues.RequestingMf && sUpdateValues.GlobalCc) {
					sUpdateValues.RequestingMf = "N/A";
					sUpdateValues.MemberFirm = ""; /*Added for SCTASK1919812 on 17-Feb-2021 by Satabdi Das*/
					locaSrv = "";

				}
				if (!sUpdateValues.GlobalCc && sUpdateValues.RequestingMf) {
					sUpdateValues.GlobalCc = "N/A";
					sUpdateValues.CcShortDesc = ""; /*Added for SCTASK1895344 on 17-Feb-2021 by Satabdi Das*/

				}
				sObj.CompanyCode = sUpdateValues.CompanyCode;
				sObj.RequestingMf = sUpdateValues.RequestingMf;
				sObj.MemberFirm = sUpdateValues.MemberFirm; /*Added on 19-Feb-2021*/
				sObj.Landx = sUpdateValues.Landx;
				sObj.GlobalCc = sUpdateValues.GlobalCc;
				sObj.CoupaRequisitionDate = sUpdateValues.CoupaRequisitionDate;
				sObj.ServNowCop = sUpdateValues.ServNowCop;
				sObj.CoupaRequisitionNumber = sUpdateValues.CoupaRequisitionNumber;
				sObj.GlobalGl = sUpdateValues.GlobalGl;
				sObj.ActRechrgAmnt = sUpdateValues.ActRechrgAmnt;
				sObj.AmntRechrgPo = sUpdateValues.AmntRechrgPo;
				sObj.AttenBrf = sUpdateValues.AttenBrf;
				sObj.AttenBrfEmail = sUpdateValues.AttenBrfEmail;
				sObj.BrfInitiate = sUpdateValues.BrfInitiate;
				sObj.BriefDescriptionOfServices = sUpdateValues.BriefDescriptionOfServices;
				// sObj.DetailsDescriptionOfService = sUpdateValues.DetailsDescriptionOfService;
				sObj.ConfYn = sUpdateValues.ConfYn;
				sObj.CopYesDate = sUpdateValues.CopYesDate;
				sObj.ContactEmailId = sUpdateValues.ContactEmailId;
				sObj.DocuNo = sUpdateValues.DocuNo;
				sObj.EntityAddress = sUpdateValues.EntityAddress;
				sObj.EntityName = sUpdateValues.EntityName;
				sObj.NewEntity = sUpdateValues.NewEntity; /*Added on 21-Feb-2020 by Satabdi Das*/
				sObj.Kunnr = sUpdateValues.Kunnr;
				sObj.LastDateSrv = sUpdateValues.LastDateSrv;
				sObj.LoaContact = sUpdateValues.LoaContact;
				sObj.LoaEmail = sUpdateValues.LoaEmail;
				sObj.SnowNoLoa = sUpdateValues.SnowNoLoa;
				sObj.LocationOfTheServicesReq = locaSrv;
				sObj.MfContactId = sUpdateValues.MfContactId;
				sObj.RrfStatus = sUpdateValues.RrfStatus;
				sObj.LongText = sUpdateValues.LongText;
				sObj.SapCodeMf = sUpdateValues.SapCodeMf;
				sObj.NatureOfService = sUpdateValues.NatureOfService;
				sObj.PercY = sUpdateValues.PercY;
				sObj.PriceUnit = sUpdateValues.PriceUnit;
				sObj.Quantity = sUpdateValues.Quantity;
				sObj.RechrgCurr = sUpdateValues.RechrgCurr;
				// sObj.LoaYn = sUpdateValues.LoaYn;
				sObj.ServNo = sUpdateValues.ServNo;
				sObj.SnowNo = sUpdateValues.SnowNo;
				sObj.VatId = sUpdateValues.VatId;
				sObj.WhTax = sUpdateValues.WhTax;
				sObj.ContactPCop = sUpdateValues.ContactPCop;
				sObj.CopEmailId = sUpdateValues.CopEmailId;
				sObj.CopAtt = sUpdateValues.CopAtt;
				sObj.MfCostCenter = sUpdateValues.MfCostCenter;
				sObj.MfApEmail = sUpdateValues.MfApEmail;
				sObj.AdlLoaContact = sUpdateValues.AdlLoaContact;
				sObj.AdlLoaEmail = sUpdateValues.AdlLoaEmail;
				sObj.AttYn = sUpdateValues.AttYn;
				sObj.DebitGl = sUpdateValues.DebitGl;
				sObj.DebitCc = sUpdateValues.DebitCc;
				sObj.Amt1 = sUpdateValues.Amt1;
				sObj.Amt2 = sUpdateValues.Amt2;
				sObj.CreditCc = sUpdateValues.CreditCc;
				sObj.CreditGl = sUpdateValues.CreditGl;
				sObj.CreditGl = sUpdateValues.Urn;
				sObj.AddlBillInfo = sUpdateValues.AddlBillInfo;
				sObj.BillingSyntax = sUpdateValues.BillingSyntax; /*Added for SCTASK1918966*/
				sObj.ShortDescription = sUpdateValues.ShortDescription; /*Added for SCTASK1943810*/
				sObj.GfName = sUpdateValues.GfName;
				sObj.GfEmail = sUpdateValues.GfEmail;
				sObj.ThirdPartyAgreement = sUpdateValues.ThirdPartyAgreement;
				sObj.ThirdParty = sUpdateValues.ThirdParty;
				sObj.ProcessGrp = sUpdateValues.ProcessGrp;
				sObj.Ltext = sUpdateValues.Ltext;
				sObj.Descript = sUpdateValues.Descript;
				sObj.LoaDesc = sUpdateValues.LoaDesc;
				sObj.ServNowStatus = sUpdateValues.ServNowStatus;
				sObj.LegalName = sUpdateValues.LegalName;
				sObj.SrvLoaStatus = sUpdateValues.SrvLoaStatus;
				sObj.TotalCommAmount = totalAmt;
				sObj.GfLineDesc = sUpdateValues.GfLineDesc;
				sObj.CommitmentType = sUpdateValues.CommitmentType;
				sObj.BaselineCommitmentAmmount = sUpdateValues.BaselineCommitmentAmmount;
				sObj.AdditionalDemand = sUpdateValues.AdditionalDemand;
				sObj.AddlContactPerson = sUpdateValues.AddlContactPerson;
				sObj.AddlContactEmail = sUpdateValues.AddlContactEmail;
				sObj.ConsumptionBasedAmount = sUpdateValues.ConsumptionBasedAmount;
				sObj.Year2CommitmentAmount = sUpdateValues.Year2CommitmentAmount;
				sObj.Year3CommitmentAmount = sUpdateValues.Year3CommitmentAmount;
				sObj.Year4CommitmentAmount = sUpdateValues.Year4CommitmentAmount;
				sObj.Year5CommitmentAmount = sUpdateValues.Year5CommitmentAmount;
				sObj.Year6CommitmentAmount = sUpdateValues.Year6CommitmentAmount;
				sObj.FinancialComment = sUpdateValues.FinancialComment;
				sObj.DescriptionOfRecharge = sUpdateValues.DescriptionOfRecharge;
				sObj.GpFiscalYear = sUpdateValues.GpFiscalYear;
				// sObj.ConsolidatedLoa = sUpdateValues.ConsolidatedLoa;
				// sObj.LocOfRenderingUs = sUpdateValues.LocOfRenderingUs;

				var oCopied = $.extend(true, [], sObj);

				if (adhocFlagPo === "false") {
					if (!sVales) {
						sArray.push(oCopied);

						this.getView().getModel("mModelSummary").setProperty("/TableItemSet/results", sArray);
					} else {
						this.getView().getModel("mModelSummary").getProperty("/TableItemSet/results").push(oCopied);
					}
				}
			} else {
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				MessageBox.alert(
					"Please enter mandatory field.", {
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					}
				);
				mModelSummary.setProperty("/SelcKeySet", sUpdateValues.RequestingMf);
				return;

			}
			this.grandTotalLineAmount();
			this.getView().getModel("mModelSummary").refresh(true);

		},
		grandTotalLineAmount: function () {
			var mModelSummary = this.getView().getModel("mModelSummary");
			var tbl = mModelSummary.getProperty("/TableItemSet").results;
			var grandtotalAmt = 0;
			for (var i = 0; i < tbl.length; i++) {
				var TotalCommAmount = tbl[i].TotalCommAmount;

				if (TotalCommAmount) {
					grandtotalAmt = grandtotalAmt + Number(TotalCommAmount);
				} else {
					grandtotalAmt = grandtotalAmt.toString();

				}
			}
			grandtotalAmt = grandtotalAmt.toString();
			mModelSummary.setProperty("/totalLineItemAmt", grandtotalAmt);
		},
		onRowSelect: function (oEvent) {
			var sTableRowItem = oEvent.getSource().getBindingContext("mModelSummary").getObject();
			this.getView().getModel("mModelSummary").setProperty("/updateRowData", sTableRowItem);

			var rrfTablefragment = this.getView().createId("rrfTablefragment");
			if (!this.rrfTablefragment) {
				this.rrfTablefragment = sap.ui.xmlfragment(rrfTablefragment, "kgo.ARRecharge.view.RRFTable", this);
				this.getView().addDependent(this.rrfTablefragment);
			}
			if (this.rrfTablefragment.isOpen()) {
				this.rrfTablefragment.close();
			} else {
				this.byId(sap.ui.core.Fragment.createId("rrfTablefragment", "idselectok")).setVisible(false);
				this.byId(sap.ui.core.Fragment.createId("rrfTablefragment", "idselectEdit")).setVisible(true);
				this.rrfTablefragment.open();

			}

		},
		// handlePressLinkCopy: function (oEvent) {
		// 	var acontext = this.getView().byId("tableid").getSelectedContextPaths();
		// 	if (acontext.length === 0) {
		// 		var msg = "Please Select At Least one Row";
		// 		MessageToast.show(msg);
		// 		this.getView().getModel("mModelSummary").refresh(true);
		// 	} else {
		// 		for (var i = 0; i < acontext.length; i++) {
		// 			var oTable = this.getView().byId("tableid").getModel("mModelSummary").getProperty(acontext[i]);
		// 			var oCopied = $.extend(true, [], oTable);
		// 			this.getView().getModel("mModelSummary").getProperty("/TableItemSet/results").push(oCopied);
		// 			this.getView().getModel("mModelSummary").refresh(true);
		// 			this.getView().byId("tableid").getSelectedItem().setSelected(false);
		// 		}
		// 	}

		// },
		handlePressLinkEdit: function (oEvent) {
			if (this.rrfTablefragment.isOpen()) {
				this.rrfTablefragment.close();
			}
			this.getView().getModel("mModelSummary").refresh(true);

		},

		deleteRecord: function (oObject) {
			var _modelBase = this.getOwnerComponent().getModel(); //controllerRef.getOwnerComponent().getModel();
			_modelBase.setUseBatch(true);
			_modelBase.setDeferredGroups(["DeleteRow"]);
			var sPath = oObject.sPath;
			var groupId = oObject.groupId;
			var successCallback = oObject.success;
			var errorCallback = oObject.error;
			_modelBase.remove(sPath, {
				groupId: groupId,
				success: successCallback,
				error: errorCallback
			});
		},
		_submitBatchOperationTest: function (grpId, fnUpdSuccess, fnUpdError) {
			var that = this;

			var fnSuccess1 = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				// that.onCoupaPressed();

			}, this);
			var _modelBase = this.getOwnerComponent().getModel(); //controllerRef.getOwnerComponent().getModel();
			_modelBase.submitChanges({
				groupId: grpId,
				success: fnSuccess1,
				error: fnUpdError
			});

		},
		setBatchOperationQueue: function (sPath, fnSuccess, fnError, oParams) {

			var oModel = this.getOwnerComponent().getModel(); //controllerRef.getOwnerComponent().getModel();
			oModel.setUseBatch(true);
			oModel.setDeferredGroups(["editServicet"]);
			//var aUpdRef = [];
			var changeSet = (this.aUpdRef) ? "changeSet" + this.aUpdRef.length : "changeSet";
			var mParams = {
				"groupId": "editServicet",
				"changeSetId": changeSet,
				"success": fnSuccess,
				"error": fnError
			};
			var oUpdRef;
			oUpdRef = oModel.remove(sPath, oParams, mParams);
			this.aUpdRef.push(oUpdRef);

		},
		_submitBatchOperation: function (fnUpdSuccess, fnUpdError) {
			var _modelBase = this.getOwnerComponent().getModel();
			_modelBase.submitChanges({
				groupId: "editServicet",
				success: fnUpdSuccess,
				error: fnUpdError
			});

		},

		handleLineItemDelete: function (oEvent) {
			var mModelSummary = this.getView().getModel("mModelSummary");
			var displayMode = mModelSummary.getProperty("/displayMode"); /*Added by Saptarshi on 22-Nov-2019*/
			if (displayMode === false) { /*Added by Saptarshi on 22-Nov-2019*/
				var sDeleteData = oEvent.getSource().getBindingContext("mModelSummary").getObject();
				var lineDeleteText = this.getModel("i18n").getProperty("lineDeleteText");
				var ReqText;
				var reqGCC;
				var MF;
				var procesgrp;
				var MemberFirmText;
				var processinggrp;
				if (sDeleteData.RequestingMf !== "N/A" && sDeleteData.GlobalCc === "N/A") {
					reqGCC = sDeleteData.RequestingMf;
					MF = sDeleteData.MemberFirm;
					procesgrp = sDeleteData.ProcessGrp;
					ReqText = this.getModel("i18n").getProperty("requesDeleteText");
					MemberFirmText = this.getModel("i18n").getProperty("deleteMfText");
					processinggrp = this.getModel("i18n").getProperty("processgrp");
				} else {
					reqGCC = sDeleteData.GlobalCc;
					ReqText = this.getModel("i18n").getProperty("globalCC");
					MemberFirmText = "";
					MF = "";
					procesgrp = "";
					processinggrp = "";
				}
				if ((sDeleteData.RrfStatus !== "COPConfirmed") && (sDeleteData.RrfStatus !== "LOAInitiated") && (sDeleteData.RrfStatus !==
						"LOAConfirmed")) {
					var RrfNo = this.getView().getModel("mModelSummary").getProperty("/HeaderData").RrfNo;
					var CompanyCode = this.getView().getModel("mModelSummary").getProperty("/HeaderData").CompanyCode;
					//var CoupaRequisitionNumber = this.getView().getModel("mModelSummary").getProperty("/HeaderData").CoupaRequisitionNumber;

					/*if (sDeleteData.ProcessGrp) {
						sDeleteData.ProcessGrp = sDeleteData.ProcessGrp.replace(/\s/g, "*");
					}
					if (sDeleteData.MemberFirm) {
							sDeleteData.MemberFirm = sDeleteData.MemberFirm.replace(/\s/g, "*");
						}

					this.getView().getModel("mModelSummary").setProperty("/deleteData", sDeleteData);*/
					//	Req Country ABC Member Firm XYZ line will be deleted. Do you want to proceed?
					var that = this;
					var event = oEvent.getSource();
					var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
					MessageBox.warning(
						ReqText + reqGCC + " " + MemberFirmText + MF + " " + processinggrp + procesgrp + " " + lineDeleteText, {
							actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
							styleClass: bCompact ? "sapUiSizeCompact" : "",

							onClose: function (sAction) {
								if (sAction === "OK") {
									//Delete commercial line 
									var oLineCoomercialTable = that.getModel("mModelSummary").getProperty("/oLinePoTableSet");
									var arrAnsware = that.getModel("mModelSummary").getProperty("/questionSetSubmit");
									for (var i = oLineCoomercialTable.length - 1; i >= 0; i--) {
										if ((oLineCoomercialTable[i].RequestingMf === sDeleteData.RequestingMf && oLineCoomercialTable[i].MemberFirm ===
												sDeleteData.MemberFirm && oLineCoomercialTable[i].ProcessGrp === sDeleteData.ProcessGrp) || (oLineCoomercialTable[i].GlobalCc ===
												sDeleteData.GlobalCc)) {
											var a = i;
											a = parseInt(a);
											mModelSummary.getProperty("/copPoTableSet").splice(a, 1);
											that.getView().getModel("mModelSummary").refresh(true);
										}
									}
									for (var i = arrAnsware.length - 1; i >= 0; i--) {
										if (arrAnsware[i].RequestingMf === sDeleteData.RequestingMf && arrAnsware[i].MemberFirm === sDeleteData.MemberFirm &&
											arrAnsware[i].ProcessGrp === sDeleteData.ProcessGrp) {
											var a = i;
											a = parseInt(a);
											mModelSummary.getProperty("/questionSetSubmit").splice(a, 1);
											that.getView().getModel("mModelSummary").refresh(true);
										}
									}

									if (sDeleteData.ProcessGrp) {
										sDeleteData.ProcessGrp = sDeleteData.ProcessGrp.replace(/\s/g, "*");
										/*Start of change for INC01584421 by developer Prashant kumar on 22-June-2021*/
										var forwardslash = /[/]+/;
										if (forwardslash.test(sDeleteData.ProcessGrp)) {
											sDeleteData.ProcessGrp = sDeleteData.ProcessGrp.replace(/[/]/g, "|");

										}
										var qQuestionChar = /[?]+/;
										if (qQuestionChar.test(sDeleteData.ProcessGrp)) {
											sDeleteData.ProcessGrp = sDeleteData.ProcessGrp.replace(/[?]/g, "(");

										}
										var pPercentage = /[%]+/;
										if (pPercentage.test(sDeleteData.ProcessGrp)) {
											sDeleteData.ProcessGrp = sDeleteData.ProcessGrp.replace(/[%]/g, ")");

										}

									}
									if (sDeleteData.MemberFirm) {
										sDeleteData.MemberFirm = sDeleteData.MemberFirm.replace(/\s/g, "*");
										/*Start of change for INC01584421 by developer Prashant kumar on 22-June-2021*/
										var forwardslashMmfirm = /[/]+/;
										if (forwardslashMmfirm.test(sDeleteData.MemberFirm)) {
											sDeleteData.MemberFirm = sDeleteData.MemberFirm.replace(/[/]/g, "|");

										}
										var qQuestionCharMemFm = /[?]+/;
										if (qQuestionCharMemFm.test(sDeleteData.MemberFirm)) {
											sDeleteData.MemberFirm = sDeleteData.MemberFirm.replace(/[?]/g, "(");

										}
										var pPercentageMF = /[%]+/;
										if (pPercentageMF.test(sDeleteData.MemberFirm)) {
											sDeleteData.MemberFirm = sDeleteData.MemberFirm.replace(/[%]/g, ")");

										}

									}

									// if (new Filter(sDeleteData.MemberFirm, FilterOperator.Contains, "/")) {
									// 	sDeleteData.MemberFirm = sDeleteData.MemberFirm.replace(/[\/]/g, '.');
									// }

									that.getView().getModel("mModelSummary").setProperty("/deleteData", sDeleteData);
									var sData = that.getView().getModel("mModelSummary").getProperty("/deleteData");
									if (sData.RequestingMf === "N/A") {
										sData.RequestingMf = "NA";
										sData.MemberFirm = "";
									} else if (sData.GlobalCc) {
										sData.GlobalCc = "NA";
										sData.CcShortDesc = "";
									}

									if (RrfNo) {
										var fnSuccess = jQuery.proxy(function (d) {
											sap.ui.core.BusyIndicator.hide(0);
											// that.handlePreBtnEdit();
											var x = event.getBindingContext("mModelSummary").getPath();
											var y = x.split("/");
											var z = y[3];
											z = parseInt(z);
											var s = event.getBindingContext("mModelSummary").getProperty("/TableItemSet");
											for (var i = s.results.length - 1; i >= 0; i--) {
												if (i === z) {
													(s.results).splice(z, 1);
												}
											}
											//recalculate grand total amont
											var tbl = mModelSummary.getProperty("/TableItemSet").results;
											var grandtotalAmt = 0;
											for (var i = 0; i < tbl.length; i++) {
												var TotalCommAmount = tbl[i].TotalCommAmount;

												if (TotalCommAmount) {
													grandtotalAmt = grandtotalAmt + Number(TotalCommAmount);
												} else {
													grandtotalAmt = grandtotalAmt.toString();

												}
											}
											grandtotalAmt = grandtotalAmt.toString();
											mModelSummary.setProperty("/totalLineItemAmt", grandtotalAmt);

											that.getView().getModel("mModelSummary").refresh();

										}, that);
										var fnError = jQuery.proxy(function (d) {

											var r = JSON.parse(JSON.stringify(d));

										}, that);

										var sPath = "/RRF_Line_itemSet(CompanyCode='" + CompanyCode + "',RrfNo='" + RrfNo +
											"',RequestingMf='" + sData.RequestingMf + "',MemberFirm='" + sData.MemberFirm + "',ProcessGrp='" + sData.ProcessGrp +
											"',GlobalCc='" + sData.GlobalCc +
											"',CcShortDesc='" + sData.CcShortDesc + "')";
										var oObject = {};
										oObject.success = fnSuccess;
										oObject.error = fnError;
										oObject.sPath = sPath;
										oObject.groupId = "DeleteRow";
										that.deleteRecord(oObject);
										that._submitBatchOperationTest("DeleteRow", fnSuccess, fnError);
									} else {

										var x = event.getBindingContext("mModelSummary").getPath();
										var y = x.split("/");
										var z = y[3];
										z = parseInt(z);
										var s = event.getBindingContext("mModelSummary").getProperty("/TableItemSet");
										for (var i = 0; i < s.results.length; i++) {
											if (i === z) {
												(s.results).splice(z, 1);
												that.getView().getModel("mModelSummary").refresh();
											}
										}
									}
								}
							}
						}
					);
				} else {
					if (sDeleteData.RequestingMf !== "N/A" && sDeleteData.GlobalCc === "N/A") {
						MessageBox.alert(
							"Requesting country: " + sDeleteData.RequestingMf + " Member Firm :" + sDeleteData.MemberFirm + " and Processing group: " +
							sDeleteData.ProcessGrp +
							" line cannot be deleted as the line status is : " + sDeleteData.RrfStatus + " .", {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}
						);

					} else {
						MessageBox.alert(
							"Global CC : " + sDeleteData.GlobalCc + " line cannot be deleted as line status is : " + sDeleteData.RrfStatus + " .", {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}
						);
					}
				}
			} /*Added by Saptarshi on 22-Nov-2019*/
		},

		handleLineItem: function (oEvent) {
			var mModelSummary = this.getView().getModel("mModelSummary");
			var questionFlag = true;
			this.getView().getModel("mModelSummary").setProperty("/copPoLineItemSet", []);
			mModelSummary.getProperty("/questionSet", []);
			mModelSummary.getProperty("/firstQuestionSet", []);
			var oModelAttachmentsLast = this.getView().getModel("mModelSummary").getProperty("/FileNameSet");
			if (oModelAttachmentsLast) {
				this.getView().getModel("mModelSummary").setProperty("/FileNameSet", null);
			}
			/*Start of change on 18-Feb-2020*/
			var oModelLoaAttach = this.getView().getModel("mModelSummary").getProperty("/FileNameLoaSet");
			if (oModelLoaAttach) {
				this.getView().getModel("mModelSummary").setProperty("/FileNameLoaSet", null);
			}

			/*End of change on 18-Feb-2020*/
			var sTableRowItem = oEvent.getSource().getBindingContext("mModelSummary").getObject();
			var displayMode = this.getModel("mModelSummary").getProperty("/displayMode");
			if (sTableRowItem.GpFiscalYear === "0000") {
				sTableRowItem.GpFiscalYear = "";
			}

			//code added for cop decline validation message 28.12.2020
			// if(sTableRowItem.RrfStatus==="COPDeclined"){
			//   	var oBjectDCline={};
			//   	if(sTableRowItem.RrfStatus)
			//  	oBjectDCline.ContactPersonCoP=sTableRowItem.ContactPCop;
			//  	oBjectDCline.ContactPersonCoPEmail=sTableRowItem.CopEmailId;
			//  	mModelSummary.setProperty("/copDeclineSetPO",oBjectDCline);

			// }

			var oTooltipText = this.getModel("i18n").getProperty("supplierToolTip");
			this.getView().getModel("mModelSummary").setProperty("/SelcKeySet", sTableRowItem.RequestingMf);
			// mModelSummary.setProperty("/SelcKeySet", sTableRowItem.RequestingMf);
			mModelSummary.setProperty("/SelcKeySetLocServ", sTableRowItem.LocationOfTheServicesReq); /*Added on 28-Jan-2020*/
			mModelSummary.setProperty("/updateRowData", sTableRowItem);
			mModelSummary.setProperty("/oEditable/attchmentExpnded", false);
			mModelSummary.setProperty("/oEditable/editMode", false);
			mModelSummary.setProperty("/DeleteCommercialRow", "");

			/*Start of change by Saptarshi on 20-Nov-2019*/
			// if (sTableRowItem.EditReqMf === true) {
			// 	this.getModel("mModelSummary").setProperty("/oEditable/editMode", false);
			// } else {
			// 	this.getModel("mModelSummary").setProperty("/oEditable/editMode", true);
			// }
			/*End of change by Saptarshi on 20-Nov-2019*/
			var oLineItemfrg = this.getView().createId("fragmentId");

			if (!this.oLineItemfrg) {
				this.oLineItemfrg = sap.ui.xmlfragment(oLineItemfrg, "kgo.ARRecharge.view.createLineItem", this);
				this.getView().addDependent(this.oLineItemfrg);
			}
			if (this.oLineItemfrg.isOpen()) {
				this.oLineItemfrg.close();
			} else {

				// this.handleUploadComplete();
				this.fetchAttachmentList();
				this.CreateRowForComerSection();
				this.byId(sap.ui.core.Fragment.createId(oLineItemfrg, "commercialPanelId")).oIconCollapsed.setAggregation("tooltip",
					oTooltipText);
				sap.ui.core.Fragment.byId(oLineItemfrg, "updateCooID").setEnabled(false);
				//DatePickerFieldDisable Typing
				var oDatePicker = this.byId(sap.ui.core.Fragment.createId(oLineItemfrg, "comercialDatePickerId"));
				oDatePicker.addEventDelegate({
					onAfterRendering: function () {
						var oDateInner = this.$().find('.sapMInputBaseInner');
						var oID = oDateInner[0].id;
						$('#' + oID).attr("disabled", "disabled");
					}
				}, oDatePicker);

				var oDatePicker = this.byId(sap.ui.core.Fragment.createId(oLineItemfrg, "PoendDate"));
				oDatePicker.addEventDelegate({
					onAfterRendering: function () {
						var oDateInner = this.$().find('.sapMInputBaseInner');
						var oID = oDateInner[0].id;
						$('#' + oID).attr("disabled", "disabled");
					}
				}, oDatePicker);

				var oWhTaxCombo = this.byId(sap.ui.core.Fragment.createId(oLineItemfrg, "WhTaxCombo"));
				oWhTaxCombo.addEventDelegate({
					onAfterRendering: function () {
						var oDateInner = this.$().find('.sapMInputBaseInner');
						var oID = oDateInner[0].id;
						$('#' + oID).attr("disabled", "disabled");
					}
				}, oWhTaxCombo);

				// var oDatePicker = this.byId(sap.ui.core.Fragment.createId(oLineItemfrg, "thirdPartyDateForGF"));
				// oDatePicker.addEventDelegate({
				// 	onAfterRendering: function () {
				// 		var oDateInner = this.$().find('.sapMInputBaseInner');
				// 		var oID = oDateInner[0].id;
				// 		$('#' + oID).attr("disabled", "disabled");
				// 	}
				// }, oDatePicker);

				// var oDatePicker = this.byId(sap.ui.core.Fragment.createId(oLineItemfrg, "thirdPartyDateId"));
				// oDatePicker.addEventDelegate({
				// 	onAfterRendering: function () {
				// 		var oDateInner = this.$().find('.sapMInputBaseInner');
				// 		var oID = oDateInner[0].id;
				// 		$('#' + oID).attr("disabled", "disabled");
				// 	}
				// }, oDatePicker);

				//date Picker
				var oDatePicker = this.byId(sap.ui.core.Fragment.createId(oLineItemfrg, "lastservdate"));
				oDatePicker.addEventDelegate({
					onAfterRendering: function () {
						var oDateInner = this.$().find('.sapMInputBaseInner');
						var oID = oDateInner[0].id;
						$('#' + oID).attr("disabled", "disabled");
					}
				}, oDatePicker);

				if (sTableRowItem.CopYesDate === "00000000") {
					mModelSummary.setProperty("/updateRowData/CopYesDate", "");
				}

				var fiscalDate = this.byId(sap.ui.core.Fragment.createId(oLineItemfrg, "fiscalYear"));
				fiscalDate.addEventDelegate({
					onAfterRendering: function () {
						var oYear = this.$().find('.sapMInputBaseInner');
						var oID = oYear[0].id;
						$('#' + oID).attr("disabled", "disabled");
					}
				}, fiscalDate);

				// var oDatePicker = this.byId(sap.ui.core.Fragment.createId(oLineItemfrg, "lastServForGf"));
				// oDatePicker.addEventDelegate({
				// 	onAfterRendering: function () {
				// 		var oDateInner = this.$().find('.sapMInputBaseInner');
				// 		var oID = oDateInner[0].id;
				// 		$('#' + oID).attr("disabled", "disabled");
				// 	}
				// }, oDatePicker);

				var oQdropDown = this.byId(sap.ui.core.Fragment.createId(oLineItemfrg, "comboIdTable1"));
				oQdropDown.addEventDelegate({
					onAfterRendering: function () {
						var oQdropDown = this.$().find('.sapMInputBaseInner');
						var oID = oQdropDown[0].id;
						$('#' + oID).attr("disabled", "disabled");
					}
				}, oQdropDown);

				var oNatureField = this.byId(sap.ui.core.Fragment.createId(oLineItemfrg, "natureField"));
				oNatureField.addEventDelegate({
					onAfterRendering: function () {
						oNatureField.$().find("input").attr("readonly", true);
					}
				});

				/*Start of change for defect 63871 on 19-March-2021 by developer Satabdi Das*/
				var oReqCountry = this.byId(sap.ui.core.Fragment.createId(oLineItemfrg, "contryDrdwId"));
				oReqCountry.addEventDelegate({
					onAfterRendering: function () {
						var oReqCountryInner = this.$().find('.sapMInputBaseInner');
						var oID = oReqCountryInner[0].id;
						$('#' + oID).attr("disabled", "disabled");
					}
				}, oReqCountry);
				/*End of change for defect 63871 on 19-March-2021 by developer Satabdi Das*/

				this.oLineItemfrg.open();

				var oQdropDown = this.byId(sap.ui.core.Fragment.createId(oLineItemfrg, "comboIdTable"));
				oQdropDown.addEventDelegate({
					onAfterRendering: function () {
						var oQdropDown = this.$().find('.sapMInputBaseInner');
						var oID = oQdropDown[0].id;
						$('#' + oID).attr("disabled", "disabled");
					}
				}, oQdropDown);

				// var oQdropDown = this.byId(sap.ui.core.Fragment.createId(oLineItemfrg, "comboIdTable"));
				// if (oQdropDown) {
				// 	var oDroD = oQdropDown.getDomRef();
				// 	if (oDroD) {
				// 		oDroD.$().find("input").attr("readonly", true);
				// 	}
				// }

				// if (sap.m.ComboBox.prototype.onAfterRendering) {
				// 	sap.m.ComboBox.prototype.onAfterRendering.apply(this);
				// }
				// this.byId(sap.ui.core.Fragment.createId(oLineItemfrg, "comboIdTable")).disabled = true;

				/*Start of change on 21-Feb-2020*/
				var newEntry = sTableRowItem.NewEntity;
				var oCheckBox = this.byId(sap.ui.core.Fragment.createId(oLineItemfrg, "NewEntityCoupa"));
				if (oCheckBox) {
					if (newEntry === "") {
						oCheckBox.setSelected(false);
						mModelSummary.setProperty("/oEditable/entityAddress", true);
						mModelSummary.setProperty("/oEditable/entityName", false);
					}
					if (newEntry === "X") {
						oCheckBox.setSelected(true);
						mModelSummary.setProperty("/oEditable/entityAddress", false);
						mModelSummary.setProperty("/oEditable/entityName", true);
					}
					if (displayMode === true) {
						mModelSummary.setProperty("/oEditable/entityName", false);
					}

				}
				/*End of change on 21-Feb-2020*/
				//updateSignatory changes 13.4.22
				if (sTableRowItem.LoaChanged === "X") {
					this.byId(sap.ui.core.Fragment.createId(oLineItemfrg, "UpdateAuthId")).setSelected(true);
				} else {
					this.byId(sap.ui.core.Fragment.createId(oLineItemfrg, "UpdateAuthId")).setSelected(false);
				}
				//end of changes

				sap.ui.core.Fragment.byId(oLineItemfrg, "idselectokForedit").setVisible(true);

				if (sTableRowItem.GlobalCc === "N/A") {

					var oGpdetailDropDown = this.byId(sap.ui.core.Fragment.createId(oLineItemfrg, "commitmentDrp"));
					if (oGpdetailDropDown) {
						var Gpdrpdwn = oGpdetailDropDown.getDomRef();
						if (Gpdrpdwn) {
							//Gpdrpdwn.firstElementChild.setAttribute("readonly", true);
							Gpdrpdwn.firstElementChild.firstChild.setAttribute("readonly", true);
						}
					}

					if (displayMode === true) {
						mModelSummary.setProperty("/oEditable/gpDetailEdit", false);
						if (sTableRowItem.NatureOfService === "Adhoc/One-Off") {
							mModelSummary.setProperty("/oEditable/lastsrvDate", false);
							mModelSummary.setProperty("/oEditable/lastDateOfServLabel", true);

						} else {
							mModelSummary.setProperty("/oEditable/lastsrvDate", false);
							mModelSummary.setProperty("/oEditable/lastDateOfServLabel", false);

						}
					}
					if (displayMode === false) {
						mModelSummary.setProperty("/oEditable/gpDetailEdit", true);
						if (sTableRowItem.NatureOfService === "Adhoc/One-Off") {
							mModelSummary.setProperty("/oEditable/lastsrvDate", true);
							mModelSummary.setProperty("/oEditable/lastDateOfServLabel", true);
						} else {
							this.getView().getModel("mModelSummary").setProperty("/oEditable/lastsrvDate", false);
							mModelSummary.setProperty("/oEditable/lastDateOfServLabel", false);
						}
					}
					//Questionnaire changes 15.03.2021
					var oAnswer = this.getModel("mModelSummary").getProperty("/questionSetSubmit");
					var oAnswerShow = [];
					var _fFirstLineData = [];
					for (var t = 0; t < oAnswer.length; t++) {
						if (oAnswer[t].RequestingMf === sTableRowItem.RequestingMf && oAnswer[t].MemberFirm === sTableRowItem.MemberFirm && oAnswer[t]
							.ProcessGrp ===
							sTableRowItem.ProcessGrp) {
							var object = {};
							object.LineNo = oAnswer[t].LineNo;
							object.CompanyCode = oAnswer[t].CompanyCode;
							object.Mandatory = oAnswer[t].Mandatory;
							object.MemberFirm = oAnswer[t].MemberFirm;
							object.Question = oAnswer[t].Question;
							object.AnswerDesc = oAnswer[t].AnswerDesc;
							object.Answer = oAnswer[t].Answer;
							object.InternalExternal = oAnswer[t].InternalExternal;
							object.RequestingMf = oAnswer[t].RequestingMf;
							object.ProcessGrp = sTableRowItem.ProcessGrp;
							if (object.Question === "Nature of Supplier") {
								_fFirstLineData.push(object);
							} else {
								oAnswerShow.push(object);
							}

						}
					}
					mModelSummary.setProperty("/questionSet", oAnswerShow);
					mModelSummary.setProperty("/firstQuestionSet", _fFirstLineData);

					var tbl = sap.ui.core.Fragment.byId(oLineItemfrg, "QuestionTable2");
					var firstQtable = sap.ui.core.Fragment.byId(oLineItemfrg, "QuestionTable1");

					if (_fFirstLineData.length > 0) {
						if (sTableRowItem.RrfStatus === "COPInitiated" || sTableRowItem.RrfStatus === "COPConfirmed" || sTableRowItem.RrfStatus ===
							"LOAInitiated" || sTableRowItem.RrfStatus === "LOAConfirmed " || displayMode === true) {
							firstQtable.getAggregation("items")[0].getCells()[2].setProperty("editable", false);
						} else {
							firstQtable.getAggregation("items")[0].getCells()[2].setProperty("editable", true);
							if (displayMode === true) {
								firstQtable.getAggregation("items")[0].getCells()[2].setProperty("editable", false);
							}
						}

					}
					if (oAnswerShow.length > 0) {
						mModelSummary.setProperty("/oEditable/questionPnVisiblePO", true);
						for (var j = 0; j < oAnswerShow.length; j++) {
							if (oAnswerShow[j].Answer !== "N/A") {
								tbl.getAggregation("items")[j].getCells()[3].setProperty("visible", true);
								if (sTableRowItem.RrfStatus === "COPInitiated" || sTableRowItem.RrfStatus === "COPConfirmed" || sTableRowItem.RrfStatus ===
									"LOAInitiated" || sTableRowItem.RrfStatus === "LOAConfirmed " || displayMode === true) {
									tbl.getAggregation("items")[j].getCells()[3].setProperty("editable", false);
									tbl.getAggregation("items")[j].getCells()[2].setProperty("editable", false);

								} else {
									tbl.getAggregation("items")[j].getCells()[3].setProperty("editable", true);
									tbl.getAggregation("items")[j].getCells()[2].setProperty("editable", true);

								}
							} else {
								tbl.getAggregation("items")[j].getCells()[3].setProperty("visible", false);
								tbl.getAggregation("items")[j].getCells()[2].setProperty("editable", false);

								if (mModelSummary.getProperty("/firstQuestionSet")[0].Answer === "Service from external supplier") {

									if (oAnswerShow[j].InternalExternal === "EXTERNAL") {
										tbl.getAggregation("items")[j].getCells()[2].setProperty("editable", true);
									}
									if (oAnswerShow[j].InternalExternal === "INTERNAL") {
										tbl.getAggregation("items")[j].getCells()[2].setProperty("editable", false);
									}
								}

								if (mModelSummary.getProperty("/firstQuestionSet")[0].Answer === "Service from KPMGI") {

									if (oAnswerShow[j].InternalExternal === "INTERNAL") {
										tbl.getAggregation("items")[j].getCells()[2].setProperty("editable", true);
									}

									if (oAnswerShow[j].InternalExternal === "EXTERNAL") {
										tbl.getAggregation("items")[j].getCells()[2].setProperty("editable", false);
									}

								}
								if (sTableRowItem.RrfStatus === "COPInitiated" || sTableRowItem.RrfStatus === "COPConfirmed" || displayMode === true) {
									tbl.getAggregation("items")[j].getCells()[2].setProperty("editable", false);

								}
							}
						}
					} else {
						mModelSummary.setProperty("/oEditable/questionPnVisiblePO", false);
					}

					//end of questionnaire chnges

					var avlueText = this.getModel("i18n").getProperty("editMemberFirm");
					mModelSummary.setProperty("/setLineItemText", avlueText);
					mModelSummary.setProperty("/oEditable/rmdropDown", false);
					mModelSummary.setProperty("/oEditable/requMfvisible", true);
					mModelSummary.setProperty("/TextForLineItemEmailSrch", avlueText);
					mModelSummary.setProperty("/SelcKeySet", sTableRowItem.RequestingMf);
					var sPanelName = this.getModel("i18n").getProperty("MemberfirmSec");
					mModelSummary.setProperty("/setPanelText", sPanelName);
					// sap.ui.core.Fragment.byId(oLineItemfrg, "contryDrdwId").setVisible(true);

					mModelSummary.setProperty("/oEditable/rmdropDown", false);
					mModelSummary.setProperty("/oEditable/requMfvisible", true);
					sap.ui.core.Fragment.byId(oLineItemfrg, "contrylebelId").setVisible(true);
					sap.ui.core.Fragment.byId(oLineItemfrg, "descriptionForMF").setVisible(true);
					sap.ui.core.Fragment.byId(oLineItemfrg, "descriptionGF").setVisible(false);
					this.getView().getModel("mModelSummary").setProperty("/oEditable/additionalFieldBrf", true);
					sap.ui.core.Fragment.byId(oLineItemfrg, "globalcostcenterId").setVisible(false);
					sap.ui.core.Fragment.byId(oLineItemfrg, "GlobalCC").setVisible(false);
					this.getView().getModel("mModelSummary").setProperty("/oEditable/visibleforGF", false);
					this.getView().getModel("mModelSummary").setProperty("/oEditable/visibleforMF", true);
					sap.ui.core.Fragment.byId(oLineItemfrg, "ContactPersonLOAId").setEditable(false);

				} else
				if (sTableRowItem.RequestingMf === "N/A") {

					// var oNatureField = this.byId(sap.ui.core.Fragment.createId(oLineItemfrg, "natureFieldGF"));
					// if (oNatureField) {
					// 	var objNature = oNatureField.getDomRef();
					// 	if (objNature) {
					// 		objNature.firstElementChild.setAttribute("readonly", true);
					// 	}
					// }
					avlueText = this.getModel("i18n").getProperty("EditGlobalFunction");
					this.getView().getModel("mModelSummary").setProperty("/setLineItemText", avlueText);
					this.getView().getModel("mModelSummary").setProperty("/TextForLineItemEmailSrch", avlueText);
					var sPanelName1 = this.getModel("i18n").getProperty("GFSEC");
					mModelSummary.setProperty("/setPanelText", sPanelName1);
					sap.ui.core.Fragment.byId(oLineItemfrg, "globalcostcenterId").setVisible(true);
					sap.ui.core.Fragment.byId(oLineItemfrg, "GlobalCC").setVisible(true);
					mModelSummary.setProperty("/TotalCSAmt", sTableRowItem.TotalCommAmount); /*Added for SCTASK1855604 - budget approvers by developer Satabdi Das on 19-May-2021*/
					// sap.ui.core.Fragment.byId(oLineItemfrg, "contryDrdwId").setVisible(false);
					mModelSummary.setProperty("/oEditable/rmdropDown", false);
					mModelSummary.setProperty("/oEditable/requMfvisible", false);
					sap.ui.core.Fragment.byId(oLineItemfrg, "contrylebelId").setVisible(false);
					sap.ui.core.Fragment.byId(oLineItemfrg, "descriptionForMF").setVisible(false);
					sap.ui.core.Fragment.byId(oLineItemfrg, "descriptionGF").setVisible(true);
					mModelSummary.setProperty("/oEditable/questionPnVisiblePO", false);
					mModelSummary.setProperty("/oEditable/visibleforGF", true);
					mModelSummary.setProperty("/oEditable/visibleforMF", true);
					mModelSummary.setProperty("/oEditable/additionalFieldBrf", false);
					sap.ui.core.Fragment.byId(oLineItemfrg, "ContactPersonLOAId").setEditable(false);
					if (displayMode === true) {
						sap.ui.core.Fragment.byId(oLineItemfrg, "ContactPersonLOAId").setEditable(false);
						if (sTableRowItem.NatureOfService === "Adhoc/One-Off") {
							mModelSummary.setProperty("/oEditable/lastsrvDate", false);
							mModelSummary.setProperty("/oEditable/lastDateOfServLabel", true);
						} else {
							mModelSummary.setProperty("/oEditable/lastsrvDate", false);
							mModelSummary.setProperty("/oEditable/lastDateOfServLabel", false);
						}

					} else {
						if (sTableRowItem.NatureOfService === "Adhoc/One-Off") {
							mModelSummary.setProperty("/oEditable/lastsrvDate", true);
							mModelSummary.setProperty("/oEditable/lastDateOfServLabel", true);
						} else {
							mModelSummary.setProperty("/oEditable/lastsrvDate", false);
							mModelSummary.setProperty("/oEditable/lastDateOfServLabel", false);
						}
					}

				}
				if (sTableRowItem.RrfStatus === "COPInitiated" && displayMode === false) {
					mModelSummary.setProperty("/oEditable/reSetButtonEnable", true);
				} else {
					mModelSummary.setProperty("/oEditable/reSetButtonEnable", false);
				}

				if (displayMode === false) {

					switch (sTableRowItem.RrfStatus) {
					case "RRF Initiated":
						mModelSummary.setProperty("/oEditable/editLineItemCop", true);
						mModelSummary.setProperty("/oEditable/editLineItemMF", true);
						sap.ui.core.Fragment.byId(oLineItemfrg, "ContactPersonLOAId").setEditable(true); /* CR  Changed On 26-Aug-2021 By Prashant and Chhanda*/
						break;

					case "COP Changed":
						mModelSummary.setProperty("/oEditable/editLineItemCop", true);
						sap.ui.core.Fragment.byId(oLineItemfrg, "ContactPersonLOAId").setEditable(true); /* CR  Changed On 26-Aug-2021 By Prashant and Chhanda*/

					case "COPDeclined":
						mModelSummary.setProperty("/oEditable/editLineItemCop", true);
						mModelSummary.setProperty("/oEditable/editLineItemMF", true);
						mModelSummary.setProperty("/oEditable/editLineItemLOA", true);
						sap.ui.core.Fragment.byId(oLineItemfrg, "ContactPersonLOAId").setEditable(true); /* CR  Changed On 26-Aug-2021 By Prashant and Chhanda*/

						break;
					case "COPInitiated":
						mModelSummary.setProperty("/oEditable/editLineItemCop", false);
						mModelSummary.setProperty("/oEditable/editLineItemMF", true);
						mModelSummary.setProperty("/oEditable/editLineItemLOA", true);
						sap.ui.core.Fragment.byId(oLineItemfrg, "ContactPersonLOAId").setEditable(false);

						break;

					case "COPConfirmed":
						mModelSummary.setProperty("/oEditable/editLineItemCop", false);
						mModelSummary.setProperty("/oEditable/editLineItemMF", false);
						mModelSummary.setProperty("/oEditable/editLineItemLOA", true);
						mModelSummary.setProperty("/oEditable/checkBox", false);
						sap.ui.core.Fragment.byId(oLineItemfrg, "ContactPersonLOAId").setEditable(false);
						if (sTableRowItem.GlobalCc === "N/A" && sTableRowItem.RequestingMf !== "N/A") {
							if (sTableRowItem.NewEntity === "X" || sTableRowItem.LoaChanged === "X") {
								sap.ui.core.Fragment.byId(oLineItemfrg, "updateCooID").setEnabled(true);

							}

						}

						break;
					case "LOAInitiated":
						mModelSummary.setProperty("/oEditable/editLineItemCop", false);
						mModelSummary.setProperty("/oEditable/editLineItemMF", false);
						mModelSummary.setProperty("/oEditable/editLineItemLOA", false);
						mModelSummary.setProperty("/oEditable/checkBox", false);
						sap.ui.core.Fragment.byId(oLineItemfrg, "ContactPersonLOAId").setEditable(false);
						mModelSummary.setProperty("/oEditable/lastsrvDate", false);

						break;
					case "LOAConfirmed":
						mModelSummary.setProperty("/oEditable/editLineItemCop", false);
						mModelSummary.setProperty("/oEditable/editLineItemMF", false);
						mModelSummary.setProperty("/oEditable/editLineItemLOA", false);
						mModelSummary.setProperty("/oEditable/checkBox", false);
						sap.ui.core.Fragment.byId(oLineItemfrg, "ContactPersonLOAId").setEditable(false);
						mModelSummary.setProperty("/oEditable/lastsrvDate", false);

						break;

					}

					if (!sTableRowItem.RrfStatus) {
						//	sap.ui.core.Fragment.byId(oLineItemfrg, "ContactPersonLOAId").setEditable(true); /* CR  Changed On 26-Aug-2021 By Prashant and Chhanda*/
					}
				}

				if (sTableRowItem.RequestingMf === "N/A") {
					sap.ui.core.Fragment.byId(oLineItemfrg, "ContactPersonLOAId").setEditable(false);
				}

				sap.ui.core.Fragment.byId(oLineItemfrg, "idselectok").setVisible(false);

			}

		},
		//changes for COP REset new CR on 13.08.2021
		OnResetPress: function (oEvent) {
			var mModelSummary = this.getView().getModel("mModelSummary");
			var oPressReSetButtonPress = true;
			this.oRestVal = oPressReSetButtonPress;
			mModelSummary.setProperty("/oEditable/editLineItemCop", true);
			var oLineItemfrg = this.getView().createId("fragmentId");
			//sap.ui.core.Fragment.byId(oLineItemfrg, "ContactPersonLOAId").setEditable(true);
			mModelSummary.setProperty("/oEditable/editLineItemCop", true);
			var updateRowData = mModelSummary.getProperty("/updateRowData");
			var tempArr = jQuery.extend({}, updateRowData);
			mModelSummary.setProperty("/updateRowData_Old", tempArr);

			// mModelSummary.setProperty("/updateRowData/ConfYn_old", mModelSummary.getProperty("/updateRowData/ConfYn"));
			// mModelSummary.setProperty("/updateRowData/CopYesDate_old", mModelSummary.getProperty("/updateRowData/CopYesDate"));
			// mModelSummary.setProperty("/updateRowData/ServNowCop_old", mModelSummary.getProperty("/updateRowData/ServNowCop"));
			// mModelSummary.setProperty("/updateRowData/ServNowStatus_old", mModelSummary.getProperty("/updateRowData/ServNowStatus"));
			mModelSummary.setProperty("/updateRowData/ConfYn", "");
			mModelSummary.setProperty("/updateRowData/CopYesDate", "");
			mModelSummary.setProperty("/updateRowData/ServNowCop", "");
			mModelSummary.setProperty("/updateRowData/ServNowStatus", "");
			mModelSummary.setProperty("/updateRowData/SnowNoLoa", "");

		},

		handlePressLinkOKofLineItem: function (oEvent) {
			var mModelSummary = this.getView().getModel("mModelSummary");
			mModelSummary.setProperty("/copPoLineItemSet", []);
			mModelSummary.setProperty("/oEditable/attchmentExpnded", false);
			var displayMode = this.getModel("mModelSummary").getProperty("/displayMode"); /*Added by Saptarshi on 22-Nov-2019*/
			var oValue = this.getModel("mModelSummary").getProperty("/oLinePoTableSet");

			var ovalue2 = this.getModel("mModelSummary").getProperty("/copPoTableSet");
			var arreyTemp = mModelSummary.getProperty("/oLinePoTableSetTemp");
			if (arreyTemp.length > 0) {
				for (var temp = 0; temp < arreyTemp.length; temp++) {
					var objectTemp = {};
					objectTemp.PoStartDate = arreyTemp[temp].PoStartDate;
					objectTemp.PoEndDate = arreyTemp[temp].PoEndDate;
					objectTemp.PoYear = arreyTemp[temp].PoYear;
					objectTemp.PoAmount = arreyTemp[temp].PoAmount;
					objectTemp.SrvChrg = arreyTemp[temp].SrvChrg;
					objectTemp.OutlineText = arreyTemp[temp].OutlineText;
					objectTemp.RrfNo = arreyTemp[temp].RrfNo;
					objectTemp.CompanyCode = arreyTemp[temp].CompanyCode;
					objectTemp.CoupaContractNo = arreyTemp[temp].CoupaRequisitionNumber;
					objectTemp.RequestingMf = arreyTemp[temp].RequestingMf;
					objectTemp.MemberFirm = arreyTemp[temp].MemberFirm;
					objectTemp.CcShortDesc = arreyTemp[temp].CcShortDesc;
					objectTemp.GlobalCc = arreyTemp[temp].GlobalCc;
					objectTemp.ProcessGrp = arreyTemp[temp].ProcessGrp;
					objectTemp.SerialNo = arreyTemp[temp].SerialNo;
					mModelSummary.getProperty("/oLinePoTableSet").push(objectTemp);
				}
			}
			mModelSummary.setProperty("/oLinePoTableSetTemp", []);

			if (ovalue2.length > 0) {
				var i = 0;
				var totalAmt = 0;
				while (i < ovalue2.length) {
					if (ovalue2[i].SrvChrg) {
						totalAmt = totalAmt + Number(ovalue2[i].PoAmount) + Number(ovalue2[i].SrvChrg);
					} else {
						totalAmt = totalAmt + Number(ovalue2[i].PoAmount);
					}
					i++;
				}
				totalAmt = totalAmt.toString();
			}

			//this.getModel("mModelSummary").setProperty("/copPoTableSet", oValue);
			if (displayMode === false) {
				var glcc = this.getView().getModel("mModelSummary").getProperty("/updateRowData");
				if (ovalue2.length > 0) {
					for (var k = 0; k < oValue.length; k++) {
						for (var j = 0; j < ovalue2.length; j++) {
							if ((oValue[k].RequestingMf === ovalue2[j].RequestingMf) && (oValue[k].ProcessGrp === ovalue2[j].ProcessGrp) && (oValue[k].SerialNo ===
									ovalue2[j].SerialNo) && (oValue[k].MemberFirm === ovalue2[j].MemberFirm)) {
								oValue[k].PoStartDate = ovalue2[j].PoStartDate;
								oValue[k].PoEndDate = ovalue2[j].PoEndDate;
								oValue[k].PoAmount = ovalue2[j].PoAmount;
								oValue[k].OutlineText = ovalue2[j].OutlineText;
								oValue[k].SrvChrg = ovalue2[j].SrvChrg;
							}
							if ((oValue[k].GlobalCc === ovalue2[j].GlobalCc) && (oValue[k].SerialNo === ovalue2[j].SerialNo)) {
								oValue[k].PoStartDate = ovalue2[j].PoStartDate;
								oValue[k].PoEndDate = ovalue2[j].PoEndDate;
								oValue[k].PoAmount = ovalue2[j].PoAmount;
								oValue[k].OutlineText = ovalue2[j].OutlineText;
								oValue[k].SrvChrg = ovalue2[j].SrvChrg;
							}
						}
					}
				}

				/*Added by Saptarshi on 22-Nov-2019*/
				this.getView().getModel("mModelSummary").setProperty("/TextForLineItemEmailSrch");

				glcc.TotalCommAmount = totalAmt;
				if (glcc.GlobalCc && (glcc.RequestingMf === "N/A")) {
					this.getView().getModel("mModelSummary").getProperty("/updateRowData/RequestingMf", "N/A");
					if (this.oLineItemfrg.isOpen()) {
						var tbl = this.getView().byId('tableid');
						var lLineItemTable = this.getView().getModel("mModelSummary").getProperty("/TableItemSet/results");
						for (var i = 0; i < lLineItemTable.length; i++) {
							var CopInitiate = lLineItemTable[i].CopInitiate;
							var x = tbl.getAggregation("items")[i];
							if (CopInitiate === "X") {
								x.getMultiSelectControl().setEnabled(false);
							} else {
								x.getMultiSelectControl().setEnabled(true);
							}
						}

						this.getView().getModel("mModelSummary").setProperty("/oEditable/editLineItemCop", true);
						this.getView().getModel("mModelSummary").setProperty("/oEditable/editLineItemMF", true);
						this.getView().getModel("mModelSummary").setProperty("/oEditable/editLineItemLOA", true);

						// if ((glcc.NatureOfService === "Adhoc/One-Off") && (!glcc.LastDateSrv || glcc.LastDateSrv === "00000000")) {

						// 	var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
						// 	MessageBox.alert(
						// 		"Please enter mandatory field.", {
						// 			styleClass: bCompact ? "sapUiSizeCompact" : ""
						// 		}
						// 	);
						// } 
						if (!glcc.GfLineDesc) {
							var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
							MessageBox.alert(
								"Short Description is Missing.", {
									styleClass: bCompact ? "sapUiSizeCompact" : ""
								}
							);
							return;
						}
						/*Start of change for SCTASK1855604 - budget approvers by developer Satabdi Das on 19-May-2021*/
						if (!glcc.AttenBrf || glcc.AttenBrf === "" || !glcc.AttenBrfEmail || glcc.AttenBrfEmail ===
							"") {
							var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
							var sErrorMsg = this.getView().getModel("i18n").getProperty("BAMissingErrorMsg");
							MessageBox.error(sErrorMsg, {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							});
							return;
						}
						/*End of change for SCTASK1855604 - budget approvers by developer Satabdi Das on 19-May-2021*/

						this.oLineItemfrg.close();
						sap.ui.core.BusyIndicator.hide(0);

					}
				} else {
					if (this.oLineItemfrg.isOpen()) {
						if (this.oRestVal === true) {
							mModelSummary.setProperty("/updateRowData/RrfStatus", "COP Changed");
							mModelSummary.setProperty("/updateRowData/CopInitiate", " ");
							mModelSummary.setProperty("/oEditable/enableCOP", true);
							mModelSummary.setProperty("/updateRowData/ConfYn_old", undefined);
							mModelSummary.setProperty("/updateRowData/CopYesDate_old", undefined);
							mModelSummary.setProperty("/updateRowData/ServNowCop_old", undefined);
							mModelSummary.setProperty("/updateRowData/ServNowStatus_old", undefined);
							mModelSummary.setProperty("/updateRowData_Old", undefined);
							this.oRestVal = false;
						} else {
							this.oRestVal = false;
							mModelSummary.setProperty("/updateRowData_Old", undefined);
						}
						this.getModel("mModelSummary").setProperty("/GblFuncName", false);
						var questionTable = mModelSummary.getProperty("/questionSet");
						var _firstQuestionData = mModelSummary.getProperty("/firstQuestionSet");
						var tbl = this.getView().byId('tableid');
						var lLineItemTable = this.getView().getModel("mModelSummary").getProperty("/TableItemSet/results");
						for (var i = 0; i < lLineItemTable.length; i++) {
							var CopInitiate = lLineItemTable[i].CopInitiate;
							var x = tbl.getAggregation("items")[i];
							if (CopInitiate === "X") {
								x.getMultiSelectControl().setEnabled(false);
							} else {
								x.getMultiSelectControl().setEnabled(true);
							}
						}

						if (!glcc.AddlBillInfo && !glcc.LongText) {
							var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
							MessageBox.alert(
								"Please enter mandatory field.", {
									styleClass: bCompact ? "sapUiSizeCompact" : ""
								}
							);
							return;
						}

						if (((glcc.NatureOfService === "Adhoc/One-Off") && (!glcc.LastDateSrv || glcc.LastDateSrv === "00000000"))) {

							var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
							MessageBox.alert(
								"Please enter mandatory field.", {
									styleClass: bCompact ? "sapUiSizeCompact" : ""
								}
							);
						} else {

							//questionnaire changes by prashant kumar 15.03.2020 
							if (questionTable && questionTable.length > 0) {
								var messageFlag = false;
								var submitSet = mModelSummary.getProperty("/questionSetSubmit");
								for (var i = 0; i < questionTable.length; i++) {
									for (var j = 0; j < submitSet.length; j++) {
										if (submitSet[j].RequestingMf === mModelSummary.getProperty("/questionSet")[i].RequestingMf && submitSet[j].MemberFirm ===
											mModelSummary.getProperty("/questionSet")[i].MemberFirm && submitSet[j].ProcessGrp === mModelSummary.getProperty(
												"/questionSet")[i].ProcessGrp) {
											if (mModelSummary.getProperty("/questionSet")[i].Answer === "Other" && !mModelSummary.getProperty("/questionSet")[i].AnswerDesc) {
												var messageFlag = true;
												break;
											}
											if (submitSet[j].Question === mModelSummary.getProperty("/questionSet")[i].Question) {
												mModelSummary.getProperty("/questionSetSubmit")[j].Answer = mModelSummary.getProperty("/questionSet")[i].Answer;
												mModelSummary.getProperty("/questionSetSubmit")[j].AnswerDesc = mModelSummary.getProperty("/questionSet")[i].AnswerDesc;

											}

										}
									}
								}
							}

							if (_firstQuestionData && _firstQuestionData.length > 0) {
								for (var k = 0; k < submitSet.length; k++) {
									if (submitSet[k].RequestingMf === _firstQuestionData[0].RequestingMf && submitSet[k].MemberFirm === _firstQuestionData[0].MemberFirm &&
										submitSet[k].ProcessGrp === _firstQuestionData[0].ProcessGrp) {
										if (submitSet[k].Question === _firstQuestionData[0].Question) {
											mModelSummary.getProperty("/questionSetSubmit")[k].Answer = _firstQuestionData[0].Answer;
										}

									}

								}
							}
						}

						//changes for mandatry questionnaire
						var questionMess = false;
						for (var i = 0; i < questionTable.length; i++) {
							if ((!mModelSummary.getProperty("/questionSet")[i].Answer || mModelSummary.getProperty("/questionSet")[i].Answer === " ") ||
								(!
									_firstQuestionData[0].Answer || _firstQuestionData[0].Answer === " ")) {
								questionMess = true;
								break;
							}
						}

						if (questionMess === true) {
							var questionnaDetailMissing2 = this.getModel("i18n").getProperty("questionnaDetailMissing2");
							MessageBox.alert(questionnaDetailMissing2);
							return true;
						}

						if (messageFlag === true) {
							var questionnaDetailMissing2 = this.getModel("i18n").getProperty("questionnaDetailMissing2");
							MessageBox.alert(questionnaDetailMissing2);
							return true;
						}

						this.oLineItemfrg.close();
						sap.ui.core.BusyIndicator.hide(0);
					}

					var oValue2 = this.getModel("mModelSummary").getProperty("/oLinePoTableSet");
					this.getModel("mModelSummary").setProperty("/copPoTableSet", oValue2);
					this.getView().getModel("mModelSummary").setProperty("/oEditable/editLineItemCop", true);
					this.getView().getModel("mModelSummary").setProperty("/oEditable/editLineItemMF", true);
					this.getView().getModel("mModelSummary").setProperty("/oEditable/editLineItemLOA", true);

				}
			}

			//SCTASK1886857 changes by prashant kumar 01.03.2022
			this.grandTotalLineAmount();

		},
		onLineItemCancel: function () {
			this.getView().getModel("mModelSummary").setProperty("/TextForLineItemEmailSrch");
			if (this.oLineItemfrg.isOpen()) {
				this.oLineItemfrg.close();
			}
		},
		onValidatePress: function () {
			var that = this;
			var PoNumber = this.getView().getModel("mModelSummary").getProperty("/HeaderData").PoNumber;
			var CoupaRequisitionNumber = this.getView().getModel("mModelSummary").getProperty("/HeaderData").CoupaRequisitionNumber;
			var oContext = this;
			var oObject = {};
			var oModel = this.getOwnerComponent().getModel();
			if (PoNumber && CoupaRequisitionNumber) {
				oModel.callFunction(
					"/fnPOValidate", {
						method: "GET",
						urlParameters: {
							COUREQ: CoupaRequisitionNumber,
							PONO: PoNumber

						},
						success: function (d) {
							var bCompact = !!that.getView().$().closest(".sapUiSizeCompact").length;
							MessageBox.error(
								d.Message, {
									styleClass: bCompact ? "sapUiSizeCompact" : ""
								}
							);

						},
						error: function (oError) {

						}
					});
			} else {
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				MessageBox.alert(
					"Please enter coupa requisition and PO number.", {
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					}
				);
			}
		},
		onPressGlobalCC: function (oEvent) { /*Change added by Saptarshi on 19-Nov-2019*/
			var id = oEvent.getSource().getId(); /*Change added by Saptarshi on 19-Nov-2019*/
			var mModelSummary = this.getModel("mModelSummary");
			var oCompyCode = mModelSummary.getProperty("/HeaderData").CompanyCode;

			if (oEvent.getParameter("id").split("--")[2]) {
				mModelSummary.setProperty("/ccNameSet", oEvent.getParameter("id").split("--")[2]);
			}
			if (mModelSummary.getProperty("/HeaderData/GlobalCc")) {
				var oGlobalCc = mModelSummary.getProperty("/HeaderData/GlobalCc");
			} else {
				oGlobalCc = "";
			}
			/*Start of chnage by Saptarshi on 19-Nov-2019*/
			if (id.indexOf("GlobalCC") > 0) {
				this.CCValue = "GLOBALCCCOUPA";
				this.getModel("mModelSummary").setProperty("/GblFuncName", true);
				this.getModel("mModelSummary").setProperty("/LtextSearch", false);
			} else if (id.indexOf("DebitCcCoupa") > 0) {
				this.CCValue = "DEBITCCCOUPA";
				this.getModel("mModelSummary").setProperty("/LtextSearch", false);
			} else if (id.indexOf("CreditCcCoupa") > 0) {
				this.CCValue = "CREDITCCCOUPA";
				this.getModel("mModelSummary").setProperty("/LtextSearch", false);
			} else if (id.indexOf("LtextHdr") >= 0) {
				this.getModel("mModelSummary").setProperty("/LtextSearch", true);
			} else {
				this.getModel("mModelSummary").setProperty("/LtextSearch", false);
			}
			/*End of change by Saptarshi on 19-Nov-2019*/

			var sSrchVal = oGlobalCc;
			var ostcenterDetails = mModelSummary.getProperty("/CostScnterSearchSet");
			// var fragmentId = this.getView().createId("searchCoordinator");
			sap.ui.core.BusyIndicator.show(0);

			var aFilter = [];
			var oFilterSerach;

			if (ostcenterDetails.Kostl) {
				oFilterSerach = new sap.ui.model.Filter("Kostl", sap.ui.model.FilterOperator.EQ, ostcenterDetails.Kostl);
				aFilter.push(oFilterSerach);
			}
			if (ostcenterDetails.Ltext) {
				oFilterSerach = new sap.ui.model.Filter("Ltext", sap.ui.model.FilterOperator.EQ, ostcenterDetails.Ltext);
				aFilter.push(oFilterSerach);
			}
			if (oCompyCode) {
				oFilterSerach = new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.EQ, oCompyCode);
				aFilter.push(oFilterSerach);
			}

			//aFilter.push(mModelSummary.getProperty("/CostScnterSearchSet"))

			var mArrayOut = [];
			var sPath = "";

			sPath = "/RRF_CCSet "; // + Constant.CV_PV_LEAD_FIORI;

			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);

				mModelSummary = this.getModel("mModelSummary");

				for (var i = 0; i < d.results.length; i++) {
					var oGlobalCC = {};

					oGlobalCC.Kokrs = d.results[i].Kokrs;
					oGlobalCC.Kostl = d.results[i].Kostl;
					oGlobalCC.Ltext = d.results[i].Ltext;
					oGlobalCC.Descript = d.results[i].Descript;
					mArrayOut.push(oGlobalCC);
				}
				mModelSummary.setProperty("/RRF_CCSet", mArrayOut);
				mModelSummary.refresh(true);

				var fragmentId = this.getView().createId("searchCostCenter");

				if (!this._oSeachCC) {
					this._oSeachCC = sap.ui.xmlfragment(fragmentId, "kgo.ARRecharge.view.searchHelpForCC", this);
					this.getView().addDependent(this._oSeachCC);
				}
				this.onSearchCC();
				this._oSeachCC.open();

				//HomeView

			}, this);

			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();

				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"

				});
			}, this);
			// var sParams = {};
			// var oObject = {};

			// oObject.Filter = aFilter;
			// oObject.Params = sParams;
			// oObject.successCallback = fnSuccess;
			// oObject.errorCallback = fnError;
			// oObject.sPath = sPath;
			// DataManagerARrecharge.getCoupaReqiNumberhelpValus(oObject);
			/*R&D---start*/
			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
				json: true
			});
			oModel1.read("/RRF_CCSet", {
				filters: aFilter,
				success: fnSuccess,
				error: fnError
			});
			/*R&D---end*/

		},

		onCloseSeachHelp: function () {
			// var fragId = this.getView().createId("searchCostCenter");
			// var SearchId = sap.ui.core.Fragment.byId(fragId, "searchFldCC");
			// SearchId.setValue("");
			// var aFilter = [];
			// aFilter.push(new Filter("Kostl", FilterOperator.Contains, ""));
			// var frag = this.getView().createId("searchCostCenter");
			// var table = sap.ui.core.Fragment.byId(frag, "listCostCenter");
			// var oBinding = table.getBinding("items");
			// oBinding.filter(aFilter, "Application");
			if (this._oSeachCC) {
				this._oSeachCC.close();
				this.getView().getModel("mModelSummary").setProperty("/ccNameSet");
				this.getView().getModel("mModelSummary").setProperty("/filterSearch", "");
				this.getView().getModel("mModelSummary").setProperty("/CostScnterSearchSet", []);
			}

		},

		onCostCenterPress: function (oEvent) {
			var mModelSummary = this.getView().getModel("mModelSummary");
			var costCenter = oEvent.getSource().getBindingContext("mModelSummary").getObject();
			var oCheckView = this.getView().getModel("mModelSummary").getProperty("/ccNameSet");
			mModelSummary.setProperty("/filterSearch", "");
			mModelSummary.setProperty("/CostScnterSearchSet", []);
			/*Start of change by Saptarshi on 19-Nov-2019*/
			if ((oCheckView === "rrfTablefragment") || (oCheckView === "fragmentId") || (oCheckView === "GlobalCC")) { /*Change added for INC01499658 ON 26-APR-2021*/

				mModelSummary.setProperty("/updateRowData/GlobalCc", costCenter.Kostl);
				mModelSummary.setProperty("/updateRowData/Ltext", costCenter.Ltext);
				mModelSummary.setProperty("/updateRowData/Descript", costCenter.Descript);
				/*Start of change for SCTASK1855604 - budget approvers by developer Satabdi Das on 19-May-2021*/
				if (oCheckView === "GlobalCC") {
					mModelSummary.setProperty("/updateRowData/AttenBrf", "");
					mModelSummary.setProperty("/updateRowData/AttenBrfEmail", "");
					mModelSummary.setProperty("/updateRowData/LoaContact", "");
					mModelSummary.setProperty("/updateRowData/LoaEmail", "");
				}
				/*End of change for SCTASK1855604 - budget approvers by developer Satabdi Das on 19-May-2021*/

			} else {
				mModelSummary.setProperty("/HeaderData/Kostl", costCenter.Kostl);
				mModelSummary.setProperty("/HeaderData/Ltext", costCenter.Ltext);
			}

			if (this._oSeachCC) {
				this.getView().getModel("mModelSummary").setProperty("/ccNameSet");
				this._oSeachCC.close();
			}

		},

		/*Start of change by Satabdi Das on 03-March-2021 for 63648 -restricted Cost Center*/
		onPressRestGlobalCC: function (oEvent) {
			var id = oEvent.getSource().getId();
			var mModelSummary = this.getView().getModel("mModelSummary");
			var oCompyCode = mModelSummary.getProperty("/HeaderData").CompanyCode;

			if (mModelSummary.getProperty("/HeaderData/GlobalCc")) {
				var oGlobalCc = mModelSummary.getProperty("/HeaderData/GlobalCc");
			} else {
				oGlobalCc = "";
			}

			var sSrchVal = oGlobalCc;
			var aRestCc = mModelSummary.getProperty("/RestCCSearchSet");

			sap.ui.core.BusyIndicator.show(0);

			var aFilter = [];
			var oFilterSerach;

			if (aRestCc.Kostl) {
				oFilterSerach = new Filter("Kostl", FilterOperator.EQ, aRestCc.Kostl);
				aFilter.push(oFilterSerach);
			}
			if (aRestCc.Ltext) {
				oFilterSerach = new Filter("Ltext", FilterOperator.EQ, aRestCc.Ltext);
				aFilter.push(oFilterSerach);
			}
			if (oCompyCode) {
				oFilterSerach = new Filter("Bukrs", FilterOperator.EQ, oCompyCode);
				aFilter.push(oFilterSerach);
			}

			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				mModelSummary.setProperty("/RRF_RestCCSet", d.results);
				mModelSummary.refresh(true);

				var fragmentId = this.getView().createId("RestsearchCostCenter");

				if (!this._oRestSeachCC) {
					this._oRestSeachCC = sap.ui.xmlfragment(fragmentId, "kgo.ARRecharge.view.restSearchHelpForCC", this);
					this.getView().addDependent(this._oRestSeachCC);
				}
				this._oRestSeachCC.open();
			}, this);

			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();

				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"
				});
			}, this);

			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
				json: true
			});
			oModel1.read("/RRF_RestCCSet", {
				filters: aFilter,
				success: fnSuccess,
				error: fnError
			});
		},

		onCloseRestCCHelp: function () {
			if (this._oRestSeachCC) {
				this._oRestSeachCC.close();
				this.getView().getModel("mModelSummary").setProperty("/RestCCSearchSet", []);
			}
		},

		onSelectRestCC: function (oEvent) {
			var mModelSummary = this.getView().getModel("mModelSummary");
			var costCenter = oEvent.getSource().getBindingContext("mModelSummary").getObject();
			mModelSummary.setProperty("/RestCCSearchSet", []);
			mModelSummary.setProperty("/HeaderData/Kostl", costCenter.Kostl);
			mModelSummary.setProperty("/HeaderData/Ltext", costCenter.Ltext);
			this._oRestSeachCC.close();
		},
		/*End of change by Satabdi Das on 03-March-2021 for 63648 -restricted Cost Center */

		onSuppelierHelpPress: function (oEvent) {

			var mModelSummary = this.getModel("mModelSummary");
			var oCompanyCode = mModelSummary.getProperty("/HeaderData").CompanyCode;
			if (mModelSummary.getProperty("/HeaderData")) {
				var oVendorName = mModelSummary.getProperty("/HeaderData").VendorName;
			} else {
				oVendorName = "";
			}

			var sSrchVal = oVendorName;
			// var fragmentId = this.getView().createId("searchCoordinator");
			sap.ui.core.BusyIndicator.show(0);

			//var aFilter = [];

			//var sPath = "";

			//	sPath = "/SUPP_NAMESet";

			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);

				mModelSummary.setProperty("/vendorNameSet", d.results);
				var oSupplierFragment = this.getView().createId("vendorNameFrg");

				if (!this._oSearchVendor) {
					this._oSearchVendor = sap.ui.xmlfragment(oSupplierFragment, "kgo.ARRecharge.view.supplierName", this);
					this.getView().addDependent(this._oSearchVendor);
				}

				this._oSearchVendor.open();
				this.onSearchSupplierName();

				mModelSummary.refresh(true);

			}, this);

			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();

				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"

				});
			}, this);

			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
				json: true
			});
			//changes done by prashant kumar for company code on 18.8.2020
			var aFilterStr = [];
			var oFilterSerach;
			if (oCompanyCode) {
				oFilterSerach = new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.EQ, oCompanyCode);
				aFilterStr.push(oFilterSerach);

			}

			oModel1.read("/SUPP_NAMESet", {
				filters: aFilterStr,
				success: fnSuccess,
				error: fnError
			});
			// var sParams = {};
			// var oObject = {};

			// oObject.Filter = aFilter;
			// oObject.Params = sParams;
			// oObject.successCallback = fnSuccess;
			// oObject.errorCallback = fnError;
			// oObject.sPath = sPath;
			// DataManagerARrecharge.getCompanyCodeSearchHelpValues(oObject);

		},
		onSearchSupplierName: function (oEvent) {
			var aFilter = [];
			var sQuery = this.getView().getModel("mModelSummary").getProperty("/filterSearch");
			if (sQuery) {
				sQuery = sQuery.trim();
			}

			if (sQuery && sQuery.length > 0) {
				aFilter.push(new Filter("Name1", FilterOperator.Contains, sQuery));
			}
			var fragmentId = this.getView().createId("vendorNameFrg");
			var table = sap.ui.core.Fragment.byId(fragmentId, "suppTableId");
			var oBinding = table.getBinding("items");
			oBinding.filter(aFilter, "Application");
		},

		onSupllierNameSelect: function (oEvent) {
			var oVendorValue = oEvent.getSource().getBindingContext("mModelSummary").getObject();
			this.getView().getModel("mModelSummary").setProperty("/HeaderData/VendorName", oVendorValue.Name1);
			this.getView().getModel("mModelSummary").setProperty("/HeaderData/Vendor", oVendorValue.Lifnr);
			if (this._oSearchVendor.isOpen()) {
				this._oSearchVendor.close();
				this.getView().getModel("mModelSummary").setProperty("/filterSearch", "");

			}
		},
		onCloseSupllierFragment: function (oEvent) {
			if (this._oSearchVendor.isOpen()) {
				this._oSearchVendor.close();
				this.getView().getModel("mModelSummary").setProperty("/filterSearch", "");

			}
		},

		onEnterDescInvoice: function (oEvent) {
			var mModelSummary = this.getView().getModel("mModelSummary");
			var vEnterVal = oEvent.getParameter("value");
			mModelSummary.setProperty("/updateRowData/LoaDesc", vEnterVal);
		},
		onEnterDescGF: function (oEvent) {
			var mModelSummary = this.getView().getModel("mModelSummary");
			var vEnterValGf = oEvent.getParameter("value");
			mModelSummary.setProperty("/updateRowData/LoaDesc", vEnterValGf);
		},

		onPoHeaderHelpPress: function (oEvent) {

			var mModelSummary = this.getModel("mModelSummary");

			sap.ui.core.BusyIndicator.show(0);

			// var sPath = "";

			// sPath = "/RRF_POSet";
			var oFilterData = mModelSummary.getProperty("/HeaderData"); /*Added by Satabdi Das on 13-Oct-2020 for defect 63693*/
			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);

				mModelSummary.setProperty("/RRF_POSet", d.results);
				var oPoNumberFragment = this.getView().createId("poNuberFragment");

				if (!this._oSearchPoNumber) {
					this._oSearchPoNumber = sap.ui.xmlfragment(oPoNumberFragment, "kgo.ARRecharge.view.searchHelpPo", this);
					this.getView().addDependent(this._oSearchPoNumber);
				}

				this._oSearchPoNumber.open();
				this.onSearchPoNumber();

				mModelSummary.refresh(true);

			}, this);

			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();

				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"

				});
			}, this);
			/*R&D---start*/
			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
				json: true
			});

			/*Start of change by developer Satabdi Das on 13-Oct-2020 for defect 63693*/
			var aFilter = [];
			aFilter.push(new Filter("Bukrs", FilterOperator.EQ, oFilterData.CompanyCode));
			if (oFilterData.Vendor) {
				aFilter.push(new Filter("Vendor", FilterOperator.EQ, oFilterData.Vendor));
			}
			/*End of change by developer Satabdi Das on 13-Oct-2020 for defect 63693*/

			oModel1.read("/RRF_POSet", {
				success: fnSuccess,
				filters: aFilter,
				/*Added by Satabdi Das on 13-Oct-2020 for defect 63693*/
				error: fnError
			});
			/*R&D---end*/

			// var sParams = {};
			// var oObject = {};

			// oObject.Filter = aFilter;
			// oObject.Params = sParams;
			// oObject.successCallback = fnSuccess;
			// oObject.errorCallback = fnError;
			// oObject.sPath = sPath;
			// DataManagerARrecharge.getCompanyCodeSearchHelpValues(oObject);

		},
		PoHeaderCancel: function (oEvent) {
			if (this._oSearchPoNumber) {
				this.getView().getModel("mModelSummary").setProperty("/filterSearch");
				this._oSearchPoNumber.close();
			}
		},
		onSelectPoNumber: function (oEvent) {
			var oPoNumber = oEvent.getSource().getBindingContext("mModelSummary").getObject();
			this.getView().getModel("mModelSummary").setProperty("/PoSectionSet/PoNo", oPoNumber.PoNo);

			if (this._oSearchPoNumber.isOpen()) {
				this._oSearchPoNumber.close();
				this.getView().getModel("mModelSummary").setProperty("/filterSearch", "");

			}
		},
		onSearchPoNumber: function (oEvent) {
			var aFilter = [];
			var sQuery = this.getView().getModel("mModelSummary").getProperty("/filterSearch");
			if (sQuery) {
				sQuery = sQuery.trim();
			}
			if (sQuery && sQuery.length > 0) {
				aFilter.push(new Filter("PoNo", FilterOperator.Contains, sQuery));
			}
			var fragmentId = this.getView().createId("poNuberFragment");
			var table = sap.ui.core.Fragment.byId(fragmentId, "CopaPoId");
			var oBinding = table.getBinding("items");
			oBinding.filter(aFilter, "Application");
		},

		checkContractVal: function (oEvent) {
			if (isNaN(oEvent.getParameter("value")) === true || (oEvent.getParameter("value") > 99999999999.99)) { /*Defect 63120*/
				this.getView().getModel("mModelSummary").setProperty("/HeaderData/TotalPoAmount", "");
				this.getView().getModel("mModelSummary").refresh(true);
			} else {
				var ContractVal = this.getView().getModel("mModelSummary").getProperty("/HeaderData/TotalPoAmount");
				parseFloat(ContractVal).toFixed(3);
				this.getView().getModel("mModelSummary").setProperty("/HeaderData/TotalPoAmount", ContractVal);
			}

		},
		onSelectNatureOfService: function (oEvent) {
			var mModelSummary = this.getView().getModel("mModelSummary");
			var text = oEvent.getSource().getSelectedItem().getProperty("text");

			if (text === "Continuous") {
				mModelSummary.setProperty("/oEditable/lastsrvDate", false);
				mModelSummary.setProperty("/oEditable/lastDateOfServLabel", false);
				mModelSummary.setProperty("/updateRowData/LastDateSrv", "");

			}
			if (text === "Adhoc/One-Off") {
				mModelSummary.setProperty("/oEditable/lastsrvDate", true);
				mModelSummary.setProperty("/oEditable/lastDateOfServLabel", true);
				/*Start of change by Satabdi Das on 10-Feb-2021*/
				var rrfTablefragment = this.getView().createId("rrfTablefragment");

				var oLastservdate = this.byId(sap.ui.core.Fragment.createId(rrfTablefragment, "lastservdate"));
				oLastservdate.addEventDelegate({
					onAfterRendering: function () {
						var oDateInner = this.$().find('.sapMInputBaseInner');
						var oID = oDateInner[0].id;
						$('#' + oID).attr("disabled", "disabled");
					}
				}, oLastservdate);
				// var oDatePicker1 = this.byId(sap.ui.core.Fragment.createId(rrfTablefragment, "lastservdate"));
				// jQuery.sap.delayedCall(1000, this, function () {
				// 	if (oDatePicker1) {
				// 		var objDate1 = oDatePicker1.getDomRef();
				// 		if (objDate1) {
				// 			objDate1.firstElementChild.firstChild.setAttribute("readonly", true);
				// 			objDate1.children[1].setAttribute("readonly", true);
				// 		}
				// 	}
				//});
				/*End of change by Satabdi Das on 10-Feb-2021*/
			}
		},
		onChangeNatureofService: function (oEvent) {
			var mModelSummary = this.getView().getModel("mModelSummary");
			var text = mModelSummary.getProperty("/updateRowData").NatureOfService;

			switch (text) {
			case "Continuous":
				mModelSummary.setProperty("/oEditable/lastDateOfServLabel", false);
				mModelSummary.setProperty("/oEditable/lastsrvDate", false);
				//	mModelSummary.setProperty("/updateRowData/NatureOfService", text);
				break;
			case "Adhoc/One-Off":
				//mModelSummary.setProperty("/updateRowData/NatureOfService", text);
				mModelSummary.setProperty("/oEditable/lastsrvDate", true);
				mModelSummary.setProperty("/oEditable/lastDateOfServLabel", true);
				/*Start of change by Satabdi Das on 10-Feb-2021*/
				var rrfTablefragment = this.getView().createId("rrfTablefragment");

				var oLastservdate = this.byId(sap.ui.core.Fragment.createId(rrfTablefragment, "lastservdate"));
				oLastservdate.addEventDelegate({
					onAfterRendering: function () {
						var oDateInner = this.$().find('.sapMInputBaseInner');
						var oID = oDateInner[0].id;
						$('#' + oID).attr("disabled", "disabled");
					}
				}, oLastservdate);

				// var oDatePicker1 = this.byId(sap.ui.core.Fragment.createId(rrfTablefragment, "lastservdate"));
				// jQuery.sap.delayedCall(1000, this, function () {
				// 	if (oDatePicker1) {
				// 		var objDate1 = oDatePicker1.getDomRef();
				// 		if (objDate1) {
				// 			//objDate1.firstElementChild.setAttribute("readonly", true);
				// 			objDate1.firstElementChild.firstChild.setAttribute("readonly", true);
				// 			objDate1.children[1].setAttribute("readonly", true);
				// 		}
				// 	}
				// });
				/*End of change by Satabdi Das on 10-Feb-2021*/
				break;
			}

		},

		checkContractStrtDate: function (oEvent) {
			var mModelSummary = this.getView().getModel("mModelSummary");
			var oDateFlag = false;
			jQuery.sap.delayedCall(1000, this, function () {
				var oDatePicker1 = this.getView().byId("contractStdate");
				if (oDatePicker1) {
					var objDate1 = oDatePicker1.getDomRef();
					if (objDate1) {
						objDate1.firstElementChild.firstChild.setAttribute("readonly", true);
					}
				}
			});
			var ContarctstartDate = oEvent.getParameter("value");
			var oCommericaltableData = mModelSummary.getProperty("/oLinePoTableSet");
			if (oCommericaltableData.length > 0) {
				for (var i = 0; i < oCommericaltableData.length; i++) {
					var oDateDiff = ContarctstartDate - oCommericaltableData[i].PoStartDate;
					if (oDateDiff > 0) {
						oDateFlag = true;
					}
				}
			}
			if (oDateFlag == false) {
				var ContarctEndDate = mModelSummary.getProperty("/HeaderData").ContarctEndDate;
				if (ContarctEndDate != "00000000") {
					var checkDate = ContarctEndDate - ContarctstartDate;
				}
				if (checkDate < 0) {
					var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
					MessageBox.alert(
						"Please enter valid contract start date.", {
							styleClass: bCompact ? "sapUiSizeCompact" : ""
						}
					);

					this.getView().getModel("mModelSummary").setProperty("/HeaderData/ContarctStartDate", "");
				}
			} else {
				var contractStartDatemsg = this.getModel("i18n").getProperty("contractStartDatemsg");
				MessageBox.alert(contractStartDatemsg, {
					styleClass: bCompact ? "sapUiSizeCompact" : ""
				});
				this.getView().getModel("mModelSummary").setProperty("/HeaderData/ContarctStartDate", "");
			}
		},
		onCheckContractDate: function (oEvent) {
			var mModelSummary = this.getView().getModel("mModelSummary");
			var oEndDateflag = false;
			jQuery.sap.delayedCall(1000, this, function () {
				var oDatePicker1 = this.getView().byId("contractEndDate");
				if (oDatePicker1) {
					var objDate1 = oDatePicker1.getDomRef();
					if (objDate1) {
						objDate1.firstElementChild.firstChild.setAttribute("readonly", true);
					}
				}
			});
			var ContarctEndDate = oEvent.getParameter("value");
			var oCommericaltableData = mModelSummary.getProperty("/oLinePoTableSet");
			if (oCommericaltableData.length > 0) {
				for (var i = 0; i < oCommericaltableData.length; i++) {
					var oEndDateDiff = ContarctEndDate - oCommericaltableData[i].PoEndDate;
					if (oEndDateDiff < 0) {
						oEndDateflag = true;
					}
				}
			}
			if (oEndDateflag == false) {
				var ContarctStartDate = mModelSummary.getProperty("/HeaderData").ContarctStartDate;
				var checkDate = ContarctEndDate - ContarctStartDate;
				if (checkDate < 0) {
					var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
					MessageBox.alert(
						"Please enter valid contract end date.", {
							styleClass: bCompact ? "sapUiSizeCompact" : ""
						}
					);

					this.getView().getModel("mModelSummary").setProperty("/HeaderData/ContarctEndDate", "");
				}

			} else {
				var contractEndDateMsg = this.getModel("i18n").getProperty("contractEndDateMsg");
				MessageBox.alert(contractEndDateMsg, {
					styleClass: bCompact ? "sapUiSizeCompact" : ""
				});
				this.getView().getModel("mModelSummary").setProperty("/HeaderData/ContarctEndDate", "");
			}

		},

		onEnterCop: function (oEvent) {
			var value = oEvent.getParameter("value");
			if (value === "Y" || value === "N") {
				this.getView().getModel("mModelSummary").setProperty("/updateRowData/ConfYn", value);
				this.getView().getModel("mModelSummary").refresh(true);
			} else {
				this.getView().getModel("mModelSummary").setProperty("/updateRowData/ConfYn", "");
				this.getView().getModel("mModelSummary").refresh(true);
			}
		},
		checkFlatAmt: function (oEvent) {
			var vNegativeValue = -99999999999.99;
			if (isNaN(oEvent.getParameter("value")) === true || (oEvent.getParameter("value") > 99999999999.99) || (oEvent.getParameter(
						"value") <
					vNegativeValue)) {
				this.getView().getModel("mModelSummary").setProperty("/copPoLineItemSet/PoAmount", "");
				this.getView().getModel("mModelSummary").refresh(true);
			}
		},
		onPressEnterofFlatAmt: function (oEvent) {
			var vNegativeValueLine = -99999999999.99;
			if (isNaN(oEvent.getParameter("value")) === true || (oEvent.getParameter("value") > 99999999999.99) || (oEvent.getParameter(
						"value") <
					vNegativeValueLine)) {
				this.getView().getModel("mModelSummary").setProperty("/copPoLineItemSet/PoAmount", "");
				this.getView().getModel("mModelSummary").refresh(true);
			}
		},
		onChangeFlatAmount: function (oEvent) {
			var oFlateNegative = -99999999999.99;
			if (isNaN(oEvent.getParameter("value")) === true || (oEvent.getParameter("value") > 99999999999.99) || (oEvent.getParameter(
						"value") <
					oFlateNegative)) {
				this.getView().getModel("mModelSummary").setProperty("/copPoTableSet/PoAmount", "");
				this.getView().getModel("mModelSummary").refresh(true);
			}
		},
		onChangeServiceCharge: function (oEvent) {
			var oServiceCharge = -99999999999.99;
			if (isNaN(oEvent.getParameter("value")) === true || (oEvent.getParameter("value") > 99999999999.99) || (oEvent.getParameter(
						"value") <
					oServiceCharge)) {
				this.getView().getModel("mModelSummary").setProperty("/copPoTableSet/SrvChrg", "");
				this.getView().getModel("mModelSummary").refresh(true);
			}
		},
		checkServAmt: function (oEvent) {
			var oServiceChargeLine = -99999999999.99;
			if (isNaN(oEvent.getParameter("value")) === true || (oEvent.getParameter("value") > 99999999999.99) || (oEvent.getParameter(
						"value") <
					oServiceChargeLine)) {
				this.getView().getModel("mModelSummary").setProperty("/copPoLineItemSet/SrvChrg", "");
				this.getView().getModel("mModelSummary").refresh(true);
			}
		},
		onEnterofServiceAmt: function (oEvent) {
			var servChargeN = -99999999999.99;
			if (isNaN(oEvent.getParameter("value")) === true || (oEvent.getParameter("value") > 99999999999.99) || (oEvent.getParameter(
						"value") <
					servChargeN)) {
				this.getView().getModel("mModelSummary").setProperty("/copPoLineItemSet/SrvChrg", "");
				this.getView().getModel("mModelSummary").refresh(true);
			}
		},
		checkExpand: function (oEvent) {

			if (oEvent.getParameter("expand")) {
				var CheckText = this.getView().getModel("mModelSummary").getProperty("/setLineItemText");

				var checkMandatory = this.getView().getModel("mModelSummary").getProperty("/updateRowData");
				if (CheckText === "Add Member Firm") {
					if ((!checkMandatory.RequestingMf || !checkMandatory.ProcessGrp)) {
						oEvent.getSource().setProperty("expanded", false);
						var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
						MessageBox.alert(
							"Please enter mandatory fields first ", {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}
						);

					}

				}
				if (CheckText === "Add Global Function") {
					if (!checkMandatory.GlobalCc || !checkMandatory.Ltext) {
						oEvent.getSource().setProperty("expanded", false);
						var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
						MessageBox.alert(
							"Please enter mandatory fields first ", {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}
						);

					}
				}
				oEvent.reset();
			}
		},
		onEnterLoaYnforMemberFirm: function (oEvent) {
			var value = oEvent.getParameter("value");
			if (value === "Y" || value === "N") {
				this.getView().getModel("mModelSummary").setProperty("/updateRowData/LoaYn", value);
				this.getView().getModel("mModelSummary").refresh(true);
			} else {
				this.getView().getModel("mModelSummary").setProperty("/updateRowData/LoaYn", "");
				this.getView().getModel("mModelSummary").refresh(true);
			}
		},
		onCheckBoxSelect: function (oEvent) {
			if (oEvent.getParameter("selected") === true) {
				this.getView().getModel("mModelSummary").setProperty("/oEditable/entityAddress", false);
				this.getView().getModel("mModelSummary").setProperty("/oEditable/entityName", true);
				this.getView().getModel("mModelSummary").setProperty("/updateRowData/EntityAddress", "");
				this.getView().getModel("mModelSummary").setProperty("/updateRowData/EntityName", "");
				this.getView().getModel("mModelSummary").setProperty("/updateRowData/SapCodeMf", "");
				this.getView().getModel("mModelSummary").setProperty("/updateRowData/NewEntity", "X"); /*Added on 21-Feb-2020 by Satabdi Das*/
			} else {
				this.getView().getModel("mModelSummary").setProperty("/oEditable/entityAddress", true);
				this.getView().getModel("mModelSummary").setProperty("/oEditable/entityName", false);
				this.getView().getModel("mModelSummary").setProperty("/updateRowData/EntityAddress", "");
				this.getView().getModel("mModelSummary").setProperty("/updateRowData/EntityName", "");
				this.getView().getModel("mModelSummary").setProperty("/updateRowData/SapCodeMf", "");
				this.getView().getModel("mModelSummary").setProperty("/updateRowData/NewEntity", ""); /*Added on 21-Feb-2020 by Satabdi Das*/
			}
		},

		checkWhTax: function (oEvent) {
			var value = oEvent.getParameter("value");
			if (value === "Y") {
				this.getView().getModel("mModelSummary").setProperty("/updateRowData/WhTax", value);
				this.getView().getModel("mModelSummary").setProperty("/oEditable/editPercy", true);
				this.getView().getModel("mModelSummary").refresh(true);
			} else if (value === "N") {
				this.getView().getModel("mModelSummary").setProperty("/updateRowData/WhTax", value);
				this.getView().getModel("mModelSummary").setProperty("/updateRowData/PercY", "");
				this.getView().getModel("mModelSummary").setProperty("/oEditable/editPercy", false);
			} else {
				this.getView().getModel("mModelSummary").setProperty("/updateRowData/WhTax", "");
				this.getView().getModel("mModelSummary").refresh(true);
			}
		},

		checkPercentage: function (oEvent) {

			if (isNaN(oEvent.getParameter("value")) === true || (oEvent.getParameter("value") > 100)) {
				this.getView().getModel("mModelSummary").setProperty("/updateRowData/PercY", "");
				this.getView().getModel("mModelSummary").refresh(true);
			}

		},
		/*Start of change by Saptarshi on 18-Nov-2019*/
		checkAmt: function (oEvent) {
			var rrfTablefragment = this.getView().createId("rrfTablefragment");
			if (isNaN(oEvent.getParameter("value")) === true || (oEvent.getParameter("value") > 999999999999.999)) {
				var label1 = sap.ui.core.Fragment.byId(rrfTablefragment, "AmtRecharged");
				var label2 = sap.ui.core.Fragment.byId(rrfTablefragment, "amountCredited");
				var label3 = sap.ui.core.Fragment.byId(rrfTablefragment, "amountdebited");

				label1.setValue("");
				label2.setValue("");
				label3.setValue("");

			}

		},
		/*End of change by Sapatrshi on 18-Nov-2019*/
		/*Start of change by Sapatrshi on 19-Nov-2019*/
		onSearchCC: function (oEvent) {
			var aFilter = [];
			var sQuery = this.getView().getModel("mModelSummary").getProperty("/filterSearch");
			var bLtext = this.getModel("mModelSummary").getProperty("/LtextSearch");
			if (sQuery) {
				sQuery = sQuery.trim();
			}
			if (sQuery && sQuery.length > 0 && bLtext === false) {
				aFilter.push(new Filter("Kostl", FilterOperator.Contains, sQuery));
			} else if (sQuery && sQuery.length > 0 && bLtext === true) {
				aFilter.push(new Filter("Ltext", FilterOperator.Contains, sQuery));
			}
			var fragmentId = this.getView().createId("searchCostCenter");
			var table = sap.ui.core.Fragment.byId(fragmentId, "listCostCenter");
			var oBinding = table.getBinding("items");
			oBinding.filter(aFilter, "Application");

		},
		onSearchGl: function (oEvent) {
			var aFilter = [];
			var sQuery = oEvent.getSource().getValue();
			sQuery = sQuery.trim();
			if (sQuery && sQuery.length > 0) {
				aFilter.push(new Filter("Saknr", FilterOperator.Contains, sQuery));
			}
			var fragmentId = this.getView().createId("searchGlAccount");
			var table = sap.ui.core.Fragment.byId(fragmentId, "listGlAcc");
			var oBinding = table.getBinding("items");
			oBinding.filter(aFilter, "Application");

		},
		onCloseGlHelp: function () {
			/*Start by Saptarshi on 19-Nov-2019*/
			var fragId = this.getView().createId("searchGlAccount");
			var SearchId = sap.ui.core.Fragment.byId(fragId, "searchFldGl");
			SearchId.setValue("");
			var aFilter = [];
			aFilter.push(new Filter("Saknr", FilterOperator.Contains, ""));
			var frag = this.getView().createId("searchGlAccount");
			var table = sap.ui.core.Fragment.byId(frag, "listGlAcc");
			var oBinding = table.getBinding("items");
			oBinding.filter(aFilter, "Application");
			/*End of change by Saptarshi on 19-Nov-2019*/
			if (this._oSeachGlAccount) {
				this._oSeachGlAccount.close();
			}
			/*End of change by Sapatrshi on 19-Nov-2019*/
		},

		/*Start of change by Satabdi Das on 17-Feb-2021 for SCTASK1918966*/
		handlePressTextEditor: function (oEvent) {
			var mModelSummary = this.getView().getModel("mModelSummary");
			var fragmentId = this.getView().createId("longTextFrag");
			var sValue = mModelSummary.getData().updateRowData.LongText;
			if (!this._oLongTextFrag) {
				this._oLongTextFrag = sap.ui.xmlfragment(fragmentId, "kgo.ARRecharge.view.longTextEditor", this);
				this.getView().addDependent(this._oLongTextFrag);
			}
			if (sValue && sValue !== "") {
				if (sValue.indexOf("|") >= 0) {
					/*Start of chnage for Defect 63890 on 25-03-2021*/
					// sValue = sValue.replaceAll("|", "\n");
					var sPipeline = "|";
					var sNewLine = "\n";
					sValue = sValue.split(sPipeline).join(sNewLine);
					/*End of change for defect 63890 on 25-03-2021*/
				}
				mModelSummary.setProperty("/updateRowData/LongText", sValue);
			} else {
				mModelSummary.setProperty("/updateRowData/LongText", "");
			}

			/*handle 70 character limit*/
			// var txtArealongText = sap.ui.core.Fragment.byId(fragmentId, "longText");
			// var charlimit = UIGlobal.getLongTextCharLimit();
			// txtArealongText.onkeyup = function () {
			// 	var lines = txtArealongText.getValue().split('\n');
			// 	for (var i = 0; i < lines.length; i++) {
			// 		if (lines[i].length <= charlimit) continue;
			// 		var j = 0;
			// 		var space = charlimit;
			// 		while (j++ <= charlimit) {
			// 			if (lines[i].charAt(j) === ' ') space = j;
			// 		}
			// 		lines[i + 1] = lines[i].substring(space + 1) + (lines[i + 1] || "");
			// 		lines[i] = lines[i].substring(0, space);
			// 	}
			// 	txtArealongText.setValue(lines.slice(0, 100).join('\n'));
			// };

			this._oLongTextFrag.open();
		},
		onAddingText: function (oEvent) {
			var sValue = oEvent.getParameter("value");
			var mModelSummary = this.getView().getModel("mModelSummary");
			if (sValue !== "") {
				// if (sValue.length > 70) {
				// 	var chunks = sValue.match(/.{1,70}/g);
				// 	sValue = chunks.join("\n");
				// }
				mModelSummary.setProperty("/updateRowData/LongText", sValue);
			} else {
				mModelSummary.setProperty("/updateRowData/LongText", "");
			}
		},
		longTextClose: function (oEvent) {
			var mModelSummary = this.getView().getModel("mModelSummary");
			var sValue = mModelSummary.getProperty("/updateRowData/LongText");
			this._oLongTextFrag.close();
			if (sValue.indexOf("\n") >= 0) {
				/*Start of chnage for Defect 63890 on 25-03-2021*/
				// sValue = sValue.replaceAll("\n", "|");
				var sPipeline = "|";
				var sNewLine = "\n";
				sValue = sValue.split(sNewLine).join(sPipeline);
				/*End of change for defect 63890 on 25-03-2021*/
				mModelSummary.setProperty("/updateRowData/LongText", sValue);
			}
		},
		/*End of change by Satabdi Das on 17-Feb-2021 for SCTASK1918966*/

		poSectionPress: function (oEvent) {

			// var contractno = this.getView().getModel("mModelSummary").getProperty("/HeaderData").CoupaRequisitionNumber;

			var PoFrag = this.getView().createId("PoSectionFrag");

			if (!this._oPoFrag) {
				this._oPoFrag = sap.ui.xmlfragment(PoFrag, "kgo.ARRecharge.view.PoSection", this);
				this.getView().addDependent(this._oPoFrag);
			}
			//date Picker
			var oDatePicker = this.byId(sap.ui.core.Fragment.createId(PoFrag, "poHeaderDateId"));
			oDatePicker.addEventDelegate({
				onAfterRendering: function () {
					var oDateInner = this.$().find('.sapMInputBaseInner');
					var oID = oDateInner[0].id;
					$('#' + oID).attr("disabled", "disabled");
				}
			}, oDatePicker);

			this._oPoFrag.open();

		},

		onClosePoSection: function (oEvent) {

			if (this._oPoFrag) {
				this.getView().getModel("mModelSummary").setProperty("/PoSectionSet", []);

				this._oPoFrag.close();
			}
		},

		onAddPoSectionPress: function (oEvent) {
			/*Start of change on 27-Jan-2020*/
			var displayMode = this.getModel("mModelSummary").getProperty("/displayMode");
			if (displayMode === false) {
				var poNumber;
				var obj = {};
				var flag = false;
				var mModelSummary = this.getView().getModel("mModelSummary");
				var sValue = mModelSummary.getProperty("/PoSectionSet");
				// obj.PoStartDate = sValue.PoStartDate;
				// obj.PoEndDate = sValue.PoEndDate;
				obj.PoYear = sValue.PoYear;
				obj.PoNo = sValue.PoNo;
				obj.RrfNo = this.getView().getModel("mModelSummary").getProperty("/HeaderData").RrfNo;
				obj.CompanyCode = this.getView().getModel("mModelSummary").getProperty("/HeaderData").CompanyCode;
				obj.CoupaContractNo = this.getView().getModel("mModelSummary").getProperty("/HeaderData").CoupaRequisitionNumber;
				if (obj.PoYear && obj.PoNo) {
					for (var i = 0; i < this.getView().getModel("mModelSummary").getProperty("/PoTableSet").length; i++) {
						if (obj.PoNo === this.getView().getModel("mModelSummary").getProperty("/PoTableSet")[i].PoNo) {
							flag = true;
							var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
							MessageBox.alert(
								"PO number cannot be duplicate.", {
									styleClass: bCompact ? "sapUiSizeCompact" : ""
								}
							);
							break;
						}

					}
					if (flag === false) {
						this.getView().getModel("mModelSummary").getProperty("/PoTableSet").push(obj);
						this.getView().getModel("mModelSummary").setProperty("/PoSectionSet", []);
						this.getView().getModel("mModelSummary").refresh(true);
					}

				} else {
					var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
					MessageBox.alert(
						"Please enter mandatory fields.", {
							styleClass: bCompact ? "sapUiSizeCompact" : ""
						}
					);

				}

				//below line of code added for showing po number in dash board
				var oPoHeaderTableData = mModelSummary.getProperty("/PoTableSet");
				for (var i = 0; i < oPoHeaderTableData.length; i++) {
					if (!poNumber) {
						poNumber = oPoHeaderTableData[i].PoNo;
					} else {
						poNumber = poNumber + "," + oPoHeaderTableData[i].PoNo;
					}

				}
				mModelSummary.setProperty("/HeaderData/PoDashboard", poNumber);

			} /*Added on 27-Jan-2020*/
		},

		onDeletePoHeaderRow: function (oEvent) {
			/*Start of change on 27-Jan-2020*/
			var displayMode = this.getModel("mModelSummary").getProperty("/displayMode");
			if (displayMode === false) {
				/*End of change on 27-Jan-2020*/
				var that = this;
				var mModelSummary = this.getView().getModel("mModelSummary");
				var poNumber;
				var event = oEvent.getSource();
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				MessageBox.warning(
					"Are you sure you want to delete this?", {
						actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
						styleClass: bCompact ? "sapUiSizeCompact" : "",

						onClose: function (sAction) {
							if (sAction === "OK") {
								var sData = that.getView().getModel("mModelSummary").getProperty("/PoTableSet");
								var x = event.getBindingContext("mModelSummary").getPath();
								var y = x.split("/");
								var z = y[2];
								z = parseInt(z);
								var s = event.getBindingContext("mModelSummary").getProperty("/PoTableSet");

								s.splice(z, 1);
								that.getView().getModel("mModelSummary").refresh();
								//resetting the value of PoNumber after deleting poLine
								var oPoHeaderTableData = mModelSummary.getProperty("/PoTableSet");
								for (var i = 0; i < oPoHeaderTableData.length; i++) {
									if (!poNumber) {
										poNumber = oPoHeaderTableData[i].PoNo;
									} else {
										poNumber = poNumber + "," + oPoHeaderTableData[i].PoNo;
									}

								}
								mModelSummary.setProperty("/HeaderData/PoDashboard", poNumber);

							}
						}
					}

				);
			} /*Added on 27-Jan-2020*/
		},
		onAddPressCommercialSection: function (oEvent) {
			/*Start of change on 27-Jan-2020*/
			var displayMode = this.getModel("mModelSummary").getProperty("/displayMode");
			if (displayMode === false) {
				/*End of change on 27-Jan-2020*/
				var obj = {};
				var flag = false;
				var format = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/;
				var mModelSummary = this.getView().getModel("mModelSummary");
				mModelSummary.setProperty("/TotalCSAmt", ""); /*Change added for SCTASK1855604 - budget approvers by developer Satabdi Das on 19-May-2021*/
				mModelSummary.setProperty("/updateRowData/AttenBrf", ""); /*Change added for Defect 63982 - budget approvers by developer Satabdi Das on 04-June-2021*/
				mModelSummary.setProperty("/updateRowData/AttenBrfEmail", ""); /*Change added for Defect 63982 -  budget approvers by developer Satabdi Das on 04-June-2021*/
				var sValue = this.getView().getModel("mModelSummary").getProperty("/copPoLineItemSet");
				var sHeader = this.getView().getModel("mModelSummary").getProperty("/HeaderData");
				var sUpdate = this.getView().getModel("mModelSummary").getProperty("/updateRowData");
				var sDeletedRow = mModelSummary.getProperty("/DeleteCommercialRow"); /*Added for INC01437289 on 30-March-2021*/
				var oCopPoTbl = mModelSummary.getProperty("/copPoTableSet"); /*Added for INC01437289 on 30-March-2021*/
				obj.PoStartDate = sValue.PoStartDate;
				obj.PoEndDate = sValue.PoEndDate;
				obj.PoYear = sValue.PoYear;
				obj.PoAmount = sValue.PoAmount;
				obj.SrvChrg = sValue.SrvChrg;
				obj.OutlineText = sValue.OutlineText;
				obj.RrfNo = sHeader.RrfNo;
				obj.CompanyCode = sHeader.CompanyCode;
				obj.CoupaContractNo = sHeader.CoupaRequisitionNumber;
				obj.RequestingMf = sUpdate.RequestingMf;
				obj.MemberFirm = sUpdate.MemberFirm;
				obj.CcShortDesc = "";
				obj.GlobalCc = sUpdate.GlobalCc;
				obj.ProcessGrp = sUpdate.ProcessGrp;
				var oTblBRF = this.getView().byId('tableid');
				var dupiLicateFlagCommer = false;
				var editFragmentText = "Edit Member Firm";
				//	var oEnterCheckdate = obj.PoEndDate - obj.PoStartDate;

				/*Start of change by Satabdi Das for serial number INC01437289 on 30-March-2021*/
				if (!sDeletedRow && oCopPoTbl.length === 0) {
					obj.SerialNo = "1";
				} else if (sDeletedRow && sDeletedRow !== "" && oCopPoTbl.length !== 0 && Number(sDeletedRow) >= oCopPoTbl.length) {

					for (var k = 0; k < oCopPoTbl.length; k++) {
						obj.SerialNo = oCopPoTbl[k].SerialNo;
					}
					if (obj.SerialNo < sDeletedRow) {
						obj.SerialNo = sDeletedRow;
					}

				} else if (!sDeletedRow && oCopPoTbl.length !== 0) {
					for (var k = 0; k < oCopPoTbl.length; k++) {
						obj.SerialNo = oCopPoTbl[k].SerialNo;
					}
				} else if (sDeletedRow && sDeletedRow !== "" && oCopPoTbl.length == 0) {
					var SN = Number(sDeletedRow) + 1;
					obj.SerialNo = SN.toString();
				} else {
					obj.SerialNo = mModelSummary.getProperty("/SrNo");
				}
				/*End of change by Satabdi Das for serial number INC01437289 on 30-March-2021*/

				if (obj.RequestingMf === "N/A") {
					obj.RequestingMf = "";
					obj.MemberFirm = "";
				}

				if (obj.GlobalCc === "N/A") {
					obj.GlobalCc = "";
				}

				if (mModelSummary.getProperty("/setLineItemText") !== editFragmentText && (obj.GlobalCc === "N/A" || !obj.GlobalCc)) {
					for (var k = 0; k < oTblBRF.getItems().length; k++) {
						var oTableData = oTblBRF.getBindingInfo("items").binding.oList[k];
						if (oTableData.RequestingMf === obj.RequestingMf && oTableData.MemberFirm === obj.MemberFirm && oTableData
							.ProcessGrp ===
							obj.ProcessGrp) {
							dupiLicateFlagCommer = true;
							break;
						}
					}
				}
				if (dupiLicateFlagCommer === true) {
					var duplicateMessage = this.getView().getModel("i18n").getProperty("duplicateFieldMesg");
					MessageBox.alert(duplicateMessage + obj.RequestingMf + " " + "Member Firm : " + obj.MemberFirm +
						" and Processing group: " + obj.ProcessGrp + "  already exists.");
					obj = {};
					return true;
				}
				if (format.test(obj.ProcessGrp)) {
					var specialMsg = this.getModel("i18n").getProperty("specialchMsg");
					MessageBox.error(specialMsg);
					mModelSummary.setProperty("/SelcKeySet", obj.RequestingMf);
					return true;
				}

				if (obj.GlobalCc || (obj.RequestingMf && obj.ProcessGrp && obj.MemberFirm)) {
					if (obj.PoStartDate && obj.PoEndDate && obj.PoAmount && obj.OutlineText) {
						/*	for (var i = 0; i < this.getView().getModel("mModelSummary").getProperty("/copPoTableSet").length; i++) {
								var oPoStartdateInTable = this.getView().getModel("mModelSummary").getProperty("/copPoTableSet")[i].PoStartDate;
								var oPoEnddateInTable = this.getView().getModel("mModelSummary").getProperty("/copPoTableSet")[i].PoEndDate;
								var oSrNoInTable = this.getView().getModel("mModelSummary").getProperty("/copPoTableSet")[i].SerialNo;
								
								if ((obj.SerialNo === oSrNoInTable) && (obj.PoStartDate === oPoStartdateInTable) && (obj.PoEndDate === oPoEnddateInTable)) {
									flag = true;
									var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
									MessageBox.alert(
										" Start Date and End Date already Exist Please select other date.", {
											styleClass: bCompact ? "sapUiSizeCompact" : ""
										}
									);
									break;
								}
							}*/
						// if (flag === false) {
						/*Start of change by Satabdi Das for serial number INC01437289 on 30-March-2021*/
						if (oCopPoTbl.length > 0) {
							var nNum = Number(obj.SerialNo) + 1;
							obj.SerialNo = nNum.toString();
						}
						mModelSummary.setProperty("/SrNo", obj.SerialNo);
						mModelSummary.setProperty("/DeleteCommercialRow", "");
						/*End of change by Satabdi Das for serial number INC01437289 on 30-March-2021*/
						this.getView().getModel("mModelSummary").getProperty("/copPoTableSet").push(obj);
						// var oNewVal = this.getView().getModel("mModelSummary").getProperty("/copPoTableSet");
						this.getView().getModel("mModelSummary").getProperty("/oLinePoTableSetTemp").push(obj);
						// this.getView().getModel("mModelSummary").setProperty("/oLinePoTableSet", oNewVal);
						this.getView().getModel("mModelSummary").setProperty("/copPoLineItemSet", []);
						this.getView().getModel("mModelSummary").setProperty("/SelcKeySet", obj.RequestingMf);
						this.getView().getModel("mModelSummary").setProperty("/oEditable/editMode", false);

						//this.getView().getModel("mModelSummary").refresh(true);

						// }
					} else {

						var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
						MessageBox.alert(
							"Please enter mandatory field first.", {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}
						);

					}
				} else {
					if (!obj.GlobalCc && !obj.RequestingMf && !obj.ProcessGrp && !obj.MemberFirm) {
						MessageBox.alert(
							"Please enter mandatory field first.", {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}
						);
					} else if ((!obj.GlobalCc) && (!obj.RequestingMf || !obj.ProcessGrp || !obj.MemberFirm)) {
						var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
						MessageBox.alert(
							"Requesting country , MemberFirm , Processing Group are mandatory.", {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}
						);
					} else {
						MessageBox.alert(
							"Please enter mandatory field first.", {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}
						);
					}

				}
			} /*Added on 27-Jan-2020*/
		},

		/*Start of change for SCTASK1855604 - budget approvers by developer Satabdi Das on 19-May-2021*/
		onPressTtlAmt: function (oEvent) {
			var mModelSummary = this.getView().getModel("mModelSummary");
			var displayMode = mModelSummary.getProperty("/displayMode");
			if (displayMode === false) {
				mModelSummary.setProperty("/updateRowData/AttenBrf", "");
				mModelSummary.setProperty("/updateRowData/AttenBrfEmail", "");
				// mModelSummary.setProperty("/updateRowData/LoaContact", "");
				// mModelSummary.setProperty("/updateRowData/LoaEmail", "");
				var oCopPoTbl = mModelSummary.getProperty("/copPoTableSet");
				if (oCopPoTbl && oCopPoTbl.length > 0) {
					var i = 0;
					var totalAmt = 0;
					while (i < oCopPoTbl.length) {
						if (oCopPoTbl[i].SrvChrg) {
							totalAmt = totalAmt + Number(oCopPoTbl[i].PoAmount) + Number(oCopPoTbl[i].SrvChrg);
						} else {
							totalAmt = totalAmt + Number(oCopPoTbl[i].PoAmount);
						}
						i++;
					}
					totalAmt = totalAmt.toString();
					mModelSummary.setProperty("/TotalCSAmt", totalAmt);
				} else {
					mModelSummary.setProperty("/TotalCSAmt", "");
				}
			}
		},
		onPOAmtEdit: function (oEvent) {
			var mModelSummary = this.getView().getModel("mModelSummary");
			mModelSummary.setProperty("/updateRowData/AttenBrf", "");
			mModelSummary.setProperty("/updateRowData/AttenBrfEmail", "");
			// mModelSummary.setProperty("/updateRowData/LoaContact", "");
			// mModelSummary.setProperty("/updateRowData/LoaEmail", "");
			mModelSummary.setProperty("/TotalCSAmt", "");
		},
		onSrvChrgEdit: function (oEvent) {
			var mModelSummary = this.getView().getModel("mModelSummary");
			mModelSummary.setProperty("/updateRowData/AttenBrf", "");
			mModelSummary.setProperty("/updateRowData/AttenBrfEmail", "");
			// mModelSummary.setProperty("/updateRowData/LoaContact", "");
			// mModelSummary.setProperty("/updateRowData/LoaEmail", "");
			mModelSummary.setProperty("/TotalCSAmt", "");
		},
		/*End of change for SCTASK1855604 - budget approvers by developer Satabdi Das on 19-May-2021*/

		onEnterStartDate: function (oEvent) {
			var mModelSummary = this.getView().getModel("mModelSummary");
			var oDatePickerStart = this.getView().byId("comercialDatePickerId");
			if (oDatePickerStart) {
				var objDate1 = oDatePickerStart.getDomRef();
				if (objDate1) {
					objDate1.firstElementChild.firstChild.setAttribute("readonly", true);
				}
			}
			var startDate = oEvent.getParameter("value");
			var oContractStartDate = mModelSummary.getProperty("/HeaderData").ContarctStartDate;
			var oContractEnddate = mModelSummary.getProperty("/HeaderData").ContarctEndDate;
			if (oContractEnddate) {
				var oDiffoFcontrctEndDateSrvStDate = oContractEnddate - startDate;
			} else {
				oDiffoFcontrctEndDateSrvStDate = 0;
			}

			var oDiffContrDateServiceStDate = oContractStartDate - startDate;
			if ((oDiffContrDateServiceStDate <= 0 && oDiffoFcontrctEndDateSrvStDate >= 0) || (oContractStartDate === "00000000") || !
				oContractStartDate) {
				var oCommerEndDate = mModelSummary.getProperty("/copPoLineItemSet").PoEndDate;
				if (oCommerEndDate !== "00000000") {
					var checkDate = oCommerEndDate - startDate;
				}
				if (oCommerEndDate) {
					if (checkDate < 0) {
						var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
						MessageBox.alert(
							"Please enter valid service start date.", {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}
						);

						this.getView().getModel("mModelSummary").setProperty("/copPoLineItemSet/PoStartDate", "");
					}
				}

			} else {
				var servicestartdatemeg = this.getModel("i18n").getProperty("serviceStartdate");
				MessageBox.alert(servicestartdatemeg, {
					styleClass: bCompact ? "sapUiSizeCompact" : ""
				});
				this.getView().getModel("mModelSummary").setProperty("/copPoLineItemSet/PoStartDate", "");
			}
		},
		onEnterPoEndDate: function (oEvent) {
			var oPoendDate = this.getView().byId("PoendDate");
			var mModelSummary = this.getView().getModel("mModelSummary");
			if (oPoendDate) {
				var objDate1 = oPoendDate.getDomRef();
				if (objDate1) {
					//objDate1.firstElementChild.setAttribute("readonly", true);
					objDate1.firstElementChild.firstChild.setAttribute("readonly", true);
				}
			}
			var oPoEnddate = oEvent.getParameter("value");
			var oContractEndDate = mModelSummary.getProperty("/HeaderData").ContarctEndDate;
			var oDiffOfEndDateandcontraEnddate = oContractEndDate - oPoEnddate;
			if ((oDiffOfEndDateandcontraEnddate >= 0) || (oContractEndDate === "00000000") || !oContractEndDate) {
				var oPoStartDate = mModelSummary.getProperty("/copPoLineItemSet").PoStartDate;
				var checkDate = oPoEnddate - oPoStartDate;
				if (checkDate < 0) {
					var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
					MessageBox.alert(
						"Please enter valid   service end date.", {
							styleClass: bCompact ? "sapUiSizeCompact" : ""
						}
					);

					this.getView().getModel("mModelSummary").setProperty("/copPoLineItemSet/PoEndDate", "");
				}
			} else {
				var oServicesEndDate = this.getModel("i18n").getProperty("oServicesEndDate");
				MessageBox.alert(oServicesEndDate, {
					styleClass: bCompact ? "sapUiSizeCompact" : ""
				});
				this.getView().getModel("mModelSummary").setProperty("/copPoLineItemSet/PoEndDate", "");

			}
		},

		CreateRowForComerSection: function (oEvent) {
			var checkMFGCC = this.getView().getModel("mModelSummary").getProperty("/updateRowData");
			this.getModel("mModelSummary").setProperty("/copPoTableSet", []);
			var oValueForCopPo = this.getModel("mModelSummary").getProperty("/oLinePoTableSet");
			if (checkMFGCC.RequestingMf || checkMFGCC.GlobalCc) {
				// this.getModel("mModelSummary").setProperty("/oEditable/coomercialRow", true);
				if (this.rrfTablefragment) {
					var rrfTablefragment = this.getView().createId("rrfTablefragment");
					var RequestingMf = this.getModel("mModelSummary").getProperty("/updateRowData").RequestingMf;
					var ProcessGrp = this.getModel("mModelSummary").getProperty("/updateRowData").ProcessGrp;
					var MemberFirm = this.getModel("mModelSummary").getProperty("/updateRowData").MemberFirm;
					var copPoTableSet = oValueForCopPo;
					var GlobalCc = this.getModel("mModelSummary").getProperty("/updateRowData").GlobalCc;

					var sShowValueArray = [];
					for (var i = 0; i < copPoTableSet.length; i++) {

						var oObject = {};

						if ((RequestingMf === copPoTableSet[i].RequestingMf) && (ProcessGrp === copPoTableSet[i].ProcessGrp) && (MemberFirm ===
								copPoTableSet[i].MemberFirm)) {
							oObject.PoStartDate = copPoTableSet[i].PoStartDate;
							oObject.PoEndDate = copPoTableSet[i].PoEndDate;
							oObject.PoYear = copPoTableSet[i].PoYear;
							oObject.PoAmount = copPoTableSet[i].PoAmount;
							oObject.SrvChrg = copPoTableSet[i].SrvChrg;
							oObject.OutlineText = copPoTableSet[i].OutlineText;
							oObject.CompanyCode = copPoTableSet[i].CompanyCode;
							oObject.RrfNo = copPoTableSet[i].RrfNo;
							oObject.RequestingMf = copPoTableSet[i].RequestingMf;
							oObject.MemberFirm = copPoTableSet[i].MemberFirm;
							oObject.ProcessGrp = copPoTableSet[i].ProcessGrp;
							oObject.CoupaContractNo = copPoTableSet[i].CoupaContractNo;
							oObject.SerialNo = copPoTableSet[i].SerialNo;
							sShowValueArray.push(oObject);
							this.getModel("mModelSummary").setProperty("/copPoTableSet", sShowValueArray);

						} else if ((GlobalCc === copPoTableSet[i].GlobalCc) && (RequestingMf === "N/A")) {
							oObject.PoStartDate = copPoTableSet[i].PoStartDate;
							oObject.PoEndDate = copPoTableSet[i].PoEndDate;
							oObject.PoYear = copPoTableSet[i].PoYear;
							oObject.PoAmount = copPoTableSet[i].PoAmount;
							oObject.SrvChrg = copPoTableSet[i].SrvChrg;
							oObject.OutlineText = copPoTableSet[i].OutlineText;
							oObject.CompanyCode = copPoTableSet[i].CompanyCode;
							oObject.RrfNo = copPoTableSet[i].RrfNo;
							oObject.CcShortDesc = "";
							oObject.CoupaContractNo = copPoTableSet[i].CoupaContractNo;
							oObject.GlobalCc = copPoTableSet[i].GlobalCc;
							oObject.SerialNo = copPoTableSet[i].SerialNo;
							sShowValueArray.push(oObject);
							this.getModel("mModelSummary").setProperty("/copPoTableSet", sShowValueArray);
						}
					}
					// this.getModel("mModelSummary").setProperty("/oEditable/vBoxVisibleForCop", false);
					// this.byId(sap.ui.core.Fragment.createId(rrfTablefragment, "goToCommercialId")).setVisible(false);

				} else if (this.oLineItemfrg) {
					var oLineItemfrg = this.getView().createId("fragmentId");
					RequestingMf = this.getModel("mModelSummary").getProperty("/updateRowData").RequestingMf;
					ProcessGrp = this.getModel("mModelSummary").getProperty("/updateRowData").ProcessGrp;
					var MemberFirm = this.getModel("mModelSummary").getProperty("/updateRowData").MemberFirm;
					copPoTableSet = oValueForCopPo;
					GlobalCc = this.getModel("mModelSummary").getProperty("/updateRowData").GlobalCc;

					var sShowValueArray = [];
					for (var i = 0; i < copPoTableSet.length; i++) {

						var oObject = {};
						if ((RequestingMf === copPoTableSet[i].RequestingMf) && (ProcessGrp === copPoTableSet[i].ProcessGrp) && (MemberFirm ===
								copPoTableSet[i].MemberFirm)) {
							oObject.PoStartDate = copPoTableSet[i].PoStartDate;
							oObject.PoEndDate = copPoTableSet[i].PoEndDate;
							oObject.PoYear = copPoTableSet[i].PoYear;
							oObject.PoAmount = copPoTableSet[i].PoAmount;
							oObject.SrvChrg = copPoTableSet[i].SrvChrg;
							oObject.OutlineText = copPoTableSet[i].OutlineText;
							oObject.CompanyCode = copPoTableSet[i].CompanyCode;
							oObject.RrfNo = copPoTableSet[i].RrfNo;
							oObject.RequestingMf = copPoTableSet[i].RequestingMf;
							oObject.MemberFirm = copPoTableSet[i].MemberFirm;
							oObject.ProcessGrp = copPoTableSet[i].ProcessGrp;
							oObject.CoupaContractNo = copPoTableSet[i].CoupaContractNo;
							oObject.SerialNo = copPoTableSet[i].SerialNo;
							sShowValueArray.push(oObject);
							this.getModel("mModelSummary").setProperty("/copPoTableSet", sShowValueArray);

						} else if ((GlobalCc === copPoTableSet[i].GlobalCc) && (RequestingMf === "N/A")) {
							oObject.PoStartDate = copPoTableSet[i].PoStartDate;
							oObject.PoEndDate = copPoTableSet[i].PoEndDate;
							oObject.PoYear = copPoTableSet[i].PoYear;
							oObject.PoAmount = copPoTableSet[i].PoAmount;
							oObject.SrvChrg = copPoTableSet[i].SrvChrg;
							oObject.OutlineText = copPoTableSet[i].OutlineText;
							oObject.CompanyCode = copPoTableSet[i].CompanyCode;
							oObject.RrfNo = copPoTableSet[i].RrfNo;
							oObject.CcShortDesc = "";
							oObject.CoupaContractNo = copPoTableSet[i].CoupaContractNo;
							oObject.GlobalCc = copPoTableSet[i].GlobalCc;
							oObject.SerialNo = copPoTableSet[i].SerialNo;
							sShowValueArray.push(oObject);
							this.getModel("mModelSummary").setProperty("/copPoTableSet", sShowValueArray);
						}
					}
					// this.getModel("mModelSummary").setProperty("/oEditable/vBoxVisibleForCop", false);
					// this.byId(sap.ui.core.Fragment.createId(oLineItemfrg, "goToCommercialId")).setVisible(false);

				}
			} else {

				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				MessageBox.alert(
					"Please enter mandatory field first.", {
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					}
				);

			}

		},
		onPressEditOfCommercialSection: function (oEvent) {
			var oCommTable;
			var mModelSummary = this.getView().getModel("mModelSummary");
			sap.ui.core.BusyIndicator.show(0);
			var oTextfrag = mModelSummary.getProperty("/setLineItemText");
			if ((oTextfrag === "Edit Member Firm") || (oTextfrag === "Edit Global Function")) {
				var oLineItemfrg = this.getView().createId("fragmentId");
				oCommTable = sap.ui.core.Fragment.byId(oLineItemfrg, "RowForCommercial");
			} else {
				var rrfTablefragment = this.getView().createId("rrfTablefragment");
				oCommTable = sap.ui.core.Fragment.byId(rrfTablefragment, "RowForCommercial");
			}

			var rowPath = oEvent.getSource().getParent().getBindingContextPath();
			var rowNum = rowPath.split("/")[2];
			for (var i = 0; i < oCommTable.getAggregation("items").length; i++) {
				var haveToChange = oCommTable.getAggregation("items")[i].getBindingContext("mModelSummary").sPath;

				if (haveToChange === rowPath) {
					for (var k = 0; k < oCommTable.getAggregation("items")[i].getCells().length; k++) {
						if ((0 < k) && (k < 6)) {
							oCommTable.getAggregation("items")[i].getCells()[k].setProperty("editable", true);
						}

					}
				}

			}
			sap.ui.core.BusyIndicator.hide(0);
		},
		onDeleteLineItemCommercialSection: function (oEvent) {
			/*Start of change on 27-Jan-2020*/
			var mModelSummary = this.getView().getModel("mModelSummary");
			var displayMode = this.getModel("mModelSummary").getProperty("/displayMode");
			if (displayMode === false) {
				/*End of change on 27-Jan-2020*/
				var oStatus = mModelSummary.getProperty("/updateRowData").RrfStatus;
				if (!oStatus || (oStatus === "RRF Initiated") || (oStatus === "COPDeclined")) {
					var that = this;
					var sData;
					var event = oEvent.getSource();
					var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
					MessageBox.warning(
						"Are you sure you want to delete this?", {
							actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
							styleClass: bCompact ? "sapUiSizeCompact" : "",

							onClose: function (sAction) {
								if (sAction === "OK") {
									sap.ui.core.BusyIndicator.show(0);
									sData = event.getBindingContext("mModelSummary").getObject();
									mModelSummary.setProperty("/DeleteCommercialRow", sData.SerialNo); /*Added for INC01437289 on 30-March-2021*/
									var x = event.getBindingContext("mModelSummary").getPath();
									var y = x.split("/");
									var z = y[2];
									z = parseInt(z);
									var s = event.getBindingContext("mModelSummary").getProperty("/copPoTableSet");
									s.splice(z, 1);
									var oLineCoomercialTable = that.getModel("mModelSummary").getProperty("/oLinePoTableSet");
									// for (var i = oLineCoomercialTable.length - 1; i >= 0; i--) {

									// 	if ((((oLineCoomercialTable[i].RequestingMf === sData.RequestingMf) && (oLineCoomercialTable[i].ProcessGrp === sData.ProcessGrp)&&(oLineCoomercialTable[i].MemberFirm === sData.MemberFirm)) || (oLineCoomercialTable[i].GlobalCc === sData.GlobalCc) && (oLineCoomercialTable[i].PoAmount === sData.PoAmount) &&
									// 		(oLineCoomercialTable[i].SrvChrg === sData.SrvChrg) && (oLineCoomercialTable[i].OutlineText === sData.OutlineText) && (
									// 			oLineCoomercialTable[i].PoStartDate === sData.PoStartDate) && (oLineCoomercialTable[i].PoEndDate === sData.PoEndDate)) {

									// 		var a = i;
									// 		a = parseInt(a);
									// 		oLineCoomercialTable.splice(a, 1);

									// 		that.getView().getModel("mModelSummary").refresh(true);
									// 		break;

									// 	}
									// }

									for (var i = oLineCoomercialTable.length - 1; i >= 0; i--) {

										if ((((oLineCoomercialTable[i].RequestingMf === sData.RequestingMf) && (oLineCoomercialTable[i].ProcessGrp === sData.ProcessGrp) &&
													(oLineCoomercialTable[i].MemberFirm === sData.MemberFirm) && (oLineCoomercialTable[i].SerialNo === sData.SerialNo)) ||
												(oLineCoomercialTable[i].GlobalCc === sData.GlobalCc)) && (!sData.CcShortDesc) && (oLineCoomercialTable[i].PoAmount ===
												sData.PoAmount) &&
											(oLineCoomercialTable[i].SrvChrg === sData.SrvChrg) && (oLineCoomercialTable[i].OutlineText === sData.OutlineText) &&
											(
												oLineCoomercialTable[i].PoStartDate === sData.PoStartDate) && (oLineCoomercialTable[i].PoEndDate === sData.PoEndDate) &&
											(oLineCoomercialTable[i].SerialNo === sData.SerialNo)) {

											var a = i;
											a = parseInt(a);
											oLineCoomercialTable.splice(a, 1);

											that.getView().getModel("mModelSummary").refresh(true);
											break;

										}
									}
									/*Start of change for SCTASK1855604 - budget approvers by developer Satabdi Das on 19-May-2021*/
									mModelSummary.setProperty("/updateRowData/AttenBrf", "");
									mModelSummary.setProperty("/updateRowData/AttenBrfEmail", "");
									// mModelSummary.setProperty("/updateRowData/LoaContact", "");
									// mModelSummary.setProperty("/updateRowData/LoaEmail", "");
									mModelSummary.setProperty("/TotalCSAmt", "");
									/*End of change for SCTASK1855604 - budget approvers by developer Satabdi Das on 19-May-2021*/
									sap.ui.core.BusyIndicator.hide(0);

								}
							}
						}

					);
				} else {
					MessageBox.alert("This line cannot be deleted.");
				}
			}
		},
		/*Start of change by Satabdi Das for serial number INC01437289 on 06-Apr-2021*/
		onEnterCSTblStartDate: function (oEvent) {
			var mModelSummary = this.getView().getModel("mModelSummary");
			oEvent.getSource()._$input.attr("readonly", "readonly");
			var startDate = oEvent.getParameter("value");
			var CSTableData = mModelSummary.getProperty("/copPoTableSet");
			var PostsrtDatePath = oEvent.getSource().getBindingInfo("value").binding.oContext.getPath();
			var RowNumber = PostsrtDatePath.split("/")[2];
			var oCommerEndDate = CSTableData[RowNumber].PoEndDate;
			var oContractStartDate = mModelSummary.getProperty("/HeaderData").ContarctStartDate;
			var oContractEnddate = mModelSummary.getProperty("/HeaderData").ContarctEndDate;
			var PoStartDate;
			if (oContractEnddate) {
				var oDiffoFcontrctEndDateSrvStDate = oContractEnddate - startDate;
			} else {
				oDiffoFcontrctEndDateSrvStDate = 0;
			}

			var oDiffContrDateServiceStDate = oContractStartDate - startDate;

			var oAllCSLine = mModelSummary.getProperty("/oLinePoTableSet");
			for (var i = 0; i < oAllCSLine.length; i++) {
				if (oAllCSLine[i].RequestingMf === CSTableData[RowNumber].RequestingMf && oAllCSLine[i].ProcessGrp === CSTableData[RowNumber].ProcessGrp &&
					oAllCSLine[i].SerialNo === CSTableData[RowNumber].SerialNo) {
					PoStartDate = oAllCSLine[i].PoStartDate;
				} else if (oAllCSLine[i].SerialNo === CSTableData[RowNumber].SerialNo && oAllCSLine[i].GlobalCc === CSTableData[RowNumber].GlobalCc) {
					PoStartDate = oAllCSLine[i].PoStartDate;
				}
			}

			if ((oDiffContrDateServiceStDate <= 0 && oDiffoFcontrctEndDateSrvStDate >= 0) || (oContractStartDate === "00000000") || !
				oContractStartDate) {

				if (oCommerEndDate !== "00000000") {
					var checkDate = oCommerEndDate - startDate;
				}
				if (oCommerEndDate) {
					if (checkDate < 0) {
						var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
						MessageBox.alert(
							"Please enter valid service start date.", {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}
						);

						mModelSummary.getProperty("/copPoTableSet")[RowNumber].PoStartDate = PoStartDate;
					}
				}

			} else {
				var servicestartdatemeg = this.getModel("i18n").getProperty("serviceStartdate");
				MessageBox.alert(servicestartdatemeg, {
					styleClass: bCompact ? "sapUiSizeCompact" : ""
				});
				mModelSummary.getProperty("/copPoTableSet")[RowNumber].PoStartDate = PoStartDate;
			}
		},
		onEnterCSTblEndDate: function (oEvent) {
			var mModelSummary = this.getView().getModel("mModelSummary");
			oEvent.getSource()._$input.attr("readonly", "readonly");
			var CSTableData = mModelSummary.getProperty("/copPoTableSet");
			var oPoEnddate = oEvent.getParameter("value");
			var PostsrtDatePath = oEvent.getSource().getBindingInfo("value").binding.oContext.getPath();
			var RowNumber = PostsrtDatePath.split("/")[2];
			var SelectedRowStartDate = CSTableData[RowNumber].PoStartDate;
			var oContractEndDate = mModelSummary.getProperty("/HeaderData").ContarctEndDate;
			var oDiffOfEndDateandcontraEnddate = oContractEndDate - oPoEnddate;
			var PoEndDate;
			//TakingPrevious PoEnd date
			var oAllCSLine = mModelSummary.getProperty("/oLinePoTableSet");
			for (var i = 0; i < oAllCSLine.length; i++) {
				if (oAllCSLine[i].RequestingMf === CSTableData[RowNumber].RequestingMf && oAllCSLine[i].ProcessGrp === CSTableData[RowNumber].ProcessGrp &&
					oAllCSLine[i].SerialNo === CSTableData[RowNumber].SerialNo) {
					PoEndDate = oAllCSLine[i].PoEndDate;
				} else if (oAllCSLine[i].SerialNo === CSTableData[RowNumber].SerialNo && oAllCSLine[i].GlobalCc === CSTableData[RowNumber].GlobalCc) {
					PoEndDate = oAllCSLine[i].PoEndDate;
				}
			}

			if ((oDiffOfEndDateandcontraEnddate >= 0) || (oContractEndDate === "00000000") || !oContractEndDate) {
				var checkDate = oPoEnddate - SelectedRowStartDate;
				if (checkDate < 0) {
					var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
					MessageBox.alert(
						"Please enter valid service end date.", {
							styleClass: bCompact ? "sapUiSizeCompact" : ""
						}
					);

					mModelSummary.getProperty("/copPoTableSet")[RowNumber].PoEndDate = PoEndDate;
				}
			} else {
				var oServicesEndDate = this.getModel("i18n").getProperty("oServicesEndDate");
				MessageBox.alert(oServicesEndDate, {
					styleClass: bCompact ? "sapUiSizeCompact" : ""
				});
				mModelSummary.getProperty("/copPoTableSet")[RowNumber].PoEndDate = PoEndDate;
			}
		},
		/*End of change by Satabdi Das for serial number INC01437289 on 06-Apr-2021*/
		onDeleteCcMail: function (oEvent) {
			var rowItemContainer = oEvent.getSource().getParent();
			rowItemContainer.destroy();
		},

		// handleTypeMissmatch: function (oEvent) {
		// 	var aFileTypes = oEvent.getSource().getFileType();
		// 	jQuery.each(aFileTypes, function (key, value) {
		// 		aFileTypes[key] = "*." + value;
		// 	});
		// 	var sSupportedFileTypes = aFileTypes.join(", ");
		// 	MessageToast.show("The file type *." + oEvent.getParameter("fileType") +
		// 		" is not supported. Choose one of the following types: " +
		// 		sSupportedFileTypes);
		// },
		onAddAttachment: function (oEvent) {
			var uploadCollection = oEvent.getSource();
			var that = this;
			var collectionItemArr = uploadCollection.getItems();
			var files = oEvent.getParameter("files");
			var dupfile;

			for (var i = 0; i < collectionItemArr.length; i++) {
				if (collectionItemArr[i].getProperty("fileName") === files[0].name) {
					jQuery.sap.log.error("Duplicate file not allowed");
					sap.m.MessageBox.error("Duplicate filename not allowed", {
						title: "Error", // default
						onClose: null, // default
						styleClass: "", // default
						initialFocus: null, // default
						textDirection: sap.ui.core.TextDirection.Inherit // default
					});

					// UploadCollection.fireUploadTerminated(oEvent.getParameters());
					dupfile = true;
					break;

				}
			}
			if (files[0].size <= 0) {
				sap.m.MessageBox.error("Files with size 0kb not allowed to upload", {
					title: "Error", // default
					onClose: null, // default
					styleClass: "", // default
					initialFocus: null, // default
					textDirection: sap.ui.core.TextDirection.Inherit // default
				});
				oEvent.getSource().abortUpload(oEvent.getParameters());
				return;
			}

			if (dupfile === true) {
				oEvent.getSource().abortUpload(oEvent.getParameters());
				return;
			}

			var uploadUrl = "/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/AR_ATTSet";
			// var uploadUrl = "/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/AR_ATTSet(CompanyCode='" + sValue.CompanyCode + "',RrfNo='" + sValue.RrfNo +
			//  		"',RequestingMf='" + sMFGCC.RequestingMf + "',GlobalCc='" + sMFGCC.GlobalCc + "')";

			uploadCollection.setUploadUrl(uploadUrl);

			var mAttachments = this.getView().getModel();

			var token = "x-cs" + "rf-token";
			mAttachments.refreshSecurityToken();
			var T = mAttachments.getHeaders()[token];

			var csrfToken = new sap.m.UploadCollectionParameter({
				name: token,
				value: T
			});

			var reqType = new sap.m.UploadCollectionParameter({
				name: "X-Requested-With",
				value: "XMLHttpRequest"
			});

			//uploadCollection.removeAllHeaderParameters();
			uploadCollection.addHeaderParameter(csrfToken);
			uploadCollection.addHeaderParameter(reqType);

		},
		onBeforeUploadStarts: function (oEvent) {
			/*Start of change on 18-Feb-2020*/
			// var id = oEvent.getSource().getId();
			// var idLen = oEvent.getSource().getId().length;
			// var AttachSection = id.substring(idLen, 55);
			var AttachSection = oEvent.getParameter("id").split("--")[2]; /*Change added for INC01499658 ON 26-APR-2021*/
			var AttachPanelID;
			/*End of change on 18-Feb-2020*/
			var sValue = this.getView().getModel("mModelSummary").getProperty("/HeaderData");
			var sMFGCC = this.getView().getModel("mModelSummary").getProperty("/updateRowData");
			sMFGCC.CcShortDesc = ""; /*Added on 10-March-2021*/
			if ((sMFGCC.RequestingMf === "N/A") || (!sMFGCC.RequestingMf)) {
				sMFGCC.RequestingMf = "NA";
				sMFGCC.MemberFirm = ""; /*added for SCTASK1919812 on 17-Feb-2021*/
			}
			if ((sMFGCC.GlobalCc === "N/A") || (!sMFGCC.GlobalCc)) {
				sMFGCC.GlobalCc = "NA";
				sMFGCC.CcShortDesc = ""; /*added for SCTASK1895344 on 17-Feb-2021*/
				// sMFGCC.MemberFirm = sMFGCC.RequestingMf; /*added for SCTASK1919812 on 17-Feb-2021*/
			}

			/*Start of change on 18-Feb-2020*/
			if (AttachSection === "fileUploader") {
				AttachPanelID = "COP";
			} else if (AttachSection === "fileUploaderLOA") {
				AttachPanelID = "LOA";
			}
			/*End of change on 18-Feb-2020*/

			if (!sMFGCC.ProcessGrp) {
				sMFGCC.ProcessGrp = "";
			}

			// calling special char check function
			var isSpecialChar = this.checkFileNameSepecialchar(oEvent.getParameter("fileName"));
			if (isSpecialChar) {
				var sMsg = this.getView().getModel("i18n").getProperty("specialcharFileNameMsg");
				MessageBox.error(sMsg);
				return;
			}

			var uPloadpar = oEvent.getParameter("fileName") + "|" + sValue.CompanyCode + "|" + sValue.RrfNo + "|" + sMFGCC.RequestingMf +
				"|" +
				sMFGCC.ProcessGrp + "|" +
				sMFGCC.GlobalCc + "|" + AttachPanelID + "|" + sMFGCC.MemberFirm + "|" +
				sMFGCC.CcShortDesc; /*Added on 18-Feb-2020*/
			// Header Slug
			var oCustomerHeaderSlug = new sap.m.UploadCollectionParameter({
				name: "slug",
				value: uPloadpar
			});

			oEvent.getParameters().addHeaderParameter(oCustomerHeaderSlug);

			if (sMFGCC.RequestingMf === "NA" && sMFGCC.GlobalCc != "NA") {

				sMFGCC.RequestingMf = "N/A";
				sMFGCC.MemberFirm = ""; /*added for SCTASK1919812 on 17-Feb-2021*/
			}

			if (sMFGCC.GlobalCc === "NA") {
				sMFGCC.GlobalCc = "N/A";
				sMFGCC.CcShortDesc = ""; /*added for SCTASK1895344 on 17-Feb-2021*/
			}

		},

		handleUploadComplete: function (oEvent) {
			this.fetchAttachmentList();
		},

		fetchAttachmentList: function (oEvent) {
			var sValue = this.getView().getModel("mModelSummary").getProperty("/HeaderData");
			var sMFGCC = this.getView().getModel("mModelSummary").getProperty("/updateRowData");
			/*Start of change by Satabdi Das on 17-Feb-2021*/
			if (sMFGCC.RequestingMf === "N/A") {
				sMFGCC.MemberFirm = "";
			}
			// else {
			// sMFGCC.MemberFirm = sMFGCC.RequestingMf;
			sMFGCC.CcShortDesc = "";

			// }
			/*End of change by Satabdi Das on 17-Feb-2021*/
			sap.ui.core.BusyIndicator.show(0);
			var fnSucces = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				/*Start of change on 18-Feb-2020*/
				var arrayCOP = [];
				var arrayLOA = [];
				for (var i = 0; i < d.results.length; i++) {
					if (d.results[i].CopLoa === "COP") {
						arrayCOP.push(d.results[i]);

					} else if (d.results[i].CopLoa === "LOA") {
						arrayLOA.push(d.results[i]);
					}
				}
				this.getView().getModel("mModelSummary").setProperty("/FileNameSet", arrayCOP);
				this.getView().getModel("mModelSummary").setProperty("/FileNameLoaSet", arrayLOA);
				/*End of change on 18-Feb-2020*/
				this.getView().getModel("mModelSummary").refresh(true);
			}, this);

			var fnError = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
			}, this);

			var sPath1 = "/AR_ATTSet";

			/*	var sPath = "/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/AR_ATTSet(CompanyCode='" + sValue.CompanyCode + "',RrfNo='" + sValue.RrfNo +
					"',RequestingMf='" + sMFGCC.RequestingMf + "',GlobalCc='" + sMFGCC.GlobalCc + "',ProcessGrp='" + sMFGCC.ProcessGrp + "',CopLoa='" + "COP" + "')";*/

			var aFilterStr = [];
			var oFilterSerach;
			if ((sValue.RrfNo || !sValue.RrfNo) && sValue.CompanyCode && sMFGCC.RequestingMf && sMFGCC.GlobalCc) {
				oFilterSerach = new sap.ui.model.Filter("RrfNo", sap.ui.model.FilterOperator.EQ, sValue.RrfNo);
				aFilterStr.push(oFilterSerach);
				oFilterSerach = new sap.ui.model.Filter("CompanyCode", sap.ui.model.FilterOperator.EQ, sValue.CompanyCode);
				aFilterStr.push(oFilterSerach);
				oFilterSerach = new sap.ui.model.Filter("RequestingMf", sap.ui.model.FilterOperator.EQ, sMFGCC.RequestingMf);
				aFilterStr.push(oFilterSerach);
				oFilterSerach = new sap.ui.model.Filter("GlobalCc", sap.ui.model.FilterOperator.EQ, sMFGCC.GlobalCc);
				aFilterStr.push(oFilterSerach);
				oFilterSerach = new sap.ui.model.Filter("ProcessGrp", sap.ui.model.FilterOperator.EQ, sMFGCC.ProcessGrp);
				aFilterStr.push(oFilterSerach);
				/*Start of change by Satabdi Das on 17-Feb-2021*/
				oFilterSerach = new sap.ui.model.Filter("MemberFirm", sap.ui.model.FilterOperator.EQ, sMFGCC.MemberFirm);
				aFilterStr.push(oFilterSerach);
				oFilterSerach = new sap.ui.model.Filter("CcShortDesc", sap.ui.model.FilterOperator.EQ, sMFGCC.CcShortDesc);
				aFilterStr.push(oFilterSerach);
				/*End of change by Satabdi Das on 17-Feb-2021*/
			}
			/*R&D---start*/
			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
				json: true
			});
			oModel1.read("/AR_ATTSet", {
				filters: aFilterStr,
				success: fnSucces,
				error: fnError
			});
			/*R&D---end*/

			// // sFilter.push(aFilterStr);
			// var oUrlParams = {

			// };

			// DataManagerARrecharge._getODataARRecharge(sPath1, aFilterStr, oUrlParams, fnSucces, fnError);

		},

		// onAttributePressCop: function (oEvent) {
		// 	//             	var oLineItemfrg = this.getView().createId("fragmentId");

		// 	// var oUploadCollection = this.byId(sap.ui.core.Fragment.createId(oLineItemfrg, "fileUploader"));
		// 	// var x= oUploadCollection.getAggregation("items")[0];
		// 	// oUploadCollection.downloadItem(x, true);
		// 	//var aSelectedItems = oUploadCollection.getSelectedItems();
		// 	// if (aSelectedItems) {
		// 	// 	for (var i = 0; i < aSelectedItems.length; i++) {
		// 	// 		oUploadCollection.downloadItem(aSelectedItems[i], true);
		// 	// 	}
		// 	// } else {
		// 	// 	MessageToast.show("Select an item to download");
		// 	// }

		// 	var ofileName = oEvent.getSource().getParent("oParent").getProperty("fileName");

		// 	var AttDownLoad = oEvent.getParameter("id").split("--")[3].split("-")[0];

		// 	var sValue = this.getView().getModel("mModelSummary").getProperty("/HeaderData");
		// 	var sMFGCC = this.getView().getModel("mModelSummary").getProperty("/updateRowData");
		// 	if ((sMFGCC.RequestingMf === "N/A") || (!sMFGCC.RequestingMf)) {
		// 		sMFGCC.RequestingMf = "NA";
		// 	}
		// 	if ((sMFGCC.GlobalCc === "N/A") || (!sMFGCC.GlobalCc)) {
		// 		sMFGCC.GlobalCc = "NA";
		// 	}

		// 	/*Start of change on 18-Feb-2020*/
		// 	if (AttDownLoad === "fileUploader") {
		// 		var AttachPanelID = "COP";
		// 	} else if (AttDownLoad === "fileUploaderLOA") {
		// 		AttachPanelID = "LOA";
		// 	}
		// 	/*End of change on 18-Feb-2020*/

		// 	if (!sMFGCC.ProcessGrp) {
		// 		sMFGCC.ProcessGrp = "";
		// 	}

		// 	var fnSucces = jQuery.proxy(function (oData, response) {
		// 		sap.ui.core.BusyIndicator.hide(0);
		// 		// var mModelSummary = this.getModel("mModelSummary");
		// 		// ofileName = d.Filename;
		// 		// var Mimetype = d.Mimetype;

		// 		// mModelSummary.setProperty("/downloadFileName", d.Filename);
		// 		// this.FileName = d.Filename;
		// 		// var value = d.Value;

		// 		window.open(response.uri, '_self');
		// 		// this.showFile();

		// 		// window.open(pdfURL, "_self",
		// 		// 	"directories=no, status=no, menubar=no, scrollbars=yes, resizable=yes,width=" + window.innerWidth + ", height=" + window.innerHeight +
		// 		// 	",top=0,left=0,titlebar=no");

		// 	}, this);

		// 	var fnError = jQuery.proxy(function (d) {
		// 		sap.ui.core.BusyIndicator.hide(0);
		// 	}, this);

		// 	var sPath = "/AR_ATTSet(CompanyCode='" + sValue.CompanyCode + "',RrfNo='" + sValue.RrfNo +
		// 		"',RequestingMf='" + sMFGCC.RequestingMf + "',GlobalCc='" + sMFGCC.GlobalCc + "',Filename='" + ofileName + "',ProcessGrp='" +
		// 		sMFGCC.ProcessGrp + "',CopLoa='" +
		// 		AttachPanelID + "')/$value";

		// 	DataManagerARrecharge.getcallAttDownload(sPath, fnSucces, fnError);

		// },

		onAttributePressCop: function (oEvent) {
			sap.ui.core.BusyIndicator.show(0);

			var ofileName = oEvent.getSource().getParent("oParent").getProperty("fileName");
			var ofileName1 = ofileName;
			var forwardslashFile = /[/]+/;
			if (forwardslashFile.test(ofileName1)) {
				ofileName1 = ofileName1.replace(/[/]/g, "|");
			}
			var qQuestionCharFile = /[?]+/;
			if (qQuestionCharFile.test(ofileName1)) {
				ofileName1 = ofileName1.replace(/[?]/g, "(");
			}
			var pPercentageFile = /[%]+/;
			if (pPercentageFile.test(ofileName1)) {
				ofileName1 = ofileName1.replace(/[%]/g, ")");
			}

			var AttDownLoad = oEvent.getParameter("id").split("--")[2].split("-")[0]; /*Change added for INC01499658 ON 26-APR-2021*/

			var sValue = this.getView().getModel("mModelSummary").getProperty("/HeaderData");
			var sMFGCC = this.getView().getModel("mModelSummary").getProperty("/updateRowData");
			if ((sMFGCC.RequestingMf === "N/A") || (!sMFGCC.RequestingMf)) {
				sMFGCC.RequestingMf = "NA";
				sMFGCC.MemberFirm = "";
			}
			if ((sMFGCC.GlobalCc === "N/A") || (!sMFGCC.GlobalCc)) {
				sMFGCC.GlobalCc = "NA";
				sMFGCC.CcShortDesc = "";
			}

			/*Start of change for INC01584421 by developer Prashant kumar on 22-June-2021*/
			var sMf = sMFGCC.MemberFirm;
			var forwardslashMmfirm = /[/]+/;
			if (forwardslashMmfirm.test(sMf)) {
				sMf = sMf.replace(/[/]/g, "|");
			}
			var qQuestionCharMemFm = /[?]+/;
			if (qQuestionCharMemFm.test(sMf)) {
				sMf = sMf.replace(/[?]/g, "(");
			}
			var pPercentageMF = /[%]+/;
			if (pPercentageMF.test(sMf)) {
				sMf = sMf.replace(/[%]/g, ")");
			}

			/*if (sMFGCC.MemberFirm) {
				sMf = sMFGCC.MemberFirm.replace(/\s/g, "*");
			}
			if (sMFGCC.ProcessGrp) {
				sPrGrp = sMFGCC.ProcessGrp.replace(/\s/g, "*");
			}*/

			/*Start of change on 18-Feb-2020*/
			if (AttDownLoad === "fileUploader") {
				var AttachPanelID = "COP";
			} else if (AttDownLoad === "fileUploaderLOA") {
				AttachPanelID = "LOA";
			}

			/*End of change on 18-Feb-2020*/

			if (!sMFGCC.ProcessGrp) {
				sMFGCC.ProcessGrp = "";
			}
			var sPrGrp = sMFGCC.ProcessGrp;
			/*Start of change for INC01584421 by developer Prashant kumar on 22-June-2021*/
			var forwardslash = /[/]+/;
			if (forwardslash.test(sPrGrp)) {
				sPrGrp = sPrGrp.replace(/[/]/g, "|");
			}
			var qQuestionChar = /[?]+/;
			if (qQuestionChar.test(sPrGrp)) {
				sPrGrp = sPrGrp.replace(/[?]/g, "(");
			}
			var pPercentage = /[%]+/;
			if (pPercentage.test(sPrGrp)) {
				sPrGrp = sPrGrp.replace(/[%]/g, ")");
			}

			var auxArray1 = new Array();
			var that = this;
			var pdfURL = null;
			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
				json: true
			});

			var oDataQuery2 = "/AR_ATTSet(CompanyCode='" + sValue.CompanyCode + "',RrfNo='" + sValue.RrfNo +
				"',RequestingMf='" + sMFGCC.RequestingMf + "',MemberFirm='" + sMf + "',GlobalCc='" + sMFGCC.GlobalCc +
				"',Filename='" + ofileName1 + "',ProcessGrp='" +
				sPrGrp + "',CcShortDesc='" + sMFGCC.CcShortDesc + "',CopLoa='" +
				AttachPanelID + "')/$value";

			oModel1.read(oDataQuery2, null,
				null,
				false,

				function (oData, oResponse) {
					sap.ui.core.BusyIndicator.hide();
					if (oResponse) {
						sap.ui.core.BusyIndicator.hide(0);
						auxArray1 = oData;
						pdfURL = oResponse.requestUri;
						// that.showFile(oResponse.body);
					} else {
						var e = oResponse.headers;

						if (e) {
							sap.ui.core.BusyIndicator.hide(0);
							MessageBox.error("Some error has occured.");

						}
					}
				},
				function readError(e) {
					sap.ui.core.BusyIndicator.hide(0);
					var r = JSON.parse(JSON.stringify(e));
					// sap.ui.core.BusyIndicator.hide();

					MessageToast.show('No document generated', {
						autoClose: true,
						width: "20rem"
					});

				}
			);
			if (pdfURL) {

				window.open(pdfURL, "_self");
				setTimeout(function () {
					sap.ui.core.BusyIndicator.hide(0);
				}, 10000);
			} else {

				setTimeout(function () {
					sap.ui.core.BusyIndicator.hide(0);
				}, 1000);
			}

			if (sMFGCC.RequestingMf === "NA") {
				sMFGCC.RequestingMf = "N/A";
				sMFGCC.MemberFirm = "";
			}
			if (sMFGCC.GlobalCc === "NA") {
				sMFGCC.GlobalCc = "N/A";
				sMFGCC.CcShortDesc = "";
			}

		},

		//copy pdf
		// 	onPressDownloadPDF: function (oEvent) {

		// 	var busyDialog = (busyDialog) ? busyDialog : new sap.m.BusyDialog({});

		// 	busyDialog.open();

		// 	var mMasterProjectId;
		// 	var mFinancialPlanId;
		// 	var oppId;
		// 	var scenarioId;
		// 	if (this.currentTabAddOn === false) {
		// 		if (this.masterPrjId) {
		// 			mMasterProjectId = this.masterPrjId;
		// 			mFinancialPlanId = this.planId;
		// 		}
		// 		oppId = this.opportunityId;
		// 		scenarioId = oEvent.getSource().getBindingContext("oModelPricingDetails").getObject().Scenarioid;
		// 	} else {
		// 		var oModelPricingDetailsAddOn = this.getView().getModel("oModelPricingDetailsAddOn");
		// 		mMasterProjectId = oModelPricingDetailsAddOn.getProperty("/Masterprojectid");
		// 		mFinancialPlanId = oModelPricingDetailsAddOn.getProperty("/Financialplanid");
		// 		oppId = oModelPricingDetailsAddOn.getProperty("/Oppurtunityid");
		// 		scenarioId = oEvent.getSource().getBindingContext("oModelPricingDetailsAddOn").getObject().Scenarioid;
		// 	}

		// 	var auxArray1 = new Array();
		// 	var that = this;
		// 	var pdfURL = null;
		// 	var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/KGA/FIORI_CPM_SRV/", {
		// 		json: true
		// 	});

		// 	var oDataQuery2 = "/DownloadPDFContentSet(Masterprojectid='" + mMasterProjectId +
		// 		"',Financialplanid='" +
		// 		mFinancialPlanId + "',Oppurtunityid='" +
		// 		oppId + "',Scenarioid='" + scenarioId +
		// 		"')/$value";

		// 	oModel1.read(oDataQuery2, null,
		// 		null,
		// 		false,

		// 		function (oData, oResponse) {
		// 			// sap.ui.core.BusyIndicator.hide();
		// 			if (oResponse) {
		// 				auxArray1 = oData;
		// 				pdfURL = oResponse.requestUri;
		// 				// that.showFile(oResponse.body);
		// 			} else {
		// 				var e = oResponse.headers.e;
		// 				var s = oResponse.headers.s;
		// 				if (e) {
		// 					MessageToast.show(e, {
		// 						autoClose: true,
		// 						width: "20rem"

		// 					});

		// 				} else if (s) {

		// 					MessageToast.show(s, {
		// 						autoClose: true,
		// 						width: "20rem"

		// 					});
		// 				}
		// 			}
		// 		},
		// 		function readError(e) {
		// 			var r = JSON.parse(JSON.stringify(e));
		// 			// sap.ui.core.BusyIndicator.hide();

		// 			MessageToast.show('No Document generated', {
		// 				autoClose: true,
		// 				width: "20rem"
		// 			});

		// 		}
		// 	);
		// 	if (pdfURL) {
		// 		window.open(pdfURL, "_self",
		// 			"directories=no, status=no, menubar=no, scrollbars=yes, resizable=yes,width=" + window.innerWidth + ", height=" + window.innerHeight +
		// 			",top=0,left=0,titlebar=no");
		// 		setTimeout(function () {

		// 			busyDialog.close();

		// 		}, 10000);
		// 	} else {
		// 		setTimeout(function () {

		// 			busyDialog.close();

		// 		}, 1000);
		// 	}

		// },

		// showFile: function (blob) {
		// 	// // It is necessary to create a new blob object with mime-type explicitly set
		// 	// // otherwise only Chrome works like it should

		// 	var newBlob = new Blob([blob], {
		// 		type: "application/pdf"
		// 	});

		// 	var downloadFileName = this.getModel("mModelSummary").getProperty("/downloadFileName"); // Populate this field dynamically

		// 	// // IE doesn't allow using a blob object directly as link href
		// 	// // instead it is necessary to use msSaveOrOpenBlob
		// 	if (sap.ui.Device.browser.msie) {
		// 		sap.ui.Device.browser.msie(newBlob, downloadFileName);
		// 		return;
		// 	}

		// 	// // For other browsers: 
		// 	// // Create a link pointing to the ObjectURL containing the blob.
		// 	var data = window.URL.createObjectURL(newBlob);
		// 	var link = document.createElement('a');
		// 	link.href = data;
		// 	link.download = downloadFileName;

		// 	link.click();
		// 	setTimeout(function () {
		// 		// For Firefox it is necessary to delay revoking the ObjectURL
		// 		window.URL.revokeObjectURL(data);
		// 	}, 100);

		// },

		handleTypeMissmatch: function (oEvent) {
			var aFileTypes = oEvent.getSource().getFileType();
			jQuery.each(aFileTypes, function (key, value) {
				aFileTypes[key] = "*." + value;
			});
			var sSupportedFileTypes = aFileTypes.join(", ");
			MessageToast.show("The file type *." + oEvent.getParameter("fileType") +
				" is not supported. Choose one of the following types: " +
				sSupportedFileTypes);
		},
		onDeleteAttachment: function (oEvent) {
			/*Start of change on 18-Feb-2020*/
			var id = oEvent.getSource().getId();
			var idLen = oEvent.getSource().getId().length;
			var AttachSection = oEvent.getParameter("id").split("--")[2]; /*Change added for INC01499658 ON 26-APR-2021*/
			var AttachPanelID;
			/*End of change on 18-Feb-2020*/
			var oModelAttachments = this.getView().getModel("mModelSummary");
			var sValue = this.getView().getModel("mModelSummary").getProperty("/HeaderData");
			var sMFGCC = this.getView().getModel("mModelSummary").getProperty("/updateRowData");
			var sMf;
			var sPrGrp;
			if (oEvent.getParameter("item").getProperty("fileName")) {
				var fileName = oEvent.getParameter("item").getProperty("fileName").replace(/\s/g, "*");

				var ofileName1 = fileName;
				var forwardslashFile = /[/]+/;
				if (forwardslashFile.test(ofileName1)) {
					ofileName1 = ofileName1.replace(/[/]/g, "|");
				}
				var qQuestionCharFile = /[?]+/;
				if (qQuestionCharFile.test(ofileName1)) {
					ofileName1 = ofileName1.replace(/[?]/g, "(");
				}
				var pPercentageFile = /[%]+/;
				if (pPercentageFile.test(ofileName1)) {
					ofileName1 = ofileName1.replace(/[%]/g, ")");
				}
			}

			if (sMFGCC.RequestingMf === "N/A") {
				sMFGCC.RequestingMf = "NA";
				sMFGCC.MemberFirm = "";
				sMf = sMFGCC.MemberFirm;

			}

			if (sMFGCC.MemberFirm) {
				sMf = sMFGCC.MemberFirm.replace(/\s/g, "*");
				/*Start of change for INC01584421 by developer Prashant kumar on 22-June-2021*/
				var forwardslashMmfirm = /[/]+/;
				if (forwardslashMmfirm.test(sMf)) {
					sMf = sMf.replace(/[/]/g, "|");
				}
				var qQuestionCharMemFm = /[?]+/;
				if (qQuestionCharMemFm.test(sMf)) {
					sMf = sMf.replace(/[?]/g, "(");
				}
				var pPercentageMF = /[%]+/;
				if (pPercentageMF.test(sMf)) {
					sMf = sMf.replace(/[%]/g, ")");
				}
			} else if (sMFGCC.MemberFirm === "") {
				sMf = sMFGCC.MemberFirm;
			}

			if (sMFGCC.ProcessGrp) {
				sPrGrp = sMFGCC.ProcessGrp.replace(/\s/g, "*");
				/*Start of change for INC01584421 by developer Prashant kumar on 22-June-2021*/
				var forwardslash = /[/]+/;
				if (forwardslash.test(sPrGrp)) {
					sPrGrp = sPrGrp.replace(/[/]/g, "|");
				}
				var qQuestionChar = /[?]+/;
				if (qQuestionChar.test(sPrGrp)) {
					sPrGrp = sPrGrp.replace(/[?]/g, "(");
				}
				var pPercentage = /[%]+/;
				if (pPercentage.test(sPrGrp)) {
					sPrGrp = sPrGrp.replace(/[%]/g, ")");
				}

			}
			if (!sMFGCC.ProcessGrp && sMFGCC.GlobalCc) {
				sMFGCC.ProcessGrp = "";
				sPrGrp = sMFGCC.ProcessGrp;
			}
			if (sMFGCC.GlobalCc === "N/A") {
				sMFGCC.GlobalCc = "NA";

			}

			/*Start of change on 18-Feb-2020*/
			if (AttachSection === "fileUploader") {
				AttachPanelID = "COP";
			} else if (AttachSection === "fileUploaderLOA") {
				AttachPanelID = "LOA";
			}
			/*End of change on 18-Feb-2020*/
			//Attachment to delete
			var selectedAttachment = oEvent.getParameter("documentId");

			//Update Attachment list in Front End
			var attachmentArray = oModelAttachments.getProperty("/FileNameSet");
			for (var i = 0; i < attachmentArray.length; i++) {
				if (attachmentArray[i].Filename === selectedAttachment) {
					attachmentArray.splice(i, 1);
					break;
				}
			}
			oModelAttachments.setProperty("/FileNameSet", attachmentArray);
			/*Start of change on 18-Feb-2020*/
			var attachmentArrayLoa = oModelAttachments.getProperty("/FileNameLoaSet");
			for (var j = 0; j < attachmentArrayLoa.length; j++) {
				if (attachmentArrayLoa[j].Filename === selectedAttachment) {
					attachmentArrayLoa.splice(j, 1);
					break;
				}
			}
			oModelAttachments.setProperty("/FileNameLoaSet", attachmentArrayLoa);
			/*End of change on 18-Feb-2020*/

			//Backend DELETE POST call queued

			var sPath = "/AR_ATTSet(CompanyCode='" + sValue.CompanyCode + "',RrfNo='" + sValue.RrfNo +
				"',RequestingMf='" + sMFGCC.RequestingMf + "',ProcessGrp='" + sPrGrp + "',MemberFirm='" + sMf +
				"',GlobalCc='" + sMFGCC.GlobalCc + "',CcShortDesc='" + sMFGCC.CcShortDesc + "',CopLoa='" +
				AttachPanelID + "',Filename='" + ofileName1 + "')";

			if (sMFGCC.RequestingMf === "NA" && sMFGCC.GlobalCc != "NA") {
				sMFGCC.RequestingMf = "N/A";
			}
			if (sMFGCC.GlobalCc === "NA") {
				sMFGCC.GlobalCc = "N/A";
			}

			var fnUpdSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide();
				this.getView().getModel("mModelSummary").refresh(true);

			}, this);
			var fnUpdError = jQuery.proxy(function (d) {

				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();

				MessageToast.show(r, {
					autoClose: true,
					width: "20rem"
				});

			}, this);

			/*R&D---start*/
			// var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
			// 	json: true
			// });
			// oModel1.remove("/AR_ATTSet", {

			// 	success: fnUpdSuccess,
			// 	error: fnUpdError
			// });
			/*R&D---end*/

			var _oObject = {};
			_oObject.successCallback = fnUpdSuccess;
			_oObject.errorCallback = fnUpdError;
			_oObject.sPath = sPath;
			DataManagerARrecharge._deleteOData(_oObject);

		},

		handleValueChange: function (oEvent) {
			MessageToast.show("Press 'Upload File' to upload file '" +
				oEvent.getParameter("newValue") + "'");
		},

		onAttributePressOfHeaderAttachment: function (oEvent) {
			sap.ui.core.BusyIndicator.show(0);

			var ofileName = oEvent.getSource().getParent("oParent").getProperty("fileName");
			var sValue = this.getView().getModel("mModelSummary").getProperty("/HeaderData");

			var ProcessGrp = "NA";
			var GlobalCc = "NA";
			var RequestingMf = "NA";
			var MemberFirm = "";
			var CcShortDesc = "";

			var AttachPanelID = "CON";

			var auxArray1 = new Array();
			var that = this;
			var pdfURL = null;
			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
				json: true
			});

			var oDataQuery2 = "/AR_ATTSet(CompanyCode='" + sValue.CompanyCode + "',RrfNo='" + sValue.RrfNo +
				"',RequestingMf='" + RequestingMf + "',MemberFirm='" + MemberFirm + "',CcShortDesc='" + CcShortDesc + "',GlobalCc='" + GlobalCc +
				"',Filename='" + ofileName + "',ProcessGrp='" + ProcessGrp +
				"',CopLoa='" +
				AttachPanelID + "')/$value";

			oModel1.read(oDataQuery2, null,
				null,
				false,

				function (oData, oResponse) {
					sap.ui.core.BusyIndicator.hide();
					if (oResponse) {
						sap.ui.core.BusyIndicator.hide(0);
						auxArray1 = oData;
						pdfURL = oResponse.requestUri;
						// that.showFile(oResponse.body);
					} else {
						var e = oResponse.headers;

						if (e) {
							sap.ui.core.BusyIndicator.hide(0);
							MessageBox.error("Some error has occured.");

						}
					}
				},
				function readError(e) {
					sap.ui.core.BusyIndicator.hide(0);
					var r = JSON.parse(JSON.stringify(e));
					// sap.ui.core.BusyIndicator.hide();

					MessageToast.show('No document generated', {
						autoClose: true,
						width: "20rem"
					});

				}
			);
			if (pdfURL) {

				window.open(pdfURL, "_self");
				setTimeout(function () {
					sap.ui.core.BusyIndicator.hide(0);
				}, 10000);
			} else {

				setTimeout(function () {
					sap.ui.core.BusyIndicator.hide(0);
				}, 1000);
			}

		},
		onDeleteAttachmentOfHeaderAttachment: function (oEvent) {

			var AttachPanelID = "CON";
			var GlobalCc = "NA";
			var ProcessGrp = "NA";
			var RequestingMf = "NA";
			var CcShortDesc = "";
			var MemberFirm = "";
			/*End of change on 18-Feb-2020*/
			var oModelAttachments = this.getView().getModel("mModelSummary");
			var sValue = this.getView().getModel("mModelSummary").getProperty("/HeaderData");
			var sMFGCC = this.getView().getModel("mModelSummary").getProperty("/updateRowData");
			if (oEvent.getParameter("item").getProperty("fileName")) {
				var fileName = oEvent.getParameter("item").getProperty("fileName").replace(/\s/g, "*");
			}

			var selectedAttachment = oEvent.getParameter("documentId");

			//Update Attachment list in Front End
			var attachmentArray = oModelAttachments.getProperty("/FileHeaderSet");
			for (var i = 0; i < attachmentArray.length; i++) {
				if (attachmentArray[i].Filename === selectedAttachment) {
					attachmentArray.splice(i, 1);
					break;
				}
			}
			oModelAttachments.setProperty("/FileHeaderSet", attachmentArray);
			/*Start of change on 18-Feb-2020*/
			var attachmentArrayLoa = oModelAttachments.getProperty("/FileHeaderSet");
			for (var j = 0; j < attachmentArrayLoa.length; j++) {
				if (attachmentArrayLoa[j].Filename === selectedAttachment) {
					attachmentArrayLoa.splice(j, 1);
					break;
				}
			}
			oModelAttachments.setProperty("/FileNameLoaSet", attachmentArrayLoa);
			/*End of change on 18-Feb-2020*/

			//Backend DELETE POST call queued

			var sPath = "/AR_ATTSet(CompanyCode='" + sValue.CompanyCode + "',RrfNo='" + sValue.RrfNo +
				"',RequestingMf='" + RequestingMf + "',MemberFirm='" + MemberFirm + "',ProcessGrp='" + ProcessGrp + "',GlobalCc='" + GlobalCc +
				"',CopLoa='" +
				AttachPanelID + "',Filename='" + fileName + "',CcShortDesc='" + CcShortDesc +
				"')";

			var fnUpdSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide();
				this.getView().getModel("mModelSummary").refresh(true);

				this.getView().getModel("mModelSummary").setProperty("/oEditable/contractAttachEnable", false);

			}, this);
			var fnUpdError = jQuery.proxy(function (d) {

				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();

				MessageToast.show(r, {
					autoClose: true,
					width: "20rem"
				});

			}, this);

			/*R&D---start*/
			// var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
			// 	json: true
			// });
			// oModel1.remove("/AR_ATTSet", {

			// 	success: fnUpdSuccess,
			// 	error: fnUpdError
			// });
			/*R&D---end*/

			var _oObject = {};
			_oObject.successCallback = fnUpdSuccess;
			_oObject.errorCallback = fnUpdError;
			_oObject.sPath = sPath;
			DataManagerARrecharge._deleteOData(_oObject);

		},

		onPressHeaderAttachment: function (oEvent) {
			var _oHeaderAttachment = this.getView().createId("_oHeaderAttachmentFrg");
			if (!this._oHeaderAttachmentFragment) {
				this._oHeaderAttachmentFragment = sap.ui.xmlfragment(_oHeaderAttachment, "kgo.ARRecharge.view.headerAttachmentFragment", this);
				// this.rrfTablefragment = sap.ui.xmlfragment(rrfTablefragment, "kgo.ARRecharge.view.RRFTable", this);
				this.getView().addDependent(this._oHeaderAttachmentFragment);
			}
			if (this._oHeaderAttachmentFragment.isOpen()) {
				this._oHeaderAttachmentFragment.close();
			} else {
				this._oHeaderAttachmentFragment.open();
			}

		},
		onEnterGPamount: function (oEvent) {
			var mModelSummary = this.getView().getModel("mModelSummary");
			var FieldValue = oEvent.getParameter("value");
			var minimumVal = -99999999999.99;
			var maxValu = 99999999999.99;
			var sPath = oEvent.getSource().getBindingInfo("value").parts[0].path;
			var gPFields = sPath.split("/")[2];
			switch (gPFields) {
			case "BaselineCommitmentAmmount":
				if (FieldValue > minimumVal && FieldValue < maxValu) {
					mModelSummary.setProperty("/updateRowData/BaselineCommitmentAmmount", FieldValue);
				} else {
					mModelSummary.setProperty("/updateRowData/BaselineCommitmentAmmount", "");
				}
				break;

			case "Year2CommitmentAmount":
				if (FieldValue > minimumVal && FieldValue < maxValu) {
					mModelSummary.setProperty("/updateRowData/Year2CommitmentAmount", FieldValue);
				} else {
					mModelSummary.setProperty("/updateRowData/Year2CommitmentAmount", "");
				}
				break;

			case "Year3CommitmentAmount":
				if (FieldValue > minimumVal && FieldValue < maxValu) {
					mModelSummary.setProperty("/updateRowData/Year3CommitmentAmount", FieldValue);
				} else {
					mModelSummary.setProperty("/updateRowData/Year3CommitmentAmount", "");
				}
				break;

			case "Year4CommitmentAmount":
				if (FieldValue > minimumVal && FieldValue < maxValu) {
					mModelSummary.setProperty("/updateRowData/Year4CommitmentAmount", FieldValue);
				} else {
					mModelSummary.setProperty("/updateRowData/Year4CommitmentAmount", "");
				}
				break;

			case "Year5CommitmentAmount":
				if (FieldValue > minimumVal && FieldValue < maxValu) {
					mModelSummary.setProperty("/updateRowData/Year5CommitmentAmount", FieldValue);
				} else {
					mModelSummary.setProperty("/updateRowData/Year5CommitmentAmount", "");
				}
				break;
			case "Year6CommitmentAmount":
				if (FieldValue > minimumVal && FieldValue < maxValu) {
					mModelSummary.setProperty("/updateRowData/Year6CommitmentAmount", FieldValue);
				} else {
					mModelSummary.setProperty("/updateRowData/Year6CommitmentAmount", "");
				}
				break;

			}

		},

		onCloseHeaderAttachment: function (oEvent) {
			if (this._oHeaderAttachmentFragment) {
				this._oHeaderAttachmentFragment.close();
			}
		},
		onLivePODescChange: function (oEvent) {

		},
		getRemainingCharLineItem: function (value, maxLength) {

			var remainingLength = maxLength;
			if (value && value !== "") {
				var charLength = value.length;
				remainingLength = maxLength - charLength;
			}
			return remainingLength + " characters remaining";
		},
		handleLiveLongText: function (event) {
			var maxCharLimit = event.getSource().getProperty("maxLength");
			var longText = event.getParameters().value;
			if (longText.length > maxCharLimit) {
				event.getSource().setValue(longText.substring(0, maxCharLimit));
			} else {
				event.getSource().setValue(longText);
			}
		},
		onUpdateAuthSignatoryPress: function (oEvent) {
			var mModelSummary = this.getModel("mModelSummary");
			var oLineItemData = mModelSummary.getProperty("/updateRowData");
			var coonoFoundmsg = this.getModel("i18n").getProperty("coonoFound");
			var sapcodeMadtoryMsg = this.getModel("i18n").getProperty("sapcodemandatory");
			var authUpdatemsg = this.getModel("i18n").getProperty("authUpdatemsg");
			sap.ui.core.BusyIndicator.show(0);
			var oModel1 = this.getOwnerComponent().getModel();
			if (oLineItemData.SapCodeMf) {
				oModel1.callFunction(
					"/fnCOOName", {
						method: "GET",
						urlParameters: {
							"MemberFirm": oLineItemData.RequestingMf,
							"EntityName": oLineItemData.EntityName,
							"SapCustomerNumber": oLineItemData.SapCodeMf,
							"MemberFirmD": oLineItemData.MemberFirm

						},
						success: function (oData, response) {
							sap.ui.core.BusyIndicator.hide(0);
							if (!oData.CooName) {

								MessageBox.alert(coonoFoundmsg);
								return;
							} else {
								mModelSummary.setProperty("/updateRowData/LoaContact", oData.CooName);
								mModelSummary.setProperty("/updateRowData/LoaEmail", oData.CooEmailId);
								MessageBox.success(authUpdatemsg);

							}

							mModelSummary.refresh(true);

						},
						error: function (oError) {
							sap.ui.core.BusyIndicator.hide(0);
							MessageBox.alert(oError);
						}
					});
			} else {
				sap.ui.core.BusyIndicator.hide(0);
				MessageBox.alert(sapcodeMadtoryMsg);

			}

		}

	});

});