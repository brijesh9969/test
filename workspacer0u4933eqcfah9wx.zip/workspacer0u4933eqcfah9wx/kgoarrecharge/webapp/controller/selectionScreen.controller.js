sap.ui.define([
	"kgo/ARRecharge/controller/BaseController",
	"kgo/ARRecharge/util/DataManagerARrecharge",
	"sap/ui/model/Filter",
	"sap/ui/core/UIComponent",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageToast",
	"kgo/ARRecharge/formatter/formatter",
	"sap/m/MessageBox"

], function (BaseController, DataManagerARrecharge, Filter, UIComponent, FilterOperator, MessageToast, formatter, MessageBox) {
	"use strict";

	return BaseController.extend("kgo.ARRecharge.controller.selectionScreen", {
		formatter: formatter,

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf kgo.ARRecharge.view.selectionScreen
		 */
		onInit: function () {
			var oRefOdata = this.getOwnerComponent().getModel();
			var oObject = {};
			oObject.OData = oRefOdata;
			DataManagerARrecharge.init(oObject);
			/*Start of change by Debraj Date-11/6/2019*/
			var oRouter = UIComponent.getRouterFor(this);

			oRouter.getRoute("NonCoupaRRF").attachPatternMatched(this.handleRouteMatched, this);
			/*End of change by Debraj Date-11/6/2019*/

		},
		/*Start of change by Debraj Date-11/6/2019*/
		handleRouteMatched: function () {
			// Start of change by Debraj Manna on 11/11/2019
			var mModelSummary = this.getModel("mModelSummary");
			//var appTitle = this.getView().getModel("i18n").getResourceBundle().getText("NonCoupatitle");
			var disText = this.getView().getModel("i18n").getResourceBundle().getText("HDBarLblTxtDis");

		},
		/*End of change by Debraj Date-11/6/2019*/

		onCreateNewPressed: function (oEvent) {

			// this.getView().getModel("mModelSummary").setProperty("/inputdata/CreateForm", true);
			var mModelSummary = this.getModel("mModelSummary");
			this.getView().getModel("mModelSummary").setProperty("/copPoLineItemSet", []);
			this.getModel("mModelSummary").setProperty("/displayMode", false); /*Added by Saptarshi on 22-Nov-2019*/
			var avlue = this.getModel("i18n").getProperty("createRRF");
			this.getModel("mModelSummary").setProperty("/oEditable/editHeaderItem", true); /*Added on 17-Jan-2020*/
			this.getView().getModel("mModelSummary").setProperty("/oEditable/checkBox", true); /*Added on 27-Jan-2020*/
			this.getView().getModel("mModelSummary").setProperty("/oEditable/entityName", false); /*Added on 28-Janb-2020*/
			this.getView().getModel("mModelSummary").setProperty("/oEditable/entityAddress", true); /*Added on 28-Janb-2020*/
			this.getModel("mModelSummary").setProperty("/oEditable/attachVisible", false);
			this.getView().getModel("mModelSummary").setProperty("/setLineItemText");
			this.getView().getModel("mModelSummary").setProperty("/setDashBoardText", avlue);
			this.getModel("mModelSummary").setProperty("/oEditable/contractNbr", true);
			this.getModel("mModelSummary").setProperty("/oEditable/suppEdit", true);
			this.getView().getModel("mModelSummary").setProperty("/HeaderData", []);
			this.getView().getModel("mModelSummary").setProperty("/TableItemSet", []);
			this.getView().getModel("mModelSummary").setProperty("/PoTableSet", []);
			this.getModel("mModelSummary").setProperty("/oLinePoTableSet", []);
			this.getModel("mModelSummary").setProperty("/firstQuestionSet", []);
			this.getModel("mModelSummary").setProperty("/questionSet", []);
			this.getModel("mModelSummary").setProperty("/questionSetSubmit", []);
			mModelSummary.setProperty("/TRFOwnerFlag", false);
			mModelSummary.setProperty("/HeaderDataNC/CompanyCode", "");
			mModelSummary.setProperty("/oCopLoaSucesFlag", false);

			this.getCurrencySet();
			this.authoCheck();
			this.companyCodeDefaluValue();

		},
		authoCheck: function (oEvent) {
			var mModelSummary = this.getModel("mModelSummary");

			sap.ui.core.BusyIndicator.show(0);

			var aFilter = [];

			var sPath = "";
			var obj = {};
			sPath = "/RRF_DVSet"; // + Constant.CV_PV_LEAD_FIORI;

			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				obj.GpCreate = d.results[0].GpCreate;
				obj.GpEditDisplay = d.results[0].GpEditDisplay;
				obj.GfEditDisplay = d.results[0].GfEditDisplay;

				mModelSummary.setProperty("/authoSet", obj);

				mModelSummary.refresh(true);

			}, this);

			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();

				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"

				});
			}, this);
			// var sParams = {};
			// var oObject = {};

			// oObject.Filter = aFilter;
			// oObject.Params = sParams;
			// oObject.successCallback = fnSuccess;
			// oObject.errorCallback = fnError;
			// oObject.sPath = sPath;
			// DataManagerARrecharge.getCoupaReqiNumberhelpValus(oObject);
			/*R&D---start*/
			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
				json: true
			});
			oModel1.read("/RRF_DVSet", {
				success: fnSuccess,
				error: fnError
			});
			/*R&D---end*/

		},
		handleEditCoupa: function (oEvent) {
			var mModelSummary = this.getModel("mModelSummary");
			mModelSummary.setProperty("/HeaderData", []);
			mModelSummary.setProperty("/oLinePoTableSet", []);
			mModelSummary.setProperty("/FileHeaderSet", []);
			this.getModel("mModelSummary").setProperty("/firstQuestionSet", []);
			this.getModel("mModelSummary").setProperty("/questionSet", []);
			this.getModel("mModelSummary").setProperty("/questionSetSubmit", []);
			mModelSummary.setProperty("/oEditable/checkBox", true);
			mModelSummary.setProperty("/setLineItemText");
			mModelSummary.setProperty("/HeaderDataNC/CompanyCode", "");
			this.getView().getModel("mModelSummary").setProperty("/oEditable/attachmentEnable", false);
			this.getView().getModel("mModelSummary").setProperty("/oEditable/attachmentDelete", true);
			this.getModel("mModelSummary").setProperty("/oEditable/editLineItemLOA", true);
			this.getModel("mModelSummary").setProperty("/oEditable/editHeaderItem", true);
			this.getModel("mModelSummary").setProperty("/oEditable/editLineItemCop", true);
			this.getModel("mModelSummary").setProperty("/oEditable/suppEdit", true);
			mModelSummary.setProperty("/TRFOwnerFlag", false);
			mModelSummary.setProperty("/checkDisplayPress", false);
			mModelSummary.setProperty("/oCopLoaSucesFlag", false);
			var coupaPofragment = this.getView().createId("fragmentId");

			if (!this.coupaPofragment) {
				this.coupaPofragment = sap.ui.xmlfragment(coupaPofragment, "kgo.ARRecharge.view.coupaPoSelect", this);
				this.getView().addDependent(this.coupaPofragment);
			}
			if (this.coupaPofragment.isOpen()) {
				this.coupaPofragment.close();
			} else {
				this.authoCheck();
				this.coupaPofragment.open();

			}

		},
		SearchHelpOne: function (oEvent) {
			if (this.copaSelectIndexLast) {
				if (this.copaSelectIndexLast === 0) {
					this.CoupaSearchHelpOne(oEvent);
				} else if (this.copaSelectIndexLast === 1) {
					this.CoupaSearchHelpThird(oEvent);
				} else if (this.copaSelectIndexLast === 2) {
					this.CoupaSearchHelpFive(oEvent);
				} else if (this.copaSelectIndexLast === 3) {
					this.CoupaSearchHelpEight(oEvent);
				} else if (this.copaSelectIndexLast === 4) {
					this.CoupaSearchHelpFive();
				}
			} else {
				this.CoupaSearchHelpOne(oEvent);
			}
		},

		onSelect: function (oEvent) {
			// var selected = oEvent.getSource().getSelectedIndex();
			var fragmentId = this.getView().createId("fragmentId");
			var mModelSummary = this.getModel("mModelSummary");
			var x = oEvent.getParameter("selectedIndex");
			var y = oEvent.getSource().aRBs[x];
			var vLabelName = "Enter" + y.getText();
			var frag = this.coupaPofragment;
			frag.getAggregation("content")[0].getItems()[1].getItems()[0].setText(vLabelName);
			var n = frag.getAggregation("content")[0].getItems()[1].getItems()[1];

			if (x === 0) {
				sap.ui.core.Fragment.byId(fragmentId, "selectEdit").setVisible(false);
				sap.ui.core.Fragment.byId(fragmentId, "idselectok").setVisible(true);
				n.getBindingInfo("value").binding.sPath = "/HeaderData/RrfNo";
				mModelSummary.setProperty("/HeaderData/RrfNo", "");
			}
			// else if (x === 1) {

			// 	sap.ui.core.Fragment.byId(fragmentId, "selectEdit").setVisible(false);
			// 	sap.ui.core.Fragment.byId(fragmentId, "idselectok").setVisible(true);
			// 	n.getBindingInfo("value").binding.sPath = "/HeaderData/CoupaRequisitionNumber";
			// 	mModelSummary.setProperty("/HeaderData/CoupaRequisitionNumber", "");
			// }
			// } else if (x === 2) {
			// 	sap.ui.core.Fragment.byId(fragmentId, "selectEdit").setVisible(false);
			// 	sap.ui.core.Fragment.byId(fragmentId, "idselectok").setVisible(true);
			// 	n.getBindingInfo("value").binding.sPath = "/HeaderData/PoNumber";
			// 	mModelSummary.setProperty("/HeaderData/PoNumber", "");
			// } 
			else if (x === 2) {

				sap.ui.core.Fragment.byId(fragmentId, "selectEdit").setVisible(true);
				sap.ui.core.Fragment.byId(fragmentId, "idselectok").setVisible(false);
				mModelSummary.setProperty("oEditable/visibleforCC", "false");
				n.getBindingInfo("value").binding.sPath = "/RRF_SH/RrfCreator";
				mModelSummary.setProperty("/RRF_SH/RrfCreator", "");
			} else if (x === 3) {

				sap.ui.core.Fragment.byId(fragmentId, "selectEdit").setVisible(true);
				sap.ui.core.Fragment.byId(fragmentId, "idselectok").setVisible(false);
				mModelSummary.setProperty("oEditable/visibleforCC", "false");
				n.getBindingInfo("value").binding.sPath = "/RRF_SH/VendorName";
				mModelSummary.setProperty("/RRF_SH/VendorName", "");
			} else if (x === 4) {
				sap.ui.core.Fragment.byId(fragmentId, "selectEdit").setVisible(true);
				sap.ui.core.Fragment.byId(fragmentId, "idselectok").setVisible(false);
				n.getBindingInfo("value").binding.sPath = "/RRF_SH/Kostl";
				mModelSummary.setProperty("oEditable/visibleforCC", "true");
			}
			this.copaSelectIndexLast = x;

		},

		onPressEnterKey: function (oEvent) {
			var oAutho = this.getModel("mModelSummary").getProperty("/authoSet");
			if (oAutho.GpEditDisplay) {
				this.getModel("mModelSummary").setProperty("/oEditable/visibleForEdit", true);
				this.getModel("mModelSummary").setProperty("/oEditable/visibleForDisply", true);
				var sCheckValue = this.getView().getModel("mModelSummary").getProperty("/HeaderData");

				var selectedRadio = this.copaSelectIndexLast;
				if (((!selectedRadio) || selectedRadio === 0) && (oAutho.GpEditDisplay ===
						"E")) {
					this.handlePreBtnEdit();
				} else if (oEvent && (selectedRadio === 2 || selectedRadio === 3)) {
					var aText = this.getModel("i18n").getProperty("RRFNumber");
					this.getView().getModel("mModelSummary").setProperty("/setLiveSearchText", aText);
					sap.ui.core.BusyIndicator.show(0);
					var eEnterValue = oEvent.getParameter("value");
					var mModelSummary = this.getModel("mModelSummary");

					// 	if (eEnterValue) {
					// 	eEnterValue = eEnterValue.replace(/ +/g, "");

					// }
					if (eEnterValue !== "" && eEnterValue !== undefined) {
						var fnSuccess = jQuery.proxy(function (d) {
							sap.ui.core.BusyIndicator.hide();
							if (d.results.length === 0) {
								var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
								MessageBox.alert(
									"No results found.", {
										styleClass: bCompact ? "sapUiSizeCompact" : ""
									}
								);
							} else {

								for (var i = 0; i < d.results.length; i++) {
									d.results[i].RrfCreationDate = formatter.formatRrfCreationDate(d.results[i].RrfCreationDate);
								}
								mModelSummary.setSizeLimit(d.results.length);
								mModelSummary.setProperty("/RRF_SH", d.results);
								mModelSummary.refresh(true);
								var fragmentId = this.getView().createId("rrfDetail");

								if (!this._oRrfDetail) {
									this._oRrfDetail = sap.ui.xmlfragment(fragmentId, "kgo.ARRecharge.view.rrfDetail", this);
									this.getView().addDependent(this._oRrfDetail);
								}
								this.onLiveSearch();
								this._oRrfDetail.open();

							}

						}, this);
						var fnError = jQuery.proxy(function (d) {
							var r = JSON.parse(JSON.stringify(d));
							sap.ui.core.BusyIndicator.hide();

							MessageToast.show(r.message, {
								autoClose: true,
								width: "20rem"

							});
						}, this);
						var sPath = "/RRF_SHSet";
						var aFilter = [];

						var oFilterSerach;
						if (selectedRadio === 2) {

							oFilterSerach = new sap.ui.model.Filter("RrfCreator", sap.ui.model.FilterOperator.EQ, eEnterValue);
							aFilter.push(oFilterSerach);

						}
						if (selectedRadio === 3) {
							oFilterSerach = new sap.ui.model.Filter("VendorName", sap.ui.model.FilterOperator.EQ, eEnterValue);
							aFilter.push(oFilterSerach);
						}

						// var sParams = [];

						// var oObject = {};
						// oObject.Filter = aFilter;
						// oObject.Params = sParams;
						// oObject.successCallback = fnSuccess;
						// oObject.errorCallback = fnError;
						// oObject.sPath = sPath;
						// DataManagerARrecharge.getCoupaReqiNumberhelpValus(oObject);
						/*R&D---start*/
						var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
							json: true
						});
						oModel1.read("/RRF_SHSet", {
							filters: aFilter,
							success: fnSuccess,
							error: fnError
						});
						/*R&D---end*/
					} else {
						sap.ui.core.BusyIndicator.hide();
						var msg = "Please enter correct details.";
						MessageToast.show(msg);
					}
				} else {
					if (oAutho.GpEditDisplay != "E") {
						var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
						MessageBox.error(
							"You are not authorized to edit/view this RRF.", {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}
						);
					} else {
						var msg = "Please enter correct details.";
						MessageToast.show(msg);
					}
				}
			} else {
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				MessageBox.error(
					"You are not authorized to edit/view this RRF.", {
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					}
				);
			}
		},

		CoupaSearchHelpOne: function (oEvent) {
			var mModelSummary = this.getModel("mModelSummary");

			sap.ui.core.BusyIndicator.show(0);

			var aFilter = [];
			var mArrayOut = [];

			var sPath = "";

			sPath = "/RRF_NOSet"; // + Constant.CV_PV_LEAD_FIORI;

			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				mModelSummary = this.getModel("mModelSummary");
				for (var i = 0; i < d.results.length; i++) {
					var oRRFNumber = {};

					oRRFNumber.RrfNo = d.results[i].RrfNo;
					oRRFNumber.RrfDesc = d.results[i].RrfDesc;
					if (d.results[i].RrfCreationDate) {
						oRRFNumber.RrfCreationDate = formatter.formatRrfCreationDate(d.results[i].RrfCreationDate);
					}
					mArrayOut.push(oRRFNumber);
				}

				mModelSummary.setProperty("/RRF_NOSet", mArrayOut);

				mModelSummary.refresh(true);
				var fragmentId = this.getView().createId("rrfCoupaReqNofrg");

				if (!this.coupaFrgOne) {
					this.coupaFrgOne = sap.ui.xmlfragment(fragmentId, "kgo.ARRecharge.view.searchHelpCoupOne", this);
					this.getView().addDependent(this.coupaFrgOne);
				}

				this.onSearchRRFNumber();

				this.coupaFrgOne.open();
			}, this);

			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();

				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"

				});
			}, this);
			// var sParams = {};
			// var oObject = {};

			// oObject.Filter = aFilter;
			// oObject.Params = sParams;
			// oObject.successCallback = fnSuccess;
			// oObject.errorCallback = fnError;
			// oObject.sPath = sPath;
			// DataManagerARrecharge.getCoupaReqiNumberhelpValus(oObject);
			/*R&D---start*/
			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
				json: true
			});
			oModel1.read("/RRF_NOSet", {
				success: fnSuccess,
				error: fnError
			});
			/*R&D---end*/

		},
		CoupaSearchHelpTwo: function (oEvent) {
			var mModelSummary = this.getModel("mModelSummary");
			if (mModelSummary.getProperty("/HeaderData/CoupaReqNumber")) {
				var cRechargeeqNumber = mModelSummary.getProperty("/HeaderData/RechargeeqNumber");
			} else {
				cRechargeeqNumber = "";
			}

			var sSrchVal = cRechargeeqNumber;
			// var fragmentId = this.getView().createId("searchCoordinator");
			sap.ui.core.BusyIndicator.show(0);

			var aFilter = [];
			var mArrayOut = [];

			var oFilter;
			var sPath = "";

			sPath = "/RRF_GLSet  "; // + Constant.CV_PV_LEAD_FIORI;

			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				mModelSummary = this.getModel("mModelSummary");

				mModelSummary.setProperty("/RRF_GLSet", d.results);

				mModelSummary.refresh(true);
				var fragmentId = this.getView().createId("reqNumberWoc");

				if (!this.oReqNumberWithoutCoupa) {
					this.oReqNumberWithoutCoupa = sap.ui.xmlfragment(fragmentId, "kgo.ARRecharge.view.searchHelpRRFSecond", this);
					this.getView().addDependent(this.oReqNumberWithoutCoupa);
				}

				this.oReqNumberWithoutCoupa.open();
			}, this);

			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();

				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"

				});
			}, this);
			// var sParams = {};
			// var oObject = {};

			// oObject.Filter = aFilter;
			// oObject.Params = sParams;
			// oObject.successCallback = fnSuccess;
			// oObject.errorCallback = fnError;
			// oObject.sPath = sPath;
			// DataManagerARrecharge.getCoupaReqiNumberhelpValus(oObject);
			/*R&D---start*/
			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
				json: true
			});
			oModel1.read("/RRF_GLSet", {
				success: fnSuccess,
				error: fnError
			});
			/*R&D---end*/
		},
		CoupaSearchHelpThird: function (oEvent) {

			var mModelSummary = this.getModel("mModelSummary");

			sap.ui.core.BusyIndicator.show(0);

			var aFilter = [];
			var mArrayOut = [];

			var sPath = "";

			sPath = "/RRF_CoupaReqNoSet "; // + Constant.CV_PV_LEAD_FIORI;

			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				mModelSummary = this.getModel("mModelSummary");
				for (var i = 0; i < d.results.length; i++) {
					var oCoupaReqNumber = {};
					oCoupaReqNumber.CoupaRequisitionNumber = d.results[i].CoupaRequisitionNumber;
					oCoupaReqNumber.RrfNo = d.results[i].RrfNo;
					oCoupaReqNumber.RrfDesc = d.results[i].RrfDesc;
					if (d.results[i].CoupaRequisitionDate) {
						oCoupaReqNumber.CoupaRequisitionDate = formatter.formatRrfCreationDate(d.results[i].CoupaRequisitionDate);
					}
					mArrayOut.push(oCoupaReqNumber);
				}

				mModelSummary.setProperty("/RRF_CoupaReqNoSet", mArrayOut);

				mModelSummary.refresh(true);
				var fragmentId = this.getView().createId("searchHelpCoupaReqNo");

				if (!this.oCoupaReqNumberfrg) {
					this.oCoupaReqNumberfrg = sap.ui.xmlfragment(fragmentId, "kgo.ARRecharge.view.searchHelpCoupaReqNoThird", this);
					this.getView().addDependent(this.oCoupaReqNumberfrg);
				}
				this.onSearchCoupaRequisitionNbr();
				this.oCoupaReqNumberfrg.open();
			}, this);

			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();

				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"

				});
			}, this);
			// var sParams = {};
			// var oObject = {};

			// oObject.Filter = aFilter;
			// oObject.Params = sParams;
			// oObject.successCallback = fnSuccess;
			// oObject.errorCallback = fnError;
			// oObject.sPath = sPath;
			// DataManagerARrecharge.getCoupaReqiNumberhelpValus(oObject);
			/*R&D---start*/
			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
				json: true
			});
			oModel1.read("/RRF_CoupaReqNoSet", {
				success: fnSuccess,
				error: fnError
			});
			/*R&D---end*/
		},
		CoupaSearchHelpFive: function (oEvent) { //RRF Created by
			var mModelSummary = this.getModel("mModelSummary");

			mModelSummary.setProperty("/oEditable/visibleForEdit", true);
			mModelSummary.setProperty("/oEditable/visibleForDisply", true);
			var aText;
			var sButtonIndex = this.copaSelectIndexLast;
			switch (sButtonIndex) {
			case 3:
				aText = this.getModel("i18n").getProperty("RRFCreatedBy");
				mModelSummary.setProperty("/setLiveSearchText", aText);
				break;
			case 4:
				aText = this.getModel("i18n").getProperty("CostCenter");
				mModelSummary.setProperty("/setLiveSearchText", aText);
				break;
			}

			sap.ui.core.BusyIndicator.show(0);

			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				/*Start change on 02-Jan-2020*/
				for (var i = 0; i < d.results.length; i++) {
					d.results[i].RrfCreationDate = formatter.formatRrfCreationDate(d.results[i].RrfCreationDate);
				}
				/*End change on 02-Jan-2020*/
				mModelSummary.setSizeLimit(d.results.length);
				mModelSummary.setProperty("/RRF_SH", d.results);
				mModelSummary.refresh(true);
				var fragmentId = this.getView().createId("rrfDetail");

				if (!this._oRrfDetail) {
					this._oRrfDetail = sap.ui.xmlfragment(fragmentId, "kgo.ARRecharge.view.rrfDetail", this);
					this.getView().addDependent(this._oRrfDetail);
				}
				this.onLiveSearch();
				this._oRrfDetail.open();
			}, this);

			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();

				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"

				});
			}, this);
			// var sParams = {};
			// var oObject = {};

			// oObject.Filter = aFilter;
			// oObject.Params = sParams;
			// oObject.successCallback = fnSuccess;
			// oObject.errorCallback = fnError;
			// oObject.sPath = sPath;
			// DataManagerARrecharge.getCoupaReqiNumberhelpValus(oObject);
			/*R&D---start*/
			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
				json: true
			});
			oModel1.read("/RRF_SHSet", {
				success: fnSuccess,
				error: fnError
			});
			/*R&D---end*/
		},
		
		CoupaSearchHelpSix: function (oEvent) { //RRF Creation Date
			var aText = this.getModel("i18n").getProperty("RRFCreationDate");
			this.getView().getModel("mModelSummary").setProperty("/setLiveSearchText", aText);
			var mModelSummary = this.getModel("mModelSummary");
			var sRrfNumber;
			var dRrfCreationDate;
			if (mModelSummary.getProperty("/RRF_SH/RrfCreationDate")) {
				sRrfNumber = mModelSummary.getProperty("/RRF_SH/RrfNo");
				dRrfCreationDate = mModelSummary.getProperty("/RRF_SH/RrfCreationDate");
			} else {
				sRrfNumber = "";
				dRrfCreationDate = "";
			}
			sap.ui.core.BusyIndicator.show(0);
			var aFilter = [];
			var sPath = "";
			sPath = "/RRF_SHSet ";
			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				/*Start change on 02-Jan-2020*/
				for (var i = 0; i < d.results.length; i++) {
					d.results[i].RrfCreationDate = formatter.formatRrfCreationDate(d.results[i].RrfCreationDate);
				}
				/*End change on 02-Jan-2020*/
				mModelSummary.setSizeLimit(d.results.length);
				mModelSummary.setProperty("/RRF_SH", d.results);
				mModelSummary.refresh(true);
				var fragmentId = this.getView().createId("rrfDetail");

				if (!this._oRrfDetail) {
					this._oRrfDetail = sap.ui.xmlfragment(fragmentId, "kgo.ARRecharge.view.rrfDetail", this);
					this.getView().addDependent(this._oRrfDetail);
				}

				this._oRrfDetail.open();
			}, this);

			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();

				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"

				});
			}, this);
			// var sParams = {};
			// var oObject = {};

			// oObject.Filter = aFilter;
			// oObject.Params = sParams;
			// oObject.successCallback = fnSuccess;
			// oObject.errorCallback = fnError;
			// oObject.sPath = sPath;
			// DataManagerARrecharge.getCoupaReqiNumberhelpValus(oObject);
			/*R&D---start*/
			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
				json: true
			});
			oModel1.read("/RRF_SHSet", {
				success: fnSuccess,
				error: fnError
			});
			/*R&D---end*/
		},
		CoupaSearchHelpEight: function (oEvent) { //Vendor Name
			this.getModel("mModelSummary").setProperty("/oEditable/visibleForEdit", true);
			this.getModel("mModelSummary").setProperty("/oEditable/visibleForDisply", true);
			var aText = this.getModel("i18n").getProperty("Vendor");
			this.getView().getModel("mModelSummary").setProperty("/setLiveSearchText", aText);
			var mModelSummary = this.getModel("mModelSummary");
			var sVendorName;
			var sRrfNumber;
			if (mModelSummary.getProperty("/RRF_SH/VendorName")) {
				sRrfNumber = mModelSummary.getProperty("/RRF_SH/RrfNo");
				sVendorName = mModelSummary.getProperty("/RRF_SH/VendorName");
			} else {
				sRrfNumber = "";
				sVendorName = "";
			}
			sap.ui.core.BusyIndicator.show(0);
			var aFilter = [];
			var sPath = "";
			sPath = "/RRF_SHSet ";

			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				/*Start change on 02-Jan-2020*/
				for (var i = 0; i < d.results.length; i++) {
					d.results[i].RrfCreationDate = formatter.formatRrfCreationDate(d.results[i].RrfCreationDate);
				}
				/*End change on 02-Jan-2020*/
				mModelSummary.setSizeLimit(d.results.length);
				mModelSummary.setProperty("/RRF_SH", d.results);

				mModelSummary.refresh(true);
				var fragmentId = this.getView().createId("rrfDetail");

				if (!this._oRrfDetail) {
					this._oRrfDetail = sap.ui.xmlfragment(fragmentId, "kgo.ARRecharge.view.rrfDetail", this);
					this.getView().addDependent(this._oRrfDetail);
				}
				this.onLiveSearch();
				this._oRrfDetail.open();
			}, this);

			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();

				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"

				});
			}, this);
			// var sParams = {};
			// var oObject = {};

			// oObject.Filter = aFilter;
			// oObject.Params = sParams;
			// oObject.successCallback = fnSuccess;
			// oObject.errorCallback = fnError;
			// oObject.sPath = sPath;
			// DataManagerARrecharge.getCoupaReqiNumberhelpValus(oObject);
			/*R&D---start*/
			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
				json: true
			});
			oModel1.read("/RRF_SHSet", {
				success: fnSuccess,
				error: fnError
			});
			/*R&D---end*/
		},

		onCoupaSCloseSecond: function () {
			if (this.oReqNumberWithoutCoupa.isOpen()) {
				this.oReqNumberWithoutCoupa.close();
			}
		},
		onCoupaCloseThird: function () {
			if (this.oCoupaReqNumberfrg.isOpen()) {
				this.oCoupaReqNumberfrg.close();
			}
		},
		onCoupatCloseOne: function () {
			if (this.coupaFrgOne.isOpen()) {
				// var aFilter;
				this.getView().getModel("mModelSummary").setProperty("/filterSearch", "");
				// 	var table = sap.ui.core.Fragment.byId(searchHelpRRFNoOne, "tableIdForRrfSearch");

				// 	var oBinding = table.getBinding("items");
				// 	oBinding.filter(aFilter, "Application");
				this.coupaFrgOne.close();
			}
		},

		// =======
		// >>>>>>> refs/remotes/origin/master
		handlePressbtnCancel: function (oEvent) {
			/*Start of change by Saptarshi on 13-Nov-2019*/
			var fragmentId = this.getView().createId("fragmentId");
			sap.ui.core.Fragment.byId(fragmentId, "inputValueHelp").setValue("");
			/*End of change by Saptarshi 0n 13-Nov-2019*/
			if (this.coupaPofragment.isOpen()) {
				this.coupaPofragment.close();
			}
		},
		onCreateNewNonCopaPressed: function (oEvent) {
			var mModelSummary = this.getModel("mModelSummary");
			mModelSummary.setProperty("/HeaderData/CompanyCode", "");
			this.getView().getModel("mModelSummary").setProperty("/oEditableNC/visibleForDisplyGf", false); /*Added on 17-Jan-2020*/
			this.getModel("mModelSummary").setProperty("/displayMode", false); /*Added by Saptarshi on 22-Nov-2019*/
			this.getModel("mModelSummary").setProperty("/oEditableNC/attachVisibleNC", false);
			this.getView().getModel("mModelSummary").setProperty("/setLineItemText");
			this.getView().getModel("mModelSummary").setProperty("/oEditableNC/checkBox", true); /*Added on 27-Jan-2020*/
			this.getView().getModel("mModelSummary").setProperty("/oEditableNC/entityName", false); /*Added on 28-Janb-2020*/
			this.getView().getModel("mModelSummary").setProperty("/oEditableNC/entityAddress", true); /*Added on 28-Janb-2020*/
			this.getModel("mModelSummary").setProperty("/oEditableNC/editHeaderItem", true);
			this.getView().getModel("mModelSummary").setProperty("/HeaderDataNC", []); /*Changed by Saptarshi on 7th-Nov-2019*/
			this.getView().getModel("mModelSummary").setProperty("/oEditableNC/enableLOA", false); /*Defect 63146*/
			this.getView().getModel("mModelSummary").setProperty("/oEditableNC/enableCOP", false); /*Defect 63146*/
			this.getView().getModel("mModelSummary").setProperty("/TableItemSetNC", []); /*Changed by Saptarshi on 7th-Nov-2019*/
			this.getView().getModel("mModelSummary").setProperty("/nPquestionSetFirst", []);
			this.getView().getModel("mModelSummary").setProperty("/nPquestionSet", []);
			this.getView().getModel("mModelSummary").setProperty("/nPQuestionSetSubmit", []);
			var sHdrLbl = this.getModel("i18n").getProperty("HDBarLblTxt");
			mModelSummary.setProperty("/oEditableNC/companyCodeEdit", true); //added by prashant 14.08.2020
			mModelSummary.setProperty("/TRFOwnerFlagNP", false);
			mModelSummary.setProperty("/NonCopaHdrLbl", sHdrLbl);

			this.getCurrencySet(); /*Added on 02-Jan-2020*/
			this.authoCheck();

			if (mModelSummary.getProperty("/HeaderDataNC/CoupaReqNumber")) { /*Changed by Saptarshi on 7th-Nov-2019*/
				var oRRFDefaultValue = mModelSummary.getProperty("/HeaderDataNC/oRRFDefaultValue"); /*Changed by Saptarshi on 7th-Nov-2019*/
			} else {
				oRRFDefaultValue = "";
			}

			var sSrchVal = oRRFDefaultValue;

			var aFilter = [];
			var mArrayOut = [];

			var oFilter;
			var sPath = "";
			var obj = {};
			sPath = "/RRF_DVSet"; // + Constant.CV_PV_LEAD_FIORI;

			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				for (var i = 0; i < d.results.length; i++) {
					mModelSummary = this.getModel("mModelSummary");

					obj.CompanyCode = d.results[i].CompanyCode;
					obj.oDfaultCompanyCodeNP = d.results[i].CompanyCode;
					obj.RrfStatus = d.results[i].RrfStatus;
					obj.Currency = d.results[i].Currency;
					obj.GfCreate = d.results[i].GfCreate; /*Added on 20-Jan-2020*/
					mModelSummary.setProperty("/HeaderDataNC", obj);
					if (obj.GfCreate === true) { /*Added on 20-Jan-2020*/
						var oRouter = UIComponent.getRouterFor(this);
						oRouter.navTo("NonCoupaRRF", {
							No: obj.CompanyCode
						});
						/*Start of change on 20-Jan-2020*/
					} else {
						var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
						var msg = this.getView().getModel("i18n").getProperty("CreatAuthGF");
						MessageBox.error(
							msg, {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}
						);
					}
					/*End of change on 20-Jan-2020*/
				}

				mModelSummary.refresh(true);

			}, this);

			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();

				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"

				});
			}, this);
			// var sParams = {};
			// var oObject = {};

			// oObject.Filter = aFilter;
			// oObject.Params = sParams;
			// oObject.successCallback = fnSuccess;
			// oObject.errorCallback = fnError;
			// oObject.sPath = sPath;
			// DataManagerARrecharge.getNonCoupaReqhelpValue(oObject);
			/*R&D---start*/
			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
				json: true
			});
			oModel1.read("/RRF_DVSet", {
				success: fnSuccess,
				error: fnError
			});
			/*R&D---end*/

		},
		handleEditNonCoupa: function (oEvent) {
			var mModelSummary = this.getView().getModel("mModelSummary");
			this.getModel("mModelSummary").setProperty("/GF_SH", []); /*Change added by Saptarshi on 7th-Nov-2019*/
			mModelSummary.setProperty("/HeaderDataNC", []); /*Added for 63097 on 31-Jan-2020*/
			mModelSummary.setProperty("/nPquestionSetFirst", []);
			mModelSummary.setProperty("/nPquestionSet", []);
			this.getView().getModel("mModelSummary").setProperty("/nPQuestionSetSubmit", []);
			var editNonCoupafrg = this.getView().createId("fragmentId");
			mModelSummary.setProperty("/setLineItemText");
			mModelSummary.setProperty("/oEditableNC/checkBox", true);
			mModelSummary.setProperty("/oEditableNC/attachAddButton", false);
			mModelSummary.setProperty("/oEditableNC/deleteBtnAttchment", true);
			mModelSummary.setProperty("/HeaderData/CompanyCode", "");
			mModelSummary.setProperty("/checkDisplayPressNP", false);
			mModelSummary.setProperty("/TRFOwnerFlagNP", false);

			if (!this.editNonCoupafrg) {
				this.editNonCoupafrg = sap.ui.xmlfragment(editNonCoupafrg, "kgo.ARRecharge.view.editNonCoupaRRf", this);
				this.getView().addDependent(this.editNonCoupafrg);
			}
			if (this.editNonCoupafrg.isOpen()) {
				this.editNonCoupafrg.close();
			} else {
				this.authoCheck();
				this.editNonCoupafrg.open();

			}
		},
		handleCancelforNonCoupa: function () {
			if (this.editNonCoupafrg.isOpen()) {
				this.editNonCoupafrg.close();
			}
		},
		onSelectNonCoupa: function (oEvent) {
			var mModelSummary = this.getModel("mModelSummary");
			var iIndex = oEvent.getParameters().selectedIndex;
			var sLabelName = "Enter " + oEvent.getSource().aRBs[iIndex].getText();
			var frag = this.editNonCoupafrg;
			frag.getAggregation("content")[0].getItems()[1].getItems()[0].setText(sLabelName);
			var n = frag.getAggregation("content")[0].getItems()[1].getItems()[1];
			if (iIndex !== undefined) { /*changed by Saptarshi on 7th-Nov-2019*/
				if (iIndex === 0) {
					n.getBindingInfo("value").binding.sPath = "/GF_SH/RrfNoGf";
					mModelSummary.setProperty("/GF_SH/RrfNoGf", "");
				} else if (iIndex === 1) {
					n.getBindingInfo("value").binding.sPath = "/GF_SH/CreatedBy";
					mModelSummary.setProperty("/GF_SH/CreatedBy", "");
					mModelSummary.setProperty("/oEditableNC/costCenterEdit", true);
				} else if (iIndex === 2) {
					n.getBindingInfo("value").binding.sPath = "/GF_SH/CreatedBy";
					mModelSummary.setProperty("/GF_SH/CreatedBy", "");
					mModelSummary.setProperty("/oEditableNC/costCenterEdit", true);
				}
			} else { /*Start of change added by Saptarshi on 7th-Nov-2019*/
				n.getBindingInfo("value").binding.sPath = "/GF_SH/RrfNoGf";
				mModelSummary.setProperty("/GF_SH/RrfNoGf", "");
			} /*End of change added by Saptarshi on 7th-Nov-2019*/
			this.radioIndex = iIndex;
		},
		SearchHelpNonCoupa: function (oEvent) {
			if (this.radioIndex !== undefined) {
				if (this.radioIndex === 0) {
					this.valueHelpOne(oEvent);
				} else if (this.radioIndex === 1) {
					this.valueHelpTwo(oEvent);
				} else if (this.radioIndex === 2) {
					this.valueHelpThree(oEvent);
				} else if (this.radioIndex === 3) {
					this.valueHelpFour(oEvent);
				}
			} else {
				this.valueHelpOne(oEvent);
			}
		},
		valueHelpOne: function (oEvent) {
			this.getView().getModel("mModelSummary").setProperty("/oEditableNC/visibleForEditGf", true);
			this.getView().getModel("mModelSummary").setProperty("/oEditableNC/visibleForDisplyGf", true);
			var mModelSummary = this.getModel("mModelSummary");
			var iIrfNumber;
			var sIrfDesc;
			var dIrfDate;
			var sPlaceHolder = this.getView().getModel("i18n").getProperty("RBNCTxt1"); /*Added on 09-Jan-2020*/
			if (mModelSummary.getProperty("/GF_SH/RrfNoGf")) {
				iIrfNumber = mModelSummary.getProperty("/GF_SH/RrfNoGf");
				sIrfDesc = mModelSummary.getProperty("/GF_SH/GfDesc");
				dIrfDate = mModelSummary.getProperty("/GF_SH/CreatedOn");
			} else {
				iIrfNumber = "";
				sIrfDesc = "";
				dIrfDate = "";
			}
			sap.ui.core.BusyIndicator.show(0);
			var aFilter = [];
			var sPath = "";
			sPath = "/GF_NOSet";
			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				/*Start change on 02-Jan-2020*/
				for (var i = 0; i < d.results.length; i++) {
					d.results[i].CreatedOn = formatter.formatRrfCreationDate(d.results[i].CreatedOn);
				}
				/*End change on 02-Jan-2020*/
				mModelSummary.setProperty("/GF_NOSet", d.results);
				mModelSummary.refresh(true);
				var fragmentId = this.getView().createId("helpIRFOne");
				if (!this._oHelpIRFOne) {
					this._oHelpIRFOne = sap.ui.xmlfragment(fragmentId, "kgo.ARRecharge.view.helpIRFOne", this);
					this.getView().addDependent(this._oHelpIRFOne);
				}
				/*Start of change on 09-Jan-2020*/
				if (sap.ui.core.Fragment.byId(fragmentId, "searchFieldIrf")) {
					sap.ui.core.Fragment.byId(fragmentId, "searchFieldIrf").setPlaceholder(sPlaceHolder);
				}
				/*End of change on 09-Jan-2020*/
				this._oHelpIRFOne.open();
			}, this);
			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();
				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"
				});
			}, this);
			// var sParams = {};
			// var oObject = {};
			// oObject.Filter = aFilter;
			// oObject.Params = sParams;
			// oObject.successCallback = fnSuccess;
			// oObject.errorCallback = fnError;
			// oObject.sPath = sPath;
			// DataManagerARrecharge.getNonCoupaReqhelpValue(oObject);
			/*R&D---start*/
			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
				json: true
			});
			oModel1.read("/GF_NOSet", {
				success: fnSuccess,
				error: fnError
			});
			/*R&D---end*/
		},
		valueHelpTwo: function (oEvent) { //RRF Created by for Non-Coupa
			var mModelSummary = this.getModel("mModelSummary");

			var sPlaceHolder;
			mModelSummary.setProperty("/oEditableNC/visibleForEditGf", true);
			mModelSummary.setProperty("/oEditableNC/visibleForDisplyGf", true);
			mModelSummary.setProperty("/oEditableNC/costCenterEdit", false);

			sPlaceHolder = this.getView().getModel("i18n").getProperty("RBNCTxt2"); /*Added on 09-Jan-2020*/
			mModelSummary.setProperty("/textSet", sPlaceHolder);

			sap.ui.core.BusyIndicator.show(0);

			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				/*Start change on 02-Jan-2020*/
				for (var i = 0; i < d.results.length; i++) {
					d.results[i].CreatedOn = formatter.formatRrfCreationDate(d.results[i].CreatedOn);
				}
				/*End change on 02-Jan-2020*/
				mModelSummary.setProperty("/GF_SH", d.results);
				mModelSummary.refresh(true);
				var fragmentId = this.getView().createId("irfDetail");
				if (!this._oIrfDetail) {
					this._oIrfDetail = sap.ui.xmlfragment(fragmentId, "kgo.ARRecharge.view.irfDetail", this);
					this.getView().addDependent(this._oIrfDetail);
				}
				/*Start of change on 09-Jan-2020*/
				if (sap.ui.core.Fragment.byId(fragmentId, "seachBar")) {
					sap.ui.core.Fragment.byId(fragmentId, "seachBar").setPlaceholder(sPlaceHolder);
				}
				/*End of change on 09-Jan-2020*/
				this._oIrfDetail.open();
			}, this);
			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();
				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"
				});
			}, this);
			// var sParams = {};
			// var oObject = {};
			// oObject.Filter = aFilter;
			// oObject.Params = sParams;
			// oObject.successCallback = fnSuccess;
			// oObject.errorCallback = fnError;
			// oObject.sPath = sPath;
			// DataManagerARrecharge.getNonCoupaReqhelpValue(oObject);
			/*R&D---start*/
			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
				json: true
			});
			oModel1.read("/GF_NOSet", {
				success: fnSuccess,
				error: fnError
			});
			/*R&D---end*/
		},
		valueHelpThree: function (oEvent) { //RRF Creation Date for Non-Coupa
			var mModelSummary = this.getModel("mModelSummary");
			var sPlaceHolder = this.getView().getModel("i18n").getProperty("CostCenter"); /*Added on 09-Jan-2020*/
			mModelSummary.setProperty("/textSet", sPlaceHolder);
			mModelSummary.setProperty("/oEditableNC/visibleForDisplyGf", true);
			mModelSummary.setProperty("/oEditableNC/visibleForEditGf", true);
			mModelSummary.setProperty("/oEditableNC/costCenterEdit", true);

			sap.ui.core.BusyIndicator.show(0);

			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				/*Start change on 02-Jan-2020*/
				for (var i = 0; i < d.results.length; i++) {
					d.results[i].CreatedOn = formatter.formatRrfCreationDate(d.results[i].CreatedOn);
				}
				/*End change on 02-Jan-2020*/
				mModelSummary.setProperty("/GF_SH", d.results);
				mModelSummary.refresh(true);
				var fragmentId = this.getView().createId("irfDetail");
				if (!this._oIrfDetail) {
					this._oIrfDetail = sap.ui.xmlfragment(fragmentId, "kgo.ARRecharge.view.irfDetail", this);
					this.getView().addDependent(this._oIrfDetail);
				}

				this._oIrfDetail.open();
			}, this);
			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();
				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"
				});
			}, this);
			// var sParams = {};
			// var oObject = {};
			// oObject.Filter = aFilter;
			// oObject.Params = sParams;
			// oObject.successCallback = fnSuccess;
			// oObject.errorCallback = fnError;
			// oObject.sPath = sPath;
			// DataManagerARrecharge.getNonCoupaReqhelpValue(oObject);
			/*R&D---start*/
			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
				json: true
			});
			oModel1.read("/GF_SHSet", {
				success: fnSuccess,
				error: fnError
			});
			/*R&D---end*/
		},
		valueHelpFour: function (oEvent) { //Cost Center for non-coupa
			var mModelSummary = this.getModel("mModelSummary");
			var sIrfNumber;
			var iCostCenter;
			if (mModelSummary.getProperty("/GF_SH/CoupaCc")) {
				sIrfNumber = mModelSummary.getProperty("/GF_SH/RrfNoGf");
				iCostCenter = mModelSummary.getProperty("/GF_SH/CoupaCc");
			} else {
				sIrfNumber = "";
				iCostCenter = "";
			}
			sap.ui.core.BusyIndicator.show(0);
			var aFilter = [];
			var sPath = "";
			sPath = "/GF_NOSet";
			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				/*Start change on 02-Jan-2020*/
				for (var i = 0; i < d.results.length; i++) {
					d.results[i].CreatedOn = formatter.formatRrfCreationDate(d.results[i].CreatedOn);
				}
				/*End change on 02-Jan-2020*/
				mModelSummary.setProperty("/GF_SH", d.results);
				mModelSummary.refresh(true);
				var fragmentId = this.getView().createId("irfDetail");
				if (!this._oIrfDetail) {
					this._oIrfDetail = sap.ui.xmlfragment(fragmentId, "kgo.ARRecharge.view.irfDetail", this);
					this.getView().addDependent(this._oIrfDetail);
				}
				this._oIrfDetail.open();
			}, this);
			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();
				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"
				});
			}, this);
			// var sParams = {};
			// var oObject = {};
			// oObject.Filter = aFilter;
			// oObject.Params = sParams;
			// oObject.successCallback = fnSuccess;
			// oObject.errorCallback = fnError;
			// oObject.sPath = sPath;
			// DataManagerARrecharge.getNonCoupaReqhelpValue(oObject);
			/*R&D---start*/
			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
				json: true
			});
			oModel1.read("/GF_NOSet", {
				success: fnSuccess,
				error: fnError
			});
			/*R&D---end*/
		},

		onCloseOne: function () {
			/*start of change by Saptarshi on 13-Nov-2019*/
			var fragId = this.getView().createId("helpIRFOne");
			var SearchId = sap.ui.core.Fragment.byId(fragId, "searchFieldIrf");
			SearchId.setValue("");
			var aFilter = [];
			aFilter.push(new Filter("RrfNoGf", FilterOperator.Contains, ""));
			var frag = this.getView().createId("helpIRFOne");
			var table = sap.ui.core.Fragment.byId(frag, "irfNumTbl");
			var oBinding = table.getBinding("items");
			oBinding.filter(aFilter, "Application");
			/*End of change by Saptarshi on 13-Nov-2019*/
			if (this._oHelpIRFOne.isOpen()) {
				this._oHelpIRFOne.close();

			}
		},
		/*Start of change on 07-Jan-2020*/
		onPressEnterKeyNC: function (oEvent) {
			var oAutho = this.getModel("mModelSummary").getProperty("/authoSet");
			if (oAutho.GfEditDisplay) {
				this.getModel("mModelSummary").setProperty("/oEditableNC/visibleForEditGf", true);
				this.getModel("mModelSummary").setProperty("/oEditableNC/visibleForDisplyGf", true); /*Changed on 28-Jan-2020*/
				var sCheckValue = this.getView().getModel("mModelSummary").getProperty("/HeaderDataNC");
				var eEnterValue = oEvent.getParameter("value");
				if (eEnterValue !== "" && eEnterValue !== undefined) {
					sap.ui.core.BusyIndicator.show(0);
					var mModelSummary = this.getModel("mModelSummary");
					var iButtonNum = this.radioIndex;

					if (iButtonNum === 0 || iButtonNum === undefined) {
						if (oAutho.GfEditDisplay === "E") {
							this.editNonCoupa();
						} else if (oAutho.GfEditDisplay === "D") {
							sap.ui.core.BusyIndicator.hide(0);
							var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
							MessageBox.error(
								"You are not authorized to edit/view this RRF.", {
									styleClass: bCompact ? "sapUiSizeCompact" : ""
								}
							);
						}

					} else if (iButtonNum === 1) {
						var fnSuccess = jQuery.proxy(function (d) {
							sap.ui.core.BusyIndicator.hide(0);
							if (d.results.length === 0) {
								var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
								MessageBox.alert(
									"No results found.", {
										styleClass: bCompact ? "sapUiSizeCompact" : ""
									}
								);
							} else {
								for (var i = 0; i < d.results.length; i++) {
									d.results[i].CreatedOn = formatter.formatRrfCreationDate(d.results[i].CreatedOn);
								}
								mModelSummary.setProperty("/GF_SH", d.results);
								mModelSummary.refresh(true);
								var fragmentId = this.getView().createId("irfDetail");
								if (!this._oIrfDetail) {
									this._oIrfDetail = sap.ui.xmlfragment(fragmentId, "kgo.ARRecharge.view.irfDetail", this);
									this.getView().addDependent(this._oIrfDetail);
								}
								this._oIrfDetail.open();
							}
						}, this);
						var fnError = jQuery.proxy(function (d) {
							var r = JSON.parse(JSON.stringify(d));
							sap.ui.core.BusyIndicator.hide();

							MessageToast.show(r.message, {
								autoClose: true,
								width: "20rem"

							});
						}, this);
						var sPath = "/GF_SHSet";
						var aFilter = [];

						var oFilterSerach;
						if (iButtonNum === 1) {

							oFilterSerach = new sap.ui.model.Filter("CreatedBy", sap.ui.model.FilterOperator.EQ, eEnterValue);
							aFilter.push(oFilterSerach);

						}
						// var sParams = [];

						// var oObject = {};
						// oObject.Filter = aFilter;
						// oObject.Params = sParams;
						// oObject.successCallback = fnSuccess;
						// oObject.errorCallback = fnError;
						// oObject.sPath = sPath;
						// DataManagerARrecharge.getNonCoupaReqhelpValue(oObject);
						/*R&D---start*/
						var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
							json: true
						});
						oModel1.read("/GF_SHSet", {
							filters: aFilter,
							success: fnSuccess,
							error: fnError
						});
						/*R&D---end*/
					}

				} else {
					var msg = "Please enter correct details";
					MessageToast.show(msg);
				}
				/*else {
					if ((oAutho.GfEditDisplay === "E")) {
						var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
						MessageBox.error(
							"You are Not Authorized to Edit.", {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}
						);
					} 
				}*/
			} else {
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				MessageBox.error(
					"You are not authorized to edit/view this RRF.", {
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					}
				);
			}
		},
		/*End of change on 07-Jan-2020*/

	});

});