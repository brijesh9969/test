sap.ui.define([
	"kgo/ARRecharge/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"sap/ui/core/UIComponent",
	"sap/ui/core/Fragment",
	"kgo/ARRecharge/formatter/formatter",
	"kgo/ARRecharge/util/DataManagerARrecharge",
	"sap/m/MessageBox",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/Filter",
	"sap/m/MessageToast",
	"kgo/ARRecharge/util/UIGlobal",
], function (BaseController, JSONModel, History, UIComponent, Fragment, formatter, DataManagerARrecharge, MessageBox, FilterOperator,
	Filter, MessageToast, UIGlobal) {
	"use strict";
	return BaseController.extend("kgo.ARRecharge.controller.NonCoupaRRF", {
		/**
		 * 
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf kgo.ARRecharge.view.NonCoupaRRF
		 */
		/*Start of change by Debraj Date-11/6/2019*/
		onInit: function () {
			var oRouter = UIComponent.getRouterFor(this);
			oRouter.getRoute("TargetSelectionView").attachPatternMatched(this.handleRouteMatched, this);
			this.oRouter = UIComponent.getRouterFor(this);
			this.oRouter.attachRouteMatched(this.onRouteMatchedNC, this);
			//this.oRouter.attachRouteMatched(this.companyCodTextDisable, this);
		},
		onRouteMatchedNC: function (oEvent) {

			if (oEvent.getParameter("name") === "NonCoupaRRF") {
				//only invoke if a pernr has been selected
				this.firstInitialDataNC();

				this.companyCodTextDisable();

			}

		},
		firstInitialDataNC: function () {

			var tblNC = this.getView().byId('LineItemTab');
			var mModelSummary = this.getView().getModel("mModelSummary");
			var HeaderData = this.getModel("mModelSummary").getData().HeaderDataNC;
			var displayMode = mModelSummary.getProperty("/displayMode");
			if (HeaderData.ToDisplay === "X" && displayMode != true) {
				this.getView().byId("trnOwnerNPID").setProperty("enabled", true);
			} else {
				this.getView().byId("trnOwnerNPID").setProperty("enabled", false);
			}

			for (var i = 0; i < tblNC.getItems().length; i++) {
				var copInitiateNC = tblNC.getBindingInfo("items").binding.oList[i].CopInitiate;
				if (copInitiateNC === "X") {
					var x = tblNC.getAggregation("items")[i];
					x.getMultiSelectControl().setEnabled(false); //added by prashant for company code drowpdown diable
				}

			}

			/*Start of change for developer Satabdi Das on 26-Nov-2020*/
			var sCompCode = this.getView().getModel("mModelSummary").getProperty("/HeaderDataNC/CompanyCode");
			if (sCompCode === "9921") {
				this.getView().getModel("mModelSummary").setProperty("/Bukrs9921", true);
				/*Start of chnage by developer Satabdi Das on 26-Nov-2020 for RrfType*/
				jQuery.sap.delayedCall(1000, this, function () {
					var oRrfType = this.getView().byId("NPRrfType");
					if (oRrfType) {
						var obj = oRrfType.getDomRef();
						if (obj) {
							obj.firstElementChild.firstChild.setAttribute("readonly", true);
							// obj.firstElementChild.setAttribute("readonly", true);
							// obj.children[1].setAttribute("readonly", true);
							// obj.children[2].setAttribute("readonly", true);
						}
					}
				});
				/*End of chnage by developer Satabdi Das on 26-Nov-2020 for RrfType*/
			} else if (sCompCode !== "9921") {
				this.getView().getModel("mModelSummary").setProperty("/Bukrs9921", false);
			}
			/*End of change for developer Satabdi Das on 26-Nov-2020*/

		},
		companyCodTextDisable: function () {
			//companyCode drowpdown changes by prashant 17.08.2020
			var companyCode = this.getView().byId("companycodeforNP");

			companyCode.addEventDelegate({
				onAfterRendering: function () {
					companyCode.$().find("input").attr("readonly", true);
				}
			});
			// if (companyCode) {
			// 	var oCompanyText = companyCode.getDomRef();
			// 	if (oCompanyText) {
			// 		oCompanyText.firstElementChild.setAttribute("readonly", true);
			// 	}
			// }
		},

		/*Start of chnage by developer Satabdi Das on 26-Nov-2020 for RrfType*/
		onSlcTypeOfNPRRF: function (oEvent) {
			var sComboBoxItemText = oEvent.getParameter("value");
			this.getView().getModel("mModelSummary").setProperty("/HeaderDataNC/RrfType", sComboBoxItemText);
		},
		/*End of chnage by developer Satabdi Das on 26-Nov-2020 for RrfType*/

		onChangeCompanyCodeofNP: function (oEvent) {
			var that = this;

			var mModelSummary = this.getView().getModel("mModelSummary");
			var oHeaderDataNP = mModelSummary.getProperty("/HeaderDataNC");
			var oSelectedCompanyCodeNP = mModelSummary.getProperty("/HeaderDataNC").CompanyCode;
			this.oDfaultCompanyCodeNP = mModelSummary.getProperty("/HeaderDataNC").oDfaultCompanyCodeNP;
			if (oSelectedCompanyCodeNP !== this.oDfaultCompanyCodeNP) {
				if (oHeaderDataNP.VendorName || oHeaderDataNP.Vendor || oHeaderDataNP.Kostl) {
					var messageText = this.getModel("i18n").getProperty("companycodechangeMessage");
					MessageBox.information(messageText, {
						actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
						emphasizedAction: MessageBox.Action.OK,
						onClose: function (sAction) {
							if (sAction === "CANCEL") {
								mModelSummary.setProperty("/HeaderDataNC/CompanyCode", that.oDfaultCompanyCodeNP);

							} else {
								that.oDfaultCompanyCode = oSelectedCompanyCodeNP;
								mModelSummary.setProperty("/HeaderDataNC/oDfaultCompanyCodeNP", oSelectedCompanyCodeNP);

								if (oHeaderDataNP.Kostl) {
									mModelSummary.setProperty("/HeaderDataNC/Kostl");
									mModelSummary.setProperty("/HeaderDataNC/Ltext");
								}
							}
						}
					});
				} else {
					this.oDfaultCompanyCodeNP = oSelectedCompanyCodeNP;
					mModelSummary.setProperty("/HeaderDataNC/oDfaultCompanyCodeNP", oSelectedCompanyCodeNP);
				}
			}
			/*Start of change for developer Satabdi Das on 26-Nov-2020*/
			if (oSelectedCompanyCodeNP === "9921") {
				mModelSummary.setProperty("/Bukrs9921", true);
				/*Start of chnage by developer Satabdi Das on 26-Nov-2020 for RrfType*/
				jQuery.sap.delayedCall(1000, this, function () {
					var oRrfType = this.getView().byId("NPRrfType");
					if (oRrfType) {
						var obj = oRrfType.getDomRef();
						if (obj) {
							obj.firstElementChild.firstChild.setAttribute("readonly", true);
							// obj.firstElementChild.setAttribute("readonly", true);
							// obj.children[1].setAttribute("readonly", true);
							// obj.children[2].setAttribute("readonly", true);
						}
					}
				});
				/*End of chnage by developer Satabdi Das on 26-Nov-2020 for RrfType*/
			} else if (oSelectedCompanyCodeNP !== "9921") {
				mModelSummary.setProperty("/Bukrs9921", false);
			}
			/*End of change for developer Satabdi Das on 26-Nov-2020*/
		},

		handleRouteMatched: function () {
			var appTitle = this.getView().getModel("i18n").getResourceBundle().getText("appTitle");
			sap.ui.getCore().byId("shellAppTitle").setText(appTitle);
			// Start of change by Debraj Manna on 11/11/2019
			this.getModel("mModelSummary").setProperty("/NonCopaAppTitle", "");
			// End of change by Debraj Manna on 11/11/2019
			this.getModel("mModelSummary").setProperty("/TextForLineItemEmailSrch", ""); // Change done by Debraj Manna on 11/14/2019
		},
		onExit: function () {
			var appTitle = this.getView().getModel("i18n").getResourceBundle().getText("appTitle");
			sap.ui.getCore().byId("shellAppTitle").setText(appTitle);
			// Start of change by Debraj Manna on 11/11/2019
			this.getModel("mModelSummary").setProperty("/NonCopaAppTitle", "");
			// End of change by Debraj Manna on 11/11/2019
			this.getModel("mModelSummary").setProperty("/TextForLineItemEmailSrch", ""); // Change done by Debraj Manna on 11/14/2019
		},

		/*End of change by Debraj Date-11/6/2019*/
		//start of changes for company code disable 14.08.2020

		AddMemberFirmRow: function (oEvent) {
			var mModelSummary = this.getView().getModel("mModelSummary");
			var displayMode = this.getModel("mModelSummary").getProperty("/displayMode"); /*Added by Saptarshi on 22-Nov-2019*/
			var oModelAttachmentsLastNC = this.getView().getModel("mModelSummary").getProperty("/FileNameSetNC");
			if (oModelAttachmentsLastNC) {
				this.getView().getModel("mModelSummary").setProperty("/FileNameSetNC", null);
			}
			if (displayMode === false) { /*Added by Saptarshi on 22-Nov-2019*/
				sap.ui.core.BusyIndicator.show(0);
				var avlueText = this.getModel("i18n").getProperty("addmemberfirm");
				this.getModel("mModelSummary").setProperty("/setLineItemText", avlueText);
				this.getModel("mModelSummary").setProperty("/TextForLineItemEmailSrch", avlueText);
				var msg; /*Added by Saptarshi on 8th-Nov-2019*/
				this.getModel("mModelSummary").setProperty("/oEditableNC/visibleforGF", false);
				this.getModel("mModelSummary").setProperty("/oEditableNC/visibleforMF", true);
				this.getModel("mModelSummary").setProperty("/oEditableNC/rmdropDownNP", true);
				this.getModel("mModelSummary").setProperty("/oEditableNC/requMfvisibleNP", false);
				this.getModel("mModelSummary").setProperty("/updateRowDataNC", []);
				mModelSummary.setProperty("/nPquestionSet", []);
				mModelSummary.setProperty("/nPquestionSetFirst", []);
				mModelSummary.setProperty("/SelcKeySet", "");
				mModelSummary.setProperty("/oEditable/attchmentExpndedNC", false);
				mModelSummary.setProperty("/oEditableNC/entityName", false); /*Added on 29-Janb-2020*/
				mModelSummary.setProperty("/oEditableNC/entityAddress", true); /*Added on 29-Janb-2020*/
				mModelSummary.setProperty("/oEditableNC/editLineItemAddInfJV", false); /*Added on 18-Dec-2019*/
				mModelSummary.setProperty("/oEditableNC/editLineItemBillSch", true); /*Chnage by Saptarshi on 20-Nov-2019*/
				mModelSummary.setProperty("/BillEnable", true); /*Added on 19-May-2020 for defect 63320*/
				this.getModel("mModelSummary").setProperty("/oEditableNC/Occurence", true); /*Chnage by Saptarshi on 20-Nov-2019*/
				this.getModel("mModelSummary").setProperty("/oEditableNC/editMode", true); /*Chnage added by Saptarshi on 20-Nov-2019*/
				this.getModel("mModelSummary").setProperty("/oEditableNC/PercY", true); /*Added on 20-Jan-2020*/
				/*Start of change on 17-Jan-2020*/
				this.getModel("mModelSummary").setProperty("/oEditableNC/editLineItemCop", true);
				this.getModel("mModelSummary").setProperty("/oEditableNC/editLineItemMF", true);
				this.getModel("mModelSummary").setProperty("/oEditableNC/editLineItemAddInf", true);
				mModelSummary.setProperty("/SelcKeySet", "");
				mModelSummary.setProperty("/oEditableNC/questionPnVisibleNP", false);
				mModelSummary.setProperty("/oEditableNC/reSetButtonEnableNP", false);

				/*End of change on 17-Jan-2020*/
				//start of code by NITIN 06.11.19//
				var oControllerNameNC = mModelSummary.getProperty("/HeaderDataNC").ContrlName;
				var oControllerEmailIdNC = mModelSummary.getProperty("/HeaderDataNC").ContrlEmail;
				var oCurrencyNC = mModelSummary.getProperty("/HeaderDataNC").Currency;
				var oRechDescNC = mModelSummary.getProperty("/HeaderDataNC").GfDesc;
				var oRrfStatusNC = mModelSummary.getProperty("/HeaderDataNC").RrfStatus;

				if (!oControllerNameNC || !oControllerEmailIdNC || !oCurrencyNC || !oRechDescNC || !oRrfStatusNC) {
					sap.ui.core.BusyIndicator.hide(0);
					this.getView().getModel("mModelSummary").setProperty("/TextForLineItemEmailSrch");

					var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
					MessageBox.alert(
						"Please enter mandatory fields .", {
							styleClass: bCompact ? "sapUiSizeCompact" : ""
						}
					);

					return;
				}
				//End of code by NITIN 06.11.19//
				var rrfTablefragmentNonCoupa = this.getView().createId("rrfTablefragmentNonCoupa");

				// var JVSchPanel = sap.ui.core.Fragment.byId(rrfTablefragmentNonCoupa, "JVPanelNC"); /*Added on 10-Jan-2020*/
				if (!this.rrfTablefragmentNonCoupa) {
					this.rrfTablefragmentNonCoupa = sap.ui.xmlfragment(rrfTablefragmentNonCoupa, "kgo.ARRecharge.view.createLineItemNonCoupa", this);
					this.getView().addDependent(this.rrfTablefragmentNonCoupa);
				}
				if (this.rrfTablefragmentNonCoupa.isOpen()) {
					this.rrfTablefragmentNonCoupa.close();
				} else {

					sap.ui.core.BusyIndicator.hide(0);

					var oNatureField = this.byId(sap.ui.core.Fragment.createId(rrfTablefragmentNonCoupa, "npComboboxnature"));
					oNatureField.addEventDelegate({
						onAfterRendering: function () {
							oNatureField.$().find("input").attr("readonly", true);
						}
					});

					var oDatePicker = this.byId(sap.ui.core.Fragment.createId(rrfTablefragmentNonCoupa, "LastDateSrvNC"));
					oDatePicker.addEventDelegate({
						onAfterRendering: function () {
							var oDateInner = this.$().find('.sapMInputBaseInner');
							var oID = oDateInner[0].id;
							$('#' + oID).attr("disabled", "disabled");
						}
					}, oDatePicker);

					this.byId(sap.ui.core.Fragment.createId("rrfTablefragmentNonCoupa", "FragOk")).setVisible(true);
					this.byId(sap.ui.core.Fragment.createId("rrfTablefragmentNonCoupa", "EditOk")).setVisible(false);
					this.byId(sap.ui.core.Fragment.createId("rrfTablefragmentNonCoupa", "updateCooID")).setEnabled(false);
					this.byId(sap.ui.core.Fragment.createId("rrfTablefragmentNonCoupa", "UpdateAuthId")).setSelected(false);
					this.onMfSearchHelpNC();
					this.onMfLocValueNC(); /*Added on 17-Feb-2021 for SCTASK1919812*/
					mModelSummary.setProperty("/oEditableNC/lastservdateNP", false);
					mModelSummary.setProperty("/oEditableNC/checkBox", true); /*Added on 21-Feb-2020*/
					mModelSummary.setProperty("/oEditableNC/entityName", false); /*Added on 21-Feb-2020*/
					mModelSummary.setProperty("/oEditableNC/entityAddress", true); /*Added on 21-Feb-2020*/
					var oQuestionDroupDown = this.byId(sap.ui.core.Fragment.createId(rrfTablefragmentNonCoupa, "comboIdTablefirst"));
					oQuestionDroupDown.addEventDelegate({
						onAfterRendering: function () {
							var oQdropDown = this.$().find('.sapMInputBaseInner');
							var oID = oQdropDown[0].id;
							$('#' + oID).attr("disabled", "disabled");
						}
					}, oQuestionDroupDown);

					this.rrfTablefragmentNonCoupa.open();

					var oQdropDown = this.byId(sap.ui.core.Fragment.createId(rrfTablefragmentNonCoupa, "comboIdTable"));
					oQdropDown.addEventDelegate({
						onAfterRendering: function () {
							var oQdropDown = this.$().find('.sapMInputBaseInner');
							var oID = oQdropDown[0].id;
							$('#' + oID).attr("disabled", "disabled");
						}
					}, oQdropDown);

					var BRFSchPanel = sap.ui.core.Fragment.byId(rrfTablefragmentNonCoupa, "BRFSecNC"); /*Added on 10-Jan-2020*/
					BRFSchPanel.setExpanded(false); /*Added on 10-Jan-2020*/
					// JVSchPanel.setExpanded(false); /*Added on 10-Jan-2020*/
					/*Start of change on 01-Jan-2020*/
					/*Start of change on 21-Feb-20202*/
					var oCheckBox = this.byId(sap.ui.core.Fragment.createId(rrfTablefragmentNonCoupa, "NewEntityNC"));
					if (oCheckBox) {
						oCheckBox.setSelected(false);
					}
					/*End of change on 21-Feb-2020*/
					/*Start of change for defect 63871 on 19-March-2021 by developer Satabdi Das*/
					var oReqCountry = this.byId(sap.ui.core.Fragment.createId(rrfTablefragmentNonCoupa, "contryDrdwIdNC"));
					oReqCountry.addEventDelegate({
						onAfterRendering: function () {
							var oReqCountryInner = this.$().find('.sapMInputBaseInner');
							var oID = oReqCountryInner[0].id;
							$('#' + oID).attr("disabled", "disabled");
						}
					}, oReqCountry);

					/*End of change for defect 63871 on 19-March-2021 by developer Satabdi Das*/
					// var oDatePicker1 = this.byId(sap.ui.core.Fragment.createId(rrfTablefragmentNonCoupa, "BillStartDate"));
					// if (oDatePicker1) {
					// 	var objDate1 = oDatePicker1.getDomRef();
					// 	if (objDate1) {
					// 		//objDate1.firstElementChild.setAttribute("readonly", true);
					// 		objDate1.firstElementChild.firstChild.setAttribute("readonly", true);
					// 	}
					// }
					var oReqCountry = this.byId(sap.ui.core.Fragment.createId(rrfTablefragmentNonCoupa, "BillStartDate"));
					oReqCountry.addEventDelegate({
						onAfterRendering: function () {
							var oReqCountryInner = this.$().find('.sapMInputBaseInner');
							var oID = oReqCountryInner[0].id;
							$('#' + oID).attr("disabled", "disabled");
						}
					}, oReqCountry);

					var oDatePicker2 = this.byId(sap.ui.core.Fragment.createId(rrfTablefragmentNonCoupa, "LastDateSrvNC"));
					if (oDatePicker2) {
						var objDate2 = oDatePicker2.getDomRef();
						if (objDate2) {
							//	objDate2.firstElementChild.setAttribute("readonly", true);
							objDate2.firstElementChild.firstChild.setAttribute("readonly", true);
						}
					}
					/*End of change on 01-Jan-2020*/
					this.byId(sap.ui.core.Fragment.createId("rrfTablefragmentNonCoupa", "ContactPersonLOAId")).setEditable(true); /*End - CR  Changed On 26-Aug-2021 By Prashant and Chhanda*/
				}
			} /*Added by Saptarshi on 22-Nov-2019*/
		},
		onEnterProcess: function (oEvent) {
			var mModelSummary = this.getModel("mModelSummary");
			mModelSummary.getProperty("/updateRowDataNC");
			var format = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/;
			if (format.test(oEvent.getParameter("value"))) {
				var specialMsg = this.getModel("i18n").getProperty("specialchMsg");
				MessageBox.error(specialMsg);
				return true;
			} else {
				return false;
			}
			if (mModelSummary.getProperty("/updateRowDataNC").RequestingMf) {
				var reqCountry = mModelSummary.getProperty("/updateRowDataNC").RequestingMf;
				mModelSummary.setProperty("/SelcKeySet", reqCountry);
			}
		},

		AddGlobalFirmRow: function (oEvent) {
			var displayMode = this.getModel("mModelSummary").getProperty("/displayMode"); /*Added by Saptarshi on 22-Nov-2019*/
			var mModelSummary = this.getModel("mModelSummary");
			var oModelAttachmentsLastNC = this.getView().getModel("mModelSummary").getProperty("/FileNameSetNC");
			if (oModelAttachmentsLastNC) {
				this.getView().getModel("mModelSummary").setProperty("/FileNameSetNC", null);
			}
			if (displayMode === false) { /*Added by Saptarshi on 22-Nov-2019*/
				sap.ui.core.BusyIndicator.show(0);
				var avlueText = this.getModel("i18n").getProperty("addGlobalFunction");
				this.getModel("mModelSummary").setProperty("/setLineItemText", avlueText);
				this.getModel("mModelSummary").setProperty("/TextForLineItemEmailSrch", avlueText);
				var msg; /*Added by Saptarshi on 8th-Nov-2019*/
				this.getModel("mModelSummary").setProperty("/oEditableNC/visibleforGF", true);
				this.getModel("mModelSummary").setProperty("/oEditableNC/visibleforMF", false);
				this.getModel("mModelSummary").setProperty("/oEditableNC/rmdropDownNP", false);
				this.getModel("mModelSummary").setProperty("/oEditableNC/requMfvisibleNP", false);
				this.getView().getModel("mModelSummary").setProperty("/oEditable/attchmentExpndedNC", false);
				this.getModel("mModelSummary").setProperty("/updateRowDataNC", []);
				this.getModel("mModelSummary").setProperty("/updateRowDataNC/RequestingMf");
				this.getModel("mModelSummary").setProperty("/RRF_MFSet");
				this.getModel("mModelSummary").setProperty("/oEditableNC/editLineItemBillSch", false); /*Added on 18-Dec-2019*/
				this.getView().getModel("mModelSummary").setProperty("/BillEnable", true); /*Added on 19-May-2020 for Defect 63320*/
				this.getModel("mModelSummary").setProperty("/oEditableNC/editLineItemAddInfJV", true); /*Added on 18-Dec-2019*/
				this.getModel("mModelSummary").setProperty("/oEditableNC/Occurence", true); /*Added on 18-Dec-2019*/
				this.getModel("mModelSummary").setProperty("/oEditableNC/editMode", true); /*Chnage added by Saptarshi on 20-Nov-2019*/
				/*Start of change on 17-Jan-2020*/
				this.getModel("mModelSummary").setProperty("/oEditableNC/editLineItemCop", true);
				this.getModel("mModelSummary").setProperty("/oEditableNC/editLineItemMF", true);
				this.getModel("mModelSummary").setProperty("/oEditableNC/editLineItemAddInf", true);
				mModelSummary.setProperty("/oEditableNC/questionPnVisibleNP", false);
				mModelSummary.setProperty("/oEditableNC/reSetButtonEnableNP", false);
				/*End of change on 17-Jan-2020*/

				//start of code by NITIN 06.11.19//
				var oControllerNameNC = this.getView().getModel("mModelSummary").getProperty("/HeaderDataNC").ContrlName;
				var oControllerEmailIdNC = this.getView().getModel("mModelSummary").getProperty("/HeaderDataNC").ContrlEmail;
				var oCurrencyNC = this.getView().getModel("mModelSummary").getProperty("/HeaderDataNC").Currency;
				var oRechDescNC = this.getView().getModel("mModelSummary").getProperty("/HeaderDataNC").GfDesc;
				var oRrfStatusNC = this.getView().getModel("mModelSummary").getProperty("/HeaderDataNC").RrfStatus;
				if (!oControllerNameNC || !oControllerEmailIdNC || !oCurrencyNC || !oRechDescNC || !oRrfStatusNC) {
					sap.ui.core.BusyIndicator.hide(0);
					this.getView().getModel("mModelSummary").setProperty("/TextForLineItemEmailSrch");
					var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
					MessageBox.alert(
						"Please enter mandatory fields .", {
							styleClass: bCompact ? "sapUiSizeCompact" : ""
						}
					);
					return;
				}
				//End of code by NITIN 06.11.19//
				var rrfTablefragmentNonCoupa = this.getView().createId("rrfTablefragmentNonCoupa");
				if (!this.rrfTablefragmentNonCoupa) {
					this.rrfTablefragmentNonCoupa = sap.ui.xmlfragment(rrfTablefragmentNonCoupa, "kgo.ARRecharge.view.createLineItemNonCoupa", this);
					this.getView().addDependent(this.rrfTablefragmentNonCoupa);
				}
				if (this.rrfTablefragmentNonCoupa.isOpen()) {
					this.rrfTablefragmentNonCoupa.close();
				} else {
					sap.ui.core.BusyIndicator.hide(0);
					this.byId(sap.ui.core.Fragment.createId("rrfTablefragmentNonCoupa", "FragOk")).setVisible(true);
					this.byId(sap.ui.core.Fragment.createId("rrfTablefragmentNonCoupa", "EditOk")).setVisible(false);
					this.rrfTablefragmentNonCoupa.open();
					var JVSchPanel = sap.ui.core.Fragment.byId(rrfTablefragmentNonCoupa, "JVPanelNC"); /*Added on 10-Jan-2020*/
					JVSchPanel.setExpanded(false); /*Added on 10-Jan-2020*/
					/*Start of change on 01-Jan-2020*/
					var oDatePicker1 = this.byId(sap.ui.core.Fragment.createId(rrfTablefragmentNonCoupa, "JVStartDate"));
					if (oDatePicker1) {
						var objDate1 = oDatePicker1.getDomRef();
						if (objDate1) {
							//objDate1.firstElementChild.setAttribute("readonly", true);
							objDate1.firstElementChild.firstChild.setAttribute("readonly", true);
						}
					}
					/*End of change on 01-Jan-2020*/
				}
			} /*Added by Saptarshi on 22-Nov-2019*/
		},
		handleLineItemBillSch: function (oEvent) {
			var mModelSummary = this.getModel("mModelSummary");
			var x = oEvent.getSource();
			var y = x.getParent().getBindingContextPath();
			/*Change start on 7th-Nov-2019 by Saptarshi*/
			var split = y.split("/");
			var rowNo = split[3];
			var msg; /*Added by Satabdi Das on 18-Dec-2019*/
			// var bGfFlag = this.getModel("mModelSummary").getProperty("/oEditableNC/visibleforGF"); /*Added by Satabdi Das on 18-Dec-2019*/
			/*Change end on 7th-Nov-2019 by Saptarshi*/
			if (mModelSummary.getData().HeaderDataNC.RrfNoGf) {
				var iIrfNumber = mModelSummary.getData().HeaderDataNC.RrfNoGf;
				var iCompCode = mModelSummary.getData().HeaderDataNC.CompanyCode;
				// if (bGfFlag === true) { /*Added by Satabdi Das on 18-Dec-2019*/
				if (mModelSummary.getData().TableItemSetNC.results[rowNo].GlobalCc !== "N/A") {
					var sGblCC = mModelSummary.getData().TableItemSetNC.results[rowNo].GlobalCc; /*Added by Satabdi Das on 18-Dec-2019*/
					mModelSummary.setProperty("/oEditableNC/LineItemJV", true);
					mModelSummary.setProperty("/oEditableNC/LineItemBill", false);
				} /*Added by Satabdi Das on 18-Dec-2019*/
				else { /*Added by Satabdi Das on 18-Dec-2019*/
					var sReqMf = mModelSummary.getData().TableItemSetNC.results[rowNo].RequestingMf;
					var sProcessGrp = mModelSummary.getData().TableItemSetNC.results[rowNo].ProcessGrp; /*Added on 17-Jan-2020*/
					var sMemberFirm = mModelSummary.getData().TableItemSetNC.results[rowNo].MemberFirm;
					var sCcShortDesc = "";
					mModelSummary.setProperty("/oEditableNC/LineItemJV", false);
					mModelSummary.setProperty("/oEditableNC/LineItemBill", true);
				} /*Added by Satabdi Das on 18-Dec-2019*/
			} else {
				iIrfNumber = "";
				iCompCode = "";
				sReqMf = "";
				sProcessGrp = ""; /*Added on 17-Jan-2020*/
				sGblCC = ""; /*Added by Satabdi Das on 18-Dec-2019*/
				sMemberFirm = "";
				sCcShortDesc = "";
			}
			sap.ui.core.BusyIndicator.show(0);
			var aFilter = [];
			var sPath = "";
			sPath = "/GF_BillingSet";
			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				if (d.results.length > 0) {
					var sDocNum; /*Added on 29-APR-2020*/
					for (var i = 0; i < d.results.length; i++) {
						d.results[i].ReqSeq = d.results[i].ReqSeq.trim();
						/*Start of change on 29-APR-2020*/
						if (d.results[i].Belnr && d.results[i].Belnr !== "") {
							sDocNum = true;
						}
						/*End of change on 29-APR-2020*/
					}
					/*Start of change on 29-APR-2020*/
					if (sDocNum === true) {
						mModelSummary.setProperty("/oEditableNC/NoDocNum", false);
					} else if (sDocNum === undefined) {
						mModelSummary.setProperty("/oEditableNC/NoDocNum", true);
					}
					/*End of change on 29-APR-2020*/
					mModelSummary.setProperty("/GF_BSH", d.results);
					// mModelSummary.refresh(true);
					mModelSummary.setProperty("/GF_AddNew", d.results[0]);
					var fragmentId = this.getView().createId("billingSchedule");
					if (!this._oBillSch) {
						this._oBillSch = sap.ui.xmlfragment(fragmentId, "kgo.ARRecharge.view.billingSchedule", this);
						this.getView().addDependent(this._oBillSch);
					}

					this._oBillSch.open();
					if (mModelSummary.getProperty("/oEditableNC/visibleForEditGf") === true) {
						// mModelSummary.setProperty("/oEditableNC/billFields", true); /*Added on 17-Jan-2020*/
						/*Start of change for defect 63320 on 19-May-2020*/
						var sLineStatus = mModelSummary.getData().TableItemSetNC.results[rowNo].RrfStatus;
						if (sLineStatus === "COPInitiated" || sLineStatus === "COPConfirmed" || sLineStatus === "LOAInitiated" || sLineStatus ===
							"LOAConfirmed") {
							mModelSummary.setProperty("/oEditableNC/billFields", false);
						} else {
							mModelSummary.setProperty("/oEditableNC/billFields", true);
						}
						/*End of change for defect 63320 on 19-May-2020*/
						/*Start of change on 17-Jan-2020*/
						var oBillFrag = this.byId(sap.ui.core.Fragment.createId(fragmentId, "billScheduletbl"));
						oBillFrag.removeSelections(true); /*Added for Defect 63096*/
						/*Start of change for defect 63322 on 19-May-2020*/
						if (sDocNum && sDocNum === true) {
							oBillFrag.addStyleClass("BillTblCheckBox");
						} else {
							oBillFrag.removeStyleClass("BillTblCheckBox");
						}
						/*End of change for defect 63321 on 19-May-2020*/
						var oBillFragItems = oBillFrag.getAggregation("items");
						var sItemLen = oBillFragItems.length;
						for (var i = 0; i <= sItemLen; i++) {
							var objDate1 = oBillFragItems[i].getAggregation("cells")[4].getDomRef();
							if (objDate1) {
								objDate1.firstElementChild.firstChild.setAttribute("readonly", true);
							}
							var objDate2 = oBillFragItems[i].getAggregation("cells")[5].getDomRef();
							if (objDate2) {
								objDate2.firstElementChild.firstChild.setAttribute("readonly", true);
							}
							var sBelnr = oBillFragItems[i].getAggregation("cells")[7].getText();
							if (sBelnr !== "") {
								var objSeqNum = oBillFragItems[i].getAggregation("cells")[3].getDomRef();
								var objAmt = oBillFragItems[i].getAggregation("cells")[6].getDomRef();
								if (objSeqNum) {
									objSeqNum.firstElementChild.firstChild.setAttribute("readonly", true);
								}
								if (objAmt) {
									objAmt.firstElementChild.firstChild.setAttribute("readonly", true);
								}
								oBillFragItems[i].getAggregation("cells")[4].addStyleClass("calender");
								oBillFragItems[i].getAggregation("cells")[5].addStyleClass("calender");
								oBillFragItems[i].getMultiSelectControl().setEnabled(false);
							}
						}
					}
					/*End of change on 17-Jan-2020*/
					/*Start of Defect 63096 on 04-Feb-2020*/
					else if (mModelSummary.getProperty("/oEditableNC/visibleForEditGf") === false) {
						oBillFrag = this.byId(sap.ui.core.Fragment.createId(fragmentId, "billScheduletbl"));
						oBillFrag.removeSelections(true);
					}
					/*End of Defect 63096 on 04-Feb-2020*/
				} else {
					if (mModelSummary.getData().TableItemSetNC.results[rowNo].GlobalCc !== "N/A") { /*Added by Satabdi Das on 18-Dec-2019*/
						msg = "JV schedule has not been created!"; /*Added by Satabdi Das on 18-Dec-2019*/
					} /*Added by Satabdi Das on 18-Dec-2019*/
					else { /*Added by Satabdi Das on 18-Dec-2019*/
						msg = "Bill schedule has not been created!";
					} /*Added by Satabdi Das on 18-Dec-2019*/
					MessageToast.show(msg);
					return;
				}
			}, this);
			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();
				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"
				});
			}, this);
			var sParams = {};
			var oObject = {};
			aFilter.push(new sap.ui.model.Filter("RrfNoGf", sap.ui.model.FilterOperator.EQ, iIrfNumber));
			aFilter.push(new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.EQ, iCompCode));
			if (mModelSummary.getData().TableItemSetNC.results[rowNo].GlobalCc !== "N/A") { /*Added by Satabdi Das on 18-Dec-2019*/
				aFilter.push(new sap.ui.model.Filter("GlobalCc", sap.ui.model.FilterOperator.EQ, sGblCC)); /*Added by Satabdi Das on 18-Dec-2019*/
				aFilter.push(new sap.ui.model.Filter("CcShortDesc", sap.ui.model.FilterOperator.EQ, sCcShortDesc));
			} /*Added by Satabdi Das on 18-Dec-2019*/
			else { /*Added by Satabdi Das on 18-Dec-2019*/
				aFilter.push(new sap.ui.model.Filter("RequestingMf", sap.ui.model.FilterOperator.EQ, sReqMf));
				aFilter.push(new sap.ui.model.Filter("ProcessGrp", sap.ui.model.FilterOperator.EQ, sProcessGrp)); /*Added on 17-Jan-2020*/
				aFilter.push(new sap.ui.model.Filter("MemberFirm", sap.ui.model.FilterOperator.EQ, sMemberFirm));
			} /*Added by Satabdi Das on 18-Dec-2019*/
			// oObject.Filter = aFilter;
			// oObject.Params = sParams;
			// oObject.successCallback = fnSuccess;
			// oObject.errorCallback = fnError;
			// oObject.sPath = sPath;
			// DataManagerARrecharge.getNonCoupaReqhelpValue(oObject);
			/*R&D---start*/
			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
				json: true
			});
			oModel1.read("/GF_BillingSet", {
				filters: aFilter,
				success: fnSuccess,
				error: fnError
			});
			/*R&D---end*/
		},
		onBillCancel: function (oEvent) {
			if (this._oBillSch.isOpen()) {
				this._oBillSch.close();
			}
		},
		// Start of change by Debraj Date - 11/8/2019
		/*Start - CR  Changed On 26-Aug-2021 By Prashant and Chhanda*/
		saveRRFNonPO: function () {
			this.getModel("mModelSummary").setProperty("/oDislayRrfNoGf");
			var displayMode = this.getModel("mModelSummary").getProperty("/displayMode"); /*Added by SAptarshi on 22-Nov-2019*/
			if (displayMode === false) { /*Added by SAptarshi on 22-Nov-2019*/
				var headerData = this.getView().getModel("mModelSummary").getProperty("/HeaderDataNC");
				// var oControllerNameNC = this.getView().getModel("mModelSummary").getProperty("/HeaderDataNC").ContrlName;
				// var oControllerEmailIdNC = this.getView().getModel("mModelSummary").getProperty("/HeaderDataNC").ContrlEmail;
				// var oCurrencyNC = this.getView().getModel("mModelSummary").getProperty("/HeaderDataNC").Currency;
				// var oRechDescNC = this.getView().getModel("mModelSummary").getProperty("/HeaderDataNC").GfDesc;
				// var msg;
				// if (!oControllerNameNC || !oControllerEmailIdNC || !oCurrencyNC || !oRechDescNC || !headerData.CanNoticeDate) {
				// 	msg = "Please enter mandatory fields";
				// 	MessageBox.error(msg);
				// 	return;
				// }
				sap.ui.core.BusyIndicator.show(0);
				var TableData = [];
				var oPayLoad = {
					CompanyCode: headerData.CompanyCode,
					ContrlName: headerData.ContrlName,
					ContrlEmail: headerData.ContrlEmail,
					TotalContractAmount: headerData.TotalContractAmount,
					GfDesc: headerData.GfDesc,
					RrfNoGf: headerData.RrfNoGf,
					AddlInfo: headerData.AddlInfo,
					/*Added by Satabdi Das on 03-Dec-2019*/
					CreatedOn: headerData.CreatedOn,
					CreatedBy: headerData.CreatedBy,
					RrfCreatorName: headerData.RrfCreatorName,
					Currency: headerData.Currency,
					Kostl: headerData.Kostl,
					Ltext: headerData.Ltext,
					CanNoticeDate: headerData.CanNoticeDate,
					RrfType: headerData.RrfType,
					ToDisplay: headerData.ToDisplay,
					/*Added by Satabdi Das on 26-Nov-2020*/
					/*Added by Satabdi Das on 09-Jan-2020*/
					/*Start of change on 03-March-2020*/
					Background: headerData.Background,
					Activity: headerData.Activity,
					/*End of change on 03-March-2020*/
					RrfStatus: headerData.RrfStatus,
					flag: headerData.flag,
					BillScheFlg: headerData.BillSchFlg,
					GF_Lineitem_Set: []
				};
				var that = this;
				var fnSuccess = jQuery.proxy(function (d) {
					sap.ui.core.BusyIndicator.hide(0);
					var GprrfNo = d.RrfNoGf;
					var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
					if (d.Flag) {
						var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
						MessageBox.error(
							d.Message, {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}
						);
					} else {
						MessageBox.show(
							d.Message, {
								icon: MessageBox.Icon.SUCCESS,
								title: "Success",
								actions: [MessageBox.Action.OK],
								onClose: function (oAction) {

									that.getView().getModel("mModelSummary").setProperty("/HeaderDataNC/RrfNoGf", GprrfNo);
									that.editNonCoupa();
									// var oRouter = UIComponent.getRouterFor(that);
									// oRouter.navTo("TargetSelectionView");
								}
							}
						);
						this.getModel("mModelSummary").setProperty("/updateRowDataNC/RequestingMf", ""); /*Chnage added on 09-Jan-2020*/
						/*Start of chnage for defect 63096 on 31-Jan-2020*/
						var oLineTbl = that.getView().byId("LineItemTab");
						oLineTbl.removeSelections(true);
						/*End of chnage for defect 63096 on 31-Jan-2020*/
					}
				}, this);
				var fnError = jQuery.proxy(function (d) {
					var r = JSON.parse(JSON.stringify(d));
					sap.ui.core.BusyIndicator.hide();
					MessageToast.show(r.message, {
						autoClose: true,
						width: "20rem"

					});
				}, this);
				var objectOne = {};
				var arr = [];
				var arrAnsware = [];
				var _answre = [];
				objectOne.successCallback = fnSuccess;
				objectOne.errorCallback = fnError;
				arr = this.getView().getModel("mModelSummary").getProperty("/TableItemSetNC");
				arrAnsware = this.getModel("mModelSummary").getProperty("/nPQuestionSetSubmit");
				for (var t = 0; t < arrAnsware.length; t++) {
					var objAns = {};
					objAns.GlobalCc = headerData.GlobalCc;
					objAns.MemberFirm = arrAnsware[t].MemberFirm;
					objAns.Question = arrAnsware[t].Question;
					objAns.RequestingMf = arrAnsware[t].RequestingMf;
					objAns.Answer = arrAnsware[t].Answer;
					objAns.InternalExternal = arrAnsware[t].InternalExternal;
					objAns.AnswerDesc = arrAnsware[t].AnswerDesc;
					objAns.ProcessGrp = arrAnsware[t].ProcessGrp;
					objAns.CompanyCode = headerData.CompanyCode;
					_answre.push(objAns);

				}
				oPayLoad.RRF_AnswerSet = _answre;

				if (arr.length !== 0 || arr.results !== undefined) {
					arr = formatter.formatFromCoupaDateToYYYYMMDD(arr);
					for (var i in arr.results) {
						/*Start of change on 10-Jan-2020*/
						if (arr.results[i].Amount === "") {
							arr.results[i].Amount = "000000000000.000";
						}
						/*End of change on 10-Jan-2020*/
						var fields = Object.keys(arr.results[i]);
						var obj = {};
						for (var j = 0; j < fields.length; j++) {
							if (fields[j] !== "__metadata") {
								obj[fields[j]] = arr.results[i][fields[j]];
							}
						}
						TableData.push(obj);
					}
				}
				oPayLoad.GF_Lineitem_Set = TableData;
				DataManagerARrecharge.CreateDataNonCoupa(oPayLoad, objectOne);
			} /*Added by SAptarshi on 22-Nov-2019*/
		},
		/*End - CR  Changed On 26-Aug-2021 By Prashant and Chhanda*/
		onSubmitPressNC: function (oEvent) {
			this.getModel("mModelSummary").setProperty("/oDislayRrfNoGf");
			var displayMode = this.getModel("mModelSummary").getProperty("/displayMode"); /*Added by SAptarshi on 22-Nov-2019*/
			if (displayMode === false) { /*Added by SAptarshi on 22-Nov-2019*/
				var headerData = this.getView().getModel("mModelSummary").getProperty("/HeaderDataNC");
				var oControllerNameNC = this.getView().getModel("mModelSummary").getProperty("/HeaderDataNC").ContrlName;
				var oControllerEmailIdNC = this.getView().getModel("mModelSummary").getProperty("/HeaderDataNC").ContrlEmail;
				var oCurrencyNC = this.getView().getModel("mModelSummary").getProperty("/HeaderDataNC").Currency;
				var oRechDescNC = this.getView().getModel("mModelSummary").getProperty("/HeaderDataNC").GfDesc;
				var arr = [];
				arr = this.getView().getModel("mModelSummary").getProperty("/TableItemSetNC");
				var msg;
				if (!oControllerNameNC || !oControllerEmailIdNC || !oCurrencyNC || !oRechDescNC || !headerData.CanNoticeDate) {
					msg = "Please enter mandatory fields";
					MessageBox.error(msg);
					return;
				} else {
					/*Start - CR  Changed On 26-Aug-2021 By Prashant and Chhanda*/
					if (arr.results && arr.results.length > 0) {
						var that = this;
						//var displayMsg = this.checkTotalMFAmountForSameMF(arr.results, "NONPO");
						var displayMsg = ""; //As per requirement 250k msg is not required now 18.11.2021
						var savecheckmessage = "";
						if (displayMsg && displayMsg.length > 0) {
							// read msg from i18n model
							var oBundle = this.getView().getModel("i18n").getResourceBundle();
							// for (var i = 0; i < displayMsg.length; i++) {
							// 	savecheckmessage = savecheckmessage + oBundle.getText("savecheckmessage", [displayMsg[i]]) + "\n";
							// }
							// savecheckmessage = savecheckmessage + oBundle.getText("savecheckmessage2");

							savecheckmessage = oBundle.getText("savecheckmessage");
							var displayMF = "";
							for (var i = 0; i < displayMsg.length; i++) {
								displayMF = displayMF + "\n" + displayMsg[i];
							}
							savecheckmessage = savecheckmessage + displayMF;

							var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
							MessageBox.information(savecheckmessage, {
								actions: [MessageBox.Action.OK],
								styleClass: bCompact ? "sapUiSizeCompact" : "",
								onClose: function (sAction) {
									if (sAction === "OK") {
										that.saveRRFNonPO(); // Save RRF Non PO data
									}
								}
							});
						} else {
							this.saveRRFNonPO();
						}
					} else {
						this.saveRRFNonPO();
					}
					/*End - CR  Changed On 26-Aug-2021 By Prashant and Chhanda*/
				}

			} /*Added by SAptarshi on 22-Nov-2019*/
		},
		// End of change by Debraj Date - 11/8/2019
		onBackPressNC: function (oEvent) {
			// this.getModel("mModelSummary").setProperty("/oEditableNC");  Commented on 21-Nov-2019
			this.getModel("mModelSummary").setProperty("/oDislayRrfNoGf");
			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();
			/*Start of change on 14-Jan-2020*/
			var that = this;
			if (this.getModel("mModelSummary").getProperty("/oEditableNC/visibleForDisplyGf") === false) {
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				MessageBox.warning(
					"Are you sure you want to go back? Change(s) made if any will be discarded!", {
						actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
						styleClass: bCompact ? "sapUiSizeCompact" : "",
						onClose: function (sAction) {
							if (sAction === "OK") {
								that.handleUnLockConcuurentUserNC();

								if (sPreviousHash !== undefined) {
									var oRouter = UIComponent.getRouterFor(that);
									oRouter.navTo("TargetSelectionView", {}, true);
								} else {
									oRouter = UIComponent.getRouterFor(that);
									oRouter.navTo("TargetSelectionView", {}, true);
								}
								that.getModel("mModelSummary").setProperty("/updateRowDataNC/RequestingMf", ""); /*Chnage added on 09-Jan-2020*/
								/*Start of chnage for defect 63096 on 31-Jan-2020*/
								var oLineTbl = that.getView().byId("LineItemTab");
								oLineTbl.removeSelections(true);
								/*End of chnage for defect 63096 on 31-Jan-2020*/
								that.getModel("mModelSummary").setProperty("/NonCopaHdrLbl", ""); /*Chnage added by Saptarshi on 21-Nov-2019*/
							}

						}
					}, this);
			} else {
				if (sPreviousHash !== undefined) {
					window.history.go(-1);
				} else {
					var oRouter = UIComponent.getRouterFor(that);
					oRouter.navTo("selectionScreen", {}, true);
				}
				/*Start of chnage for defect 63096 on 05-Feb-2020*/
				var oLineTbl = that.getView().byId("LineItemTab");
				oLineTbl.removeSelections(true);
				/*End of chnage for defect 63096 on 05-Feb-2020*/
				that.getModel("mModelSummary").setProperty("/NonCopaHdrLbl", ""); /*Chnage added by Saptarshi on 21-Nov-2019*/
				//this.handleUnLockConcuurentUserNC();
			}
			/*End of change on 14-Jan-2020*/

		},
		/*Start of change by Debraj Date-11/6/2019*/
		//added on 06.11.2020 by prashant kumar
		handleUnLockConcuurentUserNC: function (oEvent) {
			var mModelSummary = this.getModel("mModelSummary");
			var oFilterData = mModelSummary.getProperty("/HeaderDataNC");
			var aFilter = [];
			if (oFilterData.RrfNoGf && oFilterData.CompanyCode) {
				aFilter.push(new sap.ui.model.Filter("RrfNo", sap.ui.model.FilterOperator.EQ, oFilterData.RrfNoGf));
				aFilter.push(new sap.ui.model.Filter("CompanyCode", sap.ui.model.FilterOperator.EQ, oFilterData.CompanyCode));
			}
			sap.ui.core.BusyIndicator.show(0);
			var functionSucess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
			}, this);

			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();

				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"

				});
			}, this);
			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
				json: true
			});
			oModel1.read("/RRF_LockSet", {
				filters: aFilter,
				success: functionSucess,
				error: fnError
			});

		},
		handlePressLinkOKNC: function (oEvent) {
			var mModelSummary = this.getView().getModel("mModelSummary");
			var sVales = this.getView().getModel("mModelSummary").getProperty("/TableItemSetNC/results");
			this.getView().getModel("mModelSummary").setProperty("/oEditable/attchmentExpndedNC", false);
			var sUpdateValues = this.getView().getModel("mModelSummary").getProperty("/updateRowDataNC");
			var locaSrv = this.getView().getModel("mModelSummary").getProperty("/SelcKeySetLocServNC");
			var rrfTablefragmentNonCoupa = this.getView().createId("rrfTablefragmentNonCoupa"); /*Added on 16-Jan-2020*/
			var requmf = this.getView().getModel("mModelSummary").getProperty("/SelcKeySet");
			var questionTable = mModelSummary.getProperty("/nPquestionSet");
			var _qfirstQuestionData = mModelSummary.getProperty("/nPquestionSetFirst");
			var questionMess = false;
			var dupiLicateFlag = false;
			var format = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/;
			var oTblBRF = this.getView().byId('LineItemTab');
			//special character validation msg
			if (sUpdateValues.ProcessGrp) {
				if (format.test(sUpdateValues.ProcessGrp)) {
					var specialMsg = this.getModel("i18n").getProperty("specialchMsg");
					MessageBox.error(specialMsg);
					return true;
				}
			}

			if (sUpdateValues.ProcessGrp && questionTable.length > 0 && _qfirstQuestionData.length > 0) {
				mModelSummary.getProperty("/nPquestionSetFirst")[0].ProcessGrp = sUpdateValues.ProcessGrp;
				for (var i = 0; i < questionTable.length; i++) {

					if ((!mModelSummary.getProperty("/nPquestionSet")[i].Answer || mModelSummary.getProperty("/nPquestionSet")[i].Answer === " ") ||
						(!_qfirstQuestionData[0].Answer || _qfirstQuestionData[0].Answer === " ")) {
						questionMess = true;
						break;
					}
					if (mModelSummary.getProperty("/nPquestionSet")[i].Answer === "Other" && !mModelSummary.getProperty("/nPquestionSet")[i].AnswerDesc) {
						var questionMess2 = true;
						break;

					} else {
						mModelSummary.getProperty("/nPquestionSet")[i].ProcessGrp = sUpdateValues.ProcessGrp;
						questionMess2 = false;
						questionMess = false;
					}
				}
			}

			if (questionMess === true) {
				var questionnaDetailMissing = this.getModel("i18n").getProperty("questionnaDetailMissing");
				MessageBox.alert(questionnaDetailMissing);
				return true;
			}

			if (questionMess2 === true) {

				var questionnaDetailMissing2 = this.getModel("i18n").getProperty("questionnaDetailMissing2");
				MessageBox.alert(questionnaDetailMissing2);
				return true;
			}

			var sArray = [];
			var sObj = {};
			var adhocFlag;
			if (!requmf && !sUpdateValues.GlobalCc) {
				sUpdateValues.RequestingMf = "";
			}
			if (sUpdateValues.GlobalCc && sUpdateValues.GlobalCc !== "N/A") {
				sUpdateValues.RequestingMf = "";
				/*Start of change for SCTASK1855604 - budget approvers by developer Satabdi Das on 19-May-2021*/
				if (!sUpdateValues.LoaContact || sUpdateValues.LoaContact === "" || !sUpdateValues.LoaEmail || sUpdateValues.LoaEmail ===
					"") {
					var sErrorMsg = this.getView().getModel("i18n").getProperty("BAMissingErrorMsg");
					MessageBox.error(sErrorMsg, {
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					});
					return;
				}
				/*End of change for SCTASK1855604 - budget approvers by developer Satabdi Das on 19-May-2021*/
			}
			if ((sUpdateValues.RequestingMf && sUpdateValues.ProcessGrp && sUpdateValues.NatureOfService && locaSrv && (sUpdateValues.AddlBillInfo ||
					sUpdateValues.LongText) && sUpdateValues.ContactPCop) ||
				(sUpdateValues.GlobalCc && sUpdateValues.Ltext && sUpdateValues.GfLineDesc)) { /*Changed on 02-Jan-2020*/
				if (this.rrfTablefragmentNonCoupa) {
					this.getModel("mModelSummary").setProperty("/GblFuncName", false); /*Added on 14-Jan-2020*/
					/*Start of change on 16-Jan-2020*/
					var JVSchPanel = sap.ui.core.Fragment.byId(rrfTablefragmentNonCoupa, "JVPanelNC");
					var BRFSchPanel = sap.ui.core.Fragment.byId(rrfTablefragmentNonCoupa, "BRFSecNC");
					if (JVSchPanel !== undefined && (JVSchPanel.getExpanded() === true)) {
						JVSchPanel.setExpanded(false);
					}
					if (BRFSchPanel !== undefined && (BRFSchPanel.getExpanded() === true)) {
						BRFSchPanel.setExpanded(false);
					}

					if ((sUpdateValues.NatureOfService === "Adhoc/One-Off") && (!sUpdateValues.LastDateSrv)) {
						adhocFlag = "true";
						var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
						MessageBox.alert(
							"Please enter mandatory fields.", {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}

						);
						this.getView().getModel("mModelSummary").setProperty("/SelcKeySet", sUpdateValues.RequestingMf);
						return;

					} else {
						adhocFlag = "false";
						//processing group duplicate changes  developed by prashant kumar 14.05.2021
						if (!sUpdateValues.GlobalCc && sUpdateValues.RequestingMf) {
							for (var k = 0; k < oTblBRF.getItems().length; k++) {
								var oTableData = oTblBRF.getBindingInfo("items").binding.oList[k];
								if (oTableData.RequestingMf === sUpdateValues.RequestingMf && oTableData.MemberFirm === sUpdateValues.MemberFirm &&
									oTableData
									.ProcessGrp ===
									sUpdateValues.ProcessGrp) {
									dupiLicateFlag = true;
									break;
								}
							}
							if (dupiLicateFlag === true) {
								var duplicateMessage = this.getView().getModel("i18n").getProperty("duplicateFieldMesg");
								MessageBox.alert(duplicateMessage + sUpdateValues.RequestingMf + " " + "Member Firm : " + sUpdateValues.MemberFirm +
									" and Processing group: " + sUpdateValues.ProcessGrp + "  already exists.");
								return true;
							}
						}

						this.rrfTablefragmentNonCoupa.close();
						if (questionTable.length > 0 && _qfirstQuestionData.length > 0) { /*Added for 63937*/
							mModelSummary.getProperty("/nPQuestionSetSubmit").push(_qfirstQuestionData[0]); //added for first question additon to submit set
							mModelSummary.setProperty("/nPquestionSetFirst", []);
							if (mModelSummary.getProperty("/nPquestionSet").length > 0) {
								for (var i = 0; i < mModelSummary.getProperty("/nPquestionSet").length; i++) {
									mModelSummary.getProperty("/nPQuestionSetSubmit").push(mModelSummary.getProperty("/nPquestionSet")[i]);
								}

								mModelSummary.setProperty("/nPquestionSet", []);
							}
						}

					}

				}
				if (!sUpdateValues.RequestingMf && sUpdateValues.GlobalCc) {
					sUpdateValues.RequestingMf = "N/A";
					sUpdateValues.MemberFirm = ""; /*Added for SCTASK1919812 on 17-Feb-2021 by Satabdi Das*/

				}
				if (!sUpdateValues.GlobalCc && sUpdateValues.RequestingMf) {
					sUpdateValues.GlobalCc = "N/A";
					sUpdateValues.CcShortDesc = ""; /*Added for SCTASK1895344 on 17-Feb-2021 by Satabdi Das*/
				}
				sObj.CompanyCode = sUpdateValues.CompanyCode;
				sObj.RequestingMf = sUpdateValues.RequestingMf;
				sObj.MemberFirm = sUpdateValues.MemberFirm;
				sObj.Landx = sUpdateValues.Landx; /*Added by Satabdi Das on 06-JAN-2020*/
				sObj.GlobalCc = sUpdateValues.GlobalCc;
				sObj.Ltext = sUpdateValues.Ltext; /*Added by Satabdi Das on 03-Dec-2019*/
				sObj.Descript = sUpdateValues.Descript; /*Added by Satabdi Das on 13-Jan-2020*/
				sObj.ProcessGrp = sUpdateValues.ProcessGrp; /*Added by Satabdi Das on 03-Dec-2019*/
				sObj.SapCodeMf = sUpdateValues.SapCodeMf; /*Added by Satabdi Das on 04-Dec-2019*/
				sObj.ServNowStatus = sUpdateValues.ServNowStatus; /*Added by Satabdi Das on 05-Dec-2019*/
				sObj.ContactPCop = sUpdateValues.ContactPCop;
				sObj.CopEmailId = sUpdateValues.CopEmailId;
				sObj.ConfirmationOfParticipation = sUpdateValues.ConfirmationOfParticipation;
				sObj.CopYesDate = sUpdateValues.CopYesDate;
				sObj.CopAtt = sUpdateValues.CopAtt;
				sObj.ServiceNowCop = sUpdateValues.ServiceNowCop;
				sObj.GlobalGl = sUpdateValues.GlobalGl;
				sObj.ActRechrgAmnt = sUpdateValues.ActRechrgAmnt;
				sObj.AmntRechrgPo = sUpdateValues.AmntRechrgPo;
				sObj.AttenBrf = sUpdateValues.AttenBrf;
				sObj.AttenBrfEmail = sUpdateValues.AttenBrfEmail;
				sObj.BriefDescriptionOfServices = sUpdateValues.BriefDescriptionOfServices;
				sObj.DetailsDescriptionOfService = sUpdateValues.DetailsDescriptionOfService;
				sObj.EntityAddress = sUpdateValues.EntityAddress;
				sObj.EntityName = sUpdateValues.EntityName;
				sObj.NewEntity = sUpdateValues.NewEntity; /*Added on 21-Feb-2020 by Satabdi Das*/
				sObj.LastDateSrv = sUpdateValues.LastDateSrv;
				sObj.LoaContact = sUpdateValues.LoaContact;
				sObj.LoaEmail = sUpdateValues.LoaEmail;
				sObj.LocationOfTheServicesReq = locaSrv;
				sObj.RrfStatus = sUpdateValues.RrfStatus;
				sObj.LongText = sUpdateValues.LongText;
				sObj.BillingSyntax = sUpdateValues.BillingSyntax; /*Added for SCTASK1918966*/
				sObj.ShortDescription = sUpdateValues.ShortDescription; /*Added for SCTASK1943810*/
				sObj.NatureOfService = sUpdateValues.NatureOfService;
				sObj.PercY = sUpdateValues.PercY;
				sObj.VatId = sUpdateValues.VatId;
				sObj.WhTax = sUpdateValues.WhTax;
				sObj.MfCostCenter = sUpdateValues.MfCostCenter;
				sObj.MfApEmail = sUpdateValues.MfApEmail;
				sObj.AdlLoaContact = sUpdateValues.AdlLoaContact;
				sObj.AdlLoaEmail = sUpdateValues.AdlLoaEmail;
				sObj.DebitGl = sUpdateValues.DebitGl;
				sObj.DebitCc = sUpdateValues.DebitCc;
				sObj.Amt1 = sUpdateValues.Amt1;
				sObj.Amt2 = sUpdateValues.Amt2;
				sObj.CreditCc = sUpdateValues.CreditCc;
				sObj.CreditGl = sUpdateValues.CreditGl;
				sObj.Urn = sUpdateValues.Urn;
				sObj.Amount = sUpdateValues.Amount;
				sObj.LetterOfAcknowledgement = sUpdateValues.LetterOfAcknowledgement;
				sObj.ServiceNowLoa = sUpdateValues.ServiceNowLoa;
				sObj.AddlBillInfo = sUpdateValues.AddlBillInfo;
				sObj.LoaAtt = sUpdateValues.LoaAtt;
				sObj.GfLineDesc = sUpdateValues.GfLineDesc;
				sObj.AddlContactPerson = sUpdateValues.AddlContactPerson;
				sObj.AddlContactEmail = sUpdateValues.AddlContactEmail;
				// sObj.LocOfRenderingUs = sUpdateValues.LocOfRenderingUs;
				/*Start of change on 16-Jan-2020*/
				if (sUpdateValues.Amount !== undefined && sUpdateValues.BillingFrequency !== undefined && sUpdateValues.StartDate !== undefined &&
					sUpdateValues.NoOfOccur !==
					undefined) {
					sObj.Amount = sUpdateValues.Amount; // Billing Amount
					sObj.BillingFrequency = sUpdateValues.BillingFrequency; // Billing Frequency
					sObj.StartDate = sUpdateValues.StartDate; // Billing Start Date
					sObj.NoOfOccur = sUpdateValues.NoOfOccur; // No Of Occurences
					sObj.BillSchedule = true; /*Bill Flag*/
				} else {
					sObj.Amount = sUpdateValues.Amount; // Billing Amount
					sObj.BillingFrequency = sUpdateValues.BillingFrequency; // Billing Frequency
					sObj.StartDate = sUpdateValues.StartDate; // Billing Start Date
					sObj.NoOfOccur = sUpdateValues.NoOfOccur; // No Of Occurences
					sObj.BillSchedule = false; /*Bill Flag*/
				}
				/*End of change on 16-Jan-2020*/
				if (sUpdateValues.BillSch) {
					sObj.Amount = sUpdateValues.BillSch.Amount; // Billing Amount
					sObj.BillingFrequency = sUpdateValues.BillSch.BillingFrequency; // Billing Frequency
					sObj.StartDate = sUpdateValues.BillSch.StartDate; // Billing Start Date
					sObj.NoOfOccur = sUpdateValues.BillSch.NoOfOccur; // No Of Occurences
				}
				/*change start on 23-Dec-2019*/
				//Start of change by Debraj Manna on 11/13/2019
				// if (sObj.RequestingMf === "N/A") {

				// 	sObj.visibleBillSch = false;
				// } else {
				// 	sObj.visibleBillSch = true;
				// }
				//End of change by Debraj Manna on 11/13/2019
				/*change end on 23-Dec-2019*/
				var oCopied = $.extend(true, [], sObj);
				if (adhocFlag === "false") {
					if (sVales != undefined) {
						sVales.push(oCopied);
						this.getView().getModel("mModelSummary").setProperty("/TableItemSetNC/results", sVales);
					} else {
						sArray.push(oCopied);
						this.getView().getModel("mModelSummary").setProperty("/TableItemSetNC/results", sArray);
					}
				}

			} else {
				MessageBox.alert("Please enter mandatory field");
				this.getView().getModel("mModelSummary").setProperty("/SelcKeySet", sUpdateValues.RequestingMf);
				return; /*63343*/
			}
			// Start of change by Debraj on 11/11/2019
			var sHeaderData = this.getView().getModel("mModelSummary").getProperty("/HeaderDataNC");
			if (sHeaderData.RrfNoGf !== undefined && sHeaderData.CompanyCode !== undefined && sUpdateValues.Amount !== undefined &&
				sUpdateValues.BillingFrequency !==
				undefined && sUpdateValues.StartDate !== undefined && sUpdateValues.NoOfOccur !== undefined && (sUpdateValues.RequestingMf !==
					undefined || sUpdateValues.GlobalCc !== undefined) /*Added on 18-Dec-2019*/ ) { /*Chnaged by Sapatrshi on 14th-Nov-2019*/
				var oPayLoad = {
					CompanyCode: sHeaderData.CompanyCode, // Company Code
					RrfNoGf: sHeaderData.RrfNoGf, // RRF No.
					RequestingMf: sObj.RequestingMf, // Requesting MF
					ProcessGrp: sObj.ProcessGrp,
					MemberFirm: sObj.MemberFirm,
					CcShortDesc: "",
					/*Added on 10-Jan-2020*/
					Amount: sObj.Amount, // Billing Amount
					BillingFrequency: sObj.BillingFrequency, // Billing Frequency
					StartDate: sObj.StartDate, // Billing Start Date
					NoOfOccur: sObj.NoOfOccur, // No Of Occurences
					GlobalCc: sObj.GlobalCc //Global Cost Center Added ob 18-Dec-2010
				};
				var fnSuccess = jQuery.proxy(function (d) {
					sap.ui.core.BusyIndicator.hide(0);
					/*Start of change on 06-Jan-2020*/
					var sTableRows = this.getView().getModel("mModelSummary").getProperty("/TableItemSetNC/results");
					var len = sTableRows.length;
					var sNewRow = sTableRows[len - 1];
					// this.getView().getModel("mModelSummary").setProperty("/TableItemSetNC/results/BillSchedule", true);
					this.getView().getModel("mModelSummary").setProperty("/updateRowDataNC/BillSchedule", true); /*Added on 16-Jan-2020*/
					/*End of change on 06-Jan-2020*/
					var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
					if (d.Flag) {
						var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
						MessageBox.error(
							d.Message, {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}
						);
					} else {
						MessageBox.show(
							d.Message, {
								icon: MessageBox.Icon.SUCCESS,
								title: "Success",
								actions: [MessageBox.Action.OK]
							}
						);
					}

				}, this);
				var fnError = jQuery.proxy(function (d) {
					var r = JSON.parse(JSON.stringify(d));
					sap.ui.core.BusyIndicator.hide();
					// this.getView().getModel("mModelSummary").setProperty("/TableItemSetNC/results/BillSchedule", false); /*Added on 16-Jan-2020*/
					MessageToast.show(r.message, {
						autoClose: true,
						width: "20rem"

					});
				}, this);
				var objectOne = {};
				objectOne.successCallback = fnSuccess;
				objectOne.errorCallback = fnError;
				DataManagerARrecharge.CreateBillSchedule(oPayLoad, objectOne);
			}
			// End of change by Debraj on 11/11/2019
			// this.getView().getModel("mModelSummary").setProperty("/TableItemSetNC/results/BillSchedule", false); /*Added on 16-Jan-2020*/
			this.getView().getModel("mModelSummary").refresh(true);
		},
		/*End of change by Debraj Date-11/6/2019*/
		onCancel: function (oEvent) {
			var mModelSummary = this.getModel("mModelSummary");
			mModelSummary.setProperty("/oEditable/attchmentExpndedNC", false);
			mModelSummary.setProperty("/oEditableNC/lastDateOfServLabelNP", false);
			this.oRestVal = false;
			var rrfTablefragmentNonCoupa = this.getView().createId("rrfTablefragmentNonCoupa"); /*Added on 16-Jan-2020*/
			var displayMode = this.getModel("mModelSummary").getProperty("/displayMode");
			if (displayMode === false) {
				this.getView().getModel("mModelSummary").setProperty("/oEditableNC/editLineItemCop", true);
				this.getView().getModel("mModelSummary").setProperty("/oEditableNC/editLineItemMF", true);
				this.getView().getModel("mModelSummary").setProperty("/oEditableNC/editLineItemAddInf", true);
			}
			if (this.rrfTablefragmentNonCoupa.isOpen()) {
				this.getModel("mModelSummary").setProperty("/GblFuncName", false); /*Added on 14-Jan-2020*/
				/*Start of change on 16-Jan-2020*/
				var JVSchPanel = sap.ui.core.Fragment.byId(rrfTablefragmentNonCoupa, "JVPanelNC");
				var BRFSchPanel = sap.ui.core.Fragment.byId(rrfTablefragmentNonCoupa, "BRFSecNC");
				if (JVSchPanel !== undefined && (JVSchPanel.getExpanded() === true)) {
					JVSchPanel.setExpanded(false);
				}
				if (BRFSchPanel !== undefined && (BRFSchPanel.getExpanded() === true)) {
					BRFSchPanel.setExpanded(false);
				}
				/*End of change on 16-Jan-2020*/
				jQuery.sap.delayedCall(500, this,
					function () {
						var tbl = this.getView().byId('LineItemTab');
						var lLineItemTable = this.getView().getModel("mModelSummary").getProperty("/TableItemSetNC/results");
						if (lLineItemTable) {
							for (var i = 0; i < lLineItemTable.length; i++) {
								var CopInitiate = lLineItemTable[i].CopInitiate;
								if (CopInitiate === "X") {
									var x = tbl.getAggregation("items")[i];
									x.getMultiSelectControl().setEnabled(false);
								}
								if (mModelSummary.getProperty("/updateRowDataNC_Old")) {
									mModelSummary.setProperty("/updateRowDataNC", mModelSummary.getProperty("/updateRowDataNC_Old"));
									if ((lLineItemTable[i].RequestingMf === mModelSummary.getProperty("/updateRowDataNC").RequestingMf && lLineItemTable[i].ProcessGrp ===
											mModelSummary.getProperty("/updateRowDataNC").ProcessGrp && lLineItemTable[i].Ltext === mModelSummary.getProperty(
												"/updateRowDataNC").Ltext && lLineItemTable[i].MemberFirm === mModelSummary.getProperty("/updateRowDataNC").MemberFirm)) {
										mModelSummary.getProperty("/TableItemSetNC").results[i] = mModelSummary.getProperty("/updateRowDataNC");

									}
								}

							}
							mModelSummary.setProperty("/updateRowDataNC_Old", undefined);
						}
					});
				this.rrfTablefragmentNonCoupa.close();

				/*Start - CR  Changed On 26-Aug-2021 By Prashant and Chhanda*/
				if (mModelSummary.getProperty("/TableItemSetNC_Old")) {
					mModelSummary.setProperty("/TableItemSetNC", mModelSummary.getProperty("/TableItemSetNC_Old"));
				}
				if (mModelSummary.getProperty("/updateRowDataNC_Old")) {
					mModelSummary.setProperty("/updateRowDataNC", mModelSummary.getProperty("/updateRowDataNC_Old"));
				}
				mModelSummary.refresh(true);
				//	mModelSummary.setProperty("/TableItemSetNC_Old", undefined);

				// if (mModelSummary.getProperty("/updateRowDataNC/ConfYn_old")) {
				// 	mModelSummary.setProperty("/updateRowDataNC/ConfirmationOfParticipation", mModelSummary.getProperty("/updateRowDataNC/ConfYn_old"));
				// }

				// if (mModelSummary.getProperty("/updateRowDataNC/CopYesDate_old")) {
				// 	mModelSummary.setProperty("/updateRowDataNC/CopYesDate", mModelSummary.getProperty("/updateRowDataNC/CopYesDate_old"));
				// }
				// if (mModelSummary.getProperty("/updateRowDataNC/ServNowCop_old")) {
				// 	mModelSummary.setProperty("/updateRowDataNC/ServiceNowCop", mModelSummary.getProperty("/updateRowDataNC/ServNowCop_old"));
				// }
				// if (mModelSummary.getProperty("/updateRowDataNC/ServNowStatus_old")) {
				// 	mModelSummary.setProperty("/updateRowDataNC/ServNowStatus", mModelSummary.getProperty("/updateRowDataNC/ServNowStatus_old"));
				// }
				// mModelSummary.setProperty("/updateRowDataNC/ConfYn_old", undefined);
				// mModelSummary.setProperty("/updateRowDataNC/CopYesDate_old", undefined);
				// mModelSummary.setProperty("/updateRowDataNC/ServNowCop_old", undefined);
				// mModelSummary.setProperty("/updateRowDataNC/ServNowStatus_old", undefined);

				/*End - CR  Changed On 26-Aug-2021 By Prashant and Chhanda*/

			}
		},

		/*Start of change by Satabdi Das on 17-Feb-2021 for SCTASK1918966*/
		handlePressTextEditorNC: function (oEvent) {
			var mModelSummary = this.getView().getModel("mModelSummary");
			var fragmentId = this.getView().createId("longTextFrag");
			var sValue = mModelSummary.getData().updateRowDataNC.LongText;
			if (!this._oLongTextFrag) {
				this._oLongTextFrag = sap.ui.xmlfragment(fragmentId, "kgo.ARRecharge.view.longTextEditorNC", this);
				this.getView().addDependent(this._oLongTextFrag);
			}
			if (sValue && sValue !== "") {
				if (sValue.indexOf("|") >= 0) {
					/*Start of chnage for Defect 63890 on 25-03-2021*/
					// sValue = sValue.replaceAll("|", "\n");
					var sPipeline = "|";
					var sNewLine = "\n";
					sValue = sValue.split(sPipeline).join(sNewLine);
					/*End of change for defect 63890 on 25-03-2021*/
				}
				mModelSummary.setProperty("/updateRowDataNC/LongText", sValue);
			} else {
				mModelSummary.setProperty("/updateRowDataNC/LongText", "");
			}
			/*Start - handle 70 character limit*/
			// var txtArealongText = sap.ui.core.Fragment.byId(fragmentId, "longTextNC");
			// var charlimit = UIGlobal.getLongTextCharLimit();
			// txtArealongText.onkeyup = function () {
			// 	var lines = txtArealongText.getValue().split('\n');
			// 	for (var i = 0; i < lines.length; i++) {
			// 		if (lines[i].length <= charlimit) continue;
			// 		var j = 0;
			// 		var space = charlimit;
			// 		while (j++ <= charlimit) {
			// 			if (lines[i].charAt(j) === ' ') space = j;
			// 		}
			// 		lines[i + 1] = lines[i].substring(space + 1) + (lines[i + 1] || "");
			// 		lines[i] = lines[i].substring(0, space);
			// 	}
			// 	txtArealongText.setValue(lines.slice(0, 100).join('\n'));
			// };
			/*End - handle 70 character limit*/
			this._oLongTextFrag.open();
		},
		onAddingTextNC: function (oEvent) {
			var sValue = oEvent.getParameter("value");
			var mModelSummary = this.getView().getModel("mModelSummary");
			if (sValue !== "") {
				// if (sValue.length > 70) {
				// 	var chunks = sValue.match(/.{1,70}/g);
				// 	sValue = chunks.join("\n");
				// }
				mModelSummary.setProperty("/updateRowDataNC/LongText", sValue);
			} else {
				mModelSummary.setProperty("/updateRowDataNC/LongText", "");
			}
		},
		longTextCloseNC: function (oEvent) {
			var mModelSummary = this.getView().getModel("mModelSummary");
			var sValue = mModelSummary.getProperty("/updateRowDataNC/LongText");
			this._oLongTextFrag.close();
			if (sValue.indexOf("\n") >= 0) {
				/*Start of chnage for Defect 63890 on 25-03-2021*/
				// sValue = sValue.replaceAll("\n", "|");
				var sPipeline = "|";
				var sNewLine = "\n";
				sValue = sValue.split(sNewLine).join(sPipeline);
				/*End of change for defect 63890 on 25-03-2021*/
				mModelSummary.setProperty("/updateRowDataNC/LongText", sValue);
			}
		},
		/*End of change by Satabdi Das on 17-Feb-2021 for SCTASK1918966*/

		/*Start of change by Saptarshi*/

		onPressGlAccNC: function (oEvent) {
			var id = oEvent.getSource().getId();
			var mModelSummary = this.getModel("mModelSummary");
			if (mModelSummary.getProperty("/HeaderDataNC/GlobalCc")) {
				var oGlobalGl = mModelSummary.getProperty("/HeaderDataNC/GlobalGl");
			} else {
				oGlobalGl = "";
			}
			if (id.indexOf("GlAccount") > 0) {
				this.GlAccValue = "GLACC";
			} else if (id.indexOf("DebitGl") > 0) {
				this.GlAccValue = "DEBITGL";
			} else if (id.indexOf("CreditGl") > 0) {
				this.GlAccValue = "CREDITGL";
			}
			var sSrchVal = oGlobalGl;
			sap.ui.core.BusyIndicator.show(0);
			var aFilter = [];
			var mArrayOut = [];
			var sPath = "";
			sPath = "/RRF_GLSet ";
			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				mModelSummary = this.getModel("mModelSummary");
				for (var i = 0; i < d.results.length; i++) {
					var oGlobalGlAccont = {};
					oGlobalGlAccont.Ktopl = d.results[i].Ktopl;
					oGlobalGlAccont.Saknr = d.results[i].Saknr;
					mArrayOut.push(oGlobalGlAccont);
				}
				mModelSummary.setProperty("/RRF_GLSet", mArrayOut);
				// mModelSummary.refresh(true);
				var fragmentId = this.getView().createId("searchGlAccount");
				if (!this._oSeachGlAccNC) {
					this._oSeachGlAccNC = sap.ui.xmlfragment(fragmentId, "kgo.ARRecharge.view.searchHelpForGlAccNC", this);
					this.getView().addDependent(this._oSeachGlAccNC);
				}
				this._oSeachGlAccNC.open();
			}, this);
			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();
				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"
				});
			}, this);
			// var sParams = {};
			// var oObject = {};
			// oObject.Filter = aFilter;
			// oObject.Params = sParams;
			// oObject.successCallback = fnSuccess;
			// oObject.errorCallback = fnError;
			// oObject.sPath = sPath;
			// DataManagerARrecharge.getNonCoupaReqhelpValue(oObject);
			/*R&D---start*/
			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
				json: true
			});
			oModel1.read("/RRF_GLSet", {
				success: fnSuccess,
				error: fnError
			});
			/*R&D---end*/
		},
		/*Start of change by Saptarshi on 19-Nov-2019*/
		onCloseHelp: function () {
			// var fragId = this.getView().createId("searchCostCenter");
			// var SearchId = sap.ui.core.Fragment.byId(fragId, "searchCCNC");
			// SearchId.setValue("");
			// var aFilter = [];
			// var bLtext = this.getModel("mModelSummary").getProperty("/LtextSearch");
			// if (bLtext === false) {
			// 	aFilter.push(new Filter("Kostl", FilterOperator.Contains, ""));
			// } else if (bLtext === true) {
			// 	aFilter.push(new Filter("Ltext", FilterOperator.Contains, ""));
			// }
			// var frag = this.getView().createId("searchCostCenter");
			// var table = sap.ui.core.Fragment.byId(frag, "listCCNC");
			// var oBinding = table.getBinding("items");
			// oBinding.filter(aFilter, "Application");
			if (this._oSeachCCNC) {
				this.getView().getModel("mModelSummary").setProperty("/filterSearch", "");
				this.getView().getModel("mModelSummary").setProperty("/CostScnterSearchSetNP", []);
				this._oSeachCCNC.close();

			}
		},
		onSearchCCNC: function (oEvent) {
			var aFilter = [];
			var sQuery = oEvent.getSource().getValue();
			sQuery = sQuery.trim();
			var bLtext = this.getModel("mModelSummary").getProperty("/LtextSearch");
			if (sQuery && sQuery.length > 0 && bLtext === false) {
				aFilter.push(new Filter("Kostl", FilterOperator.Contains, sQuery));
			} else if (sQuery && sQuery.length > 0 && bLtext === true) {
				aFilter.push(new Filter("Ltext", FilterOperator.Contains, sQuery));
			}
			var fragmentId = this.getView().createId("searchCostCenter");
			var table = sap.ui.core.Fragment.byId(fragmentId, "listCCNC");
			var oBinding = table.getBinding("items");
			oBinding.filter(aFilter, "Application");
		},
		onSearchGlAccNC: function (oEvent) {
			var aFilter = [];
			var sQuery = oEvent.getSource().getValue();
			sQuery = sQuery.trim();
			if (sQuery && sQuery.length > 0) {
				aFilter.push(new Filter("Saknr", FilterOperator.Contains, sQuery));
			}
			var fragmentId = this.getView().createId("searchGlAccount");
			var table = sap.ui.core.Fragment.byId(fragmentId, "listGlAccNC");
			var oBinding = table.getBinding("items");
			oBinding.filter(aFilter, "Application");
		},
		onCloseHelpGLNC: function () {
			var fragId = this.getView().createId("searchGlAccount");
			var SearchId = sap.ui.core.Fragment.byId(fragId, "searchIdGLAccNc");
			SearchId.setValue("");
			var aFilter = [];
			aFilter.push(new Filter("Saknr", FilterOperator.Contains, ""));
			var frag = this.getView().createId("searchGlAccount");
			var table = sap.ui.core.Fragment.byId(frag, "listGlAccNC");
			var oBinding = table.getBinding("items");
			oBinding.filter(aFilter, "Application");
			if (this._oSeachGlAccNC) {
				this._oSeachGlAccNC.close();
			}
		},
		/*End of change by Saptarshi on 19-Nov-2019*/
		onSelectGlAccNC: function (oEvent) {
			var GlAcc = oEvent.getSource().getBindingContext("mModelSummary").getObject();
			if (this.GlAccValue != undefined) {
				if (this.GlAccValue === "GLACC") {
					this.getView().getModel("mModelSummary").setProperty("/updateRowDataNC/GlobalGl", GlAcc.Saknr);
				} else if (this.GlAccValue === "CREDITGL") {
					this.getView().getModel("mModelSummary").setProperty("/updateRowDataNC/CreditGl", GlAcc.Saknr);
				} else if (this.GlAccValue === "DEBITGL") {
					this.getView().getModel("mModelSummary").setProperty("/updateRowDataNC/DebitGl", GlAcc.Saknr);
				}
			}
			if (this._oSeachGlAccNC) {
				this._oSeachGlAccNC.close();
			}
		},

		onPressGlCCNC: function (oEvent) {
			var id = oEvent.getSource().getId();
			var mModelSummary = this.getModel("mModelSummary");
			var oCompyCode = mModelSummary.getProperty("/HeaderDataNC").CompanyCode;
			if (mModelSummary.getProperty("/HeaderDataNC/GlobalCc")) {
				var oGlobalCc = mModelSummary.getProperty("/HeaderDataNC/GlobalCc");
			} else {
				oGlobalCc = "";
			}

			if (id.indexOf("GlobalCC") > 0) {
				this.CostCenterValue = "GLOBALCC";
				this.getModel("mModelSummary").setProperty("/GblFuncName", true); /*Added on 13-Jan-2020*/
				this.getModel("mModelSummary").setProperty("/LtextSearch", false);
			} else if (id.indexOf("DebitCc") > 0) {
				this.CostCenterValue = "DEBITCC";
				this.getModel("mModelSummary").setProperty("/LtextSearch", false);
			} else if (id.indexOf("CreditCc") > 0) {
				this.CostCenterValue = "CREDITCC";
				this.getModel("mModelSummary").setProperty("/LtextSearch", false);
			} else if (id.indexOf("costCenter") >= 0) { /*Added on 24-Dec-2019*/
				this.CostCenterValue = "COSTCENTER"; /*Added on 24-Dec-2019*/
				this.getModel("mModelSummary").setProperty("/LtextSearch", false);
			} else if (id.indexOf("NPHdrLtext") >= 0) {
				this.CostCenterValue = "HDRLTEXT";
				this.getModel("mModelSummary").setProperty("/LtextSearch", true);
			}

			var sSrchVal = oGlobalCc;

			var CostScnterSearchSetNP = mModelSummary.getProperty("/CostScnterSearchSetNP");
			// var fragmentId = this.getView().createId("searchCoordinator");
			sap.ui.core.BusyIndicator.show(0);

			var aFilter = [];
			var oFilterSerach;

			if (CostScnterSearchSetNP.Kostl) {
				oFilterSerach = new sap.ui.model.Filter("Kostl", sap.ui.model.FilterOperator.EQ, CostScnterSearchSetNP.Kostl);
				aFilter.push(oFilterSerach);
			}
			if (CostScnterSearchSetNP.Ltext) {
				oFilterSerach = new sap.ui.model.Filter("Ltext", sap.ui.model.FilterOperator.EQ, CostScnterSearchSetNP.Ltext);
				aFilter.push(oFilterSerach);
			}
			if (oCompyCode) {
				oFilterSerach = new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.EQ, oCompyCode);
				aFilter.push(oFilterSerach);
			}

			var mArrayOut = [];
			var sPath = "";
			sPath = "/RRF_CCSet ";
			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				mModelSummary = this.getModel("mModelSummary");
				mModelSummary.getProperty("/CostScnterSearchSetNP", []);
				for (var i = 0; i < d.results.length; i++) {
					var oGlobalCC = {};
					oGlobalCC.Kokrs = d.results[i].Kokrs;
					oGlobalCC.Kostl = d.results[i].Kostl;
					oGlobalCC.Ltext = d.results[i].Ltext; /*Added by Satabdi Das on 03-Dec-2019*/
					oGlobalCC.Descript = d.results[i].Descript; /*Added by Satabdi Das on 13-Jan-2020*/
					mArrayOut.push(oGlobalCC);
				}
				mModelSummary.setProperty("/RRF_CCSet", mArrayOut);
				// mModelSummary.refresh(true);
				var fragmentId = this.getView().createId("searchCostCenter");
				if (!this._oSeachCCNC) {
					this._oSeachCCNC = sap.ui.xmlfragment(fragmentId, "kgo.ARRecharge.view.searchHelpForCCNC", this);
					this.getView().addDependent(this._oSeachCCNC);
				}
				this._oSeachCCNC.open();
			}, this);
			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();

				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"
				});
			}, this);
			// var sParams = {};
			// var oObject = {};
			// oObject.Filter = aFilter;
			// oObject.Params = sParams;
			// oObject.successCallback = fnSuccess;
			// oObject.errorCallback = fnError;
			// oObject.sPath = sPath;
			// DataManagerARrecharge.getNonCoupaReqhelpValue(oObject);
			/*R&D---start*/
			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
				json: true
			});
			oModel1.read("/RRF_CCSet", {
				filters: aFilter,
				success: fnSuccess,
				error: fnError
			});
			/*R&D---end*/
		},

		onPressCCNC: function (oEvent) {
			var costCenter = oEvent.getSource().getBindingContext("mModelSummary").getObject();

			this.getView().getModel("mModelSummary").setProperty("/filterSearch", "");
			this.getView().getModel("mModelSummary").setProperty("/CostScnterSearchSetNP", []);
			if (this.CostCenterValue != undefined) {
				if (this.CostCenterValue === "GLOBALCC") {
					this.getView().getModel("mModelSummary").setProperty("/updateRowDataNC/GlobalCc", costCenter.Kostl);
					this.getView().getModel("mModelSummary").setProperty("/updateRowDataNC/Ltext", costCenter.Ltext); /*Added by Satabdi Das on 03-Dec-2019*/
					this.getView().getModel("mModelSummary").setProperty("/updateRowDataNC/Descript", costCenter.Descript); /*Added on 13-Jan-2020*/
					/*Start of change for SCTASK1855604 - budget approvers by developer Satabdi Das on 19-May-2021*/
					this.getView().getModel("mModelSummary").setProperty("/updateRowDataNC/LoaContact", "");
					this.getView().getModel("mModelSummary").setProperty("/updateRowDataNC/LoaEmail", "");
					this.getView().getModel("mModelSummary").setProperty("/updateRowDataNC/AdlLoaContact", "");
					this.getView().getModel("mModelSummary").setProperty("/updateRowDataNC/AdlLoaEmail", "");
					/*End of change for SCTASK1855604 - budget approvers by developer Satabdi Das on 19-May-2021*/
				} else if (this.CostCenterValue === "DEBITCC") {
					this.getView().getModel("mModelSummary").setProperty("/updateRowDataNC/DebitCc", costCenter.Kostl);
				} else if (this.CostCenterValue === "CREDITCC") {
					this.getView().getModel("mModelSummary").setProperty("/updateRowDataNC/CreditCc", costCenter.Kostl);
				} else if (this.CostCenterValue === "COSTCENTER") { /*Added on 24-Dec-2019*/
					this.getView().getModel("mModelSummary").setProperty("/HeaderDataNC/Kostl", costCenter.Kostl); /*Added on 24-Dec-2019*/
					this.getView().getModel("mModelSummary").setProperty("/HeaderDataNC/Ltext", costCenter.Ltext); /*Added by Satabdi Das on 10-Jan-2020*/
				} /*Added on 24-Dec-2019*/
				else if (this.CostCenterValue === "HDRLTEXT") { /*Added on 24-Dec-2019*/
					this.getView().getModel("mModelSummary").setProperty("/HeaderDataNC/Kostl", costCenter.Kostl); /*Added on 24-Dec-2019*/
					this.getView().getModel("mModelSummary").setProperty("/HeaderDataNC/Ltext", costCenter.Ltext); /*Added by Satabdi Das on 10-Jan-2020*/
				}
			}
			// var fragId = this.getView().createId("searchCostCenter");
			// var SearchId = sap.ui.core.Fragment.byId(fragId, "searchCCNC");
			// SearchId.setValue("");
			// var aFilter = [];
			// aFilter.push(new Filter("Kostl", FilterOperator.Contains, ""));
			// var frag = this.getView().createId("searchCostCenter");
			// var table = sap.ui.core.Fragment.byId(frag, "listCCNC");
			// var oBinding = table.getBinding("items");
			// oBinding.filter(aFilter, "Application");
			if (this._oSeachCCNC) {
				this._oSeachCCNC.close();
			}

		},

		/*Start of change by Satabdi Das on 03-March-2021 for 63648 -restricted Cost Center*/
		onPressRestCCNP: function (oEvent) {
			var id = oEvent.getSource().getId();
			var mModelSummary = this.getView().getModel("mModelSummary");
			var oCompyCode = mModelSummary.getProperty("/HeaderDataNC").CompanyCode;

			if (mModelSummary.getProperty("/HeaderDataNC/GlobalCc")) {
				var oGlobalCc = mModelSummary.getProperty("/HeaderDataNC/GlobalCc");
			} else {
				oGlobalCc = "";
			}

			var sSrchVal = oGlobalCc;
			var aRestCc = mModelSummary.getProperty("/RestCCSearchSetNP");

			sap.ui.core.BusyIndicator.show(0);

			var aFilter = [];
			var oFilterSerach;

			if (aRestCc.Kostl) {
				oFilterSerach = new Filter("Kostl", FilterOperator.EQ, aRestCc.Kostl);
				aFilter.push(oFilterSerach);
			}
			if (aRestCc.Ltext) {
				oFilterSerach = new Filter("Ltext", FilterOperator.EQ, aRestCc.Ltext);
				aFilter.push(oFilterSerach);
			}
			if (oCompyCode) {
				oFilterSerach = new Filter("Bukrs", FilterOperator.EQ, oCompyCode);
				aFilter.push(oFilterSerach);
			}

			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				mModelSummary.setProperty("/RRF_RestCCSet", d.results);
				mModelSummary.refresh(true);

				var fragmentId = this.getView().createId("RestsearchCostCenter");

				if (!this._oRestSeachCCNP) {
					this._oRestSeachCCNP = sap.ui.xmlfragment(fragmentId, "kgo.ARRecharge.view.restSearchHelpCCNP", this);
					this.getView().addDependent(this._oRestSeachCCNP);
				}
				this._oRestSeachCCNP.open();
			}, this);

			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();

				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"
				});
			}, this);

			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
				json: true
			});
			oModel1.read("/RRF_RestCCSet", {
				filters: aFilter,
				success: fnSuccess,
				error: fnError
			});
		},

		onCloseRestCCNP: function () {
			if (this._oRestSeachCCNP) {
				this._oRestSeachCCNP.close();
				this.getView().getModel("mModelSummary").setProperty("/RestCCSearchSetNP", []);
			}
		},

		onSelectRestCCNP: function (oEvent) {
			var mModelSummary = this.getView().getModel("mModelSummary");
			var costCenter = oEvent.getSource().getBindingContext("mModelSummary").getObject();
			mModelSummary.setProperty("/RestCCSearchSetNP", []);
			mModelSummary.setProperty("/HeaderDataNC/Kostl", costCenter.Kostl);
			mModelSummary.setProperty("/HeaderDataNC/Ltext", costCenter.Ltext);
			this._oRestSeachCCNP.close();
		},
		/*End of change by Satabdi Das on 03-March-2021 for 63648 -restricted Cost Center */

		/*Start of change by Satabdi Das on 17-Feb-2021 for SCTASK1919812*/
		onMfSearchHelpNC: function () {
			var mModelSummary = this.getModel("mModelSummary");
			// if (mModelSummary.getProperty("/HeaderDataNC/memberFirm")) {
			// 	var oMemberfirm = mModelSummary.getProperty("/HeaderDataNC/memberfirm");
			// } else {
			// 	oMemberfirm = "";
			// }
			// var sSrchVal = oMemberfirm;
			// var fragmentId = this.getView().createId("searchCoordinator");
			sap.ui.core.BusyIndicator.show(0);

			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				mModelSummary = this.getModel("mModelSummary");
				mModelSummary.setSizeLimit(d.results.length); /*Added on 31-Dec-2019*/
				mModelSummary.setProperty("/RRF_MFSet", d.results);
				this.getView().getModel("mModelSummary").setProperty("/SelcKeySet", ""); /*Added on 31-Dec-2019*/
				// this.getView().getModel("mModelSummary").setProperty("/updateRowDataNC/LocationOfTheServicesReq", ""); /*Added on 28-Jan-2020*/
				// this.getView().getModel("mModelSummary").setProperty("/SelcKeySetLocServNC", "");
				this.getView().getModel("mModelSummary").refresh(true); /*Added on 27-Jan-2020*/
				// mModelSummary.refresh(true);
			}, this);
			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();

				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"
				});
			}, this);

			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
				json: true
			});
			oModel1.read("/Member_FirmSet", {
				success: fnSuccess,
				error: fnError
			});

		},
		onMfLocValueNC: function () {
			var mModelSummary = this.getModel("mModelSummary");
			if (mModelSummary.getProperty("/HeaderDataNC/memberFirm")) {
				var oMemberfirm = mModelSummary.getProperty("/HeaderDataNC/memberfirm");
			} else {
				oMemberfirm = "";
			}
			var sSrchVal = oMemberfirm;
			// var fragmentId = this.getView().createId("searchCoordinator");
			sap.ui.core.BusyIndicator.show(0);

			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				mModelSummary = this.getModel("mModelSummary");
				mModelSummary.setSizeLimit(d.results.length); /*Added on 31-Dec-2019*/
				mModelSummary.setProperty("/RRF_Loc", d.results);
				// this.getView().getModel("mModelSummary").setProperty("/SelcKeySet", ""); /*Added on 31-Dec-2019*/
				this.getView().getModel("mModelSummary").setProperty("/updateRowDataNC/LocationOfTheServicesReq", ""); /*Added on 28-Jan-2020*/
				this.getView().getModel("mModelSummary").setProperty("/SelcKeySetLocServNC", "");
				this.getView().getModel("mModelSummary").refresh(true); /*Added on 27-Jan-2020*/
				// mModelSummary.refresh(true);
			}, this);
			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();

				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"
				});
			}, this);

			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
				json: true
			});
			oModel1.read("/RRF_MFSet", {
				success: fnSuccess,
				error: fnError
			});

		},
		/*End of change by Satabdi Das on 17-Feb-2021 for SCTASK1919812*/
		/*Start on 7th Nov 2019 */
		onSlcLineItemStatusNC: function (oEvent) {
			var comboxLineItemKey = oEvent.getParameters().selectedItem.getKey();
			this.getView().getModel("mModelSummary").setProperty("/lineItemStatus", comboxLineItemKey);
			this.getView().getModel("mModelSummary").refresh();
		},
		/*Change start on 14-Nov-2019 by Saptarshi*/
		onSlcBillfrqcy: function (oEvent) {
			/*var comboxLineItemText = oEvent.getParameters().selectedItem.getText();*/
			var comboxLineItemText = oEvent.getParameter("value");
			if (comboxLineItemText === "Halfyearly" || comboxLineItemText === "Onetime" || comboxLineItemText === "Monthly" ||
				comboxLineItemText === "Quarterly" || comboxLineItemText === "Yearly") {
				this.getModel("mModelSummary").setProperty("/updateRowDataNC/BillingFrequency", comboxLineItemText);
				if (this.getModel("mModelSummary").getProperty("/updateRowDataNC/BillingFrequency") === "Onetime") {
					this.getModel("mModelSummary").setProperty("/updateRowDataNC/NoOfOccur", "1");
					this.getModel("mModelSummary").setProperty("/oEditableNC/Occurence", false);
				} else {
					this.getModel("mModelSummary").setProperty("/updateRowDataNC/NoOfOccur", "");
					this.getModel("mModelSummary").setProperty("/oEditableNC/Occurence", true);
				}
			} else {
				this.getModel("mModelSummary").setProperty("/updateRowDataNC/BillingFrequency", "");
			}
		},
		/*Change end on 14-Nov-2019 by Saptarshi*/
		handleLineItemEdit: function (oEvent) {
			var mModelSummary = this.getView().getModel("mModelSummary");
			var displayMode = this.getModel("mModelSummary").getProperty("/displayMode"); /*Added on 02-March-2020*/
			var sTableRowItem = oEvent.getSource().getBindingContext("mModelSummary").getObject();
			this.getView().getModel("mModelSummary").setProperty("/SelcKeySet", sTableRowItem.RequestingMf); /*Added on 31-Dec-2019*/
			// this.getView().getModel("mModelSummary").setProperty("/updateRowDataNC/LocationOfTheServicesReq", sTableRowItem.LocationOfTheServicesReq); /*Added on 28-Jan-2020*/
			this.getView().getModel("mModelSummary").setProperty("/SelcKeySetLocServNC", sTableRowItem.LocationOfTheServicesReq);
			this.getModel("mModelSummary").setProperty("/updateRowDataNC", sTableRowItem); /*Chnage by Saptarshi on 14-Nov-2019*/
			this.getModel("mModelSummary").setProperty("/oEditableNC/editMode", false);

			//code added for cop decline validation message 28.12.2020
			// if (sTableRowItem.RrfStatus === "COPDeclined") {
			// 	var oBjectDClineNP = {};
			// 	if (sTableRowItem.RequestingMf === "N/A") {
			// 		oBjectDClineNP.ContactPersonCoP = sTableRowItem.ContactPCop;
			// 		oBjectDClineNP.ContactPersonCoPEmail = sTableRowItem.CopEmailId;
			// 		oBjectDClineNP.LoaEmailNP = sTableRowItem.LoaEmail;
			// 		oBjectDClineNP.AdlLoaEmailNP = sTableRowItem.AdlLoaEmail;

			// 	} else if (sTableRowItem.GlobalCc === "N/A") {
			// 		oBjectDClineNP.ContactPersonCoPEmail = sTableRowItem.CopEmailId;
			// 	}

			// 	mModelSummary.setProperty("/copDeclineSetNP", oBjectDClineNP);

			// }
			//end of changes 

			/*Start of change by Saptarshi on 14-Nov-2019*/
			// if (sTableRowItem.EditReqMf === true) {
			// 	this.getModel("mModelSummary").setProperty("/oEditableNC/editMode", false);
			// } else {
			// 	this.getModel("mModelSummary").setProperty("/oEditableNC/editMode", true);
			// }
			/*End of change by Saptarshi on 14-Nov-2019*/
			var rrfTablefragmentNonCoupa = this.getView().createId("rrfTablefragmentNonCoupa");

			if (!this.rrfTablefragmentNonCoupa) {
				this.rrfTablefragmentNonCoupa = sap.ui.xmlfragment(rrfTablefragmentNonCoupa, "kgo.ARRecharge.view.createLineItemNonCoupa", this);
				this.getView().addDependent(this.rrfTablefragmentNonCoupa);
			}
			if (this.rrfTablefragmentNonCoupa.isOpen()) {
				this.rrfTablefragmentNonCoupa.close();
			} else {
				var BRFSchPanel = sap.ui.core.Fragment.byId(rrfTablefragmentNonCoupa, "BRFSecNC"); /*Added on 10-Jan-2020*/
				var JVSchPanel = sap.ui.core.Fragment.byId(rrfTablefragmentNonCoupa, "JVPanelNC"); /*Added on 10-Jan-2020*/
				this.fetchAttachmentListNC(); /*Added on 26-Dec-2019*/

				var oNatureField = this.byId(sap.ui.core.Fragment.createId(rrfTablefragmentNonCoupa, "npComboboxnature"));
				oNatureField.addEventDelegate({
					onAfterRendering: function () {
						oNatureField.$().find("input").attr("readonly", true);
					}
				});

				/*Start of change for defect 63871 on 19-March-2021 by developer Satabdi Das*/
				var oReqCountry = this.byId(sap.ui.core.Fragment.createId(rrfTablefragmentNonCoupa, "contryDrdwIdNC"));
				oReqCountry.addEventDelegate({
					onAfterRendering: function () {
						var oReqCountryInner = this.$().find('.sapMInputBaseInner');
						var oID = oReqCountryInner[0].id;
						$('#' + oID).attr("disabled", "disabled");
					}
				}, oReqCountry);

				/*End of change for defect 63871 on 19-March-2021 by developer Satabdi Das*/

				var oDatePicker = this.byId(sap.ui.core.Fragment.createId(rrfTablefragmentNonCoupa, "LastDateSrvNC"));
				oDatePicker.addEventDelegate({
					onAfterRendering: function () {
						var oDateInner = this.$().find('.sapMInputBaseInner');
						var oID = oDateInner[0].id;
						$('#' + oID).attr("disabled", "disabled");
					}
				}, oDatePicker);

				var oQuestionDroupDown = this.byId(sap.ui.core.Fragment.createId(rrfTablefragmentNonCoupa, "comboIdTablefirst"));
				oQuestionDroupDown.addEventDelegate({
					onAfterRendering: function () {
						var oQdropDown = this.$().find('.sapMInputBaseInner');
						var oID = oQdropDown[0].id;
						$('#' + oID).attr("disabled", "disabled");
					}
				}, oQuestionDroupDown);

				if (sTableRowItem.CopYesDate === "00000000") {
					this.getModel("mModelSummary").setProperty("/updateRowDataNC/CopYesDate", "");
				}

				this.rrfTablefragmentNonCoupa.open();

				var oQdropDown = this.byId(sap.ui.core.Fragment.createId(rrfTablefragmentNonCoupa, "comboIdTable"));
				oQdropDown.addEventDelegate({
					onAfterRendering: function () {
						var oQdropDown = this.$().find('.sapMInputBaseInner');
						var oID = oQdropDown[0].id;
						$('#' + oID).attr("disabled", "disabled");
					}
				}, oQdropDown);

				BRFSchPanel.setExpanded(false); /*Added on 10-Jan-2020*/
				JVSchPanel.setExpanded(false); /*Added on 10-Jan-2020*/
				/*Start of change on 21-Feb-20202*/
				var newEntry = sTableRowItem.NewEntity;
				var oCheckBox = this.byId(sap.ui.core.Fragment.createId(rrfTablefragmentNonCoupa, "NewEntityNC"));
				if (oCheckBox) {
					if (newEntry === "") {
						oCheckBox.setSelected(false);
						this.getView().getModel("mModelSummary").setProperty("/oEditableNC/entityAddress", true);
						this.getView().getModel("mModelSummary").setProperty("/oEditableNC/entityName", false);
					} else
					if (newEntry === "X") {
						oCheckBox.setSelected(true);
						this.getView().getModel("mModelSummary").setProperty("/oEditableNC/entityAddress", false);
						this.getView().getModel("mModelSummary").setProperty("/oEditableNC/entityName", true);
					}
					if (displayMode === true) {
						this.getView().getModel("mModelSummary").setProperty("/oEditableNC/entityName", false);
					}
				}
				/*End of change on 21-Feb-2020*/

				//update AuthSignatory changes 13.04.2022
				if (sTableRowItem.LoaChanged === "X") {
					this.byId(sap.ui.core.Fragment.createId("rrfTablefragmentNonCoupa", "UpdateAuthId")).setSelected(true);
				}else{
					this.byId(sap.ui.core.Fragment.createId("rrfTablefragmentNonCoupa", "UpdateAuthId")).setSelected(false);
				}

				//End of changes 13.04.222

				/*Start of change on 17-Jan-2020*/
				if (this.getModel("mModelSummary").getProperty("/oEditableNC/visibleForDisplyGf") === false) {
					this.getModel("mModelSummary").setProperty("/oEditableNC/editLineItemCop", true);
					this.getModel("mModelSummary").setProperty("/oEditableNC/editLineItemMF", true);
					this.getModel("mModelSummary").setProperty("/oEditableNC/editLineItemAddInf", true);
				} else {
					this.getModel("mModelSummary").setProperty("/oEditableNC/editLineItemCop", false);
					this.getModel("mModelSummary").setProperty("/oEditableNC/editLineItemMF", false);
					this.getModel("mModelSummary").setProperty("/oEditableNC/editLineItemAddInf", false);
				}
				/*End of change on 17-Jan-2020*/

				/*Start of change on 01-Jan-2020*/
				var oDatePicker1 = this.byId(sap.ui.core.Fragment.createId(rrfTablefragmentNonCoupa, "JVStartDate"));
				if (oDatePicker1) {
					var objDate1 = oDatePicker1.getDomRef();
					if (objDate1) {
						objDate1.firstElementChild.firstChild.setAttribute("readonly", true);
					}
				}

				var oDatePicker3 = this.byId(sap.ui.core.Fragment.createId(rrfTablefragmentNonCoupa, "BillStartDate"));
				if (oDatePicker3) {
					var objDate3 = oDatePicker3.getDomRef();
					if (objDate3) {
						objDate3.firstElementChild.firstChild.setAttribute("readonly", true);
					}
				}

				/*End of change on 01-Jan-2020*/
				sap.ui.core.Fragment.byId(rrfTablefragmentNonCoupa, "EditOk").setVisible(true);
				this.byId(sap.ui.core.Fragment.createId("rrfTablefragmentNonCoupa", "updateCooID")).setEnabled(false);
				if (sTableRowItem.GlobalCc === "N/A") {

					//Changes for new cr cop reset 
					mModelSummary.setProperty("/oEditableNC/visibleforMF", true);
					if (sTableRowItem.RrfStatus === "COPInitiated" && displayMode === false) {
						mModelSummary.setProperty("/oEditableNC/reSetButtonEnableNP", true);

					} else {
						mModelSummary.setProperty("/oEditableNC/reSetButtonEnableNP", false);
					}

					//Questionnaire changes 15.03.2021
					var oAnswer = this.getModel("mModelSummary").getProperty("/nPQuestionSetSubmit");
					var oAnswerShow = [];
					var _fFirstLineData = [];
					for (var t = 0; t < oAnswer.length; t++) {
						if (oAnswer[t].RequestingMf === sTableRowItem.RequestingMf && oAnswer[t].MemberFirm === sTableRowItem.MemberFirm && oAnswer[t]
							.ProcessGrp ===
							sTableRowItem.ProcessGrp) {
							var object = {};
							object.LineNo = oAnswer[t].LineNo;
							object.CompanyCode = oAnswer[t].CompanyCode;
							object.Mandatory = oAnswer[t].Mandatory;
							object.MemberFirm = oAnswer[t].MemberFirm;
							object.Question = oAnswer[t].Question;
							object.AnswerDesc = oAnswer[t].AnswerDesc;
							object.Answer = oAnswer[t].Answer;
							object.InternalExternal = oAnswer[t].InternalExternal;
							object.RequestingMf = oAnswer[t].RequestingMf;
							object.ProcessGrp = sTableRowItem.ProcessGrp;
							if (object.Question === "Nature of Supplier") {
								_fFirstLineData.push(object);
							} else {
								oAnswerShow.push(object);
							}
						}
					}
					mModelSummary.setProperty("/nPquestionSet", oAnswerShow);
					mModelSummary.setProperty("/nPquestionSetFirst", _fFirstLineData);

					var tbl = sap.ui.core.Fragment.byId(rrfTablefragmentNonCoupa, "QuestionTableNP");
					var firstQtable = sap.ui.core.Fragment.byId(rrfTablefragmentNonCoupa, "QuestionTableNP1");
					if (_fFirstLineData.length > 0) {
						if (sTableRowItem.RrfStatus === "COPInitiated" || sTableRowItem.RrfStatus === "COPConfirmed" || sTableRowItem.RrfStatus ===
							"LOAInitiated" || sTableRowItem.RrfStatus === "LOAConfirmed " || displayMode === true) {
							firstQtable.getAggregation("items")[0].getCells()[2].setProperty("editable", false);
						} else {
							firstQtable.getAggregation("items")[0].getCells()[2].setProperty("editable", true);
						}
					}
					if (oAnswerShow.length > 0) {
						mModelSummary.setProperty("/oEditableNC/questionPnVisibleNP", true);
						for (var j = 0; j < oAnswerShow.length; j++) {
							if (oAnswerShow[j].Answer !== "N/A") {
								tbl.getAggregation("items")[j].getCells()[3].setProperty("visible", true);
								if (sTableRowItem.RrfStatus === "COPInitiated" || sTableRowItem.RrfStatus === "COPConfirmed" || sTableRowItem.RrfStatus ===
									"LOAInitiated" || sTableRowItem.RrfStatus === "LOAConfirmed " || displayMode === true) {
									tbl.getAggregation("items")[j].getCells()[3].setProperty("editable", false);
									tbl.getAggregation("items")[j].getCells()[2].setProperty("editable", false);
								} else {
									tbl.getAggregation("items")[j].getCells()[3].setProperty("editable", true);
									tbl.getAggregation("items")[j].getCells()[2].setProperty("editable", true);
								}
							} else {

								tbl.getAggregation("items")[j].getCells()[3].setProperty("visible", false);
								tbl.getAggregation("items")[j].getCells()[2].setProperty("editable", false);
								if (mModelSummary.getProperty("/nPquestionSetFirst")[0].Answer === "Service from external supplier") {

									if (oAnswerShow[j].InternalExternal === "EXTERNAL") {
										tbl.getAggregation("items")[j].getCells()[2].setProperty("editable", true);
									}
									if (oAnswerShow[j].InternalExternal === "INTERNAL") {
										tbl.getAggregation("items")[j].getCells()[2].setProperty("editable", false);
									}
								}

								if (mModelSummary.getProperty("/nPquestionSetFirst")[0].Answer === "Service from KPMGI") {

									if (oAnswerShow[j].InternalExternal === "INTERNAL") {
										tbl.getAggregation("items")[j].getCells()[2].setProperty("editable", true);
									}

									if (oAnswerShow[j].InternalExternal === "EXTERNAL") {
										tbl.getAggregation("items")[j].getCells()[2].setProperty("editable", false);
									}

								}

								if (sTableRowItem.RrfStatus === "COPInitiated" || sTableRowItem.RrfStatus === "COPConfirmed" || displayMode === true) {
									tbl.getAggregation("items")[j].getCells()[2].setProperty("editable", false);
								}
							}
						}
					} else {
						mModelSummary.setProperty("/oEditableNC/questionPnVisibleNP", false);
					}

					//end of questionnaire chnges

					if (sTableRowItem.BillSchedule === true || displayMode === true) { /*Added on 02-March-2020*/
						this.getModel("mModelSummary").setProperty("/oEditableNC/editLineItemBillSch", false); /*Chnage by Saptarshi on 14-Nov-2019*/
						this.getModel("mModelSummary").setProperty("/oEditableNC/Occurence", false); /*Chnage by Saptarshi on 14-Nov-2019*/

					} else if (sTableRowItem.BillSchedule === false || displayMode === false) { /*Added on 02-March-2020*/
						this.getModel("mModelSummary").setProperty("/oEditableNC/editLineItemBillSch", true); /*Chnage by Saptarshi on 14-Nov-2019*/
						this.getModel("mModelSummary").setProperty("/oEditableNC/Occurence", true); /*Chnage by Saptarshi on 14-Nov-2019*/
						/*Start of change on 03-Jan-2020*/
						this.getModel("mModelSummary").setProperty("/updateRowDataNC/Amount", "");
						this.getModel("mModelSummary").setProperty("/updateRowDataNC/BillingFrequency", "");
						this.getModel("mModelSummary").setProperty("/updateRowDataNC/StartDate", "");
						this.getModel("mModelSummary").setProperty("/updateRowDataNC/NoOfOccur", "");
						/*End of change on 03-Jan-2020*/
					}

					var avlueText = this.getModel("i18n").getProperty("editMemberFirm");
					this.getView().getModel("mModelSummary").setProperty("/setLineItemText", avlueText);
					this.getView().getModel("mModelSummary").setProperty("/TextForLineItemEmailSrch", avlueText);
					this.getView().getModel("mModelSummary").setProperty("/oEditableNC/visibleforGF", false);
					this.getModel("mModelSummary").setProperty("/oEditableNC/visibleforMF", true);
					this.getModel("mModelSummary").setProperty("/oEditableNC/rmdropDownNP", false);
					this.getModel("mModelSummary").setProperty("/oEditableNC/requMfvisibleNP", true);

					if (displayMode === false) {
						if ((sTableRowItem.NatureOfService === "Adhoc/One-Off")) {
							this.getView().getModel("mModelSummary").setProperty("/oEditableNC/lastservdateNP", true);
							this.getView().getModel("mModelSummary").setProperty("/oEditableNC/lastDateOfServLabelNP", true);
						} else {
							this.getView().getModel("mModelSummary").setProperty("/oEditableNC/lastservdateNP", false);
							this.getView().getModel("mModelSummary").setProperty("/oEditableNC/lastDateOfServLabelNP", false);
						}
					} else {

						if ((sTableRowItem.NatureOfService === "Adhoc/One-Off")) {
							this.getView().getModel("mModelSummary").setProperty("/oEditableNC/lastservdateNP", false);
							this.getView().getModel("mModelSummary").setProperty("/oEditableNC/lastDateOfServLabelNP", true);
						} else {
							this.getView().getModel("mModelSummary").setProperty("/oEditableNC/lastservdateNP", false);
							this.getView().getModel("mModelSummary").setProperty("/oEditableNC/lastDateOfServLabelNP", false);
						}
					}

					// this.getView().getModel("mModelSummary").setProperty("/oEditableNC/entityName", false); /*Added on 29-Janb-2020*/
					// this.getView().getModel("mModelSummary").setProperty("/oEditableNC/entityAddress", true); /*Added on 29-Janb-2020*/
				} else
				if (sTableRowItem.RequestingMf === "N/A") {

					//questionnaire section
					mModelSummary.setProperty("/oEditableNC/questionPnVisibleNP", false);
					/*Start of change by Satabdi Das on 18-Dec-2019*/
					if (sTableRowItem.BillSchedule === true || displayMode === true) { /*Added on 02-March-2020*/
						this.getModel("mModelSummary").setProperty("/oEditableNC/editLineItemAddInfJV", false);
						this.getModel("mModelSummary").setProperty("/oEditableNC/Occurence", false);
					} else if (sTableRowItem.BillSchedule === false || displayMode === false) { /*Added on 02-March-2020*/
						this.getModel("mModelSummary").setProperty("/oEditableNC/editLineItemAddInfJV", true);
						this.getModel("mModelSummary").setProperty("/oEditableNC/Occurence", true);
						/*Start of change on 03-Jan-2020*/
						this.getModel("mModelSummary").setProperty("/updateRowDataNC/Amount", "");
						this.getModel("mModelSummary").setProperty("/updateRowDataNC/BillingFrequency", "");
						this.getModel("mModelSummary").setProperty("/updateRowDataNC/StartDate", "");
						this.getModel("mModelSummary").setProperty("/updateRowDataNC/NoOfOccur", "");
						/*End of change on 03-Jan-2020*/
					}
					/*	if (sTableRowItem.BillingFrequency === "Onetime") {
							this.getModel("mModelSummary").setProperty("/oEditableNC/Occurence", false);
						} else {
							this.getModel("mModelSummary").setProperty("/oEditableNC/Occurence", true);
						}*/
					/*End of change by Satabdi Das on 18-Dec-2019*/
					var avlueText = this.getModel("i18n").getProperty("EditGlobalFunction");
					this.getView().getModel("mModelSummary").setProperty("/setLineItemText", avlueText);
					this.getView().getModel("mModelSummary").setProperty("/TextForLineItemEmailSrch", avlueText);
					this.getView().getModel("mModelSummary").setProperty("/oEditableNC/visibleforGF", true);
					this.getModel("mModelSummary").setProperty("/oEditableNC/visibleforMF", false);
					this.getModel("mModelSummary").setProperty("/oEditableNC/rmdropDownNP", false);
					this.getModel("mModelSummary").setProperty("/oEditableNC/requMfvisibleNP", false);
				}
				this.byId(sap.ui.core.Fragment.createId("rrfTablefragmentNonCoupa", "ContactPersonLOAId")).setEditable(false); /*End - CR  Changed On 26-Aug-2021 By Prashant and Chhanda*/
				if (displayMode === false) {

					switch (sTableRowItem.RrfStatus) {
						/*Start of change for Defect 63320 on 19-May-2020*/
					case "RRF Initiated":
						this.getView().getModel("mModelSummary").setProperty("/oEditableNC/editLineItemCop", true);
						this.getView().getModel("mModelSummary").setProperty("/oEditableNC/editLineItemMF", true);
						this.getView().getModel("mModelSummary").setProperty("/oEditableNC/editLineItemAddInf", true);
						this.getView().getModel("mModelSummary").setProperty("/BillEnable", true);
						this.byId(sap.ui.core.Fragment.createId("rrfTablefragmentNonCoupa", "ContactPersonLOAId")).setEditable(true); /*End - CR  Changed On 26-Aug-2021 By Prashant and Chhanda*/
						break;
						/*End of change for defect 63320 on 19-May-2020*/

					case "COPDeclined":
						this.getView().getModel("mModelSummary").setProperty("/oEditableNC/editLineItemCop", true);
						this.getView().getModel("mModelSummary").setProperty("/oEditableNC/editLineItemMF", true);
						this.getView().getModel("mModelSummary").setProperty("/oEditableNC/editLineItemAddInf", true);
						this.getView().getModel("mModelSummary").setProperty("/BillEnable", true); /*Added for defect 63320 on 19-May-2020*/
						this.byId(sap.ui.core.Fragment.createId("rrfTablefragmentNonCoupa", "ContactPersonLOAId")).setEditable(true);
						/*Start of change bvy Satabdi Das on 30-Dec-2020*/
						if (sTableRowItem.GlobalCc === "N/A") {
							this.getModel("mModelSummary").setProperty("/oEditableNC/editLineItemBillSch", true);
							this.getModel("mModelSummary").setProperty("/oEditableNC/Occurence", true);
						} else if (sTableRowItem.RequestingMf === "N/A") {
							this.getModel("mModelSummary").setProperty("/oEditableNC/editLineItemAddInfJV", true);
							this.getModel("mModelSummary").setProperty("/oEditableNC/Occurence", true);
						}
						/*End of change by Satabdi Das on 30-Dec-2020*/
						break;

					case "COPInitiated":
						this.getView().getModel("mModelSummary").setProperty("/oEditableNC/editLineItemCop", false);
						this.getView().getModel("mModelSummary").setProperty("/oEditableNC/editLineItemMF", true);
						this.getView().getModel("mModelSummary").setProperty("/oEditableNC/editLineItemAddInf", true);
						this.getView().getModel("mModelSummary").setProperty("/BillEnable", false); /*Added for defect 63320 on 19-May-2020*/
						this.byId(sap.ui.core.Fragment.createId("rrfTablefragmentNonCoupa", "ContactPersonLOAId")).setEditable(false);
						break;

					case "COPConfirmed":
						this.getView().getModel("mModelSummary").setProperty("/oEditableNC/editLineItemCop", false);
						this.getView().getModel("mModelSummary").setProperty("/oEditableNC/editLineItemMF", false);
						this.getView().getModel("mModelSummary").setProperty("/oEditableNC/editLineItemAddInf", true);
						this.getView().getModel("mModelSummary").setProperty("/oEditableNC/checkBox", false);
						this.getView().getModel("mModelSummary").setProperty("/BillEnable", false); /*Added for defect 63320 on 19-May-2020*/
						this.byId(sap.ui.core.Fragment.createId("rrfTablefragmentNonCoupa", "ContactPersonLOAId")).setEditable(false); /*End - CR  Changed On 26-Aug-2021 By Prashant and Chhanda*/
						if (sTableRowItem.GlobalCc === "N/A" && sTableRowItem.RequestingMf !== "N/A") {
							if (sTableRowItem.NewEntity === "X" || sTableRowItem.LoaChanged === "X") {
								this.byId(sap.ui.core.Fragment.createId("rrfTablefragmentNonCoupa", "updateCooID")).setEnabled(true);
							}

						}

						break;

					case "LOAInitiated":
						this.getView().getModel("mModelSummary").setProperty("/oEditableNC/editLineItemCop", false);
						this.getView().getModel("mModelSummary").setProperty("/oEditableNC/editLineItemMF", false);
						this.getView().getModel("mModelSummary").setProperty("/oEditableNC/editLineItemAddInf", false);
						this.getView().getModel("mModelSummary").setProperty("/BillEnable", false);
						this.getView().getModel("mModelSummary").setProperty("/oEditableNC/checkBox", false);
						this.getView().getModel("mModelSummary").setProperty("/oEditableNC/lastservdateNP", false);
						this.byId(sap.ui.core.Fragment.createId("rrfTablefragmentNonCoupa", "ContactPersonLOAId")).setEditable(false); /*End - CR  Changed On 26-Aug-2021 By Prashant and Chhanda*/
						break;

					case "LOAConfirmed":
						this.getView().getModel("mModelSummary").setProperty("/oEditableNC/editLineItemCop", false);
						this.getView().getModel("mModelSummary").setProperty("/oEditableNC/editLineItemMF", false);
						this.getView().getModel("mModelSummary").setProperty("/oEditableNC/editLineItemAddInf", false);
						this.getView().getModel("mModelSummary").setProperty("/oEditableNC/checkBox", false);
						this.getView().getModel("mModelSummary").setProperty("/BillEnable", false); /*Added for defect 63320 on 19-May-2020*/
						this.getView().getModel("mModelSummary").setProperty("/oEditableNC/lastservdateNP", false);
						this.byId(sap.ui.core.Fragment.createId("rrfTablefragmentNonCoupa", "ContactPersonLOAId")).setEditable(false); /*End - CR  Changed On 26-Aug-2021 By Prashant and Chhanda*/
						break;

					}

					/*Start of defect 63320 on 20-May-2020*/
					if (sTableRowItem.RrfStatus === undefined) {
						this.getView().getModel("mModelSummary").setProperty("/BillEnable", true);
						//this.byId(sap.ui.core.Fragment.createId("rrfTablefragmentNonCoupa", "ContactPersonLOAId")).setEditable(true);
					}
					/*End of defect 63320 on 20-May-2020*/
				}

				sap.ui.core.Fragment.byId(rrfTablefragmentNonCoupa, "FragOk").setVisible(false);
			}
		},
		handleLineItemDeleteNC: function (oEvent) {
			var mModelSummary = this.getView().getModel("mModelSummary");
			var displayMode = this.getModel("mModelSummary").getProperty("/displayMode"); /*Added by Saptarshi on 22-Nov-2019*/
			if (displayMode === false) { /*Added by Saptarshi on 22-Nov-2019*/
				var sDeleteData = oEvent.getSource().getBindingContext("mModelSummary").getObject();
				var lineDeleteText = this.getModel("i18n").getProperty("lineDeleteText");
				var ReqText;
				var reqGCC;
				var MF;
				var MemberFirmText;
				var procesgrp;
				var processinggrp;
				if (sDeleteData.RequestingMf !== "N/A" && sDeleteData.GlobalCc === "N/A") {
					reqGCC = sDeleteData.RequestingMf;
					MF = sDeleteData.MemberFirm;
					procesgrp = sDeleteData.ProcessGrp;
					ReqText = this.getModel("i18n").getProperty("requesDeleteText");
					MemberFirmText = this.getModel("i18n").getProperty("deleteMfText");
					processinggrp = this.getModel("i18n").getProperty("processgrp");
				} else {
					reqGCC = sDeleteData.GlobalCc;
					ReqText = this.getModel("i18n").getProperty("globalCC");
					MemberFirmText = "";
					MF = "";
					procesgrp = "";
					processinggrp = "";
				}
				if ((sDeleteData.RrfStatus !== "COPConfirmed") && (sDeleteData.RrfStatus !== "LOAInitiated") && (sDeleteData.RrfStatus !==
						"LOAConfirmed")) {
					var IrfNo = mModelSummary.getProperty("/HeaderDataNC").RrfNoGf;
					var CompanyCode = mModelSummary.getProperty("/HeaderDataNC").CompanyCode;

					/*if (sDeleteData.ProcessGrp) {
						sDeleteData.ProcessGrp = sDeleteData.ProcessGrp.replace(/\s/g, "*");
					}
					if (sDeleteData.MemberFirm) {
							sDeleteData.MemberFirm = sDeleteData.MemberFirm.replace(/\s/g, "*");
						}
					this.getView().getModel("mModelSummary").setProperty("/deleteDataNC", sDeleteData);*/
					var that = this;
					var event = oEvent.getSource();
					var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
					MessageBox.warning(
						ReqText + reqGCC + " " + MemberFirmText + MF + " " + processinggrp + procesgrp + " " + lineDeleteText, {
							actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
							styleClass: bCompact ? "sapUiSizeCompact" : "",
							onClose: function (sAction) {
								if (sAction === "OK") {
									var arrAnsware = that.getModel("mModelSummary").getProperty("/nPQuestionSetSubmit");
									for (var i = arrAnsware.length - 1; i >= 0; i--) {
										if (arrAnsware[i].RequestingMf === sDeleteData.RequestingMf && arrAnsware[i].MemberFirm === sDeleteData.MemberFirm &&
											arrAnsware[i].ProcessGrp === sDeleteData.ProcessGrp) {
											var a = i;
											a = parseInt(a);
											mModelSummary.getProperty("/nPQuestionSetSubmit").splice(a, 1);
											that.getView().getModel("mModelSummary").refresh(true);
										}
									}

									if (sDeleteData.ProcessGrp) {
										sDeleteData.ProcessGrp = sDeleteData.ProcessGrp.replace(/\s/g, "*");
										/*Start of change for INC01584421 by developer Prashant kumar on 22-June-2021*/
										var forwardslash = /[/]+/;
										if (forwardslash.test(sDeleteData.ProcessGrp)) {
											sDeleteData.ProcessGrp = sDeleteData.ProcessGrp.replace(/[/]/g, "|");
										}
										var qQuestionChar = /[?]+/;
										if (qQuestionChar.test(sDeleteData.ProcessGrp)) {
											sDeleteData.ProcessGrp = sDeleteData.ProcessGrp.replace(/[?]/g, "(");
										}
										var pPercentage = /[%]+/;
										if (pPercentage.test(sDeleteData.ProcessGrp)) {
											sDeleteData.ProcessGrp = sDeleteData.ProcessGrp.replace(/[%]/g, ")");
										}

									}
									if (sDeleteData.MemberFirm) {
										sDeleteData.MemberFirm = sDeleteData.MemberFirm.replace(/\s/g, "*");
										/*Start of change for INC01584421 by developer Prashant kumar on 22-June-2021*/
										var forwardslashMmfirm = /[/]+/;
										if (forwardslashMmfirm.test(sDeleteData.MemberFirm)) {
											sDeleteData.MemberFirm = sDeleteData.MemberFirm.replace(/[/]/g, "|");

										}
										var qQuestionCharMemFm = /[?]+/;
										if (qQuestionCharMemFm.test(sDeleteData.MemberFirm)) {
											sDeleteData.MemberFirm = sDeleteData.MemberFirm.replace(/[?]/g, "(");

										}
										var pPercentageMF = /[%]+/;
										if (pPercentageMF.test(sDeleteData.MemberFirm)) {
											sDeleteData.MemberFirm = sDeleteData.MemberFirm.replace(/[%]/g, ")");

										}

									}
									that.getView().getModel("mModelSummary").setProperty("/deleteDataNC", sDeleteData);
									var sData = that.getView().getModel("mModelSummary").getProperty("/deleteDataNC");
									if (sData.RequestingMf === "N/A") {
										sData.RequestingMf = "NA";
									} else if (sData.GlobalCc) {
										sData.GlobalCc = "NA";
									}
									if (IrfNo) {
										var fnSuccess = jQuery.proxy(function (d) {
											sap.ui.core.BusyIndicator.hide(0);
											// that.editNonCoupa();
											var x = event.getBindingContext("mModelSummary").getPath();
											var y = x.split("/");
											var z = y[3];
											z = parseInt(z);
											var s = event.getBindingContext("mModelSummary").getProperty("/TableItemSetNC");
											for (var i = s.results.length - 1; i >= 0; i--) {
												if (i === z) {
													(s.results).splice(z, 1);
												}
											}
											that.getView().getModel("mModelSummary").refresh();
										}, that);
										var fnError = jQuery.proxy(function (d) {
											var r = JSON.parse(JSON.stringify(d));
										}, that);
										var sPath = "/GF_LineitemSet(CompanyCode='" + CompanyCode + "',RrfNoGf='" + IrfNo +
											"',RequestingMf='" + sData.RequestingMf + "',MemberFirm='" + sData.MemberFirm + "',GlobalCc='" + sData.GlobalCc +
											"',CcShortDesc='" + sData.CcShortDesc + "',ProcessGrp='" + sData.ProcessGrp + "')"; /*Added on 19-Dec-2019*/
										var oObject = {};
										oObject.success = fnSuccess;
										oObject.error = fnError;
										oObject.sPath = sPath;
										oObject.groupId = "DeleteRow";
										that.deleteRecordNC(oObject);
										that._submitBatchOperationTestNC("DeleteRow", fnSuccess, fnError);
									} else {
										var x = event.getBindingContext("mModelSummary").getPath();
										var y = x.split("/");
										var z = y[3];
										z = parseInt(z);
										var s = event.getBindingContext("mModelSummary").getProperty("/TableItemSetNC");
										for (var i = 0; i < s.results.length; i++) {
											if (i === z) {
												(s.results).splice(z, 1);
												that.getView().getModel("mModelSummary").refresh();
											}
										}
									}
								}
							}
						}
					);
				} else {
					if (sDeleteData.RequestingMf !== "N/A" && sDeleteData.GlobalCc === "N/A") {
						MessageBox.alert(
							"Requesting country: " + sDeleteData.RequestingMf + " Member Firm :" + sDeleteData.MemberFirm + " and Processing group: " +
							sDeleteData.ProcessGrp +
							" line cannot be deleted as the line status is : " + sDeleteData.RrfStatus + " .", {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}
						);

					} else {
						MessageBox.alert(
							"Global CC : " + sDeleteData.GlobalCc + " line cannot be deleted as line status is : " + sDeleteData.RrfStatus + " .", {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}
						);
					}
				}
			} /*Added by Saptarshi on 22-Nov-2019*/
		},
		_submitBatchOperationTestNC: function (grpId, fnUpdSuccess, fnUpdError) {
			var that = this;
			var fnSuccess1 = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				// that.onCoupaPressed();
			}, this);
			var _modelBase = this.getOwnerComponent().getModel(); //controllerRef.getOwnerComponent().getModel();
			_modelBase.submitChanges({
				groupId: grpId,
				success: fnSuccess1,
				error: fnUpdError
			});
		},
		deleteRecordNC: function (oObject) {
			var _modelBase = this.getOwnerComponent().getModel(); //controllerRef.getOwnerComponent().getModel();
			_modelBase.setUseBatch(true);
			_modelBase.setDeferredGroups(["DeleteRow"]);
			var sPath = oObject.sPath;
			var groupId = oObject.groupId;
			var successCallback = oObject.success;
			var errorCallback = oObject.error;
			_modelBase.remove(sPath, {
				groupId: groupId,
				success: successCallback,
				error: errorCallback
			});
		},
		/*End on 7th Nov 2019 */
		/*Start of Spatarshi on 8th-Nov-2019*/
		handlePressLinkOKofLineItemNC: function (oEvent) {
			var displayMode = this.getModel("mModelSummary").getProperty("/displayMode");
			var mModelSummary = this.getView().getModel("mModelSummary");
			if (displayMode === false) { /*Added by Sapatrshi on 22-Nov-2019*/
				this.getView().getModel("mModelSummary").setProperty("/oEditable/attchmentExpndedNC", false);
				var rrfTablefragmentNonCoupa = this.getView().createId("rrfTablefragmentNonCoupa"); /*Added on 10-Jan-2020*/
				var BRFSchPanel = sap.ui.core.Fragment.byId(rrfTablefragmentNonCoupa, "BRFSecNC"); /*Added on 10-Jan-2020*/
				var JVSchPanel = sap.ui.core.Fragment.byId(rrfTablefragmentNonCoupa, "JVPanelNC"); /*Added on 10-Jan-2020*/
				mModelSummary.setProperty("/oEditableNC/lastDateOfServLabelNP", false);
				var questionTable = mModelSummary.getProperty("/nPquestionSet");
				var BRFExp = BRFSchPanel.getExpanded(); /*Added on 10-Jan-2020*/
				var JVExp = JVSchPanel.getExpanded(); /*Added on 10-Jan-2020*/
				var sUpdateValues = this.getView().getModel("mModelSummary").getProperty("/updateRowDataNC");
				if (((sUpdateValues.RequestingMf && sUpdateValues.ProcessGrp) && sUpdateValues.GlobalCc === "N/A") || ((sUpdateValues.RequestingMf ===
							"N/A" && (sUpdateValues.ProcessGrp === "" || sUpdateValues.ProcessGrp === undefined)) && sUpdateValues.GlobalCc &&
						sUpdateValues.GfLineDesc)) {
					if (sUpdateValues.BillSchedule === false || sUpdateValues.BillSchedule === undefined) {
						/*Change by Sapatrshi on 14-Nov-2019*/
						var sHeaderData = this.getView().getModel("mModelSummary").getProperty("/HeaderDataNC");
						if (sHeaderData.RrfNoGf != undefined && sHeaderData.CompanyCode != undefined && sUpdateValues.Amount != "" && sUpdateValues
							.BillingFrequency != "" && sUpdateValues.StartDate != "" && sUpdateValues.NoOfOccur != "" && sUpdateValues.RequestingMf !=
							"") { /*Chnaged by Sapatrshi on 14th-Nov-2019*/
							var oPayLoad = {
								CompanyCode: sHeaderData.CompanyCode, // Company Code
								RrfNoGf: sHeaderData.RrfNoGf, // RRF No.
								RequestingMf: sUpdateValues.RequestingMf, // Requesting MF
								MemberFirm: sUpdateValues.MemberFirm,
								CcShortDesc: "",
								Amount: sUpdateValues.Amount, // Billing Amount
								BillingFrequency: sUpdateValues.BillingFrequency, // Billing Frequency
								StartDate: sUpdateValues.StartDate, // Billing Start Date
								NoOfOccur: sUpdateValues.NoOfOccur, // No Of Occurences
								ProcessGrp: sUpdateValues.ProcessGrp,
								/*Added on 02-Jan-2020*/
								GlobalCc: sUpdateValues.GlobalCc /*Added on 02-Jan-2020*/
							};
							var fnSuccess = jQuery.proxy(function (d) {
								sap.ui.core.BusyIndicator.hide(0);
								this.getView().getModel("mModelSummary").setProperty("/updateRowDataNC/BillSchedule", true); /*Added on 13-Jan-2020*/
								var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
								if (d.Flag) {
									var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
									MessageBox.error(
										d.Message, {
											styleClass: bCompact ? "sapUiSizeCompact" : ""
										}
									);
								} else {
									MessageBox.show(
										d.Message, {
											icon: MessageBox.Icon.SUCCESS,
											title: "Success",
											actions: [MessageBox.Action.OK]
										}
									);
								}
							}, this);
							var fnError = jQuery.proxy(function (d) {
								var r = JSON.parse(JSON.stringify(d));
								sap.ui.core.BusyIndicator.hide();
								MessageToast.show(r.message, {
									autoClose: true,
									width: "20rem"

								});
							}, this);
							var objectOne = {};
							objectOne.successCallback = fnSuccess;
							objectOne.errorCallback = fnError;
							DataManagerARrecharge.CreateBillSchedule(oPayLoad, objectOne);
						}
					} /*Added by Sapatrshi on 14-Nov-2019*/
					// End of change by Debraj Date - 11/11/2019

					if ((!sUpdateValues.AddlBillInfo && !sUpdateValues.LongText) && (sUpdateValues.GlobalCc === "N/A")) {
						var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
						MessageBox.alert(
							"Please enter mandatory fields.", {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}

						);
						return;
					}

					/*Start of change for SCTASK1855604 - budget approvers by developer Satabdi Das on 19-May-2021*/
					if (sUpdateValues.GlobalCc !== "N/A") {
						if (!sUpdateValues.LoaContact || sUpdateValues.LoaContact === "" || !sUpdateValues.LoaEmail || sUpdateValues.LoaEmail ===
							"") {
							var sErrorMsg = this.getView().getModel("i18n").getProperty("BAMissingErrorMsg");
							MessageBox.error(sErrorMsg, {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							});
							return;
						}
					}
					/*End of change for SCTASK1855604 - budget approvers by developer Satabdi Das on 19-May-2021*/

					if ((((sUpdateValues.NatureOfService === "Adhoc/One-Off") && (sUpdateValues.RequestingMf !== "N/A")) && (!sUpdateValues.LastDateSrv ||
							sUpdateValues.LastDateSrv ===
							"00000000")) || ((!sUpdateValues.LocationOfTheServicesReq) && (sUpdateValues.RequestingMf !== "N/A"))) {
						this.getView().getModel("mModelSummary").setProperty("/oEditableNC/lastDateOfServLabelNP", true);
						var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
						MessageBox.alert(
							"Please enter mandatory fields.", {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}

						);
						return;

					} else {
						if (this.rrfTablefragmentNonCoupa.isOpen()) {
							/*Start of change on 10-Jan-2020*/

							if (this.oRestVal === true) {
								mModelSummary.setProperty("/updateRowDataNC/RrfStatus", "COP Changed");
								mModelSummary.setProperty("/updateRowDataNC/CopInitiate", " ");
								mModelSummary.setProperty("/oEditableNC/enableCOP", true);
								mModelSummary.setProperty("/updateRowDataNC/ConfYn_old", undefined);
								mModelSummary.setProperty("/updateRowDataNC/CopYesDate_old", undefined);
								mModelSummary.setProperty("/updateRowDataNC/ServNowCop_old", undefined);
								mModelSummary.setProperty("/updateRowDataNC/ServNowStatus_old", undefined);
								mModelSummary.setProperty("/updateRowDataNC_Old", undefined);
								this.oRestVal = false;
							} else {
								this.oRestVal = false;
								mModelSummary.setProperty("/updateRowDataNC_Old", undefined);
							}

							//questionnaire changes by prashant kumar 15.03.2020 
							var _firstQuestionData = mModelSummary.getProperty("/nPquestionSetFirst");

							if (questionTable && questionTable.length > 0) {
								var messageFlag = false;
								var submitSet = mModelSummary.getProperty("/nPQuestionSetSubmit");
								for (var i = 0; i < questionTable.length; i++) {
									for (var j = 0; j < submitSet.length; j++) {
										if (submitSet[j].RequestingMf === mModelSummary.getProperty("/nPquestionSet")[i].RequestingMf && submitSet[j].MemberFirm ===
											mModelSummary.getProperty("/nPquestionSet")[i].MemberFirm && submitSet[j].ProcessGrp === mModelSummary.getProperty(
												"/nPquestionSet")[i].ProcessGrp) {
											if ((!mModelSummary.getProperty("/nPquestionSet")[i].Answer || mModelSummary.getProperty("/nPquestionSet")[i].Answer ===
													" ") || (!
													_firstQuestionData[0].Answer || _firstQuestionData[0].Answer === " ")) {
												messageFlag = true;
												break;
											}

											if (mModelSummary.getProperty("/nPquestionSet")[i].Answer === "Other" && !mModelSummary.getProperty("/nPquestionSet")[i].AnswerDesc) {
												var messageFlag = true;
												break;
											}
											if (submitSet[j].Question === mModelSummary.getProperty("/nPquestionSet")[i].Question) {
												mModelSummary.getProperty("/nPQuestionSetSubmit")[j].Answer = mModelSummary.getProperty("/nPquestionSet")[i].Answer;
												mModelSummary.getProperty("/nPQuestionSetSubmit")[j].AnswerDesc = mModelSummary.getProperty("/nPquestionSet")[i].AnswerDesc;

											}
										}
									}
								}

								// for (var i = 0; i < questionTable.length; i++) {
								// 		for (var j = 0; j < submitSet.length; j++) {
								// 			if (submitSet[j].RequestingMf === mModelSummary.getProperty("/nPquestionSet")[i].RequestingMf && submitSet[j].MemberFirm ===
								// 				mModelSummary.getProperty("/nPquestionSet")[i].MemberFirm && submitSet[j].ProcessGrp === mModelSummary.getProperty(
								// 					"/nPquestionSet")[i].ProcessGrp) {

								// 				if (mModelSummary.getProperty("/nPquestionSet")[i].Answer === "Other" && !mModelSummary.getProperty("/nPquestionSet")[i].AnswerDesc) {
								// 					messageFlag = true;
								// 					break;
								// 				} else {
								// 					mModelSummary.getProperty("/nPQuestionSetSubmit")[j].Answer = mModelSummary.getProperty("/nPquestionSet")[i].Answer;
								// 					mModelSummary.getProperty("/nPQuestionSetSubmit")[j].AnswerDesc = mModelSummary.getProperty("/nPquestionSet")[i].AnswerDesc;
								// 				}
								// 			}
								// 		}

								// }

							}

							//changes for mandatry questionnaire

							if (_firstQuestionData && _firstQuestionData.length > 0) {
								for (var k = 0; k < submitSet.length; k++) {
									if (submitSet[k].RequestingMf === _firstQuestionData[0].RequestingMf && submitSet[k].MemberFirm === _firstQuestionData[0].MemberFirm &&
										submitSet[k].ProcessGrp === _firstQuestionData[0].ProcessGrp) {
										if (submitSet[k].Question === _firstQuestionData[0].Question) {
											mModelSummary.getProperty("/nPQuestionSetSubmit")[k].Answer = _firstQuestionData[0].Answer;
										}

									}

								}
							}

							//end of changes 19.04.2021

							if (messageFlag === true) {
								var questionnaDetailMissing2 = this.getModel("i18n").getProperty("questionnaDetailMissing2");
								MessageBox.alert(questionnaDetailMissing2);
								return true;
							}

							//end questionnaire 15.03.2021

							var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
							if (BRFExp === true && (sUpdateValues.Amount === "" || sUpdateValues
									.BillingFrequency === "" || sUpdateValues.StartDate === "" || sUpdateValues.NoOfOccur === "")) {
								var that = this;
								MessageBox.warning(
									"BRF schedule will not be created!", {
										actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
										styleClass: bCompact ? "sapUiSizeCompact" : "",
										onClose: function (sAction) {
											if (sAction === "OK") {
												sap.ui.core.BusyIndicator.hide();
												that.rrfTablefragmentNonCoupa.close();

											}
										}
									}, this);
							} else if (JVExp === true && (sUpdateValues.Amount === "" || sUpdateValues
									.BillingFrequency === "" || sUpdateValues.StartDate === "" || sUpdateValues.NoOfOccur === "")) {
								var that = this;
								MessageBox.warning(
									"JV schedule will not be created!", {
										actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
										styleClass: bCompact ? "sapUiSizeCompact" : "",
										onClose: function (sAction) {
											if (sAction === "OK") {
												sap.ui.core.BusyIndicator.hide();
												that.rrfTablefragmentNonCoupa.close();
											}
										}
									}, this);
							} else {
								this.getModel("mModelSummary").setProperty("/GblFuncName", false); /*Added on 14-Jan-2020*/

								//disable checkbox date 3.03.2020
								var tbl = this.getView().byId('LineItemTab');
								var lLineItemTable = this.getView().getModel("mModelSummary").getProperty("/TableItemSetNC/results");
								for (var i = 0; i < lLineItemTable.length; i++) {
									var CopInitiate = lLineItemTable[i].CopInitiate;
									var x = tbl.getAggregation("items")[i];
									if (CopInitiate === "X") {
										x.getMultiSelectControl().setEnabled(false);
									} else {
										x.getMultiSelectControl().setEnabled(true);
									}
								}
								//End 3.3.2020
								sap.ui.core.BusyIndicator.hide();
								this.rrfTablefragmentNonCoupa.close();

							}

							/*End of change on 10-Jan-2020*/
						}
					}

				} else {
					var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
					MessageBox.alert(
						"Please enter mandatory fields.", {
							styleClass: bCompact ? "sapUiSizeCompact" : ""
						}
					);
				}
			} /*Added by Saptarshi on 22-Nov-2019*/
		},
		/*End of Saptarshi on 8th-Nov-2019*/
		/*Start by Saptarshi on 11th-Nov-2019*/
		onCntlerEmailHelpNC: function (oEvent) {
			sap.ui.core.BusyIndicator.show(0);
			var mModelSummary = this.getView().getModel("mModelSummary");
			mModelSummary.setProperty("/TRFOwnerFlagNP", false);
			/*Start of change by Saptarshi on 15-Nov-2019*/
			var checkField = oEvent.getSource().getBinding("value").getPath();
			var valueField = checkField.split("/")[2];
			var sId = oEvent.getSource().getId().split("--")[2]; /*Added for defect 63445*/
			this.getView().getModel("mModelSummary").setProperty("/EmailFieldLnItem", valueField);
			/*End of change by Saptarshi on 15-Nov-2019*/
			/*this.getView().getModel("mModelSummary").setProperty("/HeaderDataNC/ContrlName/ContrlEmail");*/
			this.getView().getModel("mModelSummary").setProperty("/ContrlNameSet", []);
			this.getView().getModel("mModelSummary").setProperty("/oEditableNC/visibleForcntrlEmail", false);
			/*Start defect 63445*/
			if (sId === "addioinalLoaNPMF") {
				this.getView().getModel("mModelSummary").setProperty("/updateRowDataNC/AdlLoaContact", "");
				this.getView().getModel("mModelSummary").setProperty("/updateRowDataNC/AdlLoaEmail", "");
			}
			if (sId === "AttentionToPersoninBRFId") {
				this.getView().getModel("mModelSummary").setProperty("/updateRowDataNC/AttenBrf", "");
				this.getView().getModel("mModelSummary").setProperty("/updateRowDataNC/AttenBrfEmail", "");
			}
			/*End defect 63445*/
			var fragmentId = this.getView().createId("contrlNameNC");

			if (!this.oContrlNameNC) {
				this.oContrlNameNC = sap.ui.xmlfragment(fragmentId, "kgo.ARRecharge.view.contrlNameNC", this);
				this.getView().addDependent(this.oContrlNameNC);

			}
			sap.ui.core.BusyIndicator.hide(0);
			this.oContrlNameNC.open();
		},
		onContrlCancel: function (oEvent) {
			this.getView().getModel("mModelSummary").setProperty("/ContrlerEmailSet", []);
			if (this.oContrlNameNC.isOpen()) {
				this.oContrlNameNC.close();
			}
		},
		/*Start of change by Saptarshi on 15-Nov-2019*/
		onSelectContrlNameNC: function (oEvent) {
			var mModelSummary = this.getView().getModel("mModelSummary");
			var that = this;
			var checkLineItemText = this.getView().getModel("mModelSummary").getProperty("/TextForLineItemEmailSrch");
			this.getView().getModel("mModelSummary").setProperty("/ContrlerEmailSet", []);
			var contrlName = oEvent.getSource().getBindingContext("mModelSummary").getObject();
			var ControllerName = contrlName.Firstname + " " + contrlName.Lastname;
			var valueField = this.getView().getModel("mModelSummary").getProperty("/EmailFieldLnItem");
			if (contrlName.Employeestatuscode == 1) {
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				MessageBox.information(
					"Employee status not currently assigned. Please select active employee", {
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					}
				);
				return;
			} else if (contrlName.Employeestatuscode == 3) {
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				MessageBox.information(
					"The individual is on leave", {
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					}
				);
				return;
			} else if (contrlName.Employeestatuscode == 4) {
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				MessageBox.information(
					"The individual is separated from the legal entity.", {
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					}
				);
				return;
			} else if (contrlName.Employeestatuscode == 5) {
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				MessageBox.information(
					"The individual will join the legal entity at a future date.", {
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					}
				);
				return;
			}
			if (mModelSummary.getProperty("/TRFOwnerFlagNP") === true && contrlName.Employeestatuscode == 2) {
				MessageBox.warning("RRF created by will be  changed to  : " + ControllerName + " . Do you want to Proceed ?.", {
					actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
					emphasizedAction: MessageBox.Action.OK,
					onClose: function (sAction) {
						if (sAction === "OK") {
							that.oContrlNameNC.close();
							// mModelSummary.setProperty("/HeaderDataNC/ContrlName", ControllerName);
							// mModelSummary.setProperty("/HeaderDataNC/ContrlEmail", contrlName.Emailid);
							mModelSummary.setProperty("/HeaderDataNC/CreatedBy", contrlName.Sapid);
							that.onOKPressOfTransferOwnerNP();
							mModelSummary.setProperty("/TRFOwnerFlagNP", false);
							mModelSummary.setProperty("/ContrlNameSet", []);
							mModelSummary.setProperty("/ContrlerEmailSet", []);

						}
					}

				});
				return true;
			}
			if (!checkLineItemText && (contrlName.Employeestatuscode == 2)) {
				var ContrlName = contrlName.Firstname + " " + contrlName.Lastname;
				mModelSummary.setProperty("/HeaderDataNC/ContrlName", ContrlName);
				mModelSummary.setProperty("/HeaderDataNC/ContrlEmail", contrlName.Emailid);
				if (this.oContrlNameNC.isOpen()) {
					this.oContrlNameNC.close();
				}

			}

			if ((valueField === "ContactPCop") && (contrlName.Employeestatuscode == 2)) { /*Changed on 23-Dec-2019*/
				var ContrlName1 = contrlName.Firstname + " " + contrlName.Lastname;
				mModelSummary.setProperty("/updateRowDataNC/ContactPCop", ContrlName1);
				mModelSummary.setProperty("/updateRowDataNC/CopEmailId", contrlName.Emailid);
				if (this.oContrlNameNC.isOpen()) {
					this.oContrlNameNC.close();
				}

			}
			if ((valueField === "AddlContactPerson") && (contrlName.Employeestatuscode == 2)) { /*Changed on 23-Dec-2019*/
				var ContrlName11 = contrlName.Firstname + " " + contrlName.Lastname;
				mModelSummary.setProperty("/updateRowDataNC/AddlContactPerson", ContrlName11);
				mModelSummary.setProperty("/updateRowDataNC/AddlContactEmail", contrlName.Emailid);
				if (this.oContrlNameNC.isOpen()) {
					this.oContrlNameNC.close();
				}

			}

			if ((valueField === "LoaContact") && (contrlName.Employeestatuscode == 2)) { /*Changed on 23-Dec-2019*/
				var ContrlName2 = contrlName.Firstname + " " + contrlName.Lastname;
				mModelSummary.setProperty("/updateRowDataNC/LoaContact", ContrlName2);
				mModelSummary.setProperty("/updateRowDataNC/LoaEmail", contrlName.Emailid);
				if (this.oContrlNameNC.isOpen()) {
					this.oContrlNameNC.close();
				}

			}
			if ((valueField === "AdlLoaContact") && (contrlName.Employeestatuscode == 2)) { /*Changed on 23-Dec-2019*/
				var ContrlName3 = contrlName.Firstname + " " + contrlName.Lastname;
				mModelSummary.setProperty("/updateRowDataNC/AdlLoaContact", ContrlName3);
				mModelSummary.setProperty("/updateRowDataNC/AdlLoaEmail", contrlName.Emailid);
				if (this.oContrlNameNC.isOpen()) {
					this.oContrlNameNC.close();
				}

			}
			if ((valueField === "MfApEmail") && (contrlName.Employeestatuscode == 2)) {
				mModelSummary.setProperty("/updateRowDataNC/MfApEmail", contrlName.Emailid);
				if (this.oContrlNameNC.isOpen()) {
					this.oContrlNameNC.close();
				}

			}
			if ((valueField === "AttenBrf") && (contrlName.Employeestatuscode == 2)) { /*Changed on 23-Dec-2019*/
				var ContrlName4 = contrlName.Firstname + " " + contrlName.Lastname;
				mModelSummary.setProperty("/updateRowDataNC/AttenBrf", ContrlName4);
				mModelSummary.setProperty("/updateRowDataNC/AttenBrfEmail", contrlName.Emailid);
				if (this.oContrlNameNC.isOpen()) {
					this.oContrlNameNC.close();
				}

			}

		},
		/*End of change by Saptarshi on 15-Nov-2019*/
		onOKPressOfTransferOwnerNP: function () {
			var headerData = this.getView().getModel("mModelSummary").getProperty("/HeaderDataNC");
			sap.ui.core.BusyIndicator.show(0);
			var that = this;
			var TableData = [];
			var oPayLoad = {
				CompanyCode: headerData.CompanyCode,
				ContrlName: headerData.ContrlName,
				ContrlEmail: headerData.ContrlEmail,
				TotalContractAmount: headerData.TotalContractAmount,
				GfDesc: headerData.GfDesc,
				RrfNoGf: headerData.RrfNoGf,
				AddlInfo: headerData.AddlInfo,
				/*Added by Satabdi Das on 03-Dec-2019*/
				CreatedOn: headerData.CreatedOn,
				CreatedBy: headerData.CreatedBy,
				Currency: headerData.Currency,
				Kostl: headerData.Kostl,
				Ltext: headerData.Ltext,
				RrfType: headerData.RrfType,
				ToDisplay: headerData.ToDisplay,
				/*Added by Satabdi Das on 26-Nov-2020*/
				CanNoticeDate: headerData.CanNoticeDate,
				/*Added by Satabdi Das on 09-Jan-2020*/
				/*Start of change on 03-March-2020*/
				Background: headerData.Background,
				Activity: headerData.Activity,
				/*End of change on 03-March-2020*/
				RrfStatus: headerData.RrfStatus,
				flag: headerData.flag,
				BillScheFlg: headerData.BillSchFlg,
				GF_Lineitem_Set: []
			};

			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				MessageBox.show(
					d.Message, {
						icon: MessageBox.Icon.SUCCESS,
						title: "Success",
						actions: [MessageBox.Action.OK],
						onClose: function (oAction) {
							if (oAction === "OK") {
								sap.ui.core.BusyIndicator.show(0);
								var oRouter = UIComponent.getRouterFor(that);
								oRouter.navTo("TargetSelectionView");
								sap.ui.core.BusyIndicator.hide(0);
							}

						}
					}
				);

			}, this);
			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();
				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"

				});
			}, this);
			var arr = [];
			arr = this.getView().getModel("mModelSummary").getProperty("/TableItemSetNC");
			if (arr.length !== 0 || arr.results !== undefined) {
				arr = formatter.formatFromCoupaDateToYYYYMMDD(arr);
				for (var i in arr.results) {
					/*Start of change on 10-Jan-2020*/
					if (arr.results[i].Amount === "") {
						arr.results[i].Amount = "000000000000.000";
					}
					/*End of change on 10-Jan-2020*/
					var fields = Object.keys(arr.results[i]);
					var obj = {};
					for (var j = 0; j < fields.length; j++) {
						if (fields[j] !== "__metadata") {
							obj[fields[j]] = arr.results[i][fields[j]];
						}
					}
					TableData.push(obj);
				}
			}

			oPayLoad.GF_Lineitem_Set = TableData;
			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
				json: true
			});
			oModel1.create("/GF_HeaderSet", oPayLoad, {
				success: fnSuccess,
				error: fnError
			});

		},

		onPressSearchNC: function (oEvent) {
			sap.ui.core.BusyIndicator.show(0);
			var fName = this.getView().getModel("mModelSummary").getProperty("/ContrlerEmailSet").firstName;
			var lastName = this.getView().getModel("mModelSummary").getProperty("/ContrlerEmailSet").lastName;
			var Memberfirm = this.getView().getModel("mModelSummary").getProperty("/ContrlerEmailSet").Memberfirm;
			var City = this.getView().getModel("mModelSummary").getProperty("/ContrlerEmailSet").City;
			var Department = this.getView().getModel("mModelSummary").getProperty("/ContrlerEmailSet").Department;
			var Businesstitle = this.getView().getModel("mModelSummary").getProperty("/ContrlerEmailSet").Businesstitle;

			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				if (d.results.length === 0) {
					var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
					MessageBox.alert(
						"No results found.", {
							styleClass: bCompact ? "sapUiSizeCompact" : ""
						}
					);
				} else {
					var mModelSummary = this.getModel("mModelSummary");
					mModelSummary.setProperty("/oEditableNC/visibleForcntrlEmail", true);
					mModelSummary.setProperty("/ContrlNameSet", d.results);
				}

				// mModelSummary.refresh(true);

			}, this);

			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();

				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"

				});
			}, this);

			var sPath = "/RRF_CONAMESet?$top=50&$skip=50"; /*Changed on 26-Dec-2019*/
			var aFilter = [];
			var aFilterStr = [];
			var oFilterSerach;
			if (fName || lastName || Memberfirm || City || Department || Businesstitle) {
				if (fName) {
					fName = formatter.formatValueToString(fName); /*Change added by developer Satabdi Das on 25-May-2021 for HTTP Error*/
					oFilterSerach = new sap.ui.model.Filter("Firstname", sap.ui.model.FilterOperator.EQ, fName);
					aFilterStr.push(oFilterSerach);

				}
				if (lastName) {
					lastName = formatter.formatValueToString(lastName); /*Change added by developer Satabdi Das on 25-May-2021 for HTTP Error*/
					oFilterSerach = new sap.ui.model.Filter("Lastname", sap.ui.model.FilterOperator.EQ, lastName);
					aFilterStr.push(oFilterSerach);
				}
				if (Memberfirm) {
					Memberfirm = formatter.formatValueToString(Memberfirm); /*Change added by developer Satabdi Das on 25-May-2021 for HTTP Error*/
					oFilterSerach = new sap.ui.model.Filter("Memberfirm", sap.ui.model.FilterOperator.EQ, Memberfirm);
					aFilterStr.push(oFilterSerach);
				}
				if (City) {
					City = formatter.formatValueToString(City); /*Change added by developer Satabdi Das on 25-May-2021 for HTTP Error*/
					oFilterSerach = new sap.ui.model.Filter("City", sap.ui.model.FilterOperator.EQ, City);
					aFilterStr.push(oFilterSerach);
				}
				if (Department) {
					Department = formatter.formatValueToString(Department); /*Change added by developer Satabdi Das on 25-May-2021 for HTTP Error*/
					oFilterSerach = new sap.ui.model.Filter("Department", sap.ui.model.FilterOperator.EQ, Department);
					aFilterStr.push(oFilterSerach);
				}
				if (Businesstitle) {
					Businesstitle = formatter.formatValueToString(Businesstitle); /*Change added by developer Satabdi Das on 25-May-2021 for HTTP Error*/
					oFilterSerach = new sap.ui.model.Filter("Businesstitle", sap.ui.model.FilterOperator.EQ, Businesstitle);
					aFilterStr.push(oFilterSerach);
				}

				var oFilterStr = new sap.ui.model.Filter({
					filters: aFilterStr,
					and: true
				});
				aFilter.push(oFilterStr);
			}
			// var sParams = []; /*Changed on 26-Dec-2019*/
			// sParams.push("$skip=0"); /*Added on 26-Dec-2019*/
			// sParams.push("$top=50"); /*Added on 26-Dec-2019*/
			// var oObject = {};
			// oObject.Filter = aFilter;
			// oObject.Params = sParams;
			// oObject.successCallback = fnSuccess;
			// oObject.errorCallback = fnError;
			// oObject.sPath = sPath;
			// DataManagerARrecharge.getContrlEmailValue(oObject);
			/*R&D---start*/
			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
				json: true
			});
			oModel1.read("/RRF_CONAMESet?$skip=0&$top=50", {
				filters: aFilter,
				success: fnSuccess,
				error: fnError
			});
			/*R&D---end*/
		},

		pressBillSchDisplay: function (oEvent) {
			var mModelSummary = this.getModel("mModelSummary");
			var msg; /*Added by Satabdi Das on 18-Dec-2019*/
			var bGfFlag = this.getModel("mModelSummary").getProperty("/oEditableNC/visibleforGF"); /*Added by Satabdi Das on 18-Dec-2019*/
			if (mModelSummary.getData().HeaderDataNC.RrfNoGf) {
				var iIrfNumber = mModelSummary.getData().HeaderDataNC.RrfNoGf;
				var iCompCode = mModelSummary.getData().HeaderDataNC.CompanyCode;
				if (bGfFlag === true) { /*Added by Satabdi Das on 18-Dec-2019*/
					var sGblCC = mModelSummary.getData().updateRowDataNC.GlobalCc; /*Added by Satabdi Das on 18-Dec-2019*/
					mModelSummary.setProperty("/oEditableNC/LineItemJV", true);
					mModelSummary.setProperty("/oEditableNC/LineItemBill", false);
				} /*Added by Satabdi Das on 18-Dec-2019*/
				else { /*Added by Satabdi Das on 18-Dec-2019*/
					var sReqMf = mModelSummary.getData().updateRowDataNC.RequestingMf; /*Added by Satabdi Das on 18-Dec-2019*/
					var sProcessGrp = mModelSummary.getData().updateRowDataNC.ProcessGrp; /*Added on 17-Jan-2020*/
					var sMemberFirm = mModelSummary.getData().updateRowDataNC.MemberFirm;
					var sCcShortDesc = "";
					mModelSummary.setProperty("/oEditableNC/LineItemJV", false);
					mModelSummary.setProperty("/oEditableNC/LineItemBill", true);
				} /*Added by Satabdi Das on 18-Dec-2019*/
			} else {
				iIrfNumber = "";
				iCompCode = "";
				sReqMf = "";
				sProcessGrp = ""; /*Added on 17-Jan-2020*/
				sGblCC = ""; /*Added by Satabdi Das on 18-Dec-2019*/
				sMemberFirm = "";
				sCcShortDesc = "";
			}
			sap.ui.core.BusyIndicator.show(0);
			var aFilter = [];
			var sPath = "";
			sPath = "/GF_BillingSet";
			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				// mModelSummary.setProperty("/GF_BSH", d.results);
				// mModelSummary.refresh(true);
				if (d.results.length > 0) {
					var sDocNum; /*Added on 29-APR-2020*/
					for (var i = 0; i < d.results.length; i++) {
						d.results[i].ReqSeq = d.results[i].ReqSeq.trim();
						/*Start of change on 29-APR-2020*/
						if (d.results[i].Belnr && d.results[i].Belnr !== "") {
							sDocNum = true;
						}
						/*End of change on 29-APR-2020*/
					}
					/*Start of change on 29-APR-2020*/
					if (sDocNum === true) {
						mModelSummary.setProperty("/oEditableNC/NoDocNum", false);
					} else if (sDocNum === undefined) {
						mModelSummary.setProperty("/oEditableNC/NoDocNum", true);
					}
					/*End of change on 29-APR-2020*/
					mModelSummary.setProperty("/GF_BSH", d.results);
					mModelSummary.setProperty("/GF_AddNew", d.results[0]);
					var fragmentId = this.getView().createId("billingSchedule");
					if (!this._oBillSch) {
						this._oBillSch = sap.ui.xmlfragment(fragmentId, "kgo.ARRecharge.view.billingSchedule", this);
						this.getView().addDependent(this._oBillSch);
					}
					this._oBillSch.open();
					if (mModelSummary.getProperty("/oEditableNC/visibleForEditGf") === true) {
						// mModelSummary.setProperty("/oEditableNC/billFields", true); /*Added on 17-Jan-2020*/
						/*Start of change for defect 63320 on 19-May-2020*/
						var sLineStatus = mModelSummary.getData().updateRowDataNC.RrfStatus;
						if (sLineStatus === "COPInitiated" || sLineStatus === "COPConfirmed" || sLineStatus === "LOAInitiated" || sLineStatus ===
							"LOAConfirmed") {
							mModelSummary.setProperty("/oEditableNC/billFields", false);
						} else {
							mModelSummary.setProperty("/oEditableNC/billFields", true);
						}
						/*End of change for defect 63320 on 19-May-2020*/
						/*Start of change on 17-Jan-2020*/
						var oBillFrag = this.byId(sap.ui.core.Fragment.createId(fragmentId, "billScheduletbl"));
						oBillFrag.removeSelections(true); /*Added for Defect 63096*/
						/*Start of change for defect 63322 on 19-May-2020*/
						if (sDocNum && sDocNum === true) {
							oBillFrag.addStyleClass("BillTblCheckBox");
						} else {
							oBillFrag.removeStyleClass("BillTblCheckBox");
						}
						/*End of change for defect 63321 on 19-May-2020*/
						var oBillFragItems = oBillFrag.getAggregation("items");
						var sItemLen = oBillFragItems.length;
						for (var i = 0; i <= sItemLen; i++) {
							var objDate1 = oBillFragItems[i].getAggregation("cells")[4].getDomRef();
							if (objDate1) {
								objDate1.firstElementChild.firstChild.setAttribute("readonly", true);
							}
							var objDate2 = oBillFragItems[i].getAggregation("cells")[5].getDomRef();
							if (objDate2) {
								objDate2.firstElementChild.firstChild.setAttribute("readonly", true);
							}
							var sBelnr = oBillFragItems[i].getAggregation("cells")[7].getText();
							if (sBelnr !== "") {
								var objSeqNum = oBillFragItems[i].getAggregation("cells")[3].getDomRef();
								var objAmt = oBillFragItems[i].getAggregation("cells")[6].getDomRef();
								if (objSeqNum) {
									objSeqNum.firstElementChild.firstChild.setAttribute("readonly", true);
								}
								if (objAmt) {
									objAmt.firstElementChild.firstChild.setAttribute("readonly", true);
								}
								oBillFragItems[i].getAggregation("cells")[4].addStyleClass("calender");
								oBillFragItems[i].getAggregation("cells")[5].addStyleClass("calender");
								oBillFragItems[i].getMultiSelectControl().setEnabled(false);
							}
						}
					}
					/*End of change on 17-Jan-2020*/
					/*Start of Defect 63096 on 04-Feb-2020*/
					else if (mModelSummary.getProperty("/oEditableNC/visibleForEditGf") === false) {
						oBillFrag = this.byId(sap.ui.core.Fragment.createId(fragmentId, "billScheduletbl"));
						oBillFrag.removeSelections(true);
					}
					/*End of Defect 63096 on 04-Feb-2020*/
				} else {
					if (bGfFlag === true) { /*Added by Satabdi Das on 18-Dec-2019*/
						msg = "JV schedule has not been created!"; /*Added by Satabdi Das on 18-Dec-2019*/
					} else { /*Added by Satabdi Das on 18-Dec-2019*/
						msg = "Bill schedule has not been created!";
					} /*Added by Satabdi Das on 18-Dec-2019*/
					MessageToast.show(msg);
					return;
				}
			}, this);
			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();
				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"
				});
			}, this);
			var sParams = {};
			var oObject = {};
			aFilter.push(new sap.ui.model.Filter("RrfNoGf", sap.ui.model.FilterOperator.EQ, iIrfNumber));
			aFilter.push(new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.EQ, iCompCode));
			if (bGfFlag === true) { /*Added by Satabdi Das on 18-Dec-2019*/
				aFilter.push(new sap.ui.model.Filter("GlobalCc", sap.ui.model.FilterOperator.EQ, sGblCC)); /*Added by Satabdi Das on 18-Dec-2019*/
				aFilter.push(new sap.ui.model.Filter("CcShortDesc", sap.ui.model.FilterOperator.EQ, sCcShortDesc));
			} /*Added by Satabdi Das on 18-Dec-2019*/
			else { /*Added by Satabdi Das on 18-Dec-2019*/
				aFilter.push(new sap.ui.model.Filter("RequestingMf", sap.ui.model.FilterOperator.EQ, sReqMf));
				aFilter.push(new sap.ui.model.Filter("ProcessGrp", sap.ui.model.FilterOperator.EQ, sProcessGrp)); /*Added on 17-Jan-2020*/
				aFilter.push(new sap.ui.model.Filter("MemberFirm", sap.ui.model.FilterOperator.EQ, sMemberFirm));
			} /*Added by Satabdi Das on 18-Dec-2019*/
			// oObject.Filter = aFilter;
			// oObject.Params = sParams;
			// oObject.successCallback = fnSuccess;
			// oObject.errorCallback = fnError;
			// oObject.sPath = sPath;
			// DataManagerARrecharge.getNonCoupaReqhelpValue(oObject);
			/*R&D---start*/
			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
				json: true
			});
			oModel1.read("/GF_BillingSet", {
				filters: aFilter,
				success: fnSuccess,
				error: fnError
			});
			/*R&D---end*/

		},
		/*End by Saptarshi on 11th-Nov-2019*/
		/*Start by Saptarshi on 12-Nov-2019*/
		onAdd: function (oEvent) {
			var displayMode = this.getModel("mModelSummary").getProperty("/displayMode"); /*Added by Saptarshi on 22-Nov-2019*/
			if (displayMode === false) { /*Added by Saptarshi on 22-Nov-2019*/
				var mModelSummary = this.getModel("mModelSummary");
				/*Start of change for defect 63320 on 19-May-2020*/
				var bFieldEdit = mModelSummary.getProperty("/oEditableNC/billFields");
				if (bFieldEdit === true) {
					/*End of change for defect 63320 on 19-May-2020*/
					var oLastData = mModelSummary.getProperty("/GF_AddNew");
					var oPayLoad = {
						Belnr: "",
						Budat: "",
						Bukrs: oLastData.Bukrs,
						Dmbtr: "",
						/*Changed on 03-Feb-2020 for Defect 63106*/
						Gjahr: "",
						GlobalCc: oLastData.GlobalCc,
						ReqSeq: "",
						/*Changed on 03-Feb-2020 for Defect 63106*/
						RequestingMf: oLastData.RequestingMf,
						MemberFirm: oLastData.MemberFirm,
						CcShortDesc: "",
						RrfNoGf: oLastData.RrfNoGf,
						SchDate: "",
						/*Changed on 03-Feb-2020 for Defect 63106*/
						Waers: "",
						ProcessGrp: oLastData.ProcessGrp,
						/*Added on 10-Jan-2020*/

					};
					var arr = [];
					arr = mModelSummary.getData().GF_BSH;
					arr.push(oPayLoad);
					mModelSummary.setProperty("/GF_BSH", arr);
					var fragmentId = this.getView().createId("billingSchedule");
					var oBillFrag = this.byId(sap.ui.core.Fragment.createId(fragmentId, "billScheduletbl"));
					var oBillFragItems = oBillFrag.getAggregation("items");
					var sItemLen = oBillFragItems.length;
					for (var i = 0; i <= sItemLen; i++) {
						var objDate1 = oBillFragItems[i].getAggregation("cells")[4].getDomRef();
						if (objDate1) {
							objDate1.firstElementChild.firstChild.setAttribute("readonly", true);
						}
						var objDate2 = oBillFragItems[i].getAggregation("cells")[5].getDomRef();
						if (objDate2) {
							objDate2.firstElementChild.firstChild.setAttribute("readonly", true);
						}
					}
				} /*Added for defect 63320 on 19-May-2020*/
			} /*Added by Saptarshi on 22-Nov-2019*/
		},
		onDelRow: function (oEvent) {
			var displayMode = this.getModel("mModelSummary").getProperty("/displayMode"); /*Added by Saptarshi on 22-Nov-2019*/
			if (displayMode === false) { /*Added by Saptarshi on 22-Nov-2019*/
				var fragmentId = this.getView().createId("billingSchedule");
				var table = sap.ui.core.Fragment.byId(fragmentId, "billScheduletbl");
				var mModelSummary = this.getModel("mModelSummary");
				/*Start of change for defect 63320 on 19-May-2020*/
				var bFieldEdit = mModelSummary.getProperty("/oEditableNC/billFields");
				if (bFieldEdit === true) {
					/*End of change for defect 63320 on 19-May-2020*/
					var sAcontext = table.getSelectedContextPaths();
					var iPrevRow; /*Added on 19-Dec-2019*/
					var msg; /*Added on 19-Dec-2019*/
					var z; /*Added on 20-Dec-2019*/
					var oTable = [];
					oTable = mModelSummary.getData().GF_BSH;
					if (sAcontext.length !== 0) { /*Added on 20-Dec-2019*/
						for (var i = sAcontext.length - 1; i >= 0; i--) { /* Loop condition modified for Defect 63095 on 30-Jan-2020*/
							var x = sAcontext[i].split("/");
							z = parseInt(x[2]);
							if (oTable[z].Belnr === "") {
								oTable.splice(z, 1);
							} else {
								msg = this.getView().getModel("i18n").getProperty("DelRowWarning");
								MessageToast.show(msg);

							}
						}
					} /*Added 20-Dec-2019*/
					else if (sAcontext.length === 0 || sAcontext === iPrevRow) {
						msg = "Please select atleast one row!";
						MessageToast.show(msg);
					}
					iPrevRow = z; /*Added on 20-Dec-2019*/
					table.removeSelections(true); /*Added on 20-Dec-2019*/
					this.getModel("mModelSummary").refresh(); /*added on 30-Jan-2020*/
				} /*Added for defect 63320 on 19-May-2020*/
			} /*Added by Saptarshi on 22-Nov-2019*/
		},
		onBillSave: function (oEvent) {
			var displayMode = this.getModel("mModelSummary").getProperty("/displayMode"); /*Added by Saptarshi 22-Nov-2019*/
			if (displayMode === false) { /*Added by Saptarshi 22-Nov-2019*/
				var mModelSummary = this.getModel("mModelSummary");
				/*Start of change for defect 63320 on 19-May-2020*/
				var bFieldEdit = mModelSummary.getProperty("/oEditableNC/billFields");
				if (bFieldEdit === true) {
					/*End of change for defect 63320 on 19-May-2020*/
					var iLen = mModelSummary.getData().GF_BSH.length;
					var oLastData;
					sap.ui.core.BusyIndicator.show(0);
					var TableData = [];
					for (var i = 0; i < iLen; i++) {
						oLastData = mModelSummary.getData().GF_BSH[i];
						var oPayLoad = {
							Bukrs: oLastData.Bukrs,
							RequestingMf: oLastData.RequestingMf,
							RrfNoGf: oLastData.RrfNoGf,
							GlobalCc: oLastData.GlobalCc,
							// MemberFirm: oLastData.MemberFirm,
							// CcShortDesc: "",
							GF_Bill_Set: []
						};
					}
					sap.ui.core.BusyIndicator.hide(0);
					var that = this;
					var fnSuccess = jQuery.proxy(function (d) {
						sap.ui.core.BusyIndicator.hide(0);
						var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
						if (d.Flag) {
							var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
							MessageBox.error(
								d.Message, {
									styleClass: bCompact ? "sapUiSizeCompact" : ""
								}
							);
						} else {
							MessageBox.show(
								d.Message, {
									icon: MessageBox.Icon.SUCCESS,
									title: "Success",
									actions: [MessageBox.Action.OK],
									onClose: function (oAction) {
										if (that._oBillSch.isOpen()) {
											that._oBillSch.close();
										}
									}
								}
							);
						}
					}, this);
					var fnError = jQuery.proxy(function (d) {
						var r = JSON.parse(JSON.stringify(d));
						sap.ui.core.BusyIndicator.hide();
						MessageToast.show(r.message, {
							autoClose: true,
							width: "20rem"

						});
					}, this);
					var objectOne = {};
					var arr = [];
					objectOne.successCallback = fnSuccess;
					objectOne.errorCallback = fnError;
					arr = this.getModel("mModelSummary").getProperty("/GF_BSH");
					if (!arr) {
						sap.ui.core.BusyIndicator.hide(); /*Added buy Saptarshi on 11th-Nov-2019*/
						MessageBox.alert(
							"Please enter atleast one line item.", {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}
						);
					} else if (arr.length === 0) {
						sap.ui.core.BusyIndicator.hide();
						var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
						MessageBox.alert(
							"Please enter atleast one line item.", {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}
						);
					} else {
						/*arr = formatter.formatFromCoupaDateToYYYYMMDD(arr);*/
						for (var i in arr) {
							/*Start of change on 04-Feb-2020 for Defect 63114*/
							if (arr[i].Dmbtr === "") {
								arr[i].Dmbtr = "000000000000.000";
							}
							/*End of change on 04-Feb-2020 for Defect 63114*/
							var fields = Object.keys(arr[i]);
							var obj = {};
							for (var j = 0; j < fields.length; j++) {
								if (fields[j] !== "__metadata") {
									obj[fields[j]] = arr[i][fields[j]];
								}
							}
							TableData.push(obj);
						}
						oPayLoad.GF_Bill_Set = TableData;
						DataManagerARrecharge.CreateDataBillSH(oPayLoad, objectOne);
					}
				} /*Added for defect 63320 on 19-May-2020*/
			} /*Added by Saptarshi on 22-Nov-2019*/
		},
		onDelAll: function (oEvent) {
			var displayMode = this.getModel("mModelSummary").getProperty("/displayMode"); /*Added by Saptarshi on 22-Nov-2019*/
			if (displayMode === false) { /*Added by Saptarshi on 22-Nov-2019*/
				var that = this;
				var mModelSummary = this.getModel("mModelSummary");
				/*Start of change for defect 63320 on 19-May-2020*/
				var bFieldEdit = mModelSummary.getProperty("/oEditableNC/billFields");
				if (bFieldEdit === true) {
					/*End of change for defect 63320 on 19-May-2020*/
					var iLen = mModelSummary.getData().GF_BSH.length;
					var iRowNum = iLen - 1;
					var oLastData = mModelSummary.getData().GF_BSH[iRowNum];
					var event = oEvent.getSource();
					var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
					var rrfTablefragmentNonCoupa = this.getView().createId("rrfTablefragmentNonCoupa"); /*Added on 16-Jan-2020*/
					var BRFSchPanel = sap.ui.core.Fragment.byId(rrfTablefragmentNonCoupa, "BRFSecNC"); /*Added on 16-Jan-2020*/
					var JVSchPanel = sap.ui.core.Fragment.byId(rrfTablefragmentNonCoupa, "JVPanelNC"); /*Added on 16-Jan-2020*/
					if (oLastData) {
						MessageBox.warning(
							"Are you sure you want to delete this?", {
								actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
								styleClass: bCompact ? "sapUiSizeCompact" : "",
								onClose: function (sAction) {
									if (sAction === "OK") {
										if (oLastData.RrfNoGf) {
											var fnSuccess = jQuery.proxy(function (d) {
												sap.ui.core.BusyIndicator.hide(0);
												if (that._oBillSch.isOpen()) {
													that._oBillSch.close();
													/*Start of change on 16-Jan-2020*/
													if (rrfTablefragmentNonCoupa !== undefined) {
														if (BRFSchPanel !== undefined && (BRFSchPanel.getExpanded() === true)) {
															that.getModel("mModelSummary").setProperty("/oEditableNC/editLineItemBillSch", true);
														}
														if (JVSchPanel !== undefined && (JVSchPanel.getExpanded() === true)) {
															that.getModel("mModelSummary").setProperty("/oEditableNC/editLineItemAddInfJV", true);
														}

														that.getModel("mModelSummary").setProperty("/updateRowDataNC/Amount", "");
														that.getModel("mModelSummary").setProperty("/updateRowDataNC/BillingFrequency", "");
														that.getModel("mModelSummary").setProperty("/updateRowDataNC/StartDate", "");
														that.getModel("mModelSummary").setProperty("/updateRowDataNC/NoOfOccur", "");
														that.getView().getModel("mModelSummary").setProperty("/updateRowDataNC/BillSchedule", false);
													}
													/*End of change on 16-Jan-2020*/
												}
												// that.editNonCoupa();
												that.getView().getModel("mModelSummary").refresh();
											}, that);
											var fnError = jQuery.proxy(function (d) {
												var r = JSON.parse(JSON.stringify(d));
											}, that);
											/*start of change on 18-Dec-2019*/
											if (oLastData.RequestingMf === "N/A") {
												oLastData.RequestingMf = "NA";
												oLastData.MemberFirm = "";
											} else if (oLastData.GlobalCc === "N/A") {
												oLastData.GlobalCc = "NA";
												oLastData.CcShortDesc = "";
											}
											if (oLastData.ProcessGrp) {
												oLastData.ProcessGrp = oLastData.ProcessGrp.replace(/\s/g, "*");
											}
											if (oLastData.MemberFirm) {
												oLastData.MemberFirm = oLastData.MemberFirm.replace(/\s/g, "*");
											}
											var sPath = "/GF_BillshSet(CompanyCode='" + oLastData.Bukrs + "',RrfNoGf='" + oLastData.RrfNoGf +
												"',RequestingMf='" + oLastData.RequestingMf + "',MemberFirm='" + oLastData.MemberFirm + "',GlobalCc='" + oLastData.GlobalCc +
												"',CcShortDesc='" + oLastData.CcShortDesc + "',ProcessGrp='" + oLastData.ProcessGrp +
												"')";
											/*End of change on 18-Dec-2019*/
											var oObject = {};
											oObject.success = fnSuccess;
											oObject.error = fnError;
											oObject.sPath = sPath;
											oObject.groupId = "DeleteRow";
											that.deleteRecordNC(oObject);
											that._submitBatchOperationTestNC("DeleteRow", fnSuccess, fnError);
										}
									}
								}
							}
						);
					} else {
						var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
						MessageBox.error(
							this.getView().getModel("i18n").getProperty("DelWarning"), {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}
						);
					}
				} /*Added for defect 63320 on 19-May-2020*/
			} /*Added by Saptarshi on 22-Nov-2019*/
		},
		/*End by Saptarshi on 12-Nov-2019*/
		/*Start of change on 18-Nov-2019 by Saptarshi*/
		checkAmount: function (oEvent) {
			var rrfTablefragmentNonCoupa = this.getView().createId("rrfTablefragmentNonCoupa");
			if (isNaN(oEvent.getParameter("value")) === true || (oEvent.getParameter("value") > 99999999999.99)) { /*Defect 63120*/
				var label1 = sap.ui.core.Fragment.byId(rrfTablefragmentNonCoupa, "Amount");
				var label2 = sap.ui.core.Fragment.byId(rrfTablefragmentNonCoupa, "AmountLoa");
				var label3 = sap.ui.core.Fragment.byId(rrfTablefragmentNonCoupa, "Amt1");
				var label4 = sap.ui.core.Fragment.byId(rrfTablefragmentNonCoupa, "Amt2");
				var label5 = sap.ui.core.Fragment.byId(rrfTablefragmentNonCoupa, "TotalAmtJV"); /*Added by Satabdi Das on 18-Dec-2019*/
				if (label1 !== undefined) {
					label1.setValue("");
					/*Start of change on 30-Dec-2019*/
					if (label5 !== undefined) {
						label5.setValue("");
					}
					/*End of change on 30-Dec-2019*/
				} else if (label2 !== undefined) {
					label2.setValue("");
				} else if (label3 !== undefined) {
					label3.setValue("");
				} else if (label4 !== undefined) {
					label4.setValue("");
				} else if (label5 !== undefined) {
					label5.setValue(""); /*Added by Satabdi Das on 18-Dec-2019*/
				}
			}

		},
		/*End of change on 18-Nov-2019 by Sapatrshi*/
		/*End of change by Saptarshi*/
		/*Start of change for SCTASK1855604 - budget approvers by developer Satabdi Das on 19-May-2021*/
		onChangeJVAmt: function (oEvent) {
			var sNewVal = oEvent.getParameter("value");
			var mModelSummary = this.getView().getModel("mModelSummary");
			mModelSummary.setProperty("/updateRowDataNC/LoaContact", "");
			mModelSummary.setProperty("/updateRowDataNC/LoaEmail", "");
			// mModelSummary.setProperty("/updateRowDataNC/AdlLoaContact", "");
			// mModelSummary.setProperty("/updateRowDataNC/AdlLoaEmail", "");
		},
		/*End of change for SCTASK1855604 - budget approvers by developer Satabdi Das on 19-May-2021*/
		/*Start of change by Satabdi Das on 03-Dec-2019*/
		onSelectMF: function (oEvent) {
			var id = oEvent.getSource().getId(); /*Added on 28-Jan-2020*/
			var format = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/;
			var mModelSummary = this.getView().getModel("mModelSummary");
			var that = this;
			var oKeepInstance = oEvent.getParameter("selectedItem");
			if (id.indexOf("contryDrdwIdNC") > 0) { /*Added on 28-Jan-2020*/

				if (mModelSummary.getProperty("/updateRowDataNC").RequestingMf) {
					var messageText = this.getModel("i18n").getProperty("requestingMfchangedmsg");
					MessageBox.information(messageText, {
						actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
						emphasizedAction: MessageBox.Action.OK,
						onClose: function (sAction) {
							if (sAction === "CANCEL") {
								var reqConty = mModelSummary.getProperty("/updateRowDataNC").RequestingMf;
								mModelSummary.setProperty("/SelcKeySet", reqConty);

							} else {

								if (oKeepInstance.getProperty("text").split(":")[0]) {
									var RequestingcountryName = oKeepInstance.getProperty("text").split(":")[1];
									var contrycode = oKeepInstance.getProperty("text").split(":")[0];
									if (format.test(contrycode)) {
										var specialcharmsgForMf = that.getModel("i18n").getProperty("specialcharmsgForMf");
										MessageBox.error(specialcharmsgForMf);
										return true;
									}

								}

								var oMemberFirm = oKeepInstance.getProperty("additionalText");
								//special character message validation
								if (format.test(oMemberFirm)) {
									var specialcharmsgForMemberfirm = that.getModel("i18n").getProperty("specialcharmsgForMemberfirm");
									MessageBox.error(specialcharmsgForMemberfirm);
									return true;

								}

								mModelSummary.setProperty("/SelcKeySet", contrycode);
								var key = oKeepInstance.getProperty("key");
								mModelSummary.setProperty("/SelcKeySet", key);
								mModelSummary.setProperty("/updateRowDataNC/MemberFirm", oMemberFirm);
								mModelSummary.setProperty("/updateRowDataNC/Landx", RequestingcountryName);
								mModelSummary.setProperty("/updateRowDataNC/EntityName", "");
								mModelSummary.setProperty("/updateRowDataNC/EntityAddress", "");

								mModelSummary.setProperty("/updateRowDataNC/RequestingMf", key);

								//mModelSummary.setProperty("/updateRowDataNC/")

								//questionCall
								that.questionaCallNP();
								mModelSummary.setProperty("/SelcKeySet", key);

							}
						}
					});
				} else {
					if (oEvent.getParameter("selectedItem").getProperty("text").split(":")[0]) {
						var RequestingcountryName = oEvent.getParameter("selectedItem").getProperty("text").split(":")[1];
						var contrycode = oEvent.getParameter("selectedItem").getProperty("text").split(":")[0];
						if (format.test(contrycode)) {
							var specialcharmsgForMf = this.getModel("i18n").getProperty("specialcharmsgForMf");
							MessageBox.error(specialcharmsgForMf);
							return true;
						}

					}

					var oMemberFirm = oEvent.getParameter("selectedItem").getProperty("additionalText");

					if (format.test(oMemberFirm)) {
						var specialcharmsgForMemberfirm = this.getModel("i18n").getProperty("specialcharmsgForMemberfirm");
						MessageBox.error(specialcharmsgForMemberfirm);
						return true;

					}
					this.getView().getModel("mModelSummary").setProperty("/SelcKeySet", contrycode);
					var key = oEvent.getParameter("selectedItem").getProperty("key");
					mModelSummary.setProperty("/SelcKeySet", key);
					mModelSummary.setProperty("/updateRowDataNC/MemberFirm", oMemberFirm);
					mModelSummary.setProperty("/updateRowDataNC/Landx", RequestingcountryName);
					mModelSummary.setProperty("/updateRowDataNC/RequestingMf", key);
					//special character message validation

					//questionCall
					that.questionaCallNP();
					mModelSummary.setProperty("/SelcKeySet", key);
				}

				/*Start of change  on 28-Jan-2020*/
			} else if (id.indexOf("Loservice") > 0) {
				/*Start of defect 63359*/
				if (oEvent.getParameter("selectedItem") !== null) {
					var key = oEvent.getParameter("selectedItem").getProperty("key");
					mModelSummary.setProperty("/updateRowDataNC/LocationOfTheServicesReq", key);
					// if (key === "US") {
					// 	mModelSummary.setProperty("/oEditableNC/serviceRenderBox", true);
					// } else {
					// 	mModelSummary.setProperty("/oEditableNC/serviceRenderBox", false);
					// 	mModelSummary.setProperty("/updateRowDataNC/LocOfRenderingUs", "");
					// }
				} else if (oEvent.getParameter("selectedItem") === null) {
					mModelSummary.setProperty("/updateRowDataNC/LocationOfTheServicesReq", "");
					// mModelSummary.setProperty("/oEditableNC/serviceRenderBox", false);
					// mModelSummary.setProperty("/updateRowDataNC/LocOfRenderingUs", "");
				}
				/*End of defect 63359*/
			}
			/*End of change on 28-Jan-2020*/
			mModelSummary.setProperty("/SelcKeySet", mModelSummary.getProperty("/updateRowDataNC").RequestingMf);

		},
		/*End of change by Satabdi Das on 03-Dec-2019*/
		/*Start of change for attachment section on 26-Dec-2019 by Satabdi Das*/
		// onSelectingServiceRenderNC: function (oEvent) {
		// 	var mModelSummary = this.getView().getModel("mModelSummary");
		// 	var selectedKey = oEvent.getParameter("selectedItem").getProperty("key");
		// 	mModelSummary.setProperty("/updateRowDataNC/LocOfRenderingUs", selectedKey);
		// },
		//Questionnaire changes
		questionaCallNP: function () {

			var mModelSummary = this.getModel("mModelSummary");
			var firstQuestion = this.getModel("i18n").getProperty("firstQuestionOfQuestionnaire");
			mModelSummary.setProperty("/oEditableNC/questionPnVisibleNP", false);
			var contrycode = mModelSummary.getProperty("/updateRowDataNC").RequestingMf;
			mModelSummary.setProperty("/nPquestionSet", []);
			sap.ui.core.BusyIndicator.show(0);

			var aFilter = [];
			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				var questionArr = [];
				var firstQuestionArrey = [];
				if (d.results.length > 0) {
					for (var i = 0; i < d.results.length; i++) {
						var object = {};
						object.LineNo = d.results[i].LineNo;
						object.CompanyCode = d.results[i].CompanyCode;
						object.Mandatory = d.results[i].Mandatory;
						object.MemberFirm = d.results[i].MemberFirm;
						object.Question = d.results[i].Question;
						object.RequestingMf = d.results[i].RequestingMf;
						object.Answer = "";
						object.InternalExternal = d.results[i].InternalExternal;
						object.AnswerDesc = "";
						object.ProcessGrp = "";
						questionArr.push(object);
						// if (i == 0) {
						// 	firstQuestionArrey.push(object);
						// 	// mModelSummary.setProperty("/firstQuestionSet",object );

						// } else {
						// 	questionArr.push(object);
						// }

					}
					mModelSummary.setProperty("/nPquestionSet", questionArr);

					if (questionArr.length > 0) {
						var objectFirst = {};
						objectFirst.LineNo = "01";
						objectFirst.CompanyCode = object.CompanyCode;
						objectFirst.Mandatory = "";
						objectFirst.MemberFirm = object.MemberFirm;
						objectFirst.Question = firstQuestion;
						objectFirst.InternalExternal = "";
						objectFirst.RequestingMf = object.RequestingMf;
						objectFirst.Answer = "";
						objectFirst.AnswerOther = "";
						objectFirst.ProcessGrp = "";
						firstQuestionArrey.push(objectFirst);
					}
					mModelSummary.setProperty("/nPquestionSetFirst", firstQuestionArrey);
					mModelSummary.setProperty("/oEditableNC/questionPnVisibleNP", true);
				} else {
					mModelSummary.setProperty("/oEditableNC/questionPnVisibleNP", false);
				}

				return mModelSummary.setProperty("/SelcKeySet", contrycode);

			}, this);

			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();

				MessageToast.show(r.message, {
					autoClose: true,
					width: "20rem"

				});
			}, this);

			aFilter.push(new Filter("RequestingMf", FilterOperator.EQ, mModelSummary.getProperty("/updateRowDataNC").RequestingMf));
			aFilter.push(new Filter("MemberFirm", FilterOperator.EQ, mModelSummary.getProperty("/updateRowDataNC").MemberFirm));
			aFilter.push(new Filter("CompanyCode", FilterOperator.EQ, mModelSummary.getProperty("/HeaderDataNC").CompanyCode));
			var sPath = "/RRF_QuestionSet";
			var oObject = {};
			oObject.Filter = aFilter;
			//oObject.Params = sParams;
			oObject.successCallback = fnSuccess;
			oObject.errorCallback = fnError;
			oObject.sPath = sPath;
			DataManagerARrecharge.getCoupaReqiNumberhelpValus(oObject);

		},
		onSelectingFirstAnswer: function (oEvent) {
			var EditFlag = this.getModel("mModelSummary").getProperty("/oEditableNC").rmdropDown;
			var val = oEvent.getParameter("selectedItem").getProperty("text");
			var questionTableData = this.getModel("mModelSummary").getProperty("/nPquestionSet");
			var tbl;
			var showInputField;
			var rrfTablefragmentNonCoupa = this.getView().createId("rrfTablefragmentNonCoupa");
			tbl = sap.ui.core.Fragment.byId(rrfTablefragmentNonCoupa, "QuestionTableNP");
			for (var interExt = 0; interExt < questionTableData.length; interExt++) {
				if (val === "Service from KPMGI") {
					if (questionTableData[interExt].InternalExternal === "EXTERNAL") {
						questionTableData[interExt].Answer = "N/A";
						questionTableData[interExt].AnswerDesc = " ";
						tbl.getAggregation("items")[interExt].getCells()[3].setProperty("visible", false);
						tbl.getAggregation("items")[interExt].getCells()[2].setProperty("editable", false);
					} else {
						questionTableData[interExt].Answer = " ";
						questionTableData[interExt].AnswerDesc = " ";
						tbl.getAggregation("items")[interExt].getCells()[3].setProperty("visible", false);
						tbl.getAggregation("items")[interExt].getCells()[2].setProperty("editable", true);
					}
				}
				if (val === "Service from external supplier") {
					if (questionTableData[interExt].InternalExternal === "INTERNAL") {
						questionTableData[interExt].Answer = "N/A";
						questionTableData[interExt].AnswerDesc = " ";
						tbl.getAggregation("items")[interExt].getCells()[3].setProperty("visible", false);
						tbl.getAggregation("items")[interExt].getCells()[2].setProperty("editable", false);
					} else {
						questionTableData[interExt].Answer = " ";
						questionTableData[interExt].AnswerDesc = " ";
						tbl.getAggregation("items")[interExt].getCells()[3].setProperty("visible", false);
						tbl.getAggregation("items")[interExt].getCells()[2].setProperty("editable", true);
					}
				}

			}
		},

		onSelectingAnsware: function (oEvent) {
			var val = oEvent.getParameter("selectedItem").getProperty("text");
			var mModelSummary = this.getView().getModel("mModelSummary");
			var rowPath = oEvent.getSource().getParent().getBindingContextPath();
			var tbl;
			var showInputField;
			var rrfTablefragmentNonCoupa = this.getView().createId("rrfTablefragmentNonCoupa");
			tbl = sap.ui.core.Fragment.byId(rrfTablefragmentNonCoupa, "QuestionTableNP");
			for (var i = 0; i < tbl.getAggregation("items").length; i++) {
				showInputField = tbl.getAggregation("items")[i].getBindingContext("mModelSummary").sPath;
				if ((showInputField === rowPath)) {
					for (var k = 0; k < tbl.getAggregation("items")[i].getCells().length; k++) {
						if (k === 3) {
							if (val === "YES") {
								tbl.getAggregation("items")[i].getCells()[3].setProperty("visible", true);
								mModelSummary.getProperty("/nPquestionSet")[i].AnswerDesc = "";
								//tbl.getAggregation("items")[i].getCells()[3].setProperty("value", "");

							} else if (val === "NO") {
								tbl.getAggregation("items")[i].getCells()[3].setProperty("visible", true);
								//tbl.getAggregation("items")[i].getCells()[3].setProperty("value", "");
								mModelSummary.getProperty("/nPquestionSet")[i].AnswerDesc = "";
							} else if (val === "Other") {
								tbl.getAggregation("items")[i].getCells()[3].setProperty("visible", true);
								mModelSummary.getProperty("/nPquestionSet")[i].AnswerDesc = "";
								//tbl.getAggregation("items")[i].getCells()[3].setProperty("value", "");
							} else {
								tbl.getAggregation("items")[i].getCells()[3].setProperty("visible", false);
								mModelSummary.getProperty("/nPquestionSet")[i].AnswerDesc = "";
							}
						}
					}
				}

			}

		},

		onAddAttachmentNC: function (oEvent) {
			var uploadCollection = oEvent.getSource();
			var that = this;
			var collectionItemArr = uploadCollection.getItems();
			var files = oEvent.getParameter("files");
			var dupfile;

			for (var i = 0; i < collectionItemArr.length; i++) {
				if (collectionItemArr[i].getProperty("fileName") === files[0].name) {
					jQuery.sap.log.error("Duplicate file not allowed");
					sap.m.MessageBox.error("Duplicate filename not allowed", {
						title: "Error", // default
						onClose: null, // default
						styleClass: "", // default
						initialFocus: null, // default
						textDirection: sap.ui.core.TextDirection.Inherit // default
					});

					// UploadCollection.fireUploadTerminated(oEvent.getParameters());
					dupfile = true;
					break;

				}
			}
			if (files[0].size <= 0) {
				sap.m.MessageBox.error("Files with size 0kb not allowed to upload", {
					title: "Error", // default
					onClose: null, // default
					styleClass: "", // default
					initialFocus: null, // default
					textDirection: sap.ui.core.TextDirection.Inherit // default
				});
				oEvent.getSource().abortUpload(oEvent.getParameters());
				return;
			}

			if (dupfile === true) {
				oEvent.getSource().abortUpload(oEvent.getParameters());
				return;
			}

			var uploadUrl = "/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/AR_ATTSet";
			// var uploadUrl = "/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/AR_ATTSet(CompanyCode='" + sValue.CompanyCode + "',RrfNo='" + sValue.RrfNo +
			//  		"',RequestingMf='" + sMFGCC.RequestingMf + "',GlobalCc='" + sMFGCC.GlobalCc + "')";

			uploadCollection.setUploadUrl(uploadUrl);

			var mAttachments = this.getView().getModel();

			var token = "x-cs" + "rf-token";
			mAttachments.refreshSecurityToken();
			var T = mAttachments.getHeaders()[token];

			var csrfToken = new sap.m.UploadCollectionParameter({
				name: token,
				value: T
			});

			var reqType = new sap.m.UploadCollectionParameter({
				name: "X-Requested-With",
				value: "XMLHttpRequest"
			});

			uploadCollection.removeAllHeaderParameters();
			uploadCollection.addHeaderParameter(csrfToken);
			uploadCollection.addHeaderParameter(reqType);

		},
		onBeforeUploadStartsNC: function (oEvent) {
			var sValue = this.getView().getModel("mModelSummary").getProperty("/HeaderDataNC");
			var sMFGCC = this.getView().getModel("mModelSummary").getProperty("/updateRowDataNC");
			sMFGCC.CcShortDesc = "";
			if (sMFGCC.RequestingMf === "N/A") {
				sMFGCC.RequestingMf = "NA";
				sMFGCC.MemberFirm = "";
			}
			if (sMFGCC.GlobalCc === "N/A") {
				sMFGCC.GlobalCc = "NA";
				sMFGCC.CcShortDesc = "";
				// sMFGCC.MemberFirm = sMFGCC.RequestingMf;
			}

			if (!sMFGCC.RequestingMf) {
				sMFGCC.RequestingMf = "NA";
				sMFGCC.MemberFirm = "";
			}

			if (!sMFGCC.GlobalCc) {
				sMFGCC.GlobalCc = "NA";
				sMFGCC.CcShortDesc = "";
				// sMFGCC.MemberFirm = sMFGCC.RequestingMf;
			}

			if (!sMFGCC.ProcessGrp) {
				sMFGCC.ProcessGrp = "";
			}
			var AttachPanelID = "COP";
			var isSpecialChar = this.checkFileNameSepecialchar(oEvent.getParameter("fileName"));
			if (isSpecialChar) {
				var sMsg = this.getView().getModel("i18n").getProperty("specialcharFileNameMsg");
				MessageBox.error(sMsg);
				return;
			}

			var uPloadpar = oEvent.getParameter("fileName") + "|" + sValue.CompanyCode + "|" + sValue.RrfNoGf + "|" + sMFGCC.RequestingMf +
				"|" +
				sMFGCC.ProcessGrp + "|" +
				sMFGCC.GlobalCc + "|" + AttachPanelID + "|" + sMFGCC.MemberFirm + "|" +
				sMFGCC.CcShortDesc;
			// Header Slug
			var oCustomerHeaderSlug = new sap.m.UploadCollectionParameter({
				name: "slug",
				value: uPloadpar
			});

			oEvent.getParameters().addHeaderParameter(oCustomerHeaderSlug);

			if (sMFGCC.RequestingMf === "NA" && sMFGCC.GlobalCc != "NA") {

				sMFGCC.RequestingMf = "N/A";
				sMFGCC.MemberFirm = "";

			}

			if (sMFGCC.GlobalCc === "NA") {
				sMFGCC.GlobalCc = "N/A";
				sMFGCC.CcShortDesc = "";
			}

		},
		handleUploadCompleteNC: function (oEvent) {
			this.fetchAttachmentListNC();
		},
		fetchAttachmentListNC: function () {
			var sValueNC = this.getView().getModel("mModelSummary").getProperty("/HeaderDataNC");
			var sMFGCCNC = this.getView().getModel("mModelSummary").getProperty("/updateRowDataNC");
			if (sMFGCCNC.RequestingMf === "N/A") {
				sMFGCCNC.MemberFirm = "";
			}
			// else {
			// sMFGCC.MemberFirm = sMFGCC.RequestingMf;
			sMFGCCNC.CcShortDesc = "";

			// }
			sap.ui.core.BusyIndicator.show(0);
			var fnSucces = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				this.getView().getModel("mModelSummary").setProperty("/FileNameSetNC", d.results);
				this.getView().getModel("mModelSummary").refresh(true);
				/*Start -  Request Country dropdown was showing wron value after uploading attachment like US:USA instead of only "US' **/
				this.retainRequestCountryVal();
				/*End -  Request Country dropdown was showing wron value after uploading attachment like US:USA instead of only "US' **/

			}, this);

			var fnError = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
			}, this);

			var sPath1 = "/AR_ATTSet";

			var aFilterStr = [];
			var oFilterSerach;
			if (sValueNC.RrfNoGf && sValueNC.CompanyCode && sMFGCCNC.RequestingMf && sMFGCCNC.GlobalCc) {
				/*oFilterSerach = new sap.ui.model.Filter("RrfNoGf", sap.ui.model.FilterOperator.EQ, sValue.RrfNoGf);*/
				oFilterSerach = new sap.ui.model.Filter("RrfNo", sap.ui.model.FilterOperator.EQ, sValueNC.RrfNoGf); /*Changed on 16-Jan-2020*/
				aFilterStr.push(oFilterSerach);
				oFilterSerach = new sap.ui.model.Filter("CompanyCode", sap.ui.model.FilterOperator.EQ, sValueNC.CompanyCode);
				aFilterStr.push(oFilterSerach);
				oFilterSerach = new sap.ui.model.Filter("RequestingMf", sap.ui.model.FilterOperator.EQ, sMFGCCNC.RequestingMf);
				aFilterStr.push(oFilterSerach);
				oFilterSerach = new sap.ui.model.Filter("GlobalCc", sap.ui.model.FilterOperator.EQ, sMFGCCNC.GlobalCc);
				aFilterStr.push(oFilterSerach);
				oFilterSerach = new sap.ui.model.Filter("ProcessGrp", sap.ui.model.FilterOperator.EQ, sMFGCCNC.ProcessGrp);
				aFilterStr.push(oFilterSerach);
				oFilterSerach = new sap.ui.model.Filter("MemberFirm", sap.ui.model.FilterOperator.EQ, sMFGCCNC.MemberFirm);
				aFilterStr.push(oFilterSerach);
				oFilterSerach = new sap.ui.model.Filter("CcShortDesc", sap.ui.model.FilterOperator.EQ, sMFGCCNC.CcShortDesc);
				aFilterStr.push(oFilterSerach);
			}

			// sFilter.push(aFilterStr);
			// var oUrlParams = {

			// };

			// DataManagerARrecharge._getODataARRecharge(sPath1, aFilterStr, oUrlParams, fnSucces, fnError);
			/*R&D---start*/
			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/", {
				json: true
			});
			oModel1.read("/AR_ATTSet", {
				filters: aFilterStr,
				success: fnSucces,
				error: fnError
			});
			/*R&D---end*/

		},

		handleTypeMissmatch: function (oEvent) {
			var aFileTypes = oEvent.getSource().getFileType();
			jQuery.each(aFileTypes, function (key, value) {
				aFileTypes[key] = "*." + value;
			});
			var sSupportedFileTypes = aFileTypes.join(", ");
			MessageToast.show("The file type *." + oEvent.getParameter("fileType") +
				" is not supported. Choose one of the following types: " +
				sSupportedFileTypes);
		},
		onDeleteAttachmentNC: function (oEvent) {
			var oModelAttachments = this.getView().getModel("mModelSummary");
			var sValue = this.getView().getModel("mModelSummary").getProperty("/HeaderDataNC");
			var sMFGCC = this.getView().getModel("mModelSummary").getProperty("/updateRowDataNC");
			var sMf;
			var sPrGrp;
			if (oEvent.getParameter("item").getProperty("fileName")) {
				var fileName = oEvent.getParameter("item").getProperty("fileName").replace(/\s/g, "*");
				var ofileName1 = fileName;
				var forwardslashFile = /[/]+/;
				if (forwardslashFile.test(ofileName1)) {
					ofileName1 = ofileName1.replace(/[/]/g, "|");
				}
				var qQuestionCharFile = /[?]+/;
				if (qQuestionCharFile.test(ofileName1)) {
					ofileName1 = ofileName1.replace(/[?]/g, "(");
				}
				var pPercentageFile = /[%]+/;
				if (pPercentageFile.test(ofileName1)) {
					ofileName1 = ofileName1.replace(/[%]/g, ")");
				}
			}

			if (sMFGCC.RequestingMf === "N/A") {
				sMFGCC.RequestingMf = "NA";
				sMFGCC.MemberFirm = "";
				sMf = sMFGCC.MemberFirm = "";
			}
			if (sMFGCC.MemberFirm) {
				sMf = sMFGCC.MemberFirm.replace(/\s/g, "*");
				/*Start of change for INC01584421 by developer Prashant kumar on 22-June-2021*/
				var forwardslashMmfirm = /[/]+/;
				if (forwardslashMmfirm.test(sMf)) {
					sMf = sMf.replace(/[/]/g, "|");
				}
				var qQuestionCharMemFm = /[?]+/;
				if (qQuestionCharMemFm.test(sMf)) {
					sMf = sMf.replace(/[?]/g, "(");
				}
				var pPercentageMF = /[%]+/;
				if (pPercentageMF.test(sMf)) {
					sMf = sMf.replace(/[%]/g, ")");
				}

			} else if (sMFGCC.MemberFirm === "") {
				sMf = sMFGCC.MemberFirm;
			}
			if (sMFGCC.ProcessGrp) {
				sPrGrp = sMFGCC.ProcessGrp.replace(/\s/g, "*");
				/*Start of change for INC01584421 by developer Prashant kumar on 22-June-2021*/
				var forwardslash = /[/]+/;
				if (forwardslash.test(sPrGrp)) {
					sPrGrp = sPrGrp.replace(/[/]/g, "|");

				}
				var qQuestionChar = /[?]+/;
				if (qQuestionChar.test(sPrGrp)) {
					sPrGrp = sPrGrp.replace(/[?]/g, "(");
				}
				var pPercentage = /[%]+/;
				if (pPercentage.test(sPrGrp)) {
					sPrGrp = sPrGrp.replace(/[%]/g, ")");
				}

			}
			if (!sMFGCC.ProcessGrp && sMFGCC.GlobalCc) {
				sMFGCC.ProcessGrp = "";
				sPrGrp = sMFGCC.ProcessGrp;
			}
			if (sMFGCC.GlobalCc === "N/A") {
				sMFGCC.GlobalCc = "NA";
				sMFGCC.CcShortDesc = "";
			}

			//Attachment to delete
			var selectedAttachment = oEvent.getParameter("documentId");

			//Update Attachment list in Front End
			var attachmentArray = oModelAttachments.getProperty("/FileNameSetNC");
			for (var i = 0; i < attachmentArray.length; i++) {
				if (attachmentArray[i].Filename === selectedAttachment) {
					attachmentArray.splice(i, 1);
					break;
				}
			}
			oModelAttachments.setProperty("/FileNameSetNC", attachmentArray);

			//Backend DELETE POST call queued
			/*Start of change on 16-Jan-2020*/
			/*	var sPath = "/sap/opu/odata/kgo/FI_AR_RECHARGE_RRF_SRV/AR_ATTSet(CompanyCode='" + sValue.CompanyCode + "',RrfNoGf='" + sValue.RrfNoGf +
					"',RequestingMf='" + sMFGCC.RequestingMf + "',GlobalCc='" + sMFGCC.GlobalCc + "')";*/
			var sPath = "/AR_ATTSet(CompanyCode='" + sValue.CompanyCode + "',RrfNo='" + sValue.RrfNoGf +
				"',RequestingMf='" + sMFGCC.RequestingMf + "',MemberFirm='" + sMf + "',ProcessGrp='" + sPrGrp +
				"',GlobalCc='" + sMFGCC.GlobalCc + "',CcShortDesc='" + sMFGCC.CcShortDesc + "',CopLoa='" +
				"COP" + "',Filename='" + ofileName1 + "')";

			if (sMFGCC.RequestingMf === "NA" && sMFGCC.GlobalCc != "NA") {
				sMFGCC.RequestingMf = "N/A";
			}
			if (sMFGCC.GlobalCc === "NA") {
				sMFGCC.GlobalCc = "N/A";
			}

			/*End of change on 16-Jan-2020*/
			var fnUpdSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide();
				this.getView().getModel("mModelSummary").refresh(true);
				this.retainRequestCountryVal();

			}, this);
			var fnUpdError = jQuery.proxy(function (d) {

				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();

				MessageToast.show(r, {
					autoClose: true,
					width: "20rem"
				});

			}, this);
			var _oObject = {};
			_oObject.successCallback = fnUpdSuccess;
			_oObject.errorCallback = fnUpdError;
			_oObject.sPath = sPath;
			DataManagerARrecharge._deleteOData(_oObject);

		},
		retainRequestCountryVal: function () {
			/*Start -  Request Country dropdown was showing wron value after uploading attachment like US:USA instead of only "US' **/
			var reqCountry = this.getView().getModel("mModelSummary").getProperty("/updateRowDataNC").RequestingMf;
			this.getView().getModel("mModelSummary").setProperty("/SelcKeySet", reqCountry);
			var rrfTablefragmentNonCoupa = this.getView().createId("rrfTablefragmentNonCoupa");
			var oReqCountry = this.byId(sap.ui.core.Fragment.createId(rrfTablefragmentNonCoupa, "contryDrdwIdNC"));
			if (oReqCountry) {
				oReqCountry.setSelectedKey(reqCountry);
				oReqCountry.getSelectedItem().setText(reqCountry);
			}
			/*End -  Request Country dropdown was showing wron value after uploading attachment like US:USA instead of only "US' **/
		},

		handleValueChange: function (oEvent) {
			MessageToast.show("Press 'Upload File' to upload file '" +
				oEvent.getParameter("newValue") + "'");
		},
		/*End of Change for attachment section on 26-Dec-2019 by Satabdi Das */
		/*Start of change on 01-Jan-2020*/

		onOccurNC: function (oEvent) {
			var rrfTablefragmentNonCoupa = this.getView().createId("rrfTablefragmentNonCoupa");
			var value = oEvent.getParameter("value");
			if (isNaN(value) === true) {
				var label1 = sap.ui.core.Fragment.byId(rrfTablefragmentNonCoupa, "occurBill");
				var label2 = sap.ui.core.Fragment.byId(rrfTablefragmentNonCoupa, "occurJV");
				if (label1 !== undefined) {
					label1.setValue("");
					if (label2 !== undefined) {
						label2.setValue("");
					}
				} else if (label2 !== undefined) {
					label2.setValue("");
				}
			}
		},
		/*End of change 01-Jan-2020*/
		/*Start of change on 02-Jan-2020*/
		checkPercY: function (oEvent) {
			if (isNaN(oEvent.getParameter("value")) === true || (oEvent.getParameter("value") > 100)) {
				this.getView().getModel("mModelSummary").setProperty("/updateRowDataNC/PercY", "");
				this.getView().getModel("mModelSummary").refresh(true);
			}
		},
		onCheckBoxSelectNC: function (oEvent) {
			// if (this.getModel("mModelSummary").getProperty("/oEditableNC/visibleForDisplyGf") === false) {
			// 	this.getView().getModel("mModelSummary").setProperty("/oEditableNC/checkBox", true);
			if (oEvent.getParameter("selected") === true) {
				this.getView().getModel("mModelSummary").setProperty("/oEditableNC/entityAddress", false);
				this.getView().getModel("mModelSummary").setProperty("/oEditableNC/entityName", true);
				this.getView().getModel("mModelSummary").setProperty("/updateRowDataNC/EntityAddress", "");
				this.getView().getModel("mModelSummary").setProperty("/updateRowDataNC/EntityName", "");
				this.getView().getModel("mModelSummary").setProperty("/updateRowDataNC/SapCodeMf", ""); /*Added on 21-Jan-2020*/
				this.getView().getModel("mModelSummary").setProperty("/updateRowDataNC/NewEntity", "X"); /*Added on 21-Feb-2020 by Satabdi Das*/
			} else {
				this.getView().getModel("mModelSummary").setProperty("/oEditableNC/entityAddress", true);
				this.getView().getModel("mModelSummary").setProperty("/oEditableNC/entityName", false);
				this.getView().getModel("mModelSummary").setProperty("/updateRowDataNC/EntityAddress", "");
				this.getView().getModel("mModelSummary").setProperty("/updateRowDataNC/EntityName", "");
				this.getView().getModel("mModelSummary").setProperty("/updateRowDataNC/SapCodeMf", ""); /*Added on 21-Jan-2020*/
				this.getView().getModel("mModelSummary").setProperty("/updateRowDataNC/NewEntity", ""); /*Added on 21-Feb-2020 by Satabdi Das*/
			}
			// } else {
			// 	this.getView().getModel("mModelSummary").setProperty("/oEditableNC/checkBox", false);
			// 	this.getView().getModel("mModelSummary").setProperty("/oEditableNC/entityAddress", false);
			// 	this.getView().getModel("mModelSummary").setProperty("/oEditableNC/entityName", false);
			// }
		},
		/*End of change on 02-Jan-2020*/
		/*Start of change on 06-Jan-2020*/
		onSelectCurrency: function (oEvent) {
			var currencyKey = oEvent.getParameter("selectedItem").getProperty("key");
			this.getView().getModel("mModelSummary").setProperty("/HeaderData/Currency", currencyKey);
		},
		onSelectNatureOfServiceNP: function (oEvent) {
			var mModelSummary = this.getView().getModel("mModelSummary");
			var text = oEvent.getSource().getSelectedItem().getProperty("text");

			if (text === "Continuous") {
				mModelSummary.setProperty("/oEditableNC/lastservdateNP", false);
				mModelSummary.setProperty("/oEditableNC/lastDateOfServLabelNP", false);

				mModelSummary.setProperty("/updateRowDataNC/LastDateSrv", "");

			}
			if (text === "Adhoc/One-Off") {
				mModelSummary.setProperty("/oEditableNC/lastservdateNP", true);
				mModelSummary.setProperty("/oEditableNC/lastDateOfServLabelNP", true);
			}
		},
		onChangeNatureofServiceNP: function (oEvent) {
			var mModelSummary = this.getView().getModel("mModelSummary");
			var text = mModelSummary.getProperty("/updateRowDataNC").NatureOfService;
			switch (text) {
			case "Continuous":
				mModelSummary.setProperty("/oEditableNC/lastservdateNP", false);
				mModelSummary.setProperty("/oEditableNC/lastDateOfServLabelNP", false);
				break;
			case "Adhoc/One-Off":
				mModelSummary.setProperty("/oEditableNC/lastservdateNP", true);
				mModelSummary.setProperty("/oEditableNC/lastDateOfServLabelNP", true);
				break;
			}

		},
		onSlcYnCOP: function (oEvent) {
			var value = oEvent.getParameter("value");
			if (value === "Y" || value === "N") {
				if (value === "N") {
					this.getView().getModel("mModelSummary").setProperty("/oEditableNC/PercY", false);
					this.getView().getModel("mModelSummary").setProperty("/updateRowDataNC/PercY", ""); /*Added on 07-Jan-2020*/
				} else {
					this.getView().getModel("mModelSummary").setProperty("/oEditableNC/PercY", true);
				}
				this.getView().getModel("mModelSummary").setProperty("/updateRowDataNC/WhTax", value);
				this.getView().getModel("mModelSummary").refresh(true);
			} else {
				this.getView().getModel("mModelSummary").setProperty("/updateRowDataNC/WhTax", "");
				this.getView().getModel("mModelSummary").setProperty("/oEditableNC/PercY", true);
				this.getView().getModel("mModelSummary").refresh(true);
			}
		},
		checkExpandNonCoupa: function (oEvent) {

			if ((oEvent.getParameter("expand") === true)) {
				var CheckTextNC = this.getView().getModel("mModelSummary").getProperty("/setLineItemText");
				var checkMandatoryNC = this.getView().getModel("mModelSummary").getProperty("/updateRowDataNC");
				switch (CheckTextNC) {
				case "Add Member Firm":
					if ((!checkMandatoryNC.RequestingMf || !checkMandatoryNC.ProcessGrp)) {
						oEvent.getSource().setProperty("expanded", false);
						var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
						MessageBox.alert(
							"Please enter mandatory fields first ", {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}
						);
					} else {
						oEvent.getSource().setProperty("expanded", true);
					}
					break;
				case "Add Global Function":

					if ((!checkMandatoryNC.GlobalCc || !checkMandatoryNC.Ltext)) {

						oEvent.getSource().setProperty("expanded", false);
						var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
						MessageBox.alert(
							"Please enter mandatory fields first ", {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}
						);
					} else {
						oEvent.getSource().setProperty("expanded", true);
					}

					break;

				}
			}

		},

		/*End of change on 06-Jan-2020*/

		checkNetAmt: function (oEvent) {
			if (isNaN(oEvent.getSource().getValue()) === true || (oEvent.getSource().getValue() > 999999999999.999)) {
				oEvent.getSource().setValue("");
			}
		},
		checkSeqNum: function (oEvent) {
			if (isNaN(oEvent.getSource().getValue()) === true || (oEvent.getSource().getValue() > 999)) {
				oEvent.getSource().setValue("");
			}
		},
		onTypingMf: function (oEvent) {
			var mModelSummary = this.getView().getModel("mModelSummary");
			var checkString = oEvent.getParameter("value");

			if (checkString != "") {
				if (/[^A-Za-z\d]/.test(checkString) || isNaN(checkString) === false || /\d/.test(checkString)) {
					this.getView().getModel("mModelSummary").setProperty("/SelcKeySet", "");
					this.getView().getModel("mModelSummary").setProperty("/updateRowDataNC/MemberFirmD", "");
				}
			}
			mModelSummary.setProperty("/SelcKeySet", mModelSummary.getProperty("/updateRowDataNC").RequestingMf);
		},
		onUpdateFinish: function (oEvent) {
			var rowElement = oEvent.getSource().getAggregation("items");
			var objDate1, objDate2, sDocNum, objSeqNum, objAmt;
			if (rowElement.length > 0) {
				for (var i = 0; i < rowElement.length; i++) {
					objDate1 = rowElement[i].getAggregation("cells")[4].getDomRef();
					if (objDate1) {
						objDate1.firstElementChild.firstChild.setAttribute("readonly", true);
					}
					objDate2 = rowElement[i].getAggregation("cells")[5].getDomRef();
					if (objDate2) {
						objDate2.firstElementChild.firstChild.setAttribute("readonly", true);
					}
					sDocNum = rowElement[i].getAggregation("cells")[7].getText();
					if (sDocNum !== "") {
						objSeqNum = rowElement[i].getAggregation("cells")[3].getDomRef();
						objAmt = rowElement[i].getAggregation("cells")[6].getDomRef();
						if (objSeqNum) {
							objSeqNum.firstElementChild.firstChild.setAttribute("readonly", true);
						}
						if (objAmt) {
							objAmt.firstElementChild.firstChild.setAttribute("readonly", true);
						}
						rowElement[i].getMultiSelectControl().setEnabled(false);
					}
				}
			}
		},
		onLocationServEnterNC: function (oEvent) {
			var checkString = oEvent.getParameter("value");
			if (checkString != "") {
				if (/[^A-Za-z\d]/.test(checkString) || isNaN(checkString) === false || /\d/.test(checkString)) {
					this.getView().getModel("mModelSummary").setProperty("/updateRowDataNC/LocationOfTheServicesReq", "");
				}
			}
		},
		onPressScTaskNC: function (oEvent) {
			var sLinItemLinkNC = oEvent.getSource().getBindingContext("mModelSummary").getObject();
			window.open(sLinItemLinkNC.CopSctaskLink, '_blank');
		},
		onLoaSctaskPress: function (oEvent) {
			var sLinLOANC = oEvent.getSource().getBindingContext("mModelSummary").getObject();
			window.open(sLinLOANC.LoaSctaskLink, '_blank');
		},

		getRemainingCharLineItem: function (value, maxLength) {

			var remainingLength = maxLength;
			if (value && value !== "") {
				var charLength = value.length;
				remainingLength = maxLength - charLength;
			}
			return remainingLength + " characters remaining";
		},
		//changes for COP REset new CR on 27.08.2021
		OnResetPressNP: function (oEvent) {
			var mModelSummary = this.getView().getModel("mModelSummary");
			var oPressReSetButtonPress = true;
			this.oRestVal = oPressReSetButtonPress;
			// var tableData = mModelSummary.getProperty("/TableItemSetNC").results;
			// var _TableArrya = jQuery.extend({}, tableData);
			// mModelSummary.setProperty("/TableItemSetNC_Old/results", _TableArrya);
			var updateRowDataNC = mModelSummary.getProperty("/updateRowDataNC");
			var tempArr = jQuery.extend({}, updateRowDataNC);
			mModelSummary.setProperty("/updateRowDataNC_Old", tempArr);
			mModelSummary.setProperty("/oEditableNC/editLineItemCop", true);
			//this.byId(sap.ui.core.Fragment.createId("rrfTablefragmentNonCoupa", "ContactPersonLOAId")).setEditable(true);
			// mModelSummary.setProperty("/updateRowDataNC/ConfYn_old", mModelSummary.getProperty("/updateRowDataNC/ConfirmationOfParticipation"));
			// mModelSummary.setProperty("/updateRowDataNC/CopYesDate_old", mModelSummary.getProperty("/updateRowDataNC/CopYesDate"));
			// mModelSummary.setProperty("/updateRowDataNC/ServNowCop_old", mModelSummary.getProperty("/updateRowDataNC/ServiceNowCop"));
			// mModelSummary.setProperty("/updateRowDataNC/ServNowStatus_old", mModelSummary.getProperty("/updateRowDataNC/ServNowStatus"));
			mModelSummary.setProperty("/updateRowDataNC/ConfirmationOfParticipation", "");
			mModelSummary.setProperty("/updateRowDataNC/CopYesDate", "");
			mModelSummary.setProperty("/updateRowDataNC/ServiceNowCop", "");
			mModelSummary.setProperty("/updateRowDataNC/ServNowStatus", "");
			mModelSummary.setProperty("/updateRowDataNC/ServiceNowLoa", "");

		},
		handleLiveLongTextNC: function (event) {
			var maxCharLimit = event.getSource().getProperty("maxLength");
			var longText = event.getParameters().value;
			if (longText.length > maxCharLimit) {
				event.getSource().setValue(longText.substring(0, maxCharLimit));
			} else {
				event.getSource().setValue(longText);
			}
		},
		onUpdateAuthSignatoryPressNC: function (oEvent) {
			var mModelSummary = this.getModel("mModelSummary");
			var oLineItemData = mModelSummary.getProperty("/updateRowDataNC");
			var coonoFoundmsg = this.getModel("i18n").getProperty("coonoFound");
			var authUpdatemsg = this.getModel("i18n").getProperty("authUpdatemsg");
			//sap.ui.core.BusyIndicator.show(0);
			var oModel1 = this.getOwnerComponent().getModel();
			oModel1.callFunction(
				"/fnCOOName", {
					method: "GET",
					urlParameters: {
						"MemberFirm": oLineItemData.RequestingMf,
						"EntityName": oLineItemData.EntityName,
						"SapCustomerNumber": oLineItemData.SapCodeMf,
						"MemberFirmD": oLineItemData.MemberFirm

					},
					success: function (oData, response) {

						if (!oData.CooName) {

							MessageBox.alert(coonoFoundmsg);
							return;
						} else {
							mModelSummary.setProperty("/updateRowDataNC/LoaContact", oData.CooName);
							mModelSummary.setProperty("/updateRowDataNC/LoaEmail", oData.CooEmailId);
							MessageBox.success(authUpdatemsg);
						}

						mModelSummary.refresh(true);

					},
					error: function (oError) {

					}
				});

		}
	});
});