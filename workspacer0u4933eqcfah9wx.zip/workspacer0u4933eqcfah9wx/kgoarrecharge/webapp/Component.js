sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"kgo/ARRecharge/model/models",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/HashChanger",
	'sap/m/MessageBox'
], function (UIComponent, Device, models, JSONModel, HashChanger, MessageBox) {
	"use strict";

	return UIComponent.extend("kgo.ARRecharge.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function () {
			// call the base component's init function

			HashChanger.getInstance().replaceHash("");
			UIComponent.prototype.init.apply(this, arguments);
		

			// $(window).bind("beforeunload", function (e) {
			// 	var message="Are you sure you want to leave this page ?";
			// 	e.returnValue=message;
			// 	return message;

			// });
			// enable routing
			this.getRouter().initialize();

			// set the device model
			this.setModel(models.createDeviceModel(), "device");
			var mModelSummary = new JSONModel({});
			mModelSummary.setDefaultBindingMode("TwoWay");

			this.setModel(mModelSummary, "mModelSummary");
			this.getModel("mModelSummary").setProperty("/HeaderData", []);
			this.getModel("mModelSummary").setProperty("/ContrlerEmailSet", []);
			this.getModel("mModelSummary").setProperty("/PoSectionSet", []);
			this.getModel("mModelSummary").setProperty("/PoTableSet", []);
			this.getModel("mModelSummary").setProperty("/copPoLineItemSet", []);
			this.getModel("mModelSummary").setProperty("/copPoTableSet", []);
			this.getModel("mModelSummary").setProperty("/oLinePoTableSet", []);
			this.getModel("mModelSummary").setProperty("/oLinePoTableSetTemp", []);
			this.getModel("mModelSummary").setProperty("/SelcKeySet");
			this.getModel("mModelSummary").setProperty("/filterSearch");
			this.getModel("mModelSummary").setProperty("/CostScnterSearchSet", []);
			this.getModel("mModelSummary").setProperty("/FileHeaderSet", []);
			this.getModel("mModelSummary").setProperty("/RestCCSearchSet", []); /*Added for 63648 by Satabdi Das on 03-+March-2021*/
			this.getModel("mModelSummary").setProperty("/RestCCSearchSetNP", []); /*Added for 63648 by Satabdi Das on 03-+March-2021*/
			// Start of change by Debraj Manna Date - 11/7/2019
			this.getModel("mModelSummary").setProperty("/HeaderDataNC", []); // Change Done by Debraj Manna Date - 11/7/2019
			this.getModel("mModelSummary").setProperty("/updateRowDataNC", []);
			this.getModel("mModelSummary").setProperty("/updateRowDataNC/BillSch", []);
			this.getModel("mModelSummary").setProperty("/TableItemSetNC", []);
			this.getModel("mModelSummary").setProperty("/TableItemSetNC/results", []);
			// End of change by Debraj Date - 11/7/2019
			this.getModel("mModelSummary").setProperty("/RRF_SH", []);
			this.getModel("mModelSummary").setProperty("/GF_SH", []);
			this.getModel("mModelSummary").setProperty("/GF_AddNew", []);
			this.getModel("mModelSummary").setProperty("/EntitySet", []); /*Added by Satabdi Das on 04-Dec-2019*/
			this.getModel("mModelSummary").setProperty("/questionSetSubmit", []);       /*Added by prashant  on 14-march-2021*/
			this.getModel("mModelSummary").setProperty("/nPQuestionSetSubmit", []); /*Added by prashant  on 14-march-2021*/
			// Start of change by Debraj Manna Date - 11/11/2019
			this.getModel("mModelSummary").setProperty("/NonCopaHdrLbl", "");
			this.getModel("mModelSummary").setProperty("/NonCopaAppTitle", "");
			// End of change by Debraj Manna Date - 11/11/2019
			// this.getModel("mModelSummary").setProperty("/copaLabelName", "");
			this.getModel("mModelSummary").setProperty("/displayMode", false); /*Added by Saptarshi on 22-Nov-2019*/
			this.getModel("mModelSummary").setProperty("/GblFuncName", false); /*Added 13-Jan-2020*/
			this.getModel("mModelSummary").setProperty("/BillEnable", true); /*Added 19-May-2020*/
			this.getModel("mModelSummary").setProperty("FileNameSetNC", []); /*Added by Satabdi on 26-Dec-2019*/
			this.getModel("mModelSummary").setProperty("/LtextSearch", false);
			this.getModel("mModelSummary").setProperty("/CostScnterSearchSetNP", []);
			this.getModel("mModelSummary").setProperty("/Bukrs9921", true); /*Added by Satabdi Das on 26-Nov-2020*/
			this.getModel("mModelSummary").setProperty("/Bukrs9901", true); /*Added by Satabdi Das on 26-Nov-2020*/
			this.getModel("mModelSummary").setProperty("/TRFOwnerFlag", false);
			this.getModel("mModelSummary").setProperty("/TRFOwnerFlagNP", false);
			var myJason = {
				"editHeaderItem": true,
				"editInformationItem": false,
				"editLineItemCop": true,
				"editLineItemMF": true,
				"editPercy": true,
				"editLineItemLOA": true,
				"visibleforMF": true,
				"visibleforGF": true,
				"additionalFieldBrf": true,
				"editMode": true,
				"contractNbr": true,
				"visibleForEdit": true,
				"visibleForDisply": true,
				/*20-Nov*/
				"visibleForcntrlEmail": false,
				"checkBox": true,
				/*Added on 27-Jan-2020*/
				"coomercialRow": true,
				"vBoxVisibleForCop": true,
				"enableCOP": false,
				"enableLOA": false,
				"attachVisible": false,
				"attachmentEnable": false,
				"attachmentDelete": true,
				"attchmentExpnded": false,
				"DeleteEnabPO": true,
				"lastsrvDate": false,
				"lastDateOfServLabel": false,
				"contractAttachEnable": false,
				"visibleforCC": true,
				"editCommercialSection": false,
				"suppEdit": true,
				"requMfvisible": false, //added on 14.08.2020 by prashant
				"rmdropDown": false,
				"questionPnVisiblePO": false,
				"gpDetailEdit":true,
				"reSetButtonEnable":false

				/*"entityName":false,
				"entityAddress":true*/

			};

			this.getModel("mModelSummary").setProperty("/oEditable", myJason);

			// Start of change by Debraj Date - 11/7/2019
			var myJasonNC = {

				"editHeaderItem": true,
				"editInformationItem": false,
				"editLineItemCop": true,
				"editLineItemMF": true,
				"editLineItemLOA": true,
				"editLineItemBillSch": true,
				"editLineItemAddInf": true,
				"editLineItemAddInfJV": true,
				"visibleforMF": true,
				"visibleforBillSch": true,
				"visibleforGF": true,
				"visibleForcntrlEmail": false,
				"editMode": true,
				"visibleForEditGf": true,
				"visibleForDisplyGf": true,
				/*14-Nov*/
				"checkBox": true,
				/*Added on 17-Jan-2020*/
				"billFields": true,
				/*Added on 17-Jan-2020*/
				"Occurence": true,
				/*14-Nov*/
				"LineItemBill": true,
				/*Added on 18-Dec-2019*/
				"LineItemJV": true,
				/*Added on 18-Dec-2019*/
				"enableCOP": false,
				/*Added on 26-Dec-2019*/
				"enableLOA": false,
				/*Added on 26-Dec-2019*/
				"attachVisibleNC": false,
				"attachAddButton": false,
				/*Changed on 9th-APR-2020 */
				"deleteBtnAttchment": true,
				"attchmentExpndedNC": false,
				"NoDocNum": true,
				/*Added on 29-APR-2020*/
				"DeleteEnaNP": true,
				"lastservdateNP": false,
				"lastDateOfServLabelNP": false,
				"companyCodeEdit": true, //added on 14.08.2020 by prashant
				"costCenterEdit": true, //added on 14.08.2020 by prashant
				"requMfvisibleNP": false,
				"rmdropDownNP": false,
				"questionPnVisibleNP": false,
				"reSetButtonEnableNP":false

			};
			this.getModel("mModelSummary").setProperty("/oEditableNC", myJasonNC);
			// End of change by Debraj Date - 11/7/2019

		}
	});
});