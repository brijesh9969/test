sap.ui.define([
	"kgo/ARRecharge/test/unit/controller/HomeView.controller"
], function () {
	"use strict";
});