sap.ui.controller("kno.em.billsrch.germany.ext.controller.ListReportExt", {
	onBeforeRendering: function () {

		// this.getView().byId("ActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP1button").setVisible(false);
		// this.getView().byId("ActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP2button").setVisible(false);
		//  this.getView().byId("ActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP3button").setVisible(false);
		// this.getView().byId("ActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP4button").setVisible(false);
		// this.getView().byId("ActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP5button").setVisible(false);
		// this.getView().byId("ActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP6button").setVisible(false);
		// this.getView().byId("ActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP7button").setVisible(false);
		// this.getView().byId("ActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP9button").setVisible(false);
		// this.getView().byId("ActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP10button").setVisible(false);
		// this.getView().byId("ActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP11button").setVisible(false);
		// this.getView().byId("ActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP12button").setVisible(false);
		// this.getView().byId("ActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP13button").setVisible(false);
		// this.getView().byId("ActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP14button").setVisible(false);
		// this.getView().byId("ActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP15button").setVisible(false);
		// this.getView().byId("ActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP16button").setVisible(false);
		// this.getView().byId("ActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP17button").setVisible(false);
		// this.getView().byId("ActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP18button").setVisible(false);
		// this._canInv = false;

		if (this.getOwnerComponent().getProperty("appComponent").getComponentData() && this.getOwnerComponent().getProperty("appComponent").getComponentData()
			.startupParameters && jQuery.isEmptyObject(this.getOwnerComponent().getProperty("appComponent").getComponentData().startupParameters) ===
			false) {
			var sParam = this.getOwnerComponent().getProperty("appComponent").getComponentData().startupParameters.ZACTION[0];

			switch (sParam) {
			case "ZCANCEL":
				this._canInv = true;
				this.getView().byId("ActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP1button").setVisible(true);
				this.getView().byId("ActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP2button").setVisible(true);
				this.getView().byId("ActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP16button").setVisible(true);
				this.getView().byId("ActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP17button").setVisible(true);
				break;
			case "ZCNOTE":
				this.getView().byId("ActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP3button").setVisible(true);
				this.getView().byId("ActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP4button").setVisible(true);
				this.getView().byId("ActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP13button").setVisible(true);
				this.getView().byId("ActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP15button").setVisible(true);
				break;
			case "ZATTACH":
				this.getView().byId("ActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP6button").setVisible(true);
				break;
			case "ZTEXT":
				this.getView().byId("ActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP5button").setVisible(true);
				this.getView().byId("ActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP6button").setVisible(true);
				break;
			case "ZBRE":
				this.getView().byId("ActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP7button").setVisible(true);
				this.getView().byId("ActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP5button").setVisible(true);
				this.getView().byId("ActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP6button").setVisible(true);
				this.getView().byId("ActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP14button").setVisible(true);
				this.getView().byId("ActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP18button").setVisible(true);
				break;
			case "ZPRINT":
				this.getView().byId("ActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP9button").setVisible(true);
				this.getView().byId("ActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP10button").setVisible(true);
				//this.getView().byId("ActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP11button").setVisible(true);
				//this.getView().byId("ActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP12button").setVisible(true);
				var oTable = this.getView().byId("ActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP9button").getParent().getParent().getTable();
				if (oTable) {
					oTable.setProperty("mode", "MultiSelect");
				}
				break;
			default:
			}

		}

	},

	onAfterRendering: function () {

		//this.getView().getModel().attachEventOnce("batchRequestSent", this.onBatchComplete, this); //By PP

		var oSearchButtonid = $("button[id*='Share']");
		this.getView().byId(oSearchButtonid[0].id).setVisible(false);
		var oBasicSearchid = $("input[id*='btnBasicSearch']")[0];
		var oTextResource = this.getView().getModel("i18n").getResourceBundle();
		var sSearchPlaceHolder = oTextResource.getText("SEARCH_PLACEHOLDER");
		oBasicSearchid.placeholder = sSearchPlaceHolder;
		if (this.getOwnerComponent().getProperty("appComponent").getComponentData() && this.getOwnerComponent().getProperty("appComponent").getComponentData()
			.startupParameters && jQuery.isEmptyObject(this.getOwnerComponent().getProperty("appComponent").getComponentData().startupParameters) ===
			false) {
			var sParam = this.getOwnerComponent().getProperty("appComponent").getComponentData().startupParameters.ZACTION[0];

		}

		var that = this;

		var oMySmartFilterTab = this.getView().byId("listReport");
		that = this;
		/*Add style class to the page*/
		jQuery.sap.delayedCall(1000, this, function () {
			var olistReport = this.getView().byId(
				"kno.em.billsrch.germany::sap.suite.ui.generic.template.ListReport.view.ListReport::xKNOxEM_D_DI_C_Y_BILL_CONSUMP--page");
			if (olistReport) {
				olistReport.getParent().addStyleClass("knoBillSearchGlobal");
				olistReport.addStyleClass("knoBillSearchListRpt");
			}
		});

		/*start of change by Satabdi Das*/
		that.onTableRebind();
		// oMySmartFilterTab.attachEvent("beforeRebindTable", that.onTableRebind, that);

		/*End of change by Satabdi Das*/

		$(document).keyup(function (e) {
			if (e.keyCode === 13) {
				if (sParam === "ZCANCEL" || sParam === "ZCNOTE" || sParam === "ZBRE") {
					//				that.getView().getModel().attachEventOnce("batchRequestSent", that.onBatchComplete, that); //By PP
				}
			}
		});

		try {
			if (sParam === "ZCANCEL" || sParam === "ZCNOTE" || sParam === "ZBRE") {
				var oGoButtonid = $("button[id*='btnGo']")[0].id;

				var oGoButton = this.getView().byId(oGoButtonid);

				oGoButton.addEventDelegate({
					ontap: function () {
						//					this.getView().getModel().attachEventOnce("batchRequestSent", this.onBatchComplete, this); //By PP	
					}
				}, this);
			}
		} catch (e) {}

		//Attach Event For Zuzzy Search		

		var sBtnBasicSearchId =
			"kno.em.billsrch.germany::sap.suite.ui.generic.template.ListReport.view.ListReport::xKNOxEM_D_DI_C_Y_BILL_CONSUMP--listReportFilter-btnBasicSearch";
		this.AddEvent(sBtnBasicSearchId);

		//Attach Event For Other Buttons
		// var sBtnGoFilter =
		// 	"kno.em.billsrch.germany::sap.suite.ui.generic.template.ListReport.view.ListReport::xKNOxEM_D_DI_C_Y_BILL_CONSUMP--listReportFilter-btnGoFilterDialog";
		// this.AddEvent(sBtnGoFilter);

		// var sBtnCancelFilter =
		// 	"kno.em.billsrch.germany::sap.suite.ui.generic.template.ListReport.view.ListReport::xKNOxEM_D_DI_C_Y_BILL_CONSUMP--listReportFilter-btnCancelFilterDialog";
		// this.AddEvent(sBtnCancelFilter);

		// var sBtnOkAddDialog =
		// 	"kno.em.billsrch.germany::sap.suite.ui.generic.template.ListReport.view.ListReport::xKNOxEM_D_DI_C_Y_BILL_CONSUMP--listReportFilter-btnOKAddRemoveDialog";
		// this.AddEvent(sBtnOkAddDialog);

		// var sBtnCancelAddFilter =
		// 	"kno.em.billsrch.germany::sap.suite.ui.generic.template.ListReport.view.ListReport::xKNOxEM_D_DI_C_Y_BILL_CONSUMP--listReportFilter-btnCancelAddRemoveDialog";
		// this.AddEvent(sBtnCancelAddFilter);

		// var sBtnFilter =
		// 	"kno.em.billsrch.germany::sap.suite.ui.generic.template.ListReport.view.ListReport::xKNOxEM_D_DI_C_Y_BILL_CONSUMP--listReportFilter-btnFilters";
		// this.AddEvent(sBtnFilter);
	},

	AddEvent: function (sID) {

		try {
			var oBtn = this.getView().byId(sID);
			if (oBtn) {
				oBtn.addEventDelegate({
					ontap: function () {
						//		this.getView().getModel().attachEventOnce("batchRequestSent", this.onBatchComplete, this); //By PP
					}
				}, this);

			}
		} catch (e) {}
	},
	onTableRebind: function (oControlEvent) {

		var sParam = this.getOwnerComponent().getProperty("appComponent").getComponentData().startupParameters;
		var FilterDone = true;
		/*Below line for Lenght commented by Satabdi Das*/
		// var Length = oControlEvent.getParameter("bindingParams").filters.length;
		// if (Length > 0) {
		// 	if (sParam === "ZPRINT") {
		// 		var FilterDone = true;	
		// 	} 
		// 	else {
		// 	var TabFiltersNew = oControlEvent.getParameter("bindingParams").filters;
		// //Begin of change on 25/3/2019
		// 	var TabLength = TabFiltersNew[0].aFilters.length;

		// if (TabLength > 1) {
		//   	for (var mCnt = 0; mCnt < TabLength; mCnt++) {
		//       	var FilterValue = TabFiltersNew[0].aFilters[mCnt].aFilters[0].sPath;

		// 			if ( FilterValue === 'EngNum' ||  FilterValue === 'Partner'
		// 			||  FilterValue === 'Manager' ||  FilterValue === 'client'  ) {
		// 				var FilterDone = true;
		// 			 }
		// 		}	
		// 	} else {
		// 			FilterValue = TabFiltersNew[0].aFilters[0].sPath;
		// 		    if ( FilterValue === 'EngNum' ||  FilterValue === 'Partner'
		// 			||  FilterValue === 'Manager' ||  FilterValue === 'client'  ) {
		// 				FilterDone = true;
		// 			}	
		// 		}
		// 	}
		// }

		//	if (TabFiltersNew && TabFiltersNew.length > 0) {
		if (FilterDone === true) {
			//End of change on 25/3/2019

			if (this.getOwnerComponent().getProperty("appComponent").getComponentData() && this.getOwnerComponent().getProperty("appComponent").getComponentData()
				.startupParameters && jQuery.isEmptyObject(this.getOwnerComponent().getProperty("appComponent").getComponentData().startupParameters) ===
				false) {
				var sParam = this.getOwnerComponent().getProperty("appComponent").getComponentData().startupParameters.ZACTION[0];
				var aFilter = [];
				var paramFilter = [];
				switch (sParam) {
				case "ZCANCEL":
					aFilter.push(new sap.ui.model.Filter("docTypeCode", 'EQ', "DMT"));
					aFilter.push(new sap.ui.model.Filter("docTypeCode", 'EQ', "CMT"));
					aFilter.push(new sap.ui.model.Filter("docTypeCode", 'EQ', "DPT"));
					paramFilter.push(new sap.ui.model.Filter(aFilter, false));
					break;

				case "ZBRE":
					//	oTable = this.getView().byId("ActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP7button").getParent().getParent().getTable();
					//	oContext = oTable.getBinding("items");
					aFilter = [];
					aFilter.push(new sap.ui.model.Filter("docTypeCode", 'EQ', "DMRT"));
					aFilter.push(new sap.ui.model.Filter("docTypeCode", 'EQ', "DMT"));
					aFilter.push(new sap.ui.model.Filter("docTypeCode", 'EQ', "CMRT"));
					aFilter.push(new sap.ui.model.Filter("docTypeCode", 'EQ', "CMT"));
					aFilter.push(new sap.ui.model.Filter("docTypeCode", 'EQ', "DPT"));
					paramFilter.push(new sap.ui.model.Filter(aFilter, false));
					//oContext.filter(aFilter);
					break;

				case "ZCNOTE":
					//	oTable = this.getView().byId("ActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP3button").getParent().getParent().getTable();
					//	oContext = oTable.getBinding("items");
					aFilter = [];
					var bFilter = [];
					var cFilter = [];
					var dFilter = [];
					bFilter.push(new sap.ui.model.Filter("docTypeCode", 'EQ', "CMRT"));
					bFilter.push(new sap.ui.model.Filter("docTypeCode", 'EQ', "CMT"));
					bFilter.push(new sap.ui.model.Filter("docTypeCode", 'EQ', "DMT"));
					dFilter.push(new sap.ui.model.Filter("DocTypeValue", 'NE', "ZNF"));
					cFilter.push(new sap.ui.model.Filter(bFilter, false));
					cFilter.push(new sap.ui.model.Filter(dFilter, false));
					paramFilter.push(new sap.ui.model.Filter(cFilter, true));
					//oContext.filter(aFilter);
					break;
				default:
				}

				//			oContext.filter(aFilter, sap.ui.model.FilterType.Application);

			}
			/*Below line commented by Satabdi Das*/
			// var TabFilters = oControlEvent.getParameter("bindingParams").filters;
			var authFilter = [];
			var initialFilter = [];

			authFilter.push(new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
				new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
				new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
				new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
				new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
				new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
				new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
				new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
				new sap.ui.model.Filter("zz_opp_function", 'EQ', "XXXX"),
				new sap.ui.model.Filter("zz_opp_function", 'EQ', "XXXX"),
				new sap.ui.model.Filter("zz_opp_function", 'EQ', "XXXX"),
				new sap.ui.model.Filter("zz_opp_function", 'EQ', "XXXX"),
				new sap.ui.model.Filter("zz_opp_function", 'EQ', "XXXX"),
				new sap.ui.model.Filter("DelegUserID", 'EQ', "XXXX"),
				new sap.ui.model.Filter("PartDelegUserID", 'EQ', "XXXX"),
				new sap.ui.model.Filter("ZUUSRID", 'EQ', "XXXX"),
				new sap.ui.model.Filter("PartnerUId", 'EQ', "XXXX"),
				new sap.ui.model.Filter("ManagerUId", 'EQ', "XXXX"));

			/*Start of change by Satabdi Das*/

			/*if (TabFilters && TabFilters.length > 0) {

				if (TabFilters[0].aFilters[0].sPath) {
					var intfilter = [];

					intfilter.push(new sap.ui.model.Filter(TabFilters[0].aFilters, false));
					TabFilters[0].aFilters = intfilter;
				}

				TabFilters[0].aFilters.push(new sap.ui.model.Filter(authFilter, false));
				if (paramFilter && paramFilter.length > 0) {
					TabFilters[0].aFilters.push(new sap.ui.model.Filter(paramFilter, false));
				}
				TabFilters[0].bAnd = true;

			} else {

				initialFilter.push(new sap.ui.model.Filter(authFilter, false));
				if (paramFilter && paramFilter.length > 0) {
					initialFilter.push(new sap.ui.model.Filter(paramFilter, false));
				}
				TabFilters.push(new sap.ui.model.Filter(initialFilter, true));
				
			}*/
			initialFilter.push(new sap.ui.model.Filter(authFilter, false));
			if (paramFilter && paramFilter.length > 0) {
				initialFilter.push(new sap.ui.model.Filter(paramFilter, false));
			}
			/*End of change by Satabdi Das*/
		} else {
			if (sParam === "ZPRINT") {
				var oTextResource = this.getView().getModel("i18n").getResourceBundle();
				var sMessage = oTextResource.getText("FILTER1");
			} else {
				oTextResource = this.getView().getModel("i18n").getResourceBundle();
				sMessage = oTextResource.getText("FILTER");

			}
			sap.m.MessageBox.error(sMessage, {});
			throw new Error("Processing Stopped");

		}

	},

	onBatchComplete: function (oResponse) {

		if (this.getOwnerComponent().getProperty("appComponent").getComponentData() && this.getOwnerComponent().getProperty("appComponent").getComponentData()
			.startupParameters && jQuery.isEmptyObject(this.getOwnerComponent().getProperty("appComponent").getComponentData().startupParameters) ===
			false) {
			var sParam = this.getOwnerComponent().getProperty("appComponent").getComponentData().startupParameters.ZACTION[0];
			var oTable = this.getView().byId("ActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP1button").getParent().getParent().getTable();
			var oContext = oTable.getBinding("items");
			var aFilter = [];

			switch (sParam) {
			case "ZCANCEL":
				aFilter.push(new sap.ui.model.Filter("docTypeCode", 'EQ', "DMT"));
				aFilter.push(new sap.ui.model.Filter("docTypeCode", 'EQ', "CMT"));
				aFilter.push(new sap.ui.model.Filter("docTypeCode", 'EQ', "DPT"));
				//oContext.filter(aFilter);
				break;

			case "ZBRE":
				oTable = this.getView().byId("ActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP7button").getParent().getParent().getTable();
				oContext = oTable.getBinding("items");
				aFilter = [];
				aFilter.push(new sap.ui.model.Filter("docTypeCode", 'EQ', "DMRT"));
				aFilter.push(new sap.ui.model.Filter("docTypeCode", 'EQ', "DMT"));
				aFilter.push(new sap.ui.model.Filter("docTypeCode", 'EQ', "CMRT"));
				aFilter.push(new sap.ui.model.Filter("docTypeCode", 'EQ', "CMT"));
				aFilter.push(new sap.ui.model.Filter("docTypeCode", 'EQ', "DPT"));
				//oContext.filter(aFilter);
				break;

			case "ZCNOTE":
				oTable = this.getView().byId("ActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP3button").getParent().getParent().getTable();
				oContext = oTable.getBinding("items");
				aFilter = [];
				aFilter.push(new sap.ui.model.Filter("docTypeCode", 'EQ', "CMRT"));
				aFilter.push(new sap.ui.model.Filter("docTypeCode", 'EQ', "CMT"));
				aFilter.push(new sap.ui.model.Filter("docTypeCode", 'EQ', "DMT"));
				aFilter.push(new sap.ui.model.Filter("DocTypeValue", 'NE', "ZNF"));
				//oContext.filter(aFilter);
				break;
			default:
			}

			if (oContext.aApplicationFilters && oContext.aApplicationFilters.length > 0) {
				for (var j = 0; j < oContext.aApplicationFilters.length; j++) {
					if (oContext.aApplicationFilters[j].aFilters && oContext.aApplicationFilters[j].aFilters.length > 0) {
						for (var i = 0; i < oContext.aApplicationFilters[j].aFilters.length; i++) {
							if (oContext.aApplicationFilters[j].aFilters[i].aFilters && oContext.aApplicationFilters[j].aFilters[i].aFilters.length > 0) {
								for (var k = 0; k < oContext.aApplicationFilters[j].aFilters[i].aFilters.length; k++) {
									aFilter.push(oContext.aApplicationFilters[j].aFilters[i].aFilters[k]);
								}
							} else {
								aFilter.push(oContext.aApplicationFilters[j].aFilters[i]);
							}
						}
					}
				}
			}

			aFilter.push(new sap.ui.model.Filter({
				filters: [
					// new sap.ui.model.Filter("EngManager", 'EQ', "XXXX"),
					// new sap.ui.model.Filter("EngPartner", 'EQ', "XXXX"),
					/*new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
					new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
					new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
					new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
					new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
					new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
					new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),
					new sap.ui.model.Filter("kvgr1", 'EQ', "XXXX"),*/
					/*					new sap.ui.model.Filter("zz_opp_function", 'EQ', "XXXX"),
										new sap.ui.model.Filter("zz_opp_function", 'EQ', "XXXX"),
										new sap.ui.model.Filter("zz_opp_function", 'EQ', "XXXX"),
										new sap.ui.model.Filter("zz_opp_function", 'EQ', "XXXX"),
										new sap.ui.model.Filter("zz_opp_function", 'EQ', "XXXX"),*/
					//new sap.ui.model.Filter("MangDelegID", 'EQ', "XXXX"),
					//new sap.ui.model.Filter("PartDelegUserID", 'EQ', "XXXX"),
					// new sap.ui.model.Filter("ZUUSRID", 'EQ', "XXXX"),
					new sap.ui.model.Filter("PartnerUId", 'EQ', "XXXX"),
					new sap.ui.model.Filter("ManagerUId", 'EQ', "XXXX")
				],
				and: false
			}));

			oContext.filter(aFilter, sap.ui.model.FilterType.Application);

		}

	},

	onClickActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP1: function (oEvent) {
		this.CancelBill(oEvent, "CANC");
	},

	CancelBill: function (oEvent, sMode) {
		// var oSelectedItem = oEvent.getSource().getParent().getParent().getTable().getSelectedItem();
		//changed done by prashant kumar
		var oSelectedItem = oEvent.getSource().getParent().getParent().getSelectedItem();

		var oBindingContext;
		var sVbeln = " ";
		var oDataModl;

		oBindingContext = new sap.ui.model.Context(oSelectedItem.getModel(), oSelectedItem.getBindingContext().getPath());
		sVbeln = oBindingContext.getProperty("DebCreNum");
		this.oBindingContext = oBindingContext;

		//var that = oEvent.getSource().getParent().getParent().getTable();
		var sMessage;

		var oTextResource = this.getView().getModel("i18n").getResourceBundle();
		var sConfirmMessage = oTextResource.getText("CAN");
		var sDialogHeader = oTextResource.getText("CONFIRM");
		var sErrTxt = oTextResource.getText("ERRCAN");
		var sReasonType = "";
		var fnSuccess1 = jQuery.proxy(function (oData, response) {
				if (oData.SUCCESS) {
					var fnSuccess = jQuery.proxy(function (oData, response) {

							if (oData.MESSAGE) {

								if (oData.SUCCESS) {
									var sPath = this.oBindingContext.getPath();
									var oModel = this.getView().getModel();
									oModel.setProperty(sPath + '/Cancelbillno', oData.VBELN);
									//	oModel.submitChanges();
								}
								sMessage = oData.MESSAGE;

							} else {
								sMessage = sErrTxt;
							}
							sap.ui.core.BusyIndicator.hide();
							sap.m.MessageToast.show(sMessage, {
								duration: 5000, // default
								width: "15em", // default
								my: "center bottom",
								at: "center bottom",
								of: window, // default
								offset: "0 0", // default
								collision: "fit fit", // default
								autoClose: true, // default
								animationTimingFunction: "ease", // default
								animationDuration: 1000, // default
								closeOnBrowserNavigation: true // default
							});
						},
						this);

					sap.m.MessageBox.show(
						sConfirmMessage,
						sap.m.MessageBox.Icon.WARNING,
						sDialogHeader,
						/*this.addStyleClass("Hello"),*/
						[sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
						jQuery.proxy(function (a) {
							if (a === sap.m.MessageBox.Action.YES) {
								sap.ui.core.BusyIndicator.show(0);
								oDataModl = this.getOwnerComponent().getModel();
								oDataModl.callFunction('/fnCanRejBill', {
									urlParameters: {

										VBELN: sVbeln,
										ACTION: sMode,
										REJRES: sReasonType

									},
									method: "GET",
									success: fnSuccess
								});
							}
							//	 else if (a === sap.m.MessageBox.Action.NO) {}

						}, this));
				} else {

					this.displayErrorMessage(oData.MESSAGE);
				}
			},
			this);

		//This function call has been done for MEC lock check before showing cancel pop-up
		oDataModl = this.getOwnerComponent().getModel();
		oDataModl.callFunction('/fnCanRejBill', {
			urlParameters: {
				VBELN: sVbeln,
				ACTION: "LOCK",
				REJRES: sReasonType
			},
			method: "GET",
			success: fnSuccess1
		});

	},
	onClickActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP2: function (oEvent) {
		this.CancelnReject(oEvent, "CANR");
	},

	CancelnReject: function (oEvent, sMode) {
		this.AppMode = sMode;
		// this._oSelectedItem = oEvent.getSource().getParent().getParent().getTable().getSelectedItem();
		this._oSelectedItem = oEvent.getSource().getParent().getParent().getSelectedItem();
		var oView = this.getView();
		var oDialog = oView.byId("cancelReason");
		// create dialog lazily
		if (!oDialog) {
			// create dialog via fragment factory
			// var oCtrl = sap.ui.controller("kno.em.billsrch.germany.ext.controller.ListReportActions");
			oDialog = this.oDialog = sap.ui.xmlfragment(oView.getId(), "kno.em.billsrch.germany.ext.fragments.CustomActionPopUpRejectAllItems",
				this);
			// connect dialog to view (models, lifecycle)
			oView.addDependent(oDialog);
		}
		var fnSuccess1 = jQuery.proxy(function (oData, response) {
				if (oData.SUCCESS) {
					var fnSuccess = jQuery.proxy(function (oData, response) {

							var mSalesDocumentRjcnReason = new sap.ui.model.json.JSONModel({
								items: []
							});

							var arrReason = [];

							for (var i = 0; i < oData.results.length; i++) {
								var mRejReason = {
									SALESDOCUMENTRJCNREASON: oData.results[i].SALESDOCUMENTRJCNREASON,
									SALESDOCUMENTRJCNREASONNAME: oData.results[i].SALESDOCUMENTRJCNREASONNAME
								};

								arrReason.push(mRejReason);
							}

							mSalesDocumentRjcnReason.setProperty("/items", arrReason);
							this.getView().setModel(mSalesDocumentRjcnReason, "mSalesDocumentRjcnReason");

							var oMessageStrip = this.getView().byId("rejectAllItemsMessageStrip");
							oMessageStrip.setVisible(false);
							this.oDialog.open();
						},
						this);

					var oSelectedItem = this._oSelectedItem;
					var oBindingContext;

					oBindingContext = new sap.ui.model.Context(oSelectedItem.getModel(), oSelectedItem.getBindingContext().getPath());
					sVbeln = oBindingContext.getProperty("DebCreReq");
					var sVbeln;
					var oDataModl = this.getOwnerComponent().getModel();
					oDataModl.callFunction('/fnRejreason', {
						urlParameters: {

							VBELN: sVbeln,

						},
						method: "GET",
						success: fnSuccess
					});

				} else {

					this.displayErrorMessage(oData.MESSAGE);
				}
			},
			this);

		//This function call has been done for MEC lock check before showing cancel-reject pop-up
		var oDataModl = this.getOwnerComponent().getModel();

		var oSelectedItem = this._oSelectedItem;
		var oBindingContext;
		var sReasonType = "";
		oBindingContext = new sap.ui.model.Context(oSelectedItem.getModel(), oSelectedItem.getBindingContext().getPath());
		var sVbeln =
			oBindingContext.getProperty("DebCreNum");
		oDataModl.callFunction('/fnCanRejBill', {
			urlParameters: {
				VBELN: sVbeln,
				ACTION: "LOCK",
				REJRES: sReasonType
			},
			method: "GET",
			success: fnSuccess1
		});
	},
	onOKPressed: function () {
		var oSelectedItem = this._oSelectedItem;
		var oBindingContext;
		var sVbeln = " ";
		var oDataModl;

		oBindingContext = new sap.ui.model.Context(oSelectedItem.getModel(), oSelectedItem.getBindingContext().getPath());
		sVbeln = oBindingContext.getProperty("DebCreNum");
		this.oBindingContext = oBindingContext;

		var sMessage;
		var sReasonType = this.getView().byId("idComboBoxReasonType").getSelectedKey();
		var oMessageStrip = this.getView().byId("rejectAllItemsMessageStrip");

		if (!sReasonType) {
			oMessageStrip.setVisible(true);
			return;
		} else {
			oMessageStrip.setVisible(false);
		}

		var oDialog = this.getView().byId("cancelReason");
		if (oDialog) {
			oDialog.close();
		}

		var oTextResource = this.getView().getModel("i18n").getResourceBundle();
		var sConfirmMessage = oTextResource.getText("REJ");
		var sDialogHeader = oTextResource.getText("CONFIRM");
		var sErrTxt = oTextResource.getText("ERRCAN");

		var fnSuccess = jQuery.proxy(function (oData, response) {
			if (oData.MESSAGE) {
				if (oData.SUCCESS) {
					var sPath = this.oBindingContext.getPath();
					var oModel = this.getView().getModel();
					oModel.setProperty(sPath + '/Cancelbillno', oData.VBELN);
					//	oModel.submitChanges();
				}
				sMessage = oData.MESSAGE;
			} else {
				sMessage = sErrTxt;
			}
			sap.ui.core.BusyIndicator.hide();
			this.displayMessage(sMessage);
		}, this);

		sap.m.MessageBox.show(
			sConfirmMessage,
			sap.m.MessageBox.Icon.WARNING,
			sDialogHeader,
			/*this.addStyleClass("Hello"),*/
			[sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
			jQuery.proxy(function (a) {
				if (a === sap.m.MessageBox.Action.YES) {
					sap.ui.core.BusyIndicator.show(0);
					oDataModl = this.getOwnerComponent().getModel();
					oDataModl.callFunction('/fnCanRejBill', {
						urlParameters: {

							VBELN: sVbeln,
							ACTION: this.AppMode,
							REJRES: sReasonType

						},
						method: "GET",
						success: fnSuccess
					});
				}
				// else if (a === sap.m.MessageBox.Action.NO) {}

			}, this));

	},

	onCancelPressed: function () {
		sap.ui.core.BusyIndicator.hide();
		var oDialog = this.getView().byId("cancelReason");
		if (oDialog) {
			oDialog.close();
		}
	}

	,
	onClickActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP3: function (oEvent) { // Create Credit Note

		var oSelectedItem = oEvent.getSource().getParent().getParent().getTable().getSelectedItem();
		var oBindingContext = new sap.ui.model.Context(oSelectedItem.getModel(), oSelectedItem.getBindingContext().getPath());
		var sDocNumber = oBindingContext.getProperty("EngNum");
		var sDocDesc = oBindingContext.getProperty("EngDesc");
		var sDM = oBindingContext.getProperty("DebCreNum");
		var sCMR = "";
		var sMessage;
		var oTextResource = this.getView().getModel("i18n").getResourceBundle();
		var sErrTxt = oTextResource.getText("ERRCNC");
		//Validate for Create credit Note
		//if (oBindingContext.getProperty("Cancelbillno") || !oBindingContext.getProperty("DebCreNum")) {

		//	sMessage = sErrTxt;

		//	this.displayErrorMessage(sMessage);

		//	return;
		//}
		var fnSuccess = jQuery.proxy(function (oData, response) {
				if (oData.SUCCESS) {
					if (oData.ENGNUM) {
						sDocNumber = oData.ENGNUM;
					}
					var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service
					var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
						target: {
							semanticObject: "ZCreditNote",
							action: "zmanage"
						},
						params: {
							DocId: sDocNumber,
							DocDesc: sDocDesc,
							DM: sDM,
							CMR: sCMR,
							Mode: "CRET"
								// dec_separator: oData.DEC_SEPARATOR,
								// date_format: oData.DATE_FORMAT
						}
					}));

					oCrossAppNavigator.toExternal({
						target: {
							shellHash: hash
						}
					});
				} else {

					this.displayErrorMessage(oData.MESSAGE);
				}
			},
			this);

		var oDataModl = this.getOwnerComponent().getModel();
		oDataModl.callFunction('/fnCreEditCN', {
			urlParameters: {
				ACTION: "CRET",
				VBELN: sDM,
				APP_DOC: sDM
			},
			method: "GET",
			success: fnSuccess
		});
		// }

	},
	onClickActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP4: function (oEvent) { // Edit Credit Note

		var oSelectedItem = oEvent.getSource().getParent().getParent().getTable().getSelectedItem();
		var oBindingContext = new sap.ui.model.Context(oSelectedItem.getModel(), oSelectedItem.getBindingContext().getPath());
		var sDocNumber = oBindingContext.getProperty("EngNum");
		var sDocDesc = oBindingContext.getProperty("EngDesc");
		var sDM = oBindingContext.getProperty("DebCreNum");
		var sCMR = oBindingContext.getProperty("DebCreReq");
		var oTextResource = this.getView().getModel("i18n").getResourceBundle();
		var sErrTxt = oTextResource.getText("ERRCNE");
		//Validate for Edit credit Note
		if (oBindingContext.getProperty("Cancelbillno") || oBindingContext.getProperty("DebCreNum")) {

			var sMessage = sErrTxt;

			this.displayErrorMessage(sMessage);
			return;
		}
		var fnSuccess = jQuery.proxy(function (oData, response) {
				if (oData.SUCCESS) {
					if (oData.ENGNUM) {
						sDocNumber = oData.ENGNUM;
					}
					var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service
					var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
						target: {
							semanticObject: "ZCreditNote",
							action: "zmanage"
						},
						params: {

							DocId: sDocNumber,
							DocDesc: sDocDesc,
							DM: "",
							CMR: sCMR,
							Mode: "EDIT"
								// dec_separator: oData.DEC_SEPARATOR,
								// date_format: oData.DATE_FORMAT
						}
					}));

					oCrossAppNavigator.toExternal({
						target: {
							shellHash: hash
						}
					});
				} else {

					this.displayErrorMessage(oData.MESSAGE);
				}
			},
			this);
		var oDataModl = this.getOwnerComponent().getModel();
		oDataModl.callFunction('/fnCreEditCN', {
			urlParameters: {
				ACTION: "EDIT",
				VBELN: sCMR,
				APP_DOC: sDM
			},
			method: "GET",
			success: fnSuccess
		});
	},
	onClickActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP5: function (oEvent) { //Text maintain
		var sSelectedPath = this.extensionAPI.getSelectedContexts()[0].sPath;
		var sSelectedDoc = this.getView().getModel().getProperty(sSelectedPath).DebCreReq;
		var sSelectedClnt = this.getView().getModel().getProperty(sSelectedPath).client;
		var sSelectedPrt = this.getView().getModel().getProperty(sSelectedPath).Partner;
		var sSelectedDoctype = this.getView().getModel().getProperty(sSelectedPath).Dctype;
		var sCancelbillno = this.getView().getModel().getProperty(sSelectedPath).Cancelbillno;
		var sSelectedDMCM = this.getView().getModel().getProperty(sSelectedPath).DebCreNum;
		var oTextResource = this.getView().getModel("i18n").getResourceBundle();
		var sErrTxt = oTextResource.getText("TXTCAN");
		var sErrVal = oTextResource.getText("TXTVAL");
		var sErrTxt2 = oTextResource.getText("TXT1");
		var aContexts = this.extensionAPI.getSelectedContexts();
		var sDMRCMR = sSelectedDoc;
		var sDoctype;
		if (sSelectedDoc === '') {
			if (sCancelbillno !== '') {
				sSelectedDoc = sDMRCMR;
			} else {
				if (sSelectedDMCM !== '') {
					sSelectedDoc = sSelectedDMCM;
				} else {
					sSelectedDoc = sDMRCMR;
				}
			}

		} else {
			if (sCancelbillno !== '') {
				sSelectedDoc = sDMRCMR;
			} else {
				if (sSelectedDMCM !== '') {
					sSelectedDoc = sSelectedDMCM;
				} else {
					sSelectedDoc = sDMRCMR;
				}
			}
		}

		var fnSuccess = jQuery.proxy(function (oData, response) {
				if (oData.SUCCESS) {
					/*	if (sCancelbillno) {
							this.displayErrorMessage(sErrTxt);
						} else {*/
					if (sSelectedDoc !== '') {

						if (aContexts && aContexts.length > 1) {

							this.displayErrorMessage(sErrTxt2);
						} else {

							if (sSelectedDMCM !== '') { //If Approved document is there use approved document Else use Draft Doc
								sSelectedDoc = sSelectedDMCM;
							}

							if (sCancelbillno !== '') { //If Approved document is cancelled then proceeding with DMR/CMR
								sSelectedDoc = sDMRCMR;
							}

							var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service

							var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
								target: {
									semanticObject: "ZTextMaintain",
									action: "zmanage"
								}
								// params: {
								// 	DocId: oData.VBELN,
								// 	DocType: oData.DocType,
								// 	Client: oData.Cname,
								// 	Partner: oData.Ename,
								// 	Demo: oData.DemoDm,
								// 	ParamDisp: oData.ParamDisp
								// }

							}));
							var sStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
							//to add data in the storage 
							sStorage.put("TextKey", oData);

							oCrossAppNavigator.toExternal({
								target: {
									shellHash: hash
								}
							});
						}
					} else {
						this.displayErrorMessage(sErrVal);
					}
					// }
				} else {

					this.displayErrorMessage(oData.MESSAGE);
				}
			},
			this);
		var oDataModl = this.getOwnerComponent().getModel();
		oDataModl.callFunction('/fnTextMaint', {
			urlParameters: {
				ACTION: "CRET",
				VBELN: sSelectedDoc
			},
			method: "GET",
			success: fnSuccess
		});
	},
	onClickActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP6: function (oEvent) { //Maintain Attachment

		var sSelectedPath = this.extensionAPI.getSelectedContexts()[0].sPath;
		var sSelectedDoc = this.getView().getModel().getProperty(sSelectedPath).DebCreReq;
		//var sSelectedDoctype = this.getView().getModel().getProperty(sSelectedPath).Dctype;
		//var sSelectedEngNum = this.getView().getModel().getProperty(sSelectedPath).EngNum;
		//var sSelectedEngDesc = this.getView().getModel().getProperty(sSelectedPath).EngDesc;
		//var sSelectedclient = this.getView().getModel().getProperty(sSelectedPath).client;
		var sCancelbillno = this.getView().getModel().getProperty(sSelectedPath).Cancelbillno;
		var sSelectedDMCM = this.getView().getModel().getProperty(sSelectedPath).DebCreNum;
		var oTextResource = this.getView().getModel("i18n").getResourceBundle();
		var sErrTxt = oTextResource.getText("ATTCAN");
		var aContexts = this.extensionAPI.getSelectedContexts();
		var sErrTxt2 = oTextResource.getText("ATTH1");
		var sDMRCMR = sSelectedDoc;
		var Doctype;

		/*		if (!sSelectedDoc) {
					sSelectedDoc = this.getView().getModel().getProperty(sSelectedPath).DebCreNum;
				}*/

		if (sSelectedDoc === '') {
			if (sCancelbillno !== '') {
				sSelectedDoc = sDMRCMR;
			} else {
				if (sSelectedDMCM !== '') {
					sSelectedDoc = sSelectedDMCM;
				} else {
					sSelectedDoc = sDMRCMR;
				}
			}

		} else {
			if (sCancelbillno !== '') {
				sSelectedDoc = sDMRCMR;
			} else {
				if (sSelectedDMCM !== '') {
					sSelectedDoc = sSelectedDMCM;
				} else {
					sSelectedDoc = sDMRCMR;
				}
			}
		}

		//Begin of change for defect 51350
		if (sCancelbillno) {
			if (sDMRCMR === '') {
				this.displayErrorMessage(sErrTxt);
			} else {

				if (aContexts && aContexts.length > 1) {

					this.displayErrorMessage(sErrTxt2);
				} else {
					var fnSuccess = jQuery.proxy(function (oData, response) {
							if (oData.SUCCESS) {
								if (oData.DOC_TYPE === "CMRT") {
									Doctype = "BUS2094"; //Credit Memo Request
								} else if (oData.DOC_TYPE === "DPT") {
									Doctype = "VBRK"; //DownPayment Document
								} else if (oData.DOC_TYPE === "DMRT") {
									Doctype = "BUS2096"; //Debit Memo request
								} else {
									Doctype = "VBRK"; //Credit Memo/ Debit memo
								}
								oData.DOC_TYPE = Doctype;
								// get a handle on the global XAppNav service
								var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

								var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
									target: {
										semanticObject: "Zattachment",
										action: "zmanage"
									}
									/*									params: {
																			DocId: oData.VBELN, //sSelectedDoc,
																			DocType: Doctype,
																			Dctype: oData.Print,
																			EngNum: oData.ENGNUM,
																			EngDesc: oData.ENGDESC,
																			client: oData.Cname,
																			Final: oData.FinalAtt,
																			Demo: oData.DemoDm,
																			ParamDisp: oData.ParamDisp
																		}*/
								}));
								var sStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
								//to add data in the storage&nbsp;
								sStorage.put("AttKey", oData);
								oCrossAppNavigator.toExternal({
									target: {
										shellHash: hash
									}
								});
							} else {

								this.displayErrorMessage(oData.MESSAGE);
							}
						},

						this);

					var oDataModl = this.getOwnerComponent().getModel();
					oDataModl.callFunction('/fnCreEditAtt', {
						urlParameters: {
							ACTION: "CRET",
							VBELN: sSelectedDoc
						},
						method: "GET",
						success: fnSuccess
					});
				}

			}
		} else {
			//End of change for defect 51350
			if (aContexts && aContexts.length > 1) {

				this.displayErrorMessage(sErrTxt2);
			} else {
				var fnSuccess1 = jQuery.proxy(function (oData, response) {
						if (oData.SUCCESS) {
							if (oData.DOC_TYPE === "CMRT") {
								Doctype = "BUS2094"; //Credit Memo Request
							} else if (oData.DOC_TYPE === "DPT") {
								Doctype = "VBRK"; //DownPayment Document
							} else if (oData.DOC_TYPE === "DMRT") {
								Doctype = "BUS2096"; //Debit Memo request
							} else {
								Doctype = "VBRK"; //Credit Memo/ Debit memo
							}
							oData.DOC_TYPE = Doctype;
							// get a handle on the global XAppNav service
							var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

							var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
								target: {
									semanticObject: "Zattachment",
									action: "zmanage"
								}
								/*								params: {
																	DocId: oData.VBELN, //sSelectedDoc,
																	DocType: Doctype,
																	Dctype: oData.Print,
																	EngNum: oData.ENGNUM,
																	EngDesc: oData.ENGDESC,
																	client: oData.Cname,
																	Final: oData.FinalAtt,
																	Demo: oData.DemoDm,
																	ParamDisp: oData.ParamDisp
																}*/
							}));
							var sStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
							//to add data in the storage&nbsp;
							sStorage.put("AttKey", oData);
							oCrossAppNavigator.toExternal({
								target: {
									shellHash: hash
								}
							});
						} else {

							this.displayErrorMessage(oData.MESSAGE);
						}
					},

					this);

				var oDataModl1 = this.getOwnerComponent().getModel();
				oDataModl1.callFunction('/fnCreEditAtt', {
					urlParameters: {
						ACTION: "CRET",
						VBELN: sSelectedDoc
					},
					method: "GET",
					success: fnSuccess1
				});
			}
		}
	},
	onClickActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP7: function (oEvent) { //BRE
		// var oSelectedItem = oEvent.getSource().getParent().getParent().getTable().getSelectedItem();
		//changed done by prashant kumar 16.04.2021
		var oSelectedItem = oEvent.getSource().getParent().getParent().getSelectedItem();
		var oBindingContext = new sap.ui.model.Context(oSelectedItem.getModel(), oSelectedItem.getBindingContext().getPath());
		var sSelectedPath = this.extensionAPI.getSelectedContexts()[0].sPath;
		var sSelectedDoc = this.getView().getModel().getProperty(sSelectedPath).DebCreReq;

		var oTextResource = this.getView().getModel("i18n").getResourceBundle();
		var sErrTxt = oTextResource.getText("ERRDME");
		//Validate for Edit BRE
		if (oBindingContext.getProperty("Cancelbillno") || oBindingContext.getProperty("DebCreNum")) {

			var sMessage = sErrTxt;

			this.displayErrorMessage(sMessage);
			return;
		}
		var fnSuccess = jQuery.proxy(function (oData, response) {
				if (oData.SUCCESS) {
					var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service
					var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
						target: {
							semanticObject: "ZBRE",
							action: "zmanage"
						},
						params: {
							DocId: sSelectedDoc
						}

					}));

					oCrossAppNavigator.toExternal({
						target: {
							shellHash: hash
						}
					});
				} else {

					this.displayErrorMessage(oData.MESSAGE);
				}
			},
			this);

		var oDataModl = this.getOwnerComponent().getModel();
		oDataModl.callFunction('/fnCreEditBre', {
			urlParameters: {
				ACTION: "CRET",
				VBELN: sSelectedDoc
			},
			method: "GET",
			success: fnSuccess
		});

	},

	displayMessage: function (sMessage) {

		sap.m.MessageToast.show(sMessage, {
			duration: 5000, // default
			width: "15em", // default
			my: "center bottom",
			at: "center bottom",
			of: window, // default
			offset: "0 0", // default
			collision: "fit fit", // default
			autoClose: true, // default
			animationTimingFunction: "ease", // default
			animationDuration: 1000, // default
			closeOnBrowserNavigation: true // default
		});
	},
	displayErrorMessage: function (sMessage) {
		sap.m.MessageBox.error(sMessage, {
			title: "Error", // default
			textDirection: sap.ui.core.TextDirection.Inherit // default
		});
	},
	onClickActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP8: function (oEvent) {
		var oList = oEvent.getSource().getParent().getParent();
		var oRowBinding = oList._getRowBinding();
		var sUrl = oRowBinding.getDownloadUrl("xlsx");
		// sUrl = this._adjustUrlToVisibleColumns(sUrl);
		sUrl = oList._removeExpandParameter(sUrl);
		// check for length of URL -> URLs longer than 2048 chars aren't supported in some browsers (e.g. Internet Explorer)
		if (sUrl && sUrl.length > 2048 && sap.ui.Device.browser.msie) {
			// thrown info to user!
			sap.m.MessageBox.error(sap.ui.getCore().getLibraryResourceBundle("sap.ui.comp").getText("DOWNLOAD_TOO_COMPLEX_TEXT"));
			return;
		}
		window.open(sUrl);

	},
	// Billing Ststistics for BRE in EDIT DMR screen
	onClickActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP18: function (oEvent) {

		var oTextResource = this.getView().getModel("i18n").getResourceBundle();
		var sErrTxt1 = oTextResource.getText("BILLSTAT");
		var sErrTxt2 = oTextResource.getText("PRINT2");
		var sSelectedPath = this.extensionAPI.getSelectedContexts()[0].sPath;
		var oDataModl;
		var sMessages;
		var sVbeln = this.getView().getModel().getProperty(sSelectedPath).DebCreReq;
		var sDocType = this.getView().getModel().getProperty(sSelectedPath).Dctype;

		if (sDocType === "Credit Memo Request") {
			var Cmemo = "X";
		} else if (sDocType === "KPMG Credit Memo") {
			Cmemo = "X";
		} else if (sDocType === "KPMG Down payment requ") {
			Cmemo = "X";
		} else if (sDocType === "KPMG Anzahlungsanforderg.") {
			Cmemo = "X";
		} else if (sDocType === "KPMG Re.korr.anf.") {
			Cmemo = "X";
		} else if (sDocType === "KPMG Rechnungskorrektur") {
			Cmemo = "X";
		} else {
			Cmemo = "";
		}

		if (Cmemo === "X") {
			sap.m.MessageBox.error(sErrTxt1, {});
		} else {
			var fnSuccess = jQuery.proxy(function (oData, response) {
					if (oData.SUCCESS) {
						var slink = "/sap/opu/odata/KNO/EM_BILL_PRINT_SRV/" + "Roots(ApplObjectType='BILLING_DOCUMENT',ApplObjectId='" +
							sVbeln + "',LOG_HANDLE='DMR')/" + "Preview/$value/";
						window.open(slink);
					} else {
						if (oData.MESSAGE) {
							sMessages = oData.MESSAGE;
						}
					}
					sap.m.MessageToast.show(sMessages, {
						duration: 5000, // default
						width: "15em", // default
						my: "center bottom",
						at: "center bottom",
						of: window, // default
						offset: "0 0", // default
						collision: "fit fit", // default
						autoClose: true, // default
						animationTimingFunction: "ease", // default
						animationDuration: 1000, // default
						closeOnBrowserNavigation: true // default
					});

				}, this),

				oDataModl = this.getOwnerComponent().getModel();
			oDataModl.callFunction('/fnCreEditBre', {
				urlParameters: {
					ACTION: "BILLST",
					VBELN: sVbeln,
				},
				method: "GET",
				success: fnSuccess,
				responseType: "arraybuffer"
			});
		}
	},

	// Action for Date picker for Print Basket	
	onChangeDate: function () {
		var sDate = this.getView().byId("DP1").getValue();
		var sTime = this.getView().byId("TP1").getValue();
		if (sDate) {
			if (sTime) {
				this.getView().byId("OKBUT1").setEnabled(true);
			} else {
				this.getView().byId("OKBUT1").setEnabled(false);
			}
		} else {
			this.getView().byId("OKBUT1").setEnabled(false);
		}
	},
	//Action for time picker for Print Basket
	onChangeTime: function () {
		var sDate = this.getView().byId("DP1").getValue();
		var sTime = this.getView().byId("TP1").getValue();
		if (sDate) {
			if (sTime) {
				this.getView().byId("OKBUT1").setEnabled(true);
			} else {
				this.getView().byId("OKBUT1").setEnabled(false);
			}
		} else {
			this.getView().byId("OKBUT1").setEnabled(false);
		}
	},
	//Multiple Print
	onClickActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP9: function (oEvent) {
		this._oSelectedItem = oEvent.getSource().getParent().getParent().getTable().getSelectedItems();
		var sTimezone;
		var aContexts = this.extensionAPI.getSelectedContexts();
		var oTextResource = this.getView().getModel("i18n").getResourceBundle();
		var sErrTxt1 = oTextResource.getText("PRINT10");
		var sVbeln;
		var sVbelnTemp;
		if (aContexts && aContexts.length < 2) {
			sap.m.MessageBox.error(sErrTxt1, {});
		} else {
			// create dialog lazily
			// if (!oDialog) {
			// 	// create dialog via fragment factory
			// 	// var oCtrl = sap.ui.controller("kno.em.billsrch.germany.ext.controller.ListReportActions");
			// 	oDialog = this.oDialog = sap.ui.xmlfragment(oView.getId(), "kno.em.billsrch.germany.ext.fragments.CustomActionPopUp",
			// 		this);
			// 	// connect dialog to view (models, lifecycle)
			// 	oView.addDependent(oDialog);
			// 	oDialog.open();
			// } else {
			// 	oDialog.open();
			// }

			var fnSuccess = jQuery.proxy(function (oData, response) {
					//Proceed if Success				
					if (oData.results[0].SUCCESS) {
						var oView = this.getView();
						var oDialog = oView.byId("BatchJob");
						if (!oDialog) {
							// create dialog via fragment factory
							// var oCtrl = sap.ui.controller("kno.em.billsrch.germany.ext.controller.ListReportActions");
							oDialog = this.oDialog = sap.ui.xmlfragment(oView.getId(), "kno.em.billsrch.germany.ext.fragments.CustomActionPopUp",
								this);
							// connect dialog to view (models, lifecycle)
							oView.addDependent(oDialog);
							oDialog.open();
						} else {
							oDialog.open();
						}

						var mPrinters = new sap.ui.model.json.JSONModel({
							items: [],
							timezone: ''
						});
						mPrinters.setSizeLimit(3000);

						var arrPrinters = [];

						for (var i = 0; i < oData.results.length; i++) {
							if (i === 1) {
								sTimezone = oData.results[i].TIMEZONE;
							}
							var mPrinter = {
								PRINTER: oData.results[i].PRINTER,
								PRINTER_NAME: oData.results[i].PRINTER_NAME,
							};
							try {
								this.getView().byId("idComboBoxPrinter").setSelectedKey(oData.results[i].PRINTER);
							} catch (e) {}
							arrPrinters.push(mPrinter);
						}

						mPrinters.setProperty("/items", arrPrinters);
						mPrinters.setProperty("/timezone", sTimezone);
						this.getView().setModel(mPrinters, "mPrinters");

						// var oMessageStrip = this.getView().byId("PrintersMessageStrip");
						// oMessageStrip.setVisible(false);
						this.oDialog.open();
					} else {
						this.displayErrorMessage(oData.results[0].MESSAGE);
					}
				},
				this);

			for (var sCount = 0; sCount < this._oSelectedItem.length; sCount++) {
				var oBindingContext = new sap.ui.model.Context(this._oSelectedItem[sCount].getModel(), this._oSelectedItem[sCount].getBindingContext()
					.getPath());
				// sVbeln = oBindingContext.getProperty("EngNum");
				if (oBindingContext.getProperty("Cancelbillno")) {
					sVbelnTemp = oBindingContext.getProperty("Cancelbillno");
				} else if (oBindingContext.getProperty("DebCreNum")) {
					sVbelnTemp = oBindingContext.getProperty("DebCreNum");
				} else {
					sVbelnTemp = oBindingContext.getProperty("DebCreReq");
				}
				if (!sVbeln) {
					sVbeln = sVbelnTemp;
				} else {
					sVbeln = sVbeln + "|" + sVbelnTemp;
				}

			}

			var oDataModl = this.getOwnerComponent().getModel();
			oDataModl.callFunction('/fnPrinters', {
				urlParameters: {
					ACTION: "OUT",
					VBELN: sVbeln
				},
				method: "GET",
				success: fnSuccess
			});

		}
	},
	//Print immediately
	onSpoolPressed: function (oEvent) {

		var sPrinter = this.getView().byId("idComboBoxPrinter").getSelectedKey();
		if (!sPrinter) {
			this.displayErrorMessage("Please Select a Printer");
			return;
		}

		var oDialog1 = this.byId("BusyDialog");
		oDialog1.open();
		var oSelectedItem = this._oSelectedItem;
		var oBindingContext;
		var oTextResource = this.getView().getModel("i18n").getResourceBundle();
		var sErrTxt1 = oTextResource.getText("PRINT1");
		var sErrTxt2 = oTextResource.getText("PRINT2");
		var sVbeln = " ";
		var sDoc = " ";
		var oDataModl;
		var aContexts = this.extensionAPI.getSelectedContexts();
		var arrVbeln = [];
		var sMessages;

		if (aContexts && aContexts.length > 0) {
			for (var sCount = 0; sCount < aContexts.length; sCount++) {
				oBindingContext = new sap.ui.model.Context(oSelectedItem[sCount].getModel(), oSelectedItem[sCount].getBindingContext().getPath());

				if (oBindingContext.getProperty("DebCreNum")) {
					sDoc = oBindingContext.getProperty("DebCreNum");
				} else {
					sDoc = oBindingContext.getProperty("DebCreReq");
				}

				sVbeln = sVbeln + "|" + sDoc;
				arrVbeln.push(sDoc);

			}
			var simmediate = "X";
			var oDialog = this.getView().byId("BatchJob");
			if (oDialog) {
				oDialog.close();
			}
			var fnSuccess = jQuery.proxy(function (oData, response) {
					/*					if (oData.MESSAGE === "Success") {
											sMessages = sErrTxt1;
										} else {
											if (oData.MESSAGE === "Error") {
												sMessages = sErrTxt2;
											}
										}*/
					if (oData.SUCCESS) {
						sMessages = sErrTxt1;
					} else {
						if (oData.MESSAGE) {
							sMessages = oData.MESSAGE;
						} else {
							sMessages = sErrTxt2;
						}
					}
					/*		oButton.setBusy(false);  */
					/*  sap.ui.core.BusyIndicator.hide();*/
					oDialog1.close();
					sap.m.MessageToast.show(sMessages, {
						duration: 5000, // default
						width: "15em", // default
						my: "center bottom",
						at: "center bottom",
						of: window, // default
						offset: "0 0", // default
						collision: "fit fit", // default
						autoClose: true, // default
						animationTimingFunction: "ease", // default
						animationDuration: 1000, // default
						closeOnBrowserNavigation: true // default
					});

					/*				this.removeSelections();*/
				}),

				oDataModl = this.getOwnerComponent().getModel();
			oDataModl.callFunction('/fnBillPrint', {
				urlParameters: {
					//ACTION: "MODI",
					VBELN: sVbeln,
					DATE: "",
					TIME: "",
					IMMEDIATE: simmediate,
					PRINTER: sPrinter,
					ENGNUM: "",
					DOC_TYPE_TEXT: "",
					FINALATT: "",
					PRINT: "",
					DEMODM: "",
				},
				method: "GET",
				success: fnSuccess
			});

		}
	},

	//Schedule job for printing
	onSchedulePressed: function (oEvent) {

		var sPrinter = this.getView().byId("idComboBoxPrinter").getSelectedKey();

		if (!sPrinter) {
			this.displayErrorMessage("Please Select a Printer");
			return;
		}

		var oDialog1 = this.byId("BusyDialog");
		oDialog1.open();
		var oSelectedItem = this._oSelectedItem;
		var oBindingContext;
		var sVbeln = " ";
		var sDoc = " ";
		var oDataModl;
		var oDialog = this.getView().byId("BatchJob");
		var oTextResource = this.getView().getModel("i18n").getResourceBundle();
		var sErrTxt1 = oTextResource.getText("PRINT3");
		var sErrTxt2 = oTextResource.getText("PRINT4");
		var sErrTxt3 = oTextResource.getText("PRINT5");
		var sErrTxt4 = oTextResource.getText("PRINT11");
		var aContexts = this.extensionAPI.getSelectedContexts();
		var arrVbeln = [];
		var sMessages;
		if (aContexts && aContexts.length > 0) {
			//Perform Action   
			for (var sCount = 0; sCount < aContexts.length; sCount++) {
				oBindingContext = new sap.ui.model.Context(oSelectedItem[sCount].getModel(), oSelectedItem[sCount].getBindingContext().getPath());

				if (oBindingContext.getProperty("DebCreNum")) {
					sDoc = oBindingContext.getProperty("DebCreNum");
				} else {
					sDoc = oBindingContext.getProperty("DebCreReq");
				}

				sVbeln = sVbeln + "|" + sDoc;
				arrVbeln.push(sDoc);

			}
			var sDate = this.getView().byId("DP1").getValue();
			var sTime = this.getView().byId("TP1").getValue();

			if (sDate) {
				if (sTime) {

					if (oDialog) {
						oDialog.close();
					}
					var fnSuccess = jQuery.proxy(function (oData, response) {

							/*							if (oData.MESSAGE === "Success") {
															sMessages = sErrTxt1;
														} else {
															if (oData.MESSAGE === "Error") {
																sMessages = sErrTxt2;
															}
														}*/
							if (oData.SUCCESS) {
								sMessages = sErrTxt1;
							} else {
								if (oData.MESSAGE) {
									sMessages = oData.MESSAGE;
								} else {
									sMessages = sErrTxt2;
								}
							}
							/*							oButton.setBusy(false);  */
							oDialog1.close();
							sap.m.MessageToast.show(sMessages, {
								duration: 5000, // default
								width: "15em", // default
								my: "center bottom",
								at: "center bottom",
								of: window, // default
								offset: "0 0", // default
								collision: "fit fit", // default
								autoClose: true, // default
								animationTimingFunction: "ease", // default
								animationDuration: 1000, // default
								closeOnBrowserNavigation: true // default
							});

							/*							this.removeSelections();*/
						}),

						oDataModl = this.getOwnerComponent().getModel();
					oDataModl.callFunction('/fnBillPrint', {
						urlParameters: {
							//	ACTION: "MODI",
							VBELN: sVbeln,
							DATE: sDate,
							TIME: sTime,
							IMMEDIATE: "",
							PRINTER: sPrinter,
							ENGNUM: "",
							DOC_TYPE_TEXT: "",
							FINALATT: "",
							PRINT: "",
							DEMODM: "",
						},
						method: "GET",
						success: fnSuccess
					});

				} else {
					sap.m.MessageBox.error(sErrTxt3, {});
				}

			} else {
				if (sTime) {
					sap.m.MessageBox.error(sErrTxt3, {});
				} else {

					if (oDialog) {
						oDialog.close();
					}
					var fnSuccess = jQuery.proxy(function (oData, response) {

							if (oData.MESSAGE === "Success") {
								sMessages = sErrTxt1;
							} else {
								if (oData.MESSAGE === "Error") {
									sMessages = sErrTxt2;
								}
							}
							/*		oButton.setBusy(false); */
							oDialog1.close();
							sap.m.MessageToast.show(sMessages, {
								duration: 5000, // default
								width: "15em", // default
								my: "center bottom",
								at: "center bottom",
								of: window, // default
								offset: "0 0", // default
								collision: "fit fit", // default
								autoClose: true, // default
								animationTimingFunction: "ease", // default
								animationDuration: 1000, // default
								closeOnBrowserNavigation: true // default
							});

							/*		this.removeSelections();*/
						}),

						oDataModl = this.getOwnerComponent().getModel();
					oDataModl.callFunction('/fnBillPrint', {
						urlParameters: {
							//ACTION: "MODI",
							VBELN: sVbeln,
							DATE: sDate,
							TIME: sTime,
							IMMEDIATE: "",
							PRINTER: "",
							ENGNUM: "",
							DOC_TYPE_TEXT: "",
							FINALATT: "",
							PRINT: "",
							DEMODM: "",
						},
						method: "GET",
						success: fnSuccess
					});
				}
			}

		} else {

			if (oDialog) {
				oDialog.close();
			}
			sap.m.MessageBox.error(sErrTxt4, {});
		}

	},
	//Cancel Popup
	onNoPressed: function () {

		var oDialog = this.getView().byId("BatchJob");
		if (oDialog) {
			oDialog.close();
		}
	},

	//Single Print
	onClickActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP10: function (oEvent) {
		var oTextResource = this.getView().getModel("i18n").getResourceBundle();
		var sErrTxt1 = oTextResource.getText("PRINT6");
		var sErrTxt2 = oTextResource.getText("PRINT7");
		var sErrTxt3 = oTextResource.getText("PRINT8");
		var sSelectedPath = this.extensionAPI.getSelectedContexts()[0].sPath;
		var sSelectedDoc = this.getView().getModel().getProperty(sSelectedPath).DebCreNum; //DebCreReq
		var sSelectedDoc1 = this.getView().getModel().getProperty(sSelectedPath).DebCreReq;
		var sSelectedDoctype = this.getView().getModel().getProperty(sSelectedPath).Dctype;
		var sSelectedEngNum = this.getView().getModel().getProperty(sSelectedPath).EngNum;
		var sSelectedFinalAtt = this.getView().getModel().getProperty(sSelectedPath).FinalAttachment;
		var sSelectedPrintStatus = this.getView().getModel().getProperty(sSelectedPath).PrintStatus;
		var oTextMessageSelectedDoc = oTextResource.getText("docSelectedText");
		var aContexts = this.extensionAPI.getSelectedContexts();
		var sMessages;
		// if (!sSelectedDoc) {
		// 	sap.m.MessageBox.error(oTextMessageSelectedDoc);
		// 	return;
		// }

		if (this.getView().getModel().getProperty(sSelectedPath).Cancelbillno) {
			sSelectedDoc = this.getView().getModel().getProperty(sSelectedPath).Cancelbillno;
		} else {
			if (this.getView().getModel().getProperty(sSelectedPath).DebCreNum) {
				sSelectedDoc = this.getView().getModel().getProperty(sSelectedPath).DebCreNum;
			} else {
				sSelectedDoc = this.getView().getModel().getProperty(sSelectedPath).DebCreReq;
			}
		}

		if (this.getView().getModel().getProperty(sSelectedPath).DebCreReq) {
			sSelectedDoc1 = this.getView().getModel().getProperty(sSelectedPath).DebCreReq;
		} else {
			sSelectedDoc1 = this.getView().getModel().getProperty(sSelectedPath).DebCreNum;
		}

		if (aContexts && aContexts.length > 1) {
			sap.m.MessageBox.error(sErrTxt2, {});
		} else {
			if (sSelectedDoc) {

				var fnSuccess = jQuery.proxy(function (oData, response) {
						if (oData.SUCCESS) {

							var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service
							var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
								target: {
									semanticObject: "ZPrintMaintain",
									action: "zmanage"
								}
								/*								params: {
																	DocId: sSelectedDoc,
																	Doctype: sSelectedDoctype,
																	EngNum: sSelectedEngNum,
																	FinalAtt: oData.FinalAtt,
																	PrintStatus: sSelectedPrintStatus,
																	Client: oData.Cname,
																	Partner: oData.Ename
																}*/
							}));
							var sStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
							//to add data in the storage&nbsp;
							sStorage.put("PrintKey", oData);
							oCrossAppNavigator.toExternal({
								target: {
									shellHash: hash
								}
							});

						} else {
							sMessages = oData.MESSAGE;
						}

						if (sMessages) {
							sap.m.MessageToast.show(sMessages, {
								duration: 5000, // default
								width: "15em", // default
								my: "center bottom",
								at: "center bottom",
								of: window, // default
								offset: "0 0", // default
								collision: "fit fit", // default
								autoClose: true, // default
								animationTimingFunction: "ease", // default
								animationDuration: 1000, // default
								closeOnBrowserNavigation: true // default
							});
						}

						/*						this.removeSelections();*/
					}),

					oDataModl = this.getOwnerComponent().getModel();
				oDataModl.callFunction('/fnBillPrint', {
					urlParameters: {
						//ACTION: "MODI",
						VBELN: sSelectedDoc1,
						DATE: "",
						TIME: "",
						IMMEDIATE: "",
						PRINTER: "",
						ENGNUM: sSelectedEngNum,
						DOC_TYPE_TEXT: sSelectedDoctype,
						FINALATT: "",
						PRINT: sSelectedPrintStatus,
						DEMODM: sSelectedDoc

					},
					method: "GET",
					success: fnSuccess
				});

			} else {

				sap.m.MessageBox.error(sErrTxt1, {});
			}
		}
	},
	onClickActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP11: function (oEvent) { //spool display
		var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service
		var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
			target: {
				semanticObject: "SpoolRequest",
				action: "display"
			}
		}));

		oCrossAppNavigator.toExternal({
			target: {
				shellHash: hash
			}
		});

	},

	onClickActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP12: function (oEvent) { //job display
		var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
		// get a handle on the global XAppNav service
		var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
			target: {
				semanticObject: "ApplicationJob",
				action: "show"
			},
			params: {
				JobCatalogEntryName: "/KNO/EM_PRINT_JOB_CAT"
			}
		}));
		var url = window.location.href.split('#')[0] + hash;
		sap.m.URLHelper.redirect(url, true);
		/*		oCrossAppNavigator.toExternal({
					target: {
						shellHash: hash
					}
				});
		*/
	},
	onClickActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP13: function (oEvent) { // Display Credit Note
		var oSelectedItem = oEvent.getSource().getParent().getParent().getTable().getSelectedItem();
		var oBindingContext = new sap.ui.model.Context(oSelectedItem.getModel(), oSelectedItem.getBindingContext().getPath());
		var sDocNumber = oBindingContext.getProperty("EngNum");
		var sDocDesc = oBindingContext.getProperty("EngDesc");
		var sDM = oBindingContext.getProperty("DebCreNum");
		var sCMR = oBindingContext.getProperty("DebCreReq");
		//var oTextResource = this.getView().getModel("i18n").getResourceBundle();
		//var sErrTxt = oTextResource.getText("ERRCNE");
		if (oBindingContext.getProperty("Cancelbillno")) {
			sDM = "";
		}
		var fnSuccess = jQuery.proxy(function (oData, response) {
				if (oData.SUCCESS) {
					if (oData.ENGNUM) {
						sDocNumber = oData.ENGNUM;
					}
					var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service
					var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
						target: {
							semanticObject: "ZCreditNote",
							action: "zmanage"
						},
						params: {

							DocId: sDocNumber,
							DocDesc: sDocDesc,
							DM: sDM,
							CMR: sCMR,
							Mode: "DISP"
								// dec_separator: oData.DEC_SEPARATOR,
								// date_format: oData.DATE_FORMAT
						}
					}));

					oCrossAppNavigator.toExternal({
						target: {
							shellHash: hash
						}
					});
				} else {

					this.displayErrorMessage(oData.MESSAGE);
				}
			},
			this);
		var oDataModl = this.getOwnerComponent().getModel();
		oDataModl.callFunction('/fnCreEditCN', {
			urlParameters: {
				ACTION: "DISP",
				VBELN: sCMR,
				APP_DOC: sDM
			},
			method: "GET",
			success: fnSuccess
		});

	},
	onClickActionxKNOxEM_D_DI_C_Y_BILL_CONSUMPApprove3: function (oEvent) {
		var oSelectedItem = oEvent.getSource().getParent().getParent().getSelectedItem();
		var sSelectedPath = this.extensionAPI.getSelectedContexts()[0].sPath;
		var sSelectedDoc = this.getView().getModel().getProperty(sSelectedPath).DebCreReq;
		var oBindingContext = new sap.ui.model.Context(oSelectedItem.getModel(), oSelectedItem.getBindingContext().getPath());
		var oTextResource = this.getView().getModel("i18n").getResourceBundle();
		var sErrTxt = oTextResource.getText("ERRDME");
		//Validate for Edit BRE
		// if (!oBindingContext.getProperty("DebCreNum")) {
		// 	var sMessage = sErrTxt;

		// 	this.displayErrorMessage(sMessage);
		// 	return;
		// }
		var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kno/EM_BILL_SEARCH_SRV/", {
			json: true
		});
		var fnSuccess = jQuery.proxy(function (oData, response) {
			sap.m.MessageBox.information(oData.MESSAGE);
		}, this);
		var fnError = jQuery.proxy(function (d) {}, this);
		oModel.callFunction(
			"/fnBillApprove", {
				method: "GET",
				urlParameters: {
					VBELN: sSelectedDoc

				},
				success: fnSuccess,
				error: fnError
			});

	},
	onClickActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP14: function (oEvent) {

		var oSelectedItem = oEvent.getSource().getParent().getParent().getSelectedItem();
		var oBindingContext = new sap.ui.model.Context(oSelectedItem.getModel(), oSelectedItem.getBindingContext().getPath());
		var sSelectedPath = this.extensionAPI.getSelectedContexts()[0].sPath;
		var sSelectedDoc = this.getView().getModel().getProperty(sSelectedPath).DebCreReq;

		var oTextResource = this.getView().getModel("i18n").getResourceBundle();
		var sErrTxt = oTextResource.getText("ERRDME");
		var oList = oEvent.getSource().getParent().getParent();
		// var oRowBinding = oList._getRowBinding();
		// var sUrl = oRowBinding.getModel().sServiceUrl;
		//changes for download dmr data by prashant kumar 16.04.2021
		var sUrl = oList.getModel().sServiceUrl;

		//Validate for Download
		if (oBindingContext.getProperty("Cancelbillno") || oBindingContext.getProperty("DebCreNum")) {

			var sMessage = sErrTxt;

			this.displayErrorMessage(sMessage);
			return;
		}
		var fnSuccess = jQuery.proxy(function (oData, response) {
				if (oData.SUCCESS) {
					if (sSelectedDoc) {
						sUrl = sUrl + "/downloadDMRSet?$filter=VBELN eq" + "'" + sSelectedDoc + "'" + "&$format=xlsx";
						if (sUrl && sUrl.length > 2048 && sap.ui.Device.browser.msie) {
							// thrown info to user!
							sap.m.MessageBox.error(sap.ui.getCore().getLibraryResourceBundle("sap.ui.comp").getText("DOWNLOAD_TOO_COMPLEX_TEXT"));
							return;
						}
						window.open(sUrl);
					}
				} else {

					this.displayErrorMessage(oData.MESSAGE);
				}
			},
			this);

		var oDataModl = this.getOwnerComponent().getModel();
		oDataModl.callFunction('/fnCreEditBre', {
			urlParameters: {
				ACTION: "DOWN",
				VBELN: sSelectedDoc
			},
			method: "GET",
			success: fnSuccess
		});
	},

	onClickActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP15: function (oEvent) {
		var oSelectedItem = oEvent.getSource().getParent().getParent().getTable().getSelectedItem();
		var oBindingContext;
		var sVbeln = " ";
		var oDataModl;

		var oTextResource = this.getView().getModel("i18n").getResourceBundle();
		oBindingContext = new sap.ui.model.Context(oSelectedItem.getModel(), oSelectedItem.getBindingContext().getPath());
		sVbeln = oBindingContext.getProperty("DebCreReq");
		this.oBindingContext = oBindingContext;
		var sError = oTextResource.getText("CMRREJERROR");
		//var that = oEvent.getSource().getParent().getParent().getTable();

		if (oBindingContext.getProperty("DebCreNum") || oBindingContext.getProperty("Cancelbillno") || (!oBindingContext.getProperty(
				"DebCreReq"))) {
			this.displayErrorMessage(sError);
			return;
		}
		var sConfirmMessage = oTextResource.getText("CMRREJ");
		var sDialogHeader = oTextResource.getText("CONFIRM");
		var sReasonType = "";
		var fnSuccess = jQuery.proxy(function (oData, response) {

				if (oData.SUCCESS) {
					this.displayMessage(oData.MESSAGE);

				} else {
					this.displayErrorMessage(oData.MESSAGE);
				}
				sap.ui.core.BusyIndicator.hide();

			},
			this);

		sap.m.MessageBox.show(
			sConfirmMessage,
			sap.m.MessageBox.Icon.WARNING,
			sDialogHeader,
			/*this.addStyleClass("Hello"),*/
			[sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
			jQuery.proxy(function (a) {
				if (a === sap.m.MessageBox.Action.YES) {
					sap.ui.core.BusyIndicator.show(0);
					oDataModl = this.getOwnerComponent().getModel();
					oDataModl.callFunction('/fnCanRejBill', {
						urlParameters: {

							VBELN: sVbeln,
							ACTION: "CMRR",
							REJRES: sReasonType

						},
						method: "GET",
						success: fnSuccess
					});
				}
				// else if (a === sap.m.MessageBox.Action.NO) {}

			}, this));
	},
	onClickActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP16: function (oEvent) {
		this.CancelBill(oEvent, "CANP");
	},
	onClickActionxKNOxEM_D_DI_C_Y_BILL_CONSUMP17: function (oEvent) {
		this.CancelnReject(oEvent, "CARP");
	}

});