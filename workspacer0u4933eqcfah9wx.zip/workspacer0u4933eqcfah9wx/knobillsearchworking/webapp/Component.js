jQuery.sap.declare("kno.em.billsrch.germany.Component");
sap.ui.getCore().loadLibrary("sap.ui.generic.app");
jQuery.sap.require("sap.ui.generic.app.AppComponent");

/*sap.ui.generic.app.AppComponent.extend("kno.em.billsrch.germany.Component", {
	metadata: {
		"manifest": "json"
	}
});*/


sap.ui.define(["sap/suite/ui/generic/template/lib/AppComponent"], function (AppComponent) {
	"use strict";
	return AppComponent.extend("kno.em.billsrch.germany.Component", {
		metadata: {
			"manifest": "json"
		}
	});
});