jQuery.sap.declare("cross.fnd.fiori.inbox.d49_ca_firo_inbox_ext.KGOCAINBOXExtension.Component");

// use the load function for getting the optimized preload file if present
sap.ui.component.load({
	name: "cross.fnd.fiori.inbox.d49_ca_firo_inbox_ext",
	// Use the below URL to run the extended application when SAP-delivered application is deployed on SAPUI5 ABAP Repository
	url: "/sap/bc/ui5_ui5/KGO/CAINBOX"
		// we use a URL relative to our own component
		// extension application is deployed with customer namespace
});

this.cross.fnd.fiori.inbox.d49_ca_firo_inbox_ext.Component.extend(
	"cross.fnd.fiori.inbox.d49_ca_firo_inbox_ext.KGOCAINBOXExtension.Component", {
		metadata: {
			manifest: "json"
		}
	});