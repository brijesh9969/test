sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"sap/ui/model/Filter",
	"sap/m/MessageToast",
	"sap/m/MessageBox"
], function (Controller, JSONModel, History, Filter, MessageToast, MessageBox) {
	"use strict";

	return Controller.extend("kno.em.billatt.germany.controller.View1", {

		onInit: function () {

			var sStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session),
				sNavData = sStorage.get("AttKey");
			var sImportingParamDocId = sNavData.VBELN,
				sImportingParamDocType = sNavData.DOC_TYPE,
				sImportingParamDctype = sNavData.PRINT,
				sImportingParamEngNum = sNavData.ENGNUM,
				sImportingParamEngDesc = sNavData.ENGDESC,
				sImportingParamclient = sNavData.Cname,
				sImportingParamFinalAtt = sNavData.FINALATT,
				sImportingParamDemo = sNavData.DemoDm,
				sImportingParamDisp1 = sNavData.ParamDisp;

			if (sImportingParamDisp1) {
				if (sImportingParamDisp1 == false) {
					var sImportingParamDisp = true;
				} else {
					sImportingParamDisp = false;
				}
			} else {
				sImportingParamDisp = true;
			}
			if (!sImportingParamDocId) {
				sImportingParamDocId = "";
			}

			if (!sImportingParamDocType) {
				sImportingParamDocType = "";
			}

			if (sImportingParamDocId.length < 10) {

				for (var i = sImportingParamDocId.length; i < 10; i++) {

					sImportingParamDocId = '0' + sImportingParamDocId;
				}
			}

			if (sImportingParamDemo.length < 10) {

				for (var j = sImportingParamDemo.length; j < 10; j++) {

					sImportingParamDemo = '0' + sImportingParamDemo;
				}
			}

			/* Start of change by Satabdi Das on 14-June-2021 for displaying Document text in the header section*/
			var sDocTxt, sDisDocTxt;
			// Assign Document Type text based on Doc type parameter
			if (sImportingParamDctype === "CMR") {
				sDocTxt = "BUS2094"; //Credit Memo Request
				sDisDocTxt = "Credit Memo Request";
			} else if (sImportingParamDctype === "DP") {
				sDocTxt = "VBRK"; //DownPayment Document
				sDisDocTxt = "DownPayment Document";
			} else if (sImportingParamDctype === "DMR") {
				sDocTxt = "BUS2096"; //Debit Memo request
				sDisDocTxt = "Debit Memo Request";
			} else if (sImportingParamDctype === "DM") {
				sDocTxt = "VBRK";
				sDisDocTxt = "Debit Memo"; //Debit Memo 
			} else {
				sDocTxt = "VBRK";
				sDisDocTxt = "Credit Memo"; //Credit Memo
			}
			/* End of change by Satabdi Das on 14-June-2021 for displaying Document text in the header section*/

			var oModel = new JSONModel({
				DocId: sImportingParamDocId,
				DocType: sImportingParamDctype,
				Dctype: sDocTxt,
				sDisDocTxt: sDisDocTxt,
				/* sDisDocTxt Added by Satabdi Das on 14-June-2021*/
				EngNum: sImportingParamEngNum,
				EngDesc: sImportingParamEngDesc,
				client: sImportingParamclient,
				FinalAtt: sImportingParamFinalAtt,
				Demo: sImportingParamDemo,
				ParamDisp: sImportingParamDisp

			});
			this.getOwnerComponent().setModel(oModel, "mimportaingParams");

			this.fetchAttachmentList();
		},

		/*Start of change by Satabdi Das on 31-May-2021 */
		fetchAttachmentList: function (oEvent) {
			var mParamsModel = this.getOwnerComponent().getModel("mimportaingParams");
			var sDctype = mParamsModel.getProperty("/Dctype");
			var sDemo = mParamsModel.getProperty("/Demo");

			sap.ui.core.BusyIndicator.show(0);
			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
				if (d.results.length !== 0) {
					mParamsModel.setProperty("/FileNameSet", d.results);
				}
				mParamsModel.refresh(true);
			}, this);

			var fnError = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide(0);
			}, this);

			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kno/EM_BILL_ATTACHMENT_SRV/", {
				json: true
			});

			oModel1.callFunction('/fnAttList', {
				urlParameters: {
					ObjectKey: sDemo,
					ObjectType: sDctype
				},
				method: "GET",
				success: fnSuccess,
				error: fnError
			});

		},
		onAddAttachment: function (oEvent) {
			var uploadCollection = oEvent.getSource();
			var collectionItemArr = uploadCollection.getItems();
			var files = oEvent.getParameter("files");
			var dupfile;

			for (var i = 0; i < collectionItemArr.length; i++) {
				if (collectionItemArr[i].getProperty("fileName") === files[0].name) {
					jQuery.sap.log.error("Duplicate file not allowed");
					MessageBox.error("Duplicate filename not allowed", {
						title: "Error", // default
						onClose: null, // default
						styleClass: "", // default
						initialFocus: null, // default
						textDirection: sap.ui.core.TextDirection.Inherit // default
					});
					dupfile = true;
					break;
				}
			}
			if (files[0].size <= 0) {
				MessageBox.error("Files with size 0kb not allowed to upload", {
					title: "Error", // default
					onClose: null, // default
					styleClass: "", // default
					initialFocus: null, // default
					textDirection: sap.ui.core.TextDirection.Inherit // default
				});
				oEvent.getSource().abortUpload(oEvent.getParameters());
				return;
			}

			if (dupfile === true) {
				oEvent.getSource().abortUpload(oEvent.getParameters());
				return;
			}

			var uploadUrl = "/sap/opu/odata/kno/EM_BILL_ATTACHMENT_SRV/BillFileSet";

			uploadCollection.setUploadUrl(uploadUrl);

			var mAttachments = this.getView().getModel();

			var token = "x-cs" + "rf-token";
			mAttachments.refreshSecurityToken();
			var T = mAttachments.getHeaders()[token];

			var csrfToken = new sap.m.UploadCollectionParameter({
				name: token,
				value: T
			});

			var reqType = new sap.m.UploadCollectionParameter({
				name: "X-Requested-With",
				value: "XMLHttpRequest"
			});

			uploadCollection.removeAllHeaderParameters();
			uploadCollection.addHeaderParameter(csrfToken);
			uploadCollection.addHeaderParameter(reqType);

		},
		onBeforeUploadStarts: function (oEvent) {
			var mParamsModel = this.getOwnerComponent().getModel("mimportaingParams");
			var sDctype = mParamsModel.getProperty("/Dctype");
			var sDemo = mParamsModel.getProperty("/Demo");

			var uPloadpar = oEvent.getParameter("fileName") + "|" + sDctype + "|" + sDemo + "|" + "X";

			// Header Slug
			var oCustomerHeaderSlug = new sap.m.UploadCollectionParameter({
				name: "slug",
				value: uPloadpar
			});

			oEvent.getParameters().addHeaderParameter(oCustomerHeaderSlug);
		},
		handleUploadComplete: function (oEvent) {
			this.fetchAttachmentList();
		},
		handleTypeMissmatch: function (oEvent) {
			var aFileTypes = oEvent.getSource().getFileType();
			jQuery.each(aFileTypes, function (key, value) {
				aFileTypes[key] = "*." + value;
			});
			var sSupportedFileTypes = aFileTypes.join(", ");
			MessageToast.show("The file type *." + oEvent.getParameter("fileType") +
				" is not supported. Choose one of the following types: " +
				sSupportedFileTypes);
		},
		onDeleteAttachment: function (oEvent) {
			var mParamsModel = this.getOwnerComponent().getModel("mimportaingParams");
			var sDctype = mParamsModel.getProperty("/Dctype");
			var sDemo = mParamsModel.getProperty("/Demo");
			var sDocNum;
			var sFileId;

			/*	if (oEvent.getParameter("item").getProperty("fileName")) {
					var fileName = oEvent.getParameter("item").getProperty("fileName").replace(/\s/g, "*");
				}*/

			//Attachment to delete
			var selectedAttachment = oEvent.getParameter("documentId");

			//Update Attachment list in Front End
			var attachmentArray = mParamsModel.getProperty("/FileNameSet");
			for (var i = 0; i < attachmentArray.length; i++) {
				if (attachmentArray[i].Filename === selectedAttachment) {
					sDocNum = attachmentArray[i].Documentnumber;
					sFileId = attachmentArray[i].FileId;
					attachmentArray.splice(i, 1);
					break;
				}
			}
			mParamsModel.setProperty("/FileNameSet", attachmentArray);

			//Backend DELETE POST call queued

			var sPath = "/BillFileSet(Objecttype='" + sDctype + "',Objectkey='" + sDemo +
				"',FileId='" + sFileId + "',Documentnumber='" + sDocNum + "')/$value";

			var fnSuccess = jQuery.proxy(function (d) {
				sap.ui.core.BusyIndicator.hide();
				this.getView().getModel("mModelSummary").refresh(true);

			}, this);

			var fnError = jQuery.proxy(function (d) {
				var r = JSON.parse(JSON.stringify(d));
				sap.ui.core.BusyIndicator.hide();
				MessageToast.show(r, {
					autoClose: true,
					width: "20rem"
				});

			}, this);

			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kno/EM_BILL_ATTACHMENT_SRV/", {
				json: true
			});

			oModel1.remove(sPath, {
				success: fnSuccess,
				error: fnError
			});
		},
		onPressDownload: function (oEvent) {
			sap.ui.core.BusyIndicator.show(0);
			var mParamsModel = this.getOwnerComponent().getModel("mimportaingParams");
			var ofileName = oEvent.getSource().getParent("oParent").getProperty("fileName");
			var sDctype = mParamsModel.getProperty("/Dctype");
			var sDemo = mParamsModel.getProperty("/Demo");
			var sFileId;
			var sDocNum;
			var auxArray1 = new Array();
			var that = this;
			var pdfURL = null;

			var attachmentArray = mParamsModel.getProperty("/FileNameSet");
			for (var i = 0; i < attachmentArray.length; i++) {
				if (attachmentArray[i].Filename === ofileName) {
					sDocNum = attachmentArray[i].Documentnumber;
					sFileId = attachmentArray[i].FileId;
					break;
				}
			}

			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/kno/EM_BILL_ATTACHMENT_SRV/", {
				json: true
			});

			var oDataQuery2 = "/BillFileSet(Objecttype='" + sDctype + "',Objectkey='" + sDemo +
				"',FileId='" + sFileId + "',Documentnumber='" + sDocNum + "')/$value";

			oModel1.read(oDataQuery2, null,
				null,
				false,

				function (oData, oResponse) {
					sap.ui.core.BusyIndicator.hide();
					if (oResponse) {
						sap.ui.core.BusyIndicator.hide(0);
						auxArray1 = oData;
						pdfURL = oResponse.requestUri;

					} else {
						var e = oResponse.headers;

						if (e) {
							sap.ui.core.BusyIndicator.hide(0);
							MessageBox.error("Some error has occured.");

						}
					}
				},
				function readError(e) {
					sap.ui.core.BusyIndicator.hide(0);
					var r = JSON.parse(JSON.stringify(e));

					MessageToast.show('No document generated', {
						autoClose: true,
						width: "20rem"
					});

				}
			);
			if (pdfURL) {

				window.open(pdfURL, "_self");
				setTimeout(function () {
					sap.ui.core.BusyIndicator.hide(0);
				}, 10000);
			} else {

				setTimeout(function () {
					sap.ui.core.BusyIndicator.hide(0);
				}, 1000);
			}

		},
		/*End of change by Satabdi Das on 31-May-2021*/

		onNavBack: function () {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				oCrossAppNavigator.toExternal({
					target: {
						shellHash: "#Shell-home"
					}
				});
			}
		},

	});
});