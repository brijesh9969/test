sap.ui.define([
	"kno/em/textmaint/germany/controller/BaseController",
	"sap/ui/model/json/JSONModel"
], function(BaseController, JSONModel) {
	"use strict";

	return BaseController.extend("kno.em.textmaint.germany.controller.App", {});

});