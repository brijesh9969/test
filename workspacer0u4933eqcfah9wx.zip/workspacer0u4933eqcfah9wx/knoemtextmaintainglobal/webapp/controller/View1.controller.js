sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"sap/m/MessageToast",
	"sap/ui/model/json/JSONModel",
	"sap/m/Input",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/routing/History"
], function (Controller, MessageBox, MessageToast, JSONModel, Input, Filter, FIlterOperator, History) {
	"use strict";
	return Controller.extend("kno.em.textmaint.germany.controller.View1", {
		onBeforeRendering: function () {
			var v = "";
		},
		// Trigger Hook method to initialize view&nbsp;&nbsp;
		onInit: function () {
			// Get Component Data
			// var oComponentData = this.getOwnerComponent().getComponentData();
			// Get Startup parameters&nbsp;
			var sStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session),
				sNavData = sStorage.get("TextKey");
			// // Temporarly added for work in Local. Remove it once done. !!!! -Start
						/*var tmpSNavData = {
								"ABS_TEXT": "",
								"ACTION": "",
								"BTP": "X",
								"Cname": "Wolf Schröder",
								"DemoDm": "4310001227",
								"DocType": "DMR",
								"DocTypeText": "Debit Memo Request",
								"ENGNUM": "",
								"Ename": "Rudi Meyer",
								"KUNNR": "65000015",
								"Langu": "D",
								"MESSAGE": "DM/CM already printed, no text is allowed to maintain.",
								"ParamDisp": "",
								"Print": "",
								"REJRES": "",
								"SUCCESS": "X",
								"VBELN": "9100000155",
								"Vkorg": "0001"
							};
							sNavData = tmpSNavData;*/
			// Temporarly added for work in Local. Remove it once done. !!!! - End
			var sImportingParamDocId = sNavData.VBELN,
				sImportingParamDocType = sNavData.DocType,
				sImportingParamClnt = sNavData.Cname,
				sImportingParamPrt = sNavData.Ename,
				sImportingParamDemo = sNavData.DemoDm,
				sImportingParamDisp = sNavData.ParamDisp,
				sImportingLangu = sNavData.Langu,
				sImportingVkorg = sNavData.Vkorg,
				sImportingKunnr = sNavData.KUNNR,
				sImportingParamDocTypeText = sNavData.DocTypeText,
				sImportingDocStatus = sNavData.att_status;

			if (sNavData.ABS_TEXT === 'X') {
				var bABSDisp = true;
			} else {
				bABSDisp = false;
			}

			// if (oComponentData.startupParameters && jQuery.isEmptyObject(oComponentData.startupParameters) === false) {
			// 	if (oComponentData.startupParameters.DocId) {
			// 		// Get Document ID from Startup parameters
			// 		var sImportingParamDocId = oComponentData.startupParameters.DocId[0];
			// 	}
			// 	if (oComponentData.startupParameters.DocType) {
			// 		// Get Document Type from Startup parameters
			// 		var sImportingParamDocType = oComponentData.startupParameters.DocType[0];
			// 	}
			// 	if (oComponentData.startupParameters.Client) {
			// 		// Get Client from Startup parameters
			// 		var sImportingParamClnt = oComponentData.startupParameters.Client[0];
			// 	}
			// 	if (oComponentData.startupParameters.Partner) {
			// 		// Get Partner from Startup parameters
			// 		var sImportingParamPrt = oComponentData.startupParameters.Partner[0];
			// 	}

			// 	if (oComponentData.startupParameters.Demo) {
			// 		// Get Partner from Startup parameters
			// 		var sImportingParamDemo = oComponentData.startupParameters.Demo[0];
			// 	}

			// 	if (oComponentData.startupParameters.ParamDisp) {
			// 		// Get Country Key from Startup parameters
			// 		var sImportingParamDisp = oComponentData.startupParameters.ParamDisp[0];
			// 	}
			// }
			// Left padding with zero
			if (!sImportingParamDocId) {
				sImportingParamDocId = "";
			} else {
				if (sImportingParamDocId.length < 10) {
					for (var i = sImportingParamDocId.length; i < 10; i++) {
						sImportingParamDocId = "0" + sImportingParamDocId;
					}
				}
			}
			var sDocTxt;
			var sDocStatus = false;
			var oTextResource = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var sEdit = oTextResource.getText('EditBtnText');
			var sDMR = oTextResource.getText('DMR');
			// Assign Document Type text based on Doc type parameter
			if (sImportingParamDocTypeText) {
				sDocTxt = sImportingParamDocTypeText;
			} else {
				if (sImportingParamDocType === "CMR") {
					sDocTxt = "Credit Memo Request"; // Credit Memo Request
				} else if (sImportingParamDocType === "DP") {
					sDocTxt = "Down Payment"; // Down Payment
				} else if (sImportingParamDocType === "DM") {
					sDocTxt = "Debit Memo"; // Debit Memo
				} else if (sImportingParamDocType === "CM") {
					sDocTxt = "Credit Memo"; //Credit Memo
					sDocStatus = true;
				} else if (sImportingParamDocType === "EM") {
					sDocTxt = "Engagement"; //Credit Memo
				} else {
					sDocTxt = sDMR; // Debit Memo Request
				}
			}

			if (sImportingParamDocType === "CMR") {
				sDocTxt = "Credit Memo Request"; // Credit Memo Request
			} else if (sImportingParamDocType === "DP") {
				sDocTxt = "Down Payment"; // Down Payment
				sNavData.BTP = '';
				//For downpayment language should be invisible
				sDocStatus = true;
			} else if (sImportingParamDocType === "DM") {
				sDocTxt = "Debit Memo"; // Debit Memo
				sDocStatus = true;
				sNavData.BTP = '';
			} else if (sImportingParamDocType === "CM") {
				sDocTxt = "Credit Memo"; //Credit Memo
				sDocStatus = true;
				sNavData.BTP = '';
			} else if (sImportingParamDocType === "EM") {
				sDocTxt = "Engagement"; //Credit Memo
				//	sDocStatus = true;
				sNavData.BTP = "X";
			} else if (sImportingParamDocType === "KPMG Invoice") {
				sDocTxt = "KPMG Invoice"; //KPMG Invoice
				sDocStatus = true;
				sNavData.BTP = '';
			} else {
				sDocTxt = sDMR; // Debit Memo Request
			}

			var sdocno = sImportingParamDocId.substring(0, 2);

			if (sdocno === "45") {
				sDocStatus = true;
			} else {
				if (sImportingParamDocType === "DP") {
					sDocStatus = true;
				} else {
					sDocStatus = false;
				}
			}

			if (sNavData.BTP === 'X') {
				var bBTPDisp = true;
			} else {
				bBTPDisp = false;
			}
			// santosh
			// bBTPDisp= true;
			/*var mDMR = {
            	sDocStatus: sDocStatus
            };
			var mDocStat = this.getOwnerComponent().getModel("mDocStat");
			mDocStat.setProperty("/sDocStat", mDMR);*/
			// var specialChars = "%20";
			// if (sImportingParamClnt) {
			// 	sImportingParamClnt = sImportingParamClnt.replace(new RegExp(specialChars, "gi"), " ");
			// }
			// if (sImportingParamPrt) {
			// 	sImportingParamPrt = sImportingParamPrt.replace(new RegExp(specialChars, "gi"), " ");
			// }

			// var umlet = "%C3%B6";
			// if (sImportingParamClnt) {
			// 	sImportingParamClnt = sImportingParamClnt.replace(new RegExp(umlet, "gi"), "ö");
			// }

			if (sImportingParamDisp === "X") {
				var disp = true;
			} else {
				disp = false;
			}
			// Read Header Text
			this.ReadHdrTxt(sImportingParamDocId, sImportingLangu, sImportingVkorg);

			if (bABSDisp === true) {
				// Read ABS Text
				this.ReadABSTxt(sImportingParamDocId, sImportingLangu);
			}

			if (bBTPDisp === true) {
				// Read BTP Address
				this.ReadBTPAdr(sImportingParamDocId, sImportingKunnr);
				this.ReadBTPAdrt(sImportingParamDocId, sImportingKunnr);
			}

			// Setting Importing parameters to mimportaingParams JSON Model to display details in header section
			var oModel = new JSONModel({
				DocId: sImportingParamDocId,
				// Document ID
				DocType: sDocTxt,
				// Document Type text
				Client: sImportingParamClnt,
				// Client
				Partner: sImportingParamPrt, // Partner

				Demo: sImportingParamDemo, // Selected Docno. to be diaplayed&nbsp;
				Langu: sImportingLangu, // Language
				Vkorg: sImportingVkorg, // Sales Org
				ParamDisp: disp, // Parameter Display Check
				ABSDisp: bABSDisp, // ABS Text Display Check
				BTPDisp: bBTPDisp, // BTP Display Check
				Kunnr: sImportingKunnr, // Bill to Party
				DMR: sDocStatus
			});
			this.getOwnerComponent().setModel(oModel, "mimportaingParams");
			// Set Visiblity and enable the buttons dynamically
			this.getView().byId("_HeadPrvTA").setEditable(false);
			this.getView().byId("_idEditDispBtn").setText(sEdit);
			this.getView().byId("_idEditDispBtn").setEnabled(false);
			this.getView().byId("_idEditDispBtn").setIcon("sap-icon://user-edit");
			this.getView().byId("_idSaveBtn").setVisible(false);
			this.byId("_idPrvBtn").setEnabled(false);
		},
		// Read Header Text Based on Document Id as Importing Parameter
		ReadHdrTxt: function (mImpDocId, mImpLangu, mImpVkorg) {
			// DocId data declaration to get document Id from importing parameter
			var sdocId = mImpDocId;
			// Get Default model reference.
			var oModel = this.getOwnerComponent().getModel();
			// Success Function of OData Call&nbsp;
			var fnHDRTxtSuccess = jQuery.proxy(function (oData) {
				var oResult = JSON.parse(JSON.stringify(oData));
				// Get mHdrTxtID JSON Model and set OData results to it.
				var mHdrTxtID = this.getOwnerComponent().getModel("mHdrTxtID");
				mHdrTxtID.setProperty("/items", oResult.results);
				this.getView().setModel(mHdrTxtID, "mHdrTxtID");
			}, this);
			// Error Function of OData Call
			var fnHDRTxtError = jQuery.proxy(function (oData) {
				this.oResult = JSON.parse(JSON.stringify(oData));
			}, this);

			var aTxtTypFilt = [];
			aTxtTypFilt.push(new sap.ui.model.Filter("Vkorg", "EQ", mImpVkorg));
			// Define parameters for OData call
			var mParams = {
				filters: aTxtTypFilt,
				success: fnHDRTxtSuccess,
				error: fnHDRTxtError
			};
			// Set path to retreive result
			var sFixPath = "/TextSelParamSet(DocumentId='";
			var sItemId = "";
			var sLangu = mImpLangu;
			var sSep = "',";
			// Create path for OData call
			var sPath = sFixPath + sdocId + sSep + "ItemId='" + sItemId + sSep + "Langu='" + sLangu + "')/ValueHelpTextIdSet";
			// Read OData based on path and parameters
			oModel.read(sPath, mParams);
		},

		// Read ABS Text Based on Document Id as Importing Parameter
		ReadABSTxt: function (mImportingParamDocId, mImportingLangu) {
			// DocId data declaration to get document Id from importing parameter
			var sdocId = mImportingParamDocId;
			// Get Default model reference.
			var oModel = this.getOwnerComponent().getModel();
			// Success Function of OData Call&nbsp;
			var fnABSTxtSuccess = jQuery.proxy(function (oData) {
				var oResult = JSON.parse(JSON.stringify(oData));
				// Get mABSTxt JSON Model and set OData results to it.
				var mABSTxt = this.getOwnerComponent().getModel("mABSTxt");
				if (oResult.results) {
					mABSTxt.setProperty("/items", oResult.results);
				}
				this.getView().setModel(mABSTxt, "mABSTxt");
			}, this);
			// Error Function of OData Call
			var fnABSTxtError = jQuery.proxy(function (oData) {
				this.oResult = JSON.parse(JSON.stringify(oData));
			}, this);
			// Define parameters for OData call
			var mParams = {
				success: fnABSTxtSuccess,
				error: fnABSTxtError
			};
			// Set path to retreive result
			var sFixPath = "/TextSelParamSet(DocumentId='";
			var sItemId = "",
				sLangu = mImportingLangu,
				sSep = "',";
			// Create path for OData call
			var sPath = sFixPath + sdocId + sSep + "ItemId='" + sItemId + sSep + "Langu='" + sLangu + "')/AbstextNav";
			// Read OData based on path and parameters
			oModel.read(sPath, mParams);
		},

		// Read Bill to Party Address Based on Document Id and Bill to Party No. as Importing Parameter
		ReadBTPAdr: function (mImportingParamDocId, mImportingKunnr) {
			// DocId data declaration to get document Id from importing parameter
			var sdocId = mImportingParamDocId;
			var skunnr = mImportingKunnr;
			// Get Default model reference.
			var oModel = this.getOwnerComponent().getModel();
			// Success Function of OData Call&nbsp;
			var fnBTPAdrSuccess = jQuery.proxy(function (oData) {
				var oResult = JSON.parse(JSON.stringify(oData));
				// Get mBTPAdr JSON Model and set OData results to it.
				var mBTPAdr = this.getOwnerComponent().getModel("mBTPAdr");
				mBTPAdr.setProperty("/AddrToBillParty", oResult);
				this.getView().byId("oCombobox").setSelectedKey(oData.Title); /*Added by Satabdi Das on 09-June-2021*/
				// 	var oModel1 = new JSONModel({
				// 	City1: oResult.City1,
				// 	Country: oResult.Country,
				// 	Email:oResult.Email,
				// 	HouseNum1:oResult.HouseNum1,
				// 	Name1:oResult.Name1,
				// 	Name2:oResult.Name2,
				// 	Name3:oResult.Name3,
				// 	Name4:oResult.Name4,
				// 	PoBox:oResult.PoBox,
				// 	PostCode1:oResult.PostCode1,
				// 	PostCode2:oResult.PostCode2,
				// 	PostCode3:oResult.PostCode3,
				// 	Title:oResult.Title,
				// 	Street:oResult.Street,
				// 	StrSuppl1:oResult.StrSuppl1

				// });
				// this.getOwnerComponent().setModel(oModel1, "mBTPAdr");
				// 	var mBTPAdr = this.getOwnerComponent().getModel("mBTPAdr");
				// 	if (oResult.results) {
				// 		mBTPAdr.setProperty(oResult.results);
				// 	}
				// 	this.getView().setModel(mBTPAdr, "mBTPAdr");
			}, this);
			// Error Function of OData Call
			var fnBTPAdrError = jQuery.proxy(function (oData) {
				this.oResult = JSON.parse(JSON.stringify(oData));
			}, this);
			// Define parameters for OData call
			var mParams = {
				success: fnBTPAdrSuccess,
				error: fnBTPAdrError
			};
			// Set path to retreive result
			var sFixPath = "/BtpAddrSet(VBELN='";
			var sSep = "',";
			// Create path for OData call
			var sPath = sFixPath + sdocId + sSep + "KUNNR='" + skunnr + "')";
			// Read OData based on path and parameters
			oModel.read(sPath, mParams);
		},
		// Read Bill to Party Address Based on Document Id and Bill to Party No. as Importing Parameter
		ReadBTPAdrt: function (mImportingParamDocId, mImportingKunnr) {
			// DocId data declaration to get document Id from importing parameter
			var sdocId = mImportingParamDocId;
			var skunnr = mImportingKunnr;
			// Get Default model reference.
			var oModel = this.getOwnerComponent().getModel();
			// Success Function of OData Call&nbsp;
			var fnBTPAdrtSuccess = jQuery.proxy(function (oData) {
				var oResult = JSON.parse(JSON.stringify(oData));
				// Get mBTPAdr JSON Model and set OData results to it.
				var mBTPAdr = this.getOwnerComponent().getModel("mBTPAdr");
				mBTPAdr.setProperty("/TitleDropDown", oData.results);
				// this.getView().byId("oCombobox").setSelectedKey(oResult.Title);
			}, this);
			// Error Function of OData Call
			var fnBTPAdrtError = jQuery.proxy(function (oData) {
				this.oResult = JSON.parse(JSON.stringify(oData));
			}, this);
			// Define parameters for OData call
			var mParams = {
				success: fnBTPAdrtSuccess,
				error: fnBTPAdrtError
			};
			// Set path to retreive result
			var sFixPath = "/BtpAddrSet(VBELN='";
			var sSep = "',";
			// Create path for OData call
			var sPath = sFixPath + sdocId + sSep + "KUNNR='" + skunnr + "')/BtptitleNav";
			// Read OData based on path and parameters
			oModel.read(sPath, mParams);
		},
		// Read Parameter value and set in mParamValue model.
		ReadParamValue: function (mImpValue) {
			// Get Default model reference.
			var oModel = this.getOwnerComponent().getModel();

			// Success Function of OData Call&nbsp;
			var fnParValSuccess = jQuery.proxy(function (oData) {
				var oResult = JSON.parse(JSON.stringify(oData));
				// Get mParamValue JSON Model and set OData results to it.
				var mParamValue = this.getOwnerComponent().getModel("mParamValue");
				mParamValue.setProperty("/values", oResult.results);
				this.getView().setModel(mParamValue, "mParamValue");
			}, this);
			// Error Function of OData Call
			var fnParValError = jQuery.proxy(function (oData) {
				this.oResult = JSON.parse(JSON.stringify(oData));
			}, this);
			//Prepare filter range table to get parameter values
			var sParValFilt = [];
			// sParValFilt.push(new sap.ui.model.Filter("Tdobject", "EQ", mImpValue.DocId));
			sParValFilt.push(new sap.ui.model.Filter("Tdobject", "EQ", mImpValue.TxtObj));
			sParValFilt.push(new sap.ui.model.Filter("TextId", "EQ", mImpValue.TxtId));
			// Define parameters for OData call
			var mParams = {
				context: null,
				urlParameters: null,
				async: false,
				filters: sParValFilt,
				success: fnParValSuccess,
				error: fnParValError
			};
			var sFixPath = "/TextSelParamSet(DocumentId='";
			var sItemId = "",
				sLangu = mImpValue.Langu,
				sSep = "',";
			// Create path for OData call
			var sPath = sFixPath + mImpValue.DocId + sSep + "ItemId='" + sItemId + sSep + "Langu='" + sLangu + "')/TextParamValueNav";
			// Read OData based on path and parameters
			// oModel.read("/TextParamValueSet", mParams);
			oModel.read(sPath, mParams);
		},
		// Event Handler Method: On Row Selection of Table
		onRowSelect: function (oEvent) {
			var oTextResource = this.getView().getModel("i18n").getResourceBundle();
			var sEdit = oTextResource.getText('EditBtnText');
			// Change preview section to non editable
			this.byId("_HeadPrvTA").setEditable(false);
			this.byId("_HeadPrvCharLen").setVisible(false);
			this.byId("_HeadPrvCharLen").setText(undefined);
			this.byId("_idEditDispBtn").setText(sEdit);
			this.byId("_idEditDispBtn").setIcon("sap-icon://user-edit");
			// Get model reference
			var sItemTxtUpd = this.getOwnerComponent().getModel("mHdrTxtChg").getProperty("/items");
			var sItemTxt = this.getOwnerComponent().getModel("mHdrTxtParams").getProperty("/items");
			//Local Data Declaration
			var sItems = this.getOwnerComponent().getModel("mHdrTxtID").getProperty("/items");
			// Read Selcted row details.
			//Get selected row Index
			var oTable = this.getView().byId('_HeadTxtTypeTab');
			var irowIdx = oTable.indexOfItem(oTable.getSelectedItem());
			var sTxtId = sItems[irowIdx].TextId;
			// TextID
			var sDocId = sItems[irowIdx].DocumentId;
			// DocumentId
			var sTxtObj = sItems[irowIdx].Tdobject;
			// TextObject
			var sLangnew = this.getOwnerComponent().getModel("mLangnew").getProperty("/sLang");
			if (sLangnew) {
				var sLangu = sLangnew;
			} else {
				sLangu = sItems[irowIdx].Langu;
			}
			//var sLangu = sItems[irowIdx].Langu;
			// Language
			var sContent = sItems[irowIdx].Content; // Text Content
			//Get the mHdrTxtParams JSON model refernce and set the values to JSON Model to use it later
			var oMdlTxt = this.getOwnerComponent().getModel("mHdrTxtParams");
			var mValue = {
				DocId: sDocId,
				// Document Id
				TxtId: sTxtId,
				// Text Id
				TxtObj: sTxtObj,
				// Text Object
				Langu: sLangu,
				// Language
				Content: sContent,
				// Text Content
				// Row index
				RowNo: irowIdx,
				// Language Change
				LangChg: false,
				//Pop up Yes Selected
				PopUp: false
			};
			// Set the values to items property of the JSON Model
			oMdlTxt.setProperty("/items", mValue);
			// Set model
			this.getView().setModel(oMdlTxt, "mHdrTxtParams");
			// Check whether any text changed performed in the prview section but not saved.
			// If changes are not saved trigger a popup to allow users to save changes.
			var bPopUp;
			if (sItemTxtUpd !== undefined) {
				if (sItemTxtUpd.TxtId !== sTxtId) {
					if (sItemTxtUpd.TxtChg === true) {
						bPopUp = true;
					} else {
						bPopUp = false;
					}
				} else {
					bPopUp = false;
				}
			} else {
				bPopUp = false;
			}
			// Trigger PopUp
			if (bPopUp === true) {
				var oView = this.getView();
				var oDialog = oView.byId("id_SaveText");
				// create dialog lazily
				if (!oDialog) {
					// create dialog via fragment factory
					oDialog = this.oDialog = sap.ui.xmlfragment(oView.getId(), "kno.em.textmaint.germany.fragments.CustomActionPopUp", this);
					// connect dialog to view (models, lifecycle)
					oView.addDependent(oDialog);
					// Open the Dialog
					oDialog.open();
				} else {
					oDialog.open();
				}
			}

			// Read Parameter Value
			this.ReadParamValue(mValue);

			//Parameter Selection logic
			this.ParamSelect(mValue, sItems[irowIdx].Vkorg);

			//Preapare filter range table for preview selection
			if (sItemTxt !== undefined) {
				if (sItemTxt.Langu) {
					//Preview Selection Logic
					this.PrevSelect(mValue);
				} else {
					// Set retrieved text to the text area of the Preview Section
					this.byId("_HeadPrvTA").setValue(sContent);
					// Enable or Disable Preview buttons based content's avalability
					if (!sContent) {
						this.byId("_idPrvBtn").setVisible(false);
						this.byId("_idSaveBtn").setVisible(true);
					}
				}
			} else {
				// Set retrieved text to the text area of the Preview Section
				this.byId("_HeadPrvTA").setValue(sContent);
				// Enable or Disable Preview buttons based content's avalability
				if (!sContent) {
					this.byId("_idPrvBtn").setVisible(false);
					this.byId("_idSaveBtn").setVisible(true);
				}
			}
		},
		// Logic to populate dynamic parameters based on TextId Selection&nbsp;
		ParamSelect: function (mImpValue, mImpVkorg) {
			// Get Default unnamed Model reference
			var oModel = this.getOwnerComponent().getModel();

			// get updated details from model.
			var oMdlDate = this.getOwnerComponent().getModel("mTmpDate");
			var sDates = oMdlDate.getProperty("/AddDate");
			// Success Function of OData Call
			var fnSuccess = jQuery.proxy(function (oData) {
				// Parse OData Reult
				var oResult = JSON.parse(JSON.stringify(oData));
				// Set paramater OData details in sParams
				this.sParams = oResult.results;
				//Get Form Container and add form elements dynamically based
				//on selected parameters
				var mFrmCont = this.byId("_HeadParaSelCont");
				//Destroy previously created form elements
				mFrmCont.destroyFormElements();

				var oTextResource = this.getView().getModel("i18n").getResourceBundle();
				var sLang = oTextResource.getText('Language');
				var sDocStat = this.getOwnerComponent().getModel("mimportaingParams").getProperty("/DMR");
				// Create Form Element to create language combo box dynamically in preview section
				// var oFrmElmLang = new sap.ui.layout.form.FormElement({
				// 	id: "_HeadLangElm",
				// 	label: sLang
				// });
				// Create Form Element to create language combo box dynamically in preview section
				if (sDocStat === false) {
					if (mImpValue.TxtId === 'ZDPR') {
						var oFrmElmLang = new sap.ui.layout.form.FormElement({
							id: "_HeadLangElm",
							label: sLang,
							visible: true,
							editable: true
						});
					} else {

						var oFrmElmLang = new sap.ui.layout.form.FormElement({
							id: "_HeadLangElm",
							label: sLang,
							visible: true,
							editable: false
						});
					}
				} else {
					oFrmElmLang = new sap.ui.layout.form.FormElement({
						id: "_HeadLangElm",
						label: sLang,
						visible: false
					});
				}

				oFrmElmLang.destroyFields();
				// Create Item Template for combobox which will be used for aggregation binding
				var oCmbItemTemp = new sap.ui.core.Item({
					id: "_HeadLangItm",
					key: "{LanguageCode}",
					text: "{LanguageDescr}"
				});
				// // Create Language combo box
				// var oCmbLangu = new sap.m.ComboBox({
				// 	id: "_HeadLangCB",
				// 	maxWidth: "90%",
				// 	selectedKey: "{LanguageCode}",
				// 	selectedItemId: "_HeadLangItm"
				// });
				// Create Language combo box
				if (sDocStat === true) {
					var oCmbLangu = new sap.m.ComboBox({
						visible: false,
						id: "_HeadLangCB",
						maxWidth: "90%",
						selectedKey: "{LanguageCode}",
						selectedItemId: "_HeadLangItm"
					});

				} else {
					if (mImpValue.TxtId === 'ZDPR') {
						oCmbLangu = new sap.m.ComboBox({
							visible: true,
							editable: true,
							id: "_HeadLangCB",
							maxWidth: "90%",
							selectedKey: "{LanguageCode}",
							selectedItemId: "_HeadLangItm"
						});
					} else {

						oCmbLangu = new sap.m.ComboBox({
							visible: true,
							editable: false,
							id: "_HeadLangCB",
							maxWidth: "90%",
							selectedKey: "{LanguageCode}",
							selectedItemId: "_HeadLangItm"
						});
					}
				}

				//Set Default Language
				oCmbLangu.onAfterRendering = function () {
					oCmbLangu.setSelectedKey(mImpValue.Langu);
				};

				// Create parametr list to trigger combo box selection change event
				var mValue = {
					DocId: mImpValue.DocId,
					// Document Id
					TxtId: mImpValue.TxtId,
					// Text Id
					TxtObj: mImpValue.TxtObj,
					// Text object
					View: this // View Reference
				};
				// Attach Events to the language Combo Box along with the parameters
				oCmbLangu.attachSelectionChange(mValue, this.onLangSelect);
				oCmbLangu.attachChange(mValue, this.onLangSelect);

				// Call Aggragtion binding to language combobox
				// Set path to retreive result
				var sFixPath = "/TextSelParamSet(DocumentId='";
				var sItemId = "";
				var sLangu = this.getOwnerComponent().getModel("mimportaingParams").getProperty("/Langu");
				var sSep = "',";
				// Create path for OData call
				var sPath = sFixPath + mImpValue.DocId + sSep + "ItemId='" + sItemId + sSep + "Langu='" + sLangu + "')/LanguSetNav";
				oCmbLangu.bindItems(sPath, oCmbItemTemp);

				// Add Language field to Language Form element
				oFrmElmLang.addField(oCmbLangu);
				// Add Language Form Element to Prameter Form container
				mFrmCont.addFormElement(oFrmElmLang);
				var oParamExist = this.getOwnerComponent().getModel("mParamsExist");
				if (mImpValue.Content) {
					// Get All Parameter values
					var sParamVal = this.getOwnerComponent().getModel("mParamValue").getProperty("/values");
					// Get mParamsExist JSON model
					if (this.sParams && this.sParams.length) {
						var bParamExist = true;
						// Enable Update Botton when parameters available
						this.byId("_idPrvBtn").setEnabled(true);
						this.byId("_idPrvBtn").setVisible(true);
						this.byId("_idSaveBtn").setVisible(false);
						// Get JSON model to filter single paramater value
						//Loop through Parameter details table and create form elements dynamically
						var mParamsModel = this.getOwnerComponent().getModel("mimportaingParams");
						var bParamDisp = mParamsModel.getProperty("/ParamDisp");
						if (mImpValue.TxtId === 'ZVAT') {
							// Set Parameter Display on/off
							if (bParamDisp === true) {
								bParamExist = true;
								var bParmDisOnOff = true;
							} else {
								bParamExist = false;
								bParmDisOnOff = false;
							}
						} else {
							bParamExist = true;
						}
						//change on 3/7/2019 to make EDIT button disabled when lang is E
						if (sLangu === 'E' || mImpValue.TxtId === 'ZSCA') {
							bParmDisOnOff = false;
						}

						if (bParamExist === true) {
							for (var mCnt = 0; mCnt < this.sParams.length; mCnt++) {
								var sSingleParamValue = [];
								// Populate single paramater value for ComboBox and other where value help check is on
								for (var iCnt = 0; iCnt < sParamVal.length; iCnt++) {
									if (this.sParams[mCnt].Param === sParamVal[iCnt].Param &&
										this.sParams[mCnt].TextId === sParamVal[iCnt].TextId &&
										this.sParams[mCnt].Tdobject === sParamVal[iCnt].Tdobject) {
										sSingleParamValue.push(sParamVal[iCnt]);
									}
								}
								//Disable Edit button if Edit text not selectd
								if (this.sParams[mCnt].EditText !== 'X') {
									this.getView().byId("_idEditDispBtn").setEnabled(false);
								} else {
									this.getView().byId("_idEditDispBtn").setEnabled(true);
								}
								var mParam = this.sParams[mCnt].Param;
								var mParamDesr = this.sParams[mCnt].ParamDesr;
								var mEndIdx = mParam.length;
								mEndIdx = mEndIdx - 1;
								mParam = mParam.substring(1, mEndIdx);
								mParam = mParam + "_" + this.sParams[mCnt].ParamNo;
								var oFrmElmId = "id" + mParam;
								var oFrmElm = new sap.ui.layout.form.FormElement({
									id: oFrmElmId,
									label: mParamDesr
								});
								if (this.sParams[mCnt].F4Req === "X") {
									var bValHlp = true;
								} else {
									bValHlp = false;
								}
								var mSingleParamValue = new JSONModel({
									values: sSingleParamValue
								});
								sap.ui.getCore().setModel(mSingleParamValue);
								switch (this.sParams[mCnt].ParamTyp) {
									//For DatePicker create a DatePicker UI Element
								case "DatePicker":
									if (sDates !== undefined) {
									if (mParam === "DATE1_1"){
										var mDvalue = sDates.Date1;
									}else if (mParam === "DATE2_4"){
										 mDvalue = sDates.Date2;
									}
									}
									var oDate = new sap.m.DatePicker({
										id: mParam,
										value: mDvalue
									});
									oDate.setWidth("90%");
									oFrmElm.addField(oDate);
									break;
									//For InputField create a InputField UI Element
								case "Input":
									var oInput = new sap.m.Input({
										id: mParam,
										showValueHelp: bValHlp,
										maxLength: this.sParams[mCnt].MaxLines
									});
									if (bValHlp === true) {
										if (mParamDesr.search(/month/i)) {
											oInput.setValueHelpOnly(bValHlp);
										} else {
											if (mParamDesr.search(/year/i)) {
												oInput.setValueHelpOnly(bValHlp);
											}
										}
										var mValHlpParam = {
											ParamDesc: mParamDesr,
											view: this
										};
										oInput.attachValueHelpRequest(mValHlpParam, this.onValueHelpRequest);
									}
									oInput.setWidth("90%");
									oFrmElm.addField(oInput);
									break;
									//For Combo Box create a InputField UI Element
								case "ComboBox":
									// Create a Combo Box
									var oComboBox = new sap.m.ComboBox({
										id: mParam,
										maxWidth: "90%"
									});

									oComboBox.attachChange(function (oEvent) {
										try {
											var sInput = $("[id*='DESCRIPTION_5-inner']")[0];
											if (this.getSelectedKey() != "000001" && this.getSelectedKey() != "") {
												sInput.disabled = true;

											} else {
												sInput.disabled = false;
											}
										} catch (e) {}
									});
									//Combo box									
									//oComboBox.setEditable(false);
									oComboBox.setModel(mSingleParamValue);
									var oCBParItemTemp = new sap.ui.core.ListItem();
									oCBParItemTemp.bindProperty("text", "Value");
									oCBParItemTemp.bindProperty("key", "SeqNo");
									// Aggregation binding with the items property
									oComboBox.bindItems("/values", oCBParItemTemp);
									oFrmElm.addField(oComboBox);

									//Combo box change
									//Set Default Language

									// var desc = "DESCRIPTION_5";
									oComboBox.addEventDelegate({
										onAfterRendering: function () {
											oComboBox.$().find("input").attr("readonly", true);
										}
									});

									// //Select
									// var oSelect = new sap.m.Select({
									// 	id: mParam,
									// 	maxWidth: "90%"
									// });

									// oSelect.attachChange(function (oEvent) {
									// 	try {

									// 		var a = 1;
									// 		var b = a;
									// 	} catch (e) {}
									// });
									// oSelect.setModel(mSingleParamValue);
									// oFrmElm.addField(oSelect);
									// var oCBParItemTemp = new sap.ui.core.ListItem();
									// oCBParItemTemp.bindProperty("text", "Value");
									// oCBParItemTemp.bindProperty("key", "SeqNo");
									// //	Aggregation binding with the items property
									// oSelect.bindItems("/values", oCBParItemTemp);
									break;

								case "Text":
									var sPlaceHolder = this.getView().getModel("i18n").getResourceBundle().getText('TextAreaPlaceholder'),
										sTxtLenId = mParam + 'CharLen',
										oTextArea = new sap.m.TextArea({
											id: mParam,
											rows: 6,
											showValueHelp: bValHlp,
											placeholder: sPlaceHolder,
											growing: true,
											wrapping: "Soft",
											showExceededText: true,
											maxLength: this.sParams[mCnt].MaxLines
										});
									oTextArea.setWidth("90%");

									// var sCharLenTxt = mParam + 'CharLen';
									oFrmElmId = "idRemCharText";
									var oTxtFrmElm = new sap.ui.layout.form.FormElement({
										id: oFrmElmId,
										label: ""
									});
									var oText = new sap.m.Text({
										id: sTxtLenId
									});
									var sRemCharText = this.getView().getModel("i18n").getResourceBundle().getText('RemCharText');
									var sValueChar = {
										TotChar: this.sParams[mCnt].MaxLines,
										sRemCharText: sRemCharText,
										oRemCharTxt: oText,
										TxtFldId: sTxtLenId
									};

									oTextArea.attachLiveChange(sValueChar, this.onLiveChgCntCharDesc);
									oFrmElm.addField(oTextArea);
									oTxtFrmElm.addField(oText);
									break;
								default: //Nothing to be done on&nbsp;
								}
								//Add form elements&nbsp;
								mFrmCont.addFormElement(oFrmElm);
								if (oTxtFrmElm) {
									//Add form elements&nbsp;
									mFrmCont.addFormElement(oTxtFrmElm);
								}
							}
						}
					} else {
						bParamExist = false;
					}
				} else {
					bParamExist = false;
				}

				if (bParamExist === false) {
					this.byId("_idPrvBtn").setVisible(false);
					this.byId("_idSaveBtn").setVisible(true);
					this.getView().byId("_idEditDispBtn").setEnabled(true);
					this.byId("_HeadPrvTA").setMaxLength(78);
					this.byId("_HeadPrvTA").setGrowing(true);
					// this.byId("_HeadPrvTA").setShowExceededText(true);
					this.byId("_HeadPrvTA").setRows(2);
					var sValueChar = {
						TotChar: 78,
						View: this
					};
					this.byId("_HeadPrvTA").attachLiveChange(sValueChar, this.onLiveChgCntChar);
				} else {
					this.byId("_HeadPrvTA").setMaxLength(0);
					this.byId("_HeadPrvTA").setGrowing(true);
					this.byId("_HeadPrvTA").setRows(10);
					this.byId("_HeadPrvTA").detachLiveChange(this.onLiveChgCntChar);
				}
				if (bParmDisOnOff === false) {
					this.byId("_idEditDispBtn").setEnabled(false);
				}
				oParamExist.setProperty("/ParamExist", bParamExist);
				this.getView().setModel(oParamExist, "mParamsExist");
			}, this);
			//Error Function Call
			var fnError = jQuery.proxy(function (oData) {
				this.oResult = JSON.parse(JSON.stringify(oData));
			}, this);
			//Prepare filter range table to get parameter values
			var sParamFilter = [];
			sParamFilter.push(new sap.ui.model.Filter("Vkorg", "EQ", mImpVkorg));
			sParamFilter.push(new sap.ui.model.Filter("Tdobject", "EQ", mImpValue.TxtObj));
			sParamFilter.push(new sap.ui.model.Filter("TextId", "EQ", mImpValue.TxtId));
			//Define OData Parameters for parameter seletion
			var mParams = {
				context: null,
				urlParameters: null,
				async: false,
				filters: sParamFilter,
				success: fnSuccess,
				error: fnError
			};
			//Read TextParamSet Entity Set Data from OData Service using filter values
			oModel.read("/TextParamSet", mParams);
		},

		// Logic to populate text content in preview section
		PrevSelect: function (mImpVal) {
			//Get Default unnamed Model reference
			var oModel = this.getOwnerComponent().getModel();
			// Success function call
			var fnTextSuccess = jQuery.proxy(function (oData) {
				var oResult = JSON.parse(JSON.stringify(oData));
				//Set text content to Preview Text Area
				this.byId("_HeadPrvTA").setValue(oResult.Content);
				//Get the mHdrTxtParams JSON model refernce and set the values to JSON Model to use it later
				var oMdlTxt = this.getOwnerComponent().getModel("mHdrTxtParams"),
					mValue = {
						DocId: mImpVal.DocId, // Document Id
						TxtId: mImpVal.TxtId, // Text Id
						TxtObj: mImpVal.TxtObj, // Text Object
						Langu: mImpVal.Langu, // Language
						Content: mImpVal.Content, // Content
						RowNo: mImpVal.RowNo // Selected row number
					};
				// Set the values to items property of the JSON Model
				oMdlTxt.setProperty("/items", mValue);
				// Set model
				this.getView().setModel(oMdlTxt, "mHdrTxtParams");
				if (mImpVal.LangChg === true) {
					var sRemCharText = this.ShowTxtContLen(this);
					if (this.byId("_HeadPrvTA").getProperty("editable") === true) {
						this.byId("_HeadPrvCharLen").setVisible(true);
						this.byId("_HeadPrvCharLen").setText(sRemCharText);
					} else {
						this.byId("_HeadPrvCharLen").setVisible(false);
						this.byId("_HeadPrvCharLen").setText(undefined);
					}
				}

			}, this);
			// Error function call
			var fnTextError = jQuery.proxy(function (oData) {
				this.oResult = JSON.parse(JSON.stringify(oData));
			}, this);
			//Define Odata Parameters for Text Selction
			var mTextParams = {
				context: null,
				urlParameters: null,
				async: false,
				success: fnTextSuccess,
				error: fnTextError
			};

			var sItemId = "";
			var sFixPath = "/TextValueHelpSet(DocumentId='";
			var sSep = "',";
			// Create path for OData call
			var sPath = sFixPath + mImpVal.DocId + sSep + "ItemId='" + sItemId + sSep + "TextId='" + mImpVal.TxtId + sSep + "Tdobject='" +
				mImpVal.TxtObj + sSep +
				"Langu='" + mImpVal.Langu + "')";

			// Read TextValueHelpSet entityset with key values
			oModel.read(sPath, mTextParams);
		},
		// On Language selection
		onLangSelect: function (oEvent, mParams) {
			//Getting selected parameters
			// Read dynamic parameters from dynamically created form elements
			// var sEvent = oEvent;
			// Get selected language
			if (oEvent) {
				var sLangu = oEvent.getSource().getSelectedKey();
			}
			if (sLangu === "E") {
				var tLangu = "D";
			} else if (sLangu === "D") {
				tLangu = "E";
			}
			var mFrmCont = mParams.View.byId("_HeadParaSelCont");
			var mFrmElems = mFrmCont.getFormElements();
			for (var mElmCnt = 0; mElmCnt < mFrmElems.length; mElmCnt++) {
				var mFrmElm = mFrmElems[mElmCnt];
				if (mFrmElm.getId() !== "_HeadLangElm" && mFrmElm.getId() !== "idRemCharText") {
					var mFlds = mFrmElm.getFields();
					var aStrParam = mFlds[0].getId().split("_");
					try {
						var mParam = "&" + aStrParam[0] + "&",
							sParamValue = mFlds[0].getValue();

					} catch (e) {
						var mParam = "&" + aStrParam[0] + "&",
							sParamValue = mFlds[0]._getSelectedItemText();
					}
					if (aStrParam[0] === "DATE1") {
						var sDate1 = sParamValue;
					} else if (aStrParam[0] === "DATE2") {
						var sDate2 = sParamValue;
					}
				}
			}
			var dValue = {
				Date1: sDate1,
				Date2: sDate2
			};
			// Get mTmpDate JSON Model and set OData results to it.
			var mTmpDate = mParams.View.getOwnerComponent().getModel("mTmpDate");
			mTmpDate.setProperty("/AddDate", dValue);
			
			var fnSuccess = jQuery.proxy(function (oData, response) {
					if (oData.Success) {
						// Get mHdrTxtParams JSON Model data
						var oMdlTxt = mParams.View.getOwnerComponent().getModel("mHdrTxtChg"),
							oMdlParams = mParams.View.getOwnerComponent().getModel("mHdrTxtParams");
						var sItemTxt = oMdlTxt.getProperty("/items"),
							sTxtParm = oMdlParams.getProperty("/items");
						// // Get selected language
						// if (oEvent) {
						// 	var sLangu = oEvent.getSource().getSelectedKey();
						// }
						// Update language to mHdrTxtParams model
						if (sItemTxt) {
							var sContent = sItemTxt.Content,
								sRowNo = sItemTxt.RowNo;
							// sLangu = sItemTxt.Langu;
						} else {
							if (sTxtParm) {
								sContent = sTxtParm.Content;
								sRowNo = sTxtParm.RowNo;
								// sLangu = sTxtParm.Langu;
							}
						}
						var mValue = {
							DocId: mParams.DocId,
							TxtId: mParams.TxtId,
							TxtObj: mParams.TxtObj,
							Langu: sLangu,
							Content: sContent,
							RowNo: sRowNo,
							LangChg: true
						};
						// Check whether any text changed performed in the prview section but not saved.
						// If changes are not saved trigger a popup to allow users to save changes.
						if (sItemTxt !== undefined) {
							if (sItemTxt.TxtChg === true) {
								var bPopUp = true;
							} else {
								bPopUp = false;
							}
						} else {
							bPopUp = false;
						}

						//Always trigger pop up now when try to change language
						bPopUp = true;

						//Show message that text is being changed.
						/*			var sMessage = this.getView().getModel("i18n").getResourceBundle().getText('LangwarMsg');
									this.ShowMessage(sMessage);*/

						// Trigger popup
						if (bPopUp === true) {
							var oView = mParams.View.getView();
							this.oDialog = oView.byId("id_SaveText");
							// create dialog lazily
							if (!this.oDialog) {
								// create dialog via fragment factory
								this.oDialog = sap.ui.xmlfragment(oView.getId(), "kno.em.textmaint.germany.fragments.CustomActionPopUp", mParams.View);
								oView.addDependent(this.oDialog);
								this.oDialog.open();
							} else {
								this.oDialog.open();
							}
						} else {
							// Read dynamic parameters from dynamically created form elements
							var aFrmElems = mParams.View.byId("_HeadParaSelCont").getFormElements();
							if (aFrmElems.length > 1) {
								for (var iElmCnt = 1; iElmCnt < aFrmElems.length; iElmCnt++) {
									var oFrmElm = aFrmElems[iElmCnt];
									if (oFrmElm.getId() !== "_HeadLangElm") {
										var aFlds = oFrmElm.getFields();
										aFlds[0].setValue(undefined);
									}
									// Set retrieved text to the text area of the Preview Section
									// mParams.View.getView().byId("_HeadPrvTA").setValue(sContent);
									oMdlParams.setProperty("/items", mValue);
									mParams.View.getView().setModel(oMdlParams, "mHdrTxtParams");
									mParams.View.PrevSelect(mValue);
									// Read Parameter Value
									mParams.View.ReadParamValue(mValue);
									//Parameter Selection logic
									mParams.View.ParamSelect(mValue, '0001');
								}
							} else {
								oMdlParams.setProperty("/items", mValue);
								mParams.View.getView().setModel(oMdlParams, "mHdrTxtParams");
								var bRefTxtLen = true;
								// Set retrieved text to the text area of the Preview Section
								// mParams.View.getView().byId("_HeadPrvTA").setValue(sContent);
								mParams.View.PrevSelect(mValue);
								// Read Parameter Value
								mParams.View.ReadParamValue(mValue);
								//Parameter Selection logic
								mParams.View.ParamSelect(mValue, '0001');
							}
						}
						//Preview Selection Logic
						mParams.View.PrevSelect(mValue);
						if (bRefTxtLen === true) {
							mParams.View.byId("_HeadPrvCharLen").setText(undefined);
						}
					} else {

						// // mParams.View().displayErrorMessage(oData.MESSAGE);
						// if (sEvent) {
						// 	var sLangu1 = sEvent.getSource().getSelectedKey();
						// }
						this.setSelectedKey(tLangu);
						mParams.View.ShowMessage(oData.Message);
					}
				},
				this);

			var oDataModl = mParams.View.getOwnerComponent().getModel();
			oDataModl.callFunction('/fnTextDtChk', {
				urlParameters: {
					DATE1: sDate1,
					DATE2: sDate2,
					VBELN: mParams.DocId
				},
				method: "GET",
				success: fnSuccess
			});
			// if (sDesc === '') {
			// 	if (sDesc1 === '') {
			// 		var mErr = "X";
			// 	}
			// }
			// //IF description and Description fields are empty then through error message
			// if (mErr === "X") {
			// 		if (oEvent) {
			// 		var sLangu = oEvent.getSource().getSelectedKey();
			// 	}
			// 	if (sLangu === "E"){
			// 		var tLangu = "D";
			// 	}else if (sLangu === "D"){
			// 		tLangu = "E";
			// 	}
			// 	oEvent.getSource().setSelectedKey(tLangu);
			// 	var sEMessage = mParams.View.getOwnerComponent().getModel("i18n").getResourceBundle().getText("Descr");
			// 	mParams.View.ShowMessage(sEMessage);
			// } else {
			// // Get mHdrTxtParams JSON Model data
			// var oMdlTxt = mParams.View.getOwnerComponent().getModel("mHdrTxtChg"),
			// 	oMdlParams = mParams.View.getOwnerComponent().getModel("mHdrTxtParams");
			// var sItemTxt = oMdlTxt.getProperty("/items"),
			// 	sTxtParm = oMdlParams.getProperty("/items");
			// // Get selected language
			// if (oEvent) {
			// 	var sLangu = oEvent.getSource().getSelectedKey();
			// }
			// // Update language to mHdrTxtParams model
			// if (sItemTxt) {
			// 	var sContent = sItemTxt.Content,
			// 		sRowNo = sItemTxt.RowNo;
			// 	// sLangu = sItemTxt.Langu;
			// } else {
			// 	if (sTxtParm) {
			// 		sContent = sTxtParm.Content;
			// 		sRowNo = sTxtParm.RowNo;
			// 		// sLangu = sTxtParm.Langu;
			// 	}
			// }
			// var mValue = {
			// 	DocId: mParams.DocId,
			// 	TxtId: mParams.TxtId,
			// 	TxtObj: mParams.TxtObj,
			// 	Langu: sLangu,
			// 	Content: sContent,
			// 	RowNo: sRowNo,
			// 	LangChg: true
			// };
			// // Check whether any text changed performed in the prview section but not saved.
			// // If changes are not saved trigger a popup to allow users to save changes.
			// if (sItemTxt !== undefined) {
			// 	if (sItemTxt.TxtChg === true) {
			// 		var bPopUp = true;
			// 	} else {
			// 		bPopUp = false;
			// 	}
			// } else {
			// 	bPopUp = false;
			// }

			// //Always trigger pop up now when try to change language
			// bPopUp = true;

			// //Show message that text is being changed.
			// /*			var sMessage = this.getView().getModel("i18n").getResourceBundle().getText('LangwarMsg');
			// 			this.ShowMessage(sMessage);*/

			// // Trigger popup
			// if (bPopUp === true) {
			// 	var oView = mParams.View.getView();
			// 	this.oDialog = oView.byId("id_SaveText");
			// 	// create dialog lazily
			// 	if (!this.oDialog) {
			// 		// create dialog via fragment factory
			// 		this.oDialog = sap.ui.xmlfragment(oView.getId(), "kno.em.textmaint.germany.fragments.CustomActionPopUp", mParams.View);
			// 		oView.addDependent(this.oDialog);
			// 		this.oDialog.open();
			// 	} else {
			// 		this.oDialog.open();
			// 	}
			// } else {
			// 	// Read dynamic parameters from dynamically created form elements
			// 	var aFrmElems = mParams.View.byId("_HeadParaSelCont").getFormElements();
			// 	if (aFrmElems.length > 1) {
			// 		for (var iElmCnt = 1; iElmCnt < aFrmElems.length; iElmCnt++) {
			// 			var oFrmElm = aFrmElems[iElmCnt];
			// 			if (oFrmElm.getId() !== "_HeadLangElm") {
			// 				var aFlds = oFrmElm.getFields();
			// 				aFlds[0].setValue(undefined);
			// 			}
			// 			// Set retrieved text to the text area of the Preview Section
			// 			// mParams.View.getView().byId("_HeadPrvTA").setValue(sContent);
			// 			oMdlParams.setProperty("/items", mValue);
			// 			mParams.View.getView().setModel(oMdlParams, "mHdrTxtParams");
			// 			mParams.View.PrevSelect(mValue);
			// 			// Read Parameter Value
			// 			mParams.View.ReadParamValue(mValue);
			// 			//Parameter Selection logic
			// 			mParams.View.ParamSelect(mValue, '0001');
			// 		}
			// 	} else {
			// 		oMdlParams.setProperty("/items", mValue);
			// 		mParams.View.getView().setModel(oMdlParams, "mHdrTxtParams");
			// 		var bRefTxtLen = true;
			// 		// Set retrieved text to the text area of the Preview Section
			// 		// mParams.View.getView().byId("_HeadPrvTA").setValue(sContent);
			// 		mParams.View.PrevSelect(mValue);
			// 		// Read Parameter Value
			// 		mParams.View.ReadParamValue(mValue);
			// 		//Parameter Selection logic
			// 		mParams.View.ParamSelect(mValue, '0001');
			// 	}
			// }
			// //Preview Selection Logic
			// mParams.View.PrevSelect(mValue);
			// if (bRefTxtLen === true) {
			// 	mParams.View.byId("_HeadPrvCharLen").setText(undefined);
			// }
			// }
		},
		// Update parameter values in text
		onParamValUpd: function (oEvent) {
			var mParamFilt = [];
			// Read dynamic parameters from dynamically created form elements
			var mFrmCont = this.byId("_HeadParaSelCont");
			var mFrmElems = mFrmCont.getFormElements();

			var oTextResource = this.getView().getModel("i18n").getResourceBundle();
			var sCre = oTextResource.getText('Created');
			var sNo = oTextResource.getText('No');
			// Get Form Elements refrence
			// Get updated mHdrTxtParams model
			var oMdlTxt = this.getOwnerComponent().getModel("mHdrTxtParams");
			// Read item property of the model
			var mItems = oMdlTxt.getProperty("/items");
			// loop through the form elements and create parameter filters for all parameters&nbsp;
			// to trigger oData call to update parameter values in the corresponding text
			mParamFilt.push(new sap.ui.model.Filter("Docid", "EQ", mItems.DocId));
			mParamFilt.push(new sap.ui.model.Filter("DocType", "EQ", this.getOwnerComponent().getModel("mimportaingParams").getProperty(
				"/sImportingParamDocType")));
			mParamFilt.push(new sap.ui.model.Filter("Langu", "EQ", mItems.Langu));
			mParamFilt.push(new sap.ui.model.Filter("Txtobj", "EQ", mItems.TxtObj));
			mParamFilt.push(new sap.ui.model.Filter("Txtid", "EQ", mItems.TxtId));
			for (var mElmCnt = 0; mElmCnt < mFrmElems.length; mElmCnt++) {
				var mFrmElm = mFrmElems[mElmCnt];
				if (mFrmElm.getId() !== "_HeadLangElm" && mFrmElm.getId() !== "idRemCharText") {
					var mFlds = mFrmElm.getFields();
					var aStrParam = mFlds[0].getId().split("_");
					try {
						var mParam = "&" + aStrParam[0] + "&",
							sParamValue = mFlds[0].getValue();
					} catch (e) {
						var mParam = "&" + aStrParam[0] + "&",
							sParamValue = mFlds[0]._getSelectedItemText();
					}
					if (sParamValue.length !== 0 || mFrmElm.getId() == "idDESCRIPTION_5") {
						mParamFilt.push(new sap.ui.model.Filter("Param", "EQ", mParam));
						var sParamVal = mParam + "|" + sParamValue;
						mParamFilt.push(new sap.ui.model.Filter("Value", "EQ", sParamVal));
						var aParamVal = [sParamVal];
					}

				}
			}
			if (aParamVal) {
				// Get default model
				var oModel = this.getOwnerComponent().getModel();
				// Suceess function
				var fnTxtUpdSuccess = jQuery.proxy(function (oData) {
					var oResult = JSON.parse(JSON.stringify(oData));
					if (oResult.results.length) {
						// updated text content after parameter replacement
						var sTxtvalue = oResult.results[0].Content;
						var iRowIdx = this.getOwnerComponent().getModel("mHdrTxtParams").getProperty("/items").RowNo;
						var oHdrTxtID = this.getOwnerComponent().getModel("mHdrTxtID");
						var sTextTypes = oHdrTxtID.getProperty("/items");
						var bError = oResult.results[0].Error,
							sMessage = oResult.results[0].Message;
						// set content value to Preview text area
						if (bError === 'X') {
							this.ShowMessage(sMessage);
						} else {
							if (sTxtvalue.length !== 0) {
								this.byId("_HeadPrvTA").setValue(sTxtvalue);
								if (sTextTypes[iRowIdx].Status === sNo) {
									sTextTypes[iRowIdx].Status = sCre;
									oHdrTxtID.setProperty("/items", sTextTypes);
									this.getView().setModel(oHdrTxtID, "mHdrTxtID");
								}
								sMessage = this.getView().getModel("i18n").getResourceBundle().getText('ParmUpdSucMsg');
								this.ShowMessage(sMessage);
							}
						}
					}

				}, this);
				// Error fucntion
				var fnTxtUpdError = jQuery.proxy(function (oData) {
					this.oResult = JSON.parse(JSON.stringify(oData));
					var sMessage = this.getView().getModel("i18n").getResourceBundle().getText('ParmUpdErrMsg');
					this.ShowMessage(sMessage);
				}, this);

				// Parameters for OData call
				var mParams = {
					context: null,
					urlParameters: null,
					async: false,
					filters: mParamFilt,
					success: fnTxtUpdSuccess,
					error: fnTxtUpdError
				};
				// Read TextUpdSet entity set to replace parameter values in text
				oModel.read("/TextUpdSet", mParams);
			} else {
				var sMessage = this.getView().getModel("i18n").getResourceBundle().getText('ParmUpdErrMsg');
				this.ShowMessage(sMessage);
			}
		},
		// Calculate Text Length and display remaining character below text area
		ShowTxtContLen: function (mImpView) {
			var sItemTxt = mImpView.getOwnerComponent().getModel("mHdrTxtParams").getProperty("/items"),
				sImpRemTxt = mImpView.byId("_HeadPrvCharLen").getText();
			if (sItemTxt.Content.length !== 0) {
				sImpRemTxt =
					(mImpView.byId("_HeadPrvTA").getMaxLength() - sItemTxt.Content.length) +
					' ' + mImpView.getView().getModel("i18n").getResourceBundle().getText('RemCharText');
			}
			if (sImpRemTxt.length === 0) {
				sImpRemTxt =
					mImpView.byId("_HeadPrvTA").getMaxLength() + ' ' + mImpView.getView().getModel("i18n").getResourceBundle().getText('RemCharText');
			}
			return sImpRemTxt;
		},
		// Enable edit options for text area
		onEditText: function (oEvent) {
			/**     On pressing edit button text area will be editable.
			 **/
			var bParamExist = this.getOwnerComponent().getModel("mParamsExist").getProperty("/ParamExist");
			var oTextResource = this.getView().getModel("i18n").getResourceBundle();
			var sEdit = oTextResource.getText('EditBtnText'),
				sDisplay = oTextResource.getText('Display'),
				sRemCharText = this.ShowTxtContLen(this);
			// sItemTxt = this.getOwnerComponent().getModel("mHdrTxtParams").getProperty("/items");
			// if (sItemTxt.Content.length !== 0) {
			// 	sRemCharText =
			// 		(this.byId("_HeadPrvTA").getMaxLength() - sItemTxt.Content.length) +
			// 		' ' + this.getView().getModel("i18n").getResourceBundle().getText("RemCharText");
			// }
			// if (sRemCharText.length === 0) {
			// 	sRemCharText =
			// 		this.byId("_HeadPrvTA").getMaxLength() + ' ' + this.getView().getModel("i18n").getResourceBundle().getText("RemCharText");
			// }
			// Enable or disable buttons&nbsp;
			if (oEvent.getParameter("pressed") === true) {
				if (this.byId("_HeadPrvTA").getProperty("editable") === true) {
					this.byId("_HeadPrvTA").setEditable(false);
					this.byId("_idPrvBtn").setVisible(false);
					this.byId("_HeadPrvCharLen").setVisible(false);
					this.byId("_idSaveBtn").setVisible(true);
					this.byId("_idEditDispBtn").setText(sEdit);
					this.byId("_idEditDispBtn").setIcon("sap-icon://user-edit");
				} else {
					this.byId("_HeadPrvTA").setEditable(true);
					if (bParamExist === false) {
						this.byId("_HeadPrvCharLen").setVisible(true);
						this.byId("_HeadPrvCharLen").setText(sRemCharText);

					} else {
						this.byId("_HeadPrvCharLen").setVisible(false);
					}
					this.byId("_idPrvBtn").setVisible(false);
					this.byId("_idSaveBtn").setVisible(true);
					this.byId("_idEditDispBtn").setText(sDisplay);
					this.byId("_idEditDispBtn").setIcon("sap-icon://display");
				}
			} else {
				if (this.byId("_HeadPrvTA").getProperty("editable") === true) {
					this.byId("_HeadPrvTA").setEditable(false);
					this.byId("_HeadPrvCharLen").setVisible(false);
					if (bParamExist === true) {
						this.byId("_idPrvBtn").setVisible(true);
						this.byId("_idSaveBtn").setVisible(false);
					} else {
						this.byId("_idPrvBtn").setVisible(false);
						this.byId("_idSaveBtn").setVisible(true);
					}
					this.byId("_idEditDispBtn").setText(sEdit);
					this.byId("_idEditDispBtn").setIcon("sap-icon://user-edit");
				} else {
					this.byId("_HeadPrvTA").setEditable(true);
					if (bParamExist === true) {
						this.byId("_idPrvBtn").setVisible(true);
						this.byId("_idSaveBtn").setVisible(false);
						this.byId("_HeadPrvCharLen").setVisible(false);
					} else {
						this.byId("_idPrvBtn").setVisible(false);
						this.byId("_idSaveBtn").setVisible(true);
						this.byId("_HeadPrvCharLen").setVisible(true);
						this.byId("_HeadPrvCharLen").setText(sRemCharText);
					}
					this.byId("_idEditDispBtn").setText(sDisplay);
					this.byId("_idEditDispBtn").setIcon("sap-icon://display");
				}
			}
		},
		// Delete Text from Document Level
		onClearText: function (oEvent) {
			/**     On pressing Clear Text button text will be deleted from the document level
			 **/
			var oTextResource = this.getView().getModel("i18n").getResourceBundle();
			var sNo = oTextResource.getText('No');
			var sItems = this.getOwnerComponent().getModel("mHdrTxtParams").getProperty("/items");
			var sItemId = "";
			var sFixPath = "/TextValueHelpSet(DocumentId='";
			var sSep = "',";
			var sPath = sFixPath + sItems.DocId + sSep + "ItemId='" + sItemId + sSep + "TextId='" + sItems.TxtId + sSep + "Tdobject='" +
				sItems
				.TxtObj + sSep + "Langu='" + sItems.Langu + "')";
			var oModel = this.getOwnerComponent().getModel();
			var fnSuccess = jQuery.proxy(function (oData) {}, this);
			var fnError = jQuery.proxy(function (oData) {
				this.oResult = JSON.parse(JSON.stringify(oData));
			}, this);
			var mParams = {
				success: fnSuccess,
				error: fnError
			};
			oModel.remove(sPath, mParams);
			// Logic to populate text in Preview section&nbsp;
			var fnTextSuccess = jQuery.proxy(function (oData) {
				var oResult = JSON.parse(JSON.stringify(oData));
				var mTxtvalue = oResult.Content;
				this.byId("_HeadPrvTA").setValue(mTxtvalue);
				var iRowIdx = this.getOwnerComponent().getModel("mHdrTxtParams").getProperty("/items").RowNo;
				var oHdrTxtID = this.getOwnerComponent().getModel("mHdrTxtID");
				var sTextTypes = oHdrTxtID.getProperty("/items");
				sTextTypes[iRowIdx].Status = sNo;
				sTextTypes[iRowIdx].Content = mTxtvalue;
				oHdrTxtID.setProperty("/items", sTextTypes);
				this.getView().setModel(oHdrTxtID, "mHdrTxtID");
				var sMessage = this.getView().getModel("i18n").getResourceBundle().getText('ClrSuccMsg');
				this.ShowMessage(sMessage);
			}, this);
			var fnTextError = jQuery.proxy(function (oData) {
				this.oResult = JSON.parse(JSON.stringify(oData));
				var sMessage = this.getView().getModel("i18n").getResourceBundle().getText('ClrErrMsg');
				this.ShowMessage(sMessage);
			}, this);
			//Define Odata Parameters for Text Selction
			var mTextParams = {
				success: fnTextSuccess,
				error: fnTextError
			};
			oModel.read(sPath, mTextParams);
		},
		// on Changing Text Manually Text Change flag will be updated along with updated conent
		onChangeText: function (oEvent) {
			// get updated value from text area
			var sTxtValue = oEvent.getParameter("newValue");
			// get mHdrTxtParams model reference and update new text and TxtChg flag.
			var oMdlTxt = this.getOwnerComponent().getModel("mHdrTxtParams");
			var sItems = oMdlTxt.getProperty("/items");
			var mValue = {
				DocId: sItems.DocId,
				// Document Id
				TxtId: sItems.TxtId,
				// Text I
				TxtObj: sItems.TxtObj,
				// Text Object
				Langu: sItems.Langu,
				// Language
				Content: sTxtValue,
				RowNo: sItems.RowNo, // Updated Row No.
				// Updated Text content
				TxtChg: true // Text Change flag
			};
			var oMdlTxtChg = this.getOwnerComponent().getModel("mHdrTxtChg");
			oMdlTxtChg.setProperty("/items", mValue);
			this.getView().setModel(oMdlTxtChg, "mHdrTxtChg");
		},

		// on Live Change Count remaining characters to enter in Text Preview section
		onLiveChgCntChar: function (oEvent, mImpValue) {
			var iRemLen = mImpValue.TotChar - oEvent.getParameter("value").length,
				sRemCharText = mImpValue.View.getView().getModel("i18n").getResourceBundle().getText('RemCharText');
			sRemCharText = iRemLen + ' ' + sRemCharText;
			mImpValue.View.getView().byId("_HeadPrvCharLen").setText(sRemCharText);
		},

		// on Live Change Count remaining characters to enter in Description 1 field
		onLiveChgCntCharDesc: function (oEvent, mImpValue) {
			var iRemLen = mImpValue.TotChar - oEvent.getParameter("value").length;
			var sRemText = iRemLen + ' ' + mImpValue.sRemCharText;
			mImpValue.oRemCharTxt.setText(sRemText);
		},
		// on Pressing save edited text will be updated
		onSaveText: function (oEvent) {
			// Save changes
			this.onSave();
		},
		// on Pressing Ok button text will be updated
		onOKPressed: function (oEvent) {
			var oTextResource = this.getView().getModel("i18n").getResourceBundle();
			var sEdit = oTextResource.getText('EditBtnText');
			this.getView().byId("_HeadPrvTA").setEditable(false);
			this.getView().byId("_idEditDispBtn").setText(sEdit);
			this.getView().byId("_idEditDispBtn").setIcon("sap-icon://user-edit");
			this.byId("_idPrvBtn").setEnabled(true);
			this.byId("_idEditDispBtn").setEnabled(true);
			var oDialog = this.getView().byId("id_SaveText");
			if (oDialog) {
				oDialog.close();
			}
			// get updated details from model.
			var oMdlTxtChg = this.getOwnerComponent().getModel("mHdrTxtChg");
			var mValue = {
				PopUp: true
			};
			oMdlTxtChg.setProperty("/items", mValue);
			this.getView().setModel(oMdlTxtChg, "mHdrTxtChg");
			// Save changes
			this.onChangeLang();
			this.onSave();
		},

		onChangeLang: function (oEvent, mParams) {
			// get mHdrTxtParams model reference and update new text and TxtChg flag.
			var oMdlTxt = this.getOwnerComponent().getModel("mHdrTxtParams");
			var sItems = oMdlTxt.getProperty("/items");
			//var oMdlParams = mParams.View.getOwnerComponent().getModel("mHdrTxtParams");
			var oMdlParams = this.getOwnerComponent().getModel("mHdrTxtParams");
			var slang = this.getView().byId("_HeadPrvTA").getValue();
			var mValue = {
				DocId: sItems.DocId,
				// Document Id
				TxtId: sItems.TxtId,
				// Text Id
				TxtObj: sItems.TxtObj,
				// Text Object
				Langu: sItems.Langu,
				// Language
				Content: slang,
				RowNo: sItems.RowNo, // Updated Row No.
				// Updated Text content
				LangChg: true,
				TxtChg: true
			};

			oMdlParams.setProperty("/items", mValue);
			//mParams.View.getView().setModel(oMdlParams, "mHdrTxtParams");
			this.getView().setModel(oMdlParams, "mHdrTxtParams");
			//this.PrevSelect(mValue);
			// Read Parameter Value
			this.ReadParamValue(mValue);
			//Parameter Selection logic
			this.ParamSelect(mValue, '0001');
			sItems = oMdlTxt.getProperty("/items");
			//Added for Pop up Yes Button Selection on 06.03.2019
			// get updated details from model.
			var oMdlTxtChg = this.getOwnerComponent().getModel("mHdrTxtChg");
			var sItems1 = oMdlTxtChg.getProperty("/items");
			if (sItems1 !== undefined) {
				if (sItems1.PopUp === true) {
					var sPop = true;
				} else {
					sPop = false;
				}
			}
			mValue = {
				DocId: sItems.DocId,
				// Document Id
				TxtId: sItems.TxtId,
				// Text Id
				TxtObj: sItems.TxtObj,
				// Text Object
				Langu: sItems.Langu,
				// Language
				Content: slang,
				RowNo: sItems.RowNo, // Updated Row No.
				// Updated Text content
				LangChg: true,
				TxtChg: true,
				PopUp: sPop
			};
			var oMdlTxtChg = this.getOwnerComponent().getModel("mHdrTxtChg");
			oMdlTxtChg.setProperty("/items", mValue);
			this.getView().setModel(oMdlTxtChg, "mHdrTxtChg");
		},
		// On pressing Cancel button popup will be closed and processing will continue to next step
		onCancelPressed: function (oEvent) {
			var oDialog = this.getView().byId("id_SaveText");
			if (oDialog) {
				oDialog.close();
			}
			// // get updated details from model.
			// var oMdlTxtChg = this.getOwnerComponent().getModel("mHdrTxtChg");

			// oMdlTxtChg.setProperty("/items", undefined);
			// this.getView().setModel(oMdlTxtChg, "mHdrTxtChg");
			// Save changes
			// this.onChangeLang();

			var oMdlTxt = this.getOwnerComponent().getModel("mHdrTxtParams");
			var sItem = oMdlTxt.getProperty("/items");
			if (sItem.Langu === "E") {
				var tLangu = "D";
			} else if (sItem.Langu === "D") {
				tLangu = "E";
			}
			var mValue = {
				DocId: sItem.DocId,
				TxtId: sItem.TxtId,
				TxtObj: sItem.TxtObj,
				Langu: tLangu,
				Content: sItem.Content,
				RowNo: sItem.RowNo,
				LangChg: true
			};
			this.PrevSelect(mValue);
			this.ParamSelect(mValue, '0001');
		},
		// Save edited text
		onSave: function () {
			// get updated details from model.
			var oMdlTxtChg = this.getOwnerComponent().getModel("mHdrTxtChg");
			var sItems = oMdlTxtChg.getProperty("/items");
			var sSuccMessage = this.getView().getModel("i18n").getResourceBundle().getText('SuccessMessage');
			var sNoData = this.getView().getModel("i18n").getResourceBundle().getText('NoData');
			var oTextResource = this.getView().getModel("i18n").getResourceBundle();
			var sCre = oTextResource.getText('Created'),
				sNo = oTextResource.getText('No');
			// when text is changed and pressed on save button text will be updated.
			if (sItems) {
				if (sItems.TxtChg === true) {
					//+Begin of addition for Pop Up Yes Text Deletion on 06.03.2019
					if (sItems.PopUp === true) {
						var sItemId = "10";
					} else {
						sItemId = "";
					}
					//+End of addition for Pop Up Yes Text Deletion on 06.03.2019
					// var sItemId = "";
					var sFixPath = "/TextValueHelpSet(DocumentId='";
					var sSep = "',";
					// Create gateway service path
					var sPath = sFixPath + sItems.DocId + sSep + "ItemId='" + sItemId + sSep + "TextId='" + sItems.TxtId + sSep + "Tdobject='" +
						sItems.TxtObj + sSep + "Langu='" + sItems.Langu + "')";
					var oModel = this.getOwnerComponent().getModel();
					// Success function
					var fnSuccess = jQuery.proxy(function (oData, oResponse) {
						try {
							this.oResult = JSON.parse(JSON.stringify(oData)); // sItems.TxtChg = false;
						} catch (e) {}

						this.ShowMessage(sSuccMessage);
						// Read dynamic parameters from dynamically created form elements
						var mFrmCont = this.getView().byId("_HeadParaSelCont");
						var mFrmElems = mFrmCont.getFormElements();
						for (var mElmCnt = 0; mElmCnt < mFrmElems.length; mElmCnt++) {
							var mFrmElm = mFrmElems[mElmCnt];
							if (mFrmElm.getId() !== "_HeadLangElm" && mFrmElm.getId() !== "idRemCharText") {
								var mFlds = mFrmElm.getFields();
								var aStrParam = mFlds[0].getId().split("_");
								try {
									var mParam = "&" + aStrParam[0] + "&",
										sParamValue = mFlds[0].getValue();

								} catch (e) {
									var mParam = "&" + aStrParam[0] + "&",
										sParamValue = mFlds[0]._getSelectedItemText();
								}
								if (aStrParam[0] === "DATE1") {
									var sDate1 = sParamValue;
									// mFlds[0].setValue(sDate1);
								} else if (aStrParam[0] === "DATE2") {
									var sDate2 = sParamValue;
									// mFlds[0].setValue(sDate2);
								}
							}
						}
					}, this);
					// Error function
					var fnError = jQuery.proxy(function (oData) {
						try {
							this.oResult = JSON.parse(JSON.stringify(oData));
							var sMessage = this.getView().getModel("i18n").getResourceBundle().getText('ErrorMessage');
							this.ShowMessage(sMessage);
						} catch (e) {}
					}, this);
					// OData parameters
					var mParams = {
						success: fnSuccess,
						error: fnError
					};
					// OData call to update changed text
					oModel.update(sPath, {
						Content: sItems.Content
					}, mParams);
					// sItems.TxtChg = false;
					var iRowIdx = sItems.RowNo,
						sContent = sItems.Content,
						oHdrTxtID = this.getOwnerComponent().getModel("mHdrTxtID"),
						sTextTypes = oHdrTxtID.getProperty("/items");
					if (sContent.length !== 0) {
						sTextTypes[iRowIdx].Status = sCre;
					} else {
						sTextTypes[iRowIdx].Status = sNo;
					}

					sTextTypes[iRowIdx].Content = sContent;
					oHdrTxtID.setProperty("/items", sTextTypes);

					var mLangnew = this.getOwnerComponent().getModel("mLangnew");
					mLangnew.setProperty("/sLang", sItems.Langu);

					/*		for (var iCnt = 0; iCnt < sData.length; iCnt++) {
								sData[iCnt].Langu = sItems.Langu;
						      }*/
					//	this.getOwnerComponent().setModel(oHdrTxtID,"mHdrTxtID").setProperty("/items",sData);						

					this.getView().setModel(oHdrTxtID, "mHdrTxtID");
					sItems = undefined;
					oMdlTxtChg.setProperty("/items", sItems);
					this.getView().setModel(oMdlTxtChg, "mHdrTxtChg");
				} else {
					this.ShowMessage(sNoData);
				}
			} else {
				this.ShowMessage(sNoData);
			}
		},
		// Show Message
		ShowMessage: function (mMsg) {
			MessageToast.show(mMsg, {
				duration: 5000,
				// default
				width: "15em",
				// default
				my: "center bottom",
				at: "center bottom",
				of: window,
				// default
				offset: "0 0",
				// default
				collision: "fit fit",
				// default
				autoClose: true,
				// default
				animationTimingFunction: "ease",
				// default
				animationDuration: 1000,
				// default
				closeOnBrowserNavigation: true // default
			});
		},
		onNavBack: function () {
			// Clear Session storage value on Nav Back
			// var sStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
			// sStorage.clear();

			this.dequeueEngagement();
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				oCrossAppNavigator.toExternal({
					target: {
						shellHash: "#Shell-home"
					}
				});
			}
		},

		// Value Help Request for Year and Month Field
		onValueHelpRequest: function (oEvent, mParam) {
			var oView = mParam.view.getView();
			//	if (!this.selFld) {
			try {
				this.selFld = oEvent.getSource();
			} catch (e) {}
			//	}
			// create dialog lazily
			try {
				var aViewDepend = oView.getDependents();
				if (aViewDepend.length > 0) {
					oView.destroyDependents();
				}
			} catch (e) {}

			this.oDialog = sap.ui.xmlfragment(oView.getId(), "kno.em.textmaint.germany.fragments.MonthPopUp", this);
			var oTextResource = oView.getModel("i18n").getResourceBundle();
			// oView.addDependent(this.oDialog);
			var sMon = oTextResource.getText('MonthPopUptitle');
			var sYear = oTextResource.getText('YearPopUpTitle');
			var oFlexYearMnth = oView.byId("idFlexMnthYear");
			// Search Month if found generate month picker as value help
			var oCurrDate = new Date();
			// Based on current language trigger Month/Year PopUp
			//	var sLangu = oView.getModel("mHdrTxtParams").getProperty("/items").Langu;
			//		if (sLangu === 'E') {
			if (mParam.ParamDesc.search(/month/i) >= 0 || (mParam.ParamDesc.search(/monat/i) >= 0)) {
				var bMonth = true;
			} else {
				if (mParam.ParamDesc.search(/year/i) >= 0 || (mParam.ParamDesc.search(/jahr/i) >= 0)) {
					var bYear = true;
				}
			}
			// } else {
			// 	if (sLangu === 'D') {
			// 		if (mParam.ParamDesc.search(/month/i) >= 0 || (mParam.ParamDesc.search(/monat/i) >= 0)) {
			// 			bMonth = true;
			// 		} else {
			// 			if (mParam.ParamDesc.search(/year/i) >= 0 || (mParam.ParamDesc.search(/jahr/i) >= 0)) {
			// 				bYear = true;
			// 			}
			// 		}
			// 	}
			// }
			if (bMonth === true) {
				this.oDialog.setTitle(oTextResource.getText(sMon));
				oView.addDependent(this.oDialog);
				this.nCurrMonth = oCurrDate.getMonth();
				this.oYearMnth = new sap.ui.unified.calendar.MonthPicker({
					month: this.nCurrMonth,
					select: jQuery.proxy(function (oEvent) {
						this.selMnthYear = oEvent.getSource().getMonth();
					}, this)
				});
			} else {
				// Search year if found generate year picker as value help
				if (bYear === true) {
					this.oDialog.setTitle(oTextResource.getText(sYear));
					oView.addDependent(this.oDialog);
					this.oYearMnth = new sap.ui.unified.calendar.YearPicker({
						// columns: 5,
						date: oCurrDate,
						// years: 10,
						pageChange: jQuery.proxy(function (oEvent) {
							oEvent.getSource();
						}, this),
						previousPage: jQuery.proxy(function (oEvent) {
							oEvent.getSource();
						}, this),
						nextPage: jQuery.proxy(function (oEvent) {
							oEvent.getSource();
						}, this),
						select: jQuery.proxy(function (oEvent) {
							this.selMnthYear = oEvent.getSource().getDate().getFullYear();
						}, this)
					});
				}
			}
			var sOkTxt = oTextResource.getText('Ok'),
				sCancelTxt = oTextResource.getText('Cancel');

			// if ((oView.getModel("mHdrTxtParams").getProperty("/items").Langu) == "D") {
			// 	var sJan = "Januar";
			// 	var sFeb = "Februar";
			// 	var sMar = "März";
			// 	var sApr = "April";
			// 	var sMay = "Mai";
			// 	var sJun = "Juni";
			// 	var sJul = "Juli";
			// 	var sAug = "August";
			// 	var sSep = "September";
			// 	var sOct = "Oktober";
			// 	var sNov = "November";
			// 	var sDec = "Dezember";

			// } else {
			// 	sJan = "January";
			// 	sFeb = "February";
			// 	sMar = "March";
			// 	sApr = "April";
			// 	sMay = "May";
			// 	sJun = "June";
			// 	sJul = "July";
			// 	sAug = "August";
			// 	sSep = "September";
			// 	sOct = "October";
			// 	sNov = "November";
			// 	sDec = "December";
			// }

			var sJan = oTextResource.getText('Jan');
			var sFeb = oTextResource.getText('Feb');
			var sMar = oTextResource.getText('Mar');
			var sApr = oTextResource.getText('Apr');
			var sMay = oTextResource.getText('May');
			var sJun = oTextResource.getText('Jun');
			var sJul = oTextResource.getText('Jul');
			var sAug = oTextResource.getText('Aug');
			var sSep = oTextResource.getText('Sep');
			var sOct = oTextResource.getText('Oct');
			var sNov = oTextResource.getText('Nov');
			var sDec = oTextResource.getText('Dec');

			var oTBMnthYear = oView.byId("idTBMnthYear"),
				oOkBtn = new sap.m.Button({
					text: sOkTxt,
					// on pressing OK button of selected month/ year result will be copied to input field
					press: jQuery.proxy(function (oEvent) {
						var aMonthNames = [sJan, sFeb, sMar, sApr, sMay, sJun, sJul, sAug, sSep, sOct, sNov, sDec];
						if (this.selMnthYear) {
							if (this.selMnthYear <= 11) {
								this.selFld.setValue(aMonthNames[this.selMnthYear]);
							} else {
								this.selFld.setValue(this.selMnthYear);
							}
						} else {
							if (this.nCurrMonth) {
								this.selFld.setValue(aMonthNames[this.oYearMnth.getMonth()]);
							} else {
								this.selFld.setValue(this.oYearMnth.getYear());
							}
						}
						if (this.oDialog) {
							this.oDialog.close();
						}
						try {
							oView.byId("idFlexMnthYear").destroy();
							oView.byId("idTBMnthYear").destroy();
						} catch (e) {}

					}, this)
				}),
				// on pressing CANCEL button, month/year picker value help will be closed
				oCancelBtn = new sap.m.Button({
					text: sCancelTxt,
					press: jQuery.proxy(function (oEvent) {
						if (this.oDialog) {
							try {
								oView.byId("idFlexMnthYear").destroy();
								oView.byId("idTBMnthYear").destroy();
							} catch (e) {}
							this.oDialog.close();
						}
					}, this)
				});
			if (this.oYearMnth) {
				oFlexYearMnth.addItem(this.oYearMnth);
				oTBMnthYear.addContent(oOkBtn);
				oTBMnthYear.addContent(oCancelBtn);
				this.oDialog.open();
			}
		},

		// ABS Text Save&nbsp;
		onABSTxtSave: function (oEvent) {
			var aABSTxtFilt = [];
			// Get updated mHdrTxtParams model
			var mItems = this.getOwnerComponent().getModel("mABSTxt").getProperty("/items");
			// loop through the mABSTxt JSON model and create filters for all ABS Texts
			// to trigger oData call to update text in background
			for (var iCnt = 0; iCnt < mItems.length; iCnt++) {
				aABSTxtFilt.push(new sap.ui.model.Filter("VBELN", "EQ", mItems[iCnt].VBELN));
				aABSTxtFilt.push(new sap.ui.model.Filter("MATNR", "EQ", mItems[iCnt].MATNR));
				aABSTxtFilt.push(new sap.ui.model.Filter("ARKTX", "EQ", mItems[iCnt].ARKTX));
			}
			// Get default model
			var oModel = this.getOwnerComponent().getModel();
			// Suceess function
			var fnTxtUpdSuccess = jQuery.proxy(function (oData) {
				var oResult = JSON.parse(JSON.stringify(oData));
				if (oResult.results.length) {
					if (oResult.results[0].SUCCESS === true) {
						var sMessage = this.getView().getModel("i18n").getResourceBundle().getText('ParmUpdSucMsg');
						this.ShowMessage(sMessage);
					} else {
						sMessage = this.getView().getModel("i18n").getResourceBundle().getText('ParmUpdErrMsg');
						this.ShowMessage(sMessage);
					}
				}
			}, this);
			// Error fucntion
			var fnTxtUpdError = jQuery.proxy(function (oData) {
				this.oResult = JSON.parse(JSON.stringify(oData));
			}, this);
			// Parameters for OData call
			var mParams = {
				context: null,
				urlParameters: null,
				async: false,
				filters: aABSTxtFilt,
				success: fnTxtUpdSuccess,
				error: fnTxtUpdError
			};
			// Read AbsUpdSet entity set to replace parameter values in text
			oModel.read("/AbsUpdSet", mParams);
		},
		onExit: function () {
			// Clear Session storage value on Nav Back
			var sStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
			sStorage.clear();

			var mParamsModel = this.getOwnerComponent().getModel("mimportaingParams");
			var docId = mParamsModel.getProperty("/DocId");
			// var fnSuccess = jQuery.proxy(function(oData, response) {

			// 	},
			// 	this);

			// DocId data declaration to get document Id from importing parameter
			var sdocId = docId;
			// Get Default model reference.
			var oModel = this.getOwnerComponent().getModel();
			// Success Function of OData Call&nbsp;
			var fnSuccess = jQuery.proxy(function (oData) {
				var oResult = JSON.parse(JSON.stringify(oData));
			}, this);
			// Error Function of OData Call
			var fnError = jQuery.proxy(function (oData) {
				// this.oResult = JSON.parse(JSON.stringify(oData));
			}, this);
			// Define parameters for OData call
			var mParams = {
				success: fnSuccess,
				error: fnError
			};
			// Set path to retreive result
			var sFixPath = "/docLockSet(VBELN='";
			// Create path for OData call
			var sPath = sFixPath + sdocId + "')";
			// Read OData based on path and parameters
			oModel.read(sPath, mParams);

		},

		dequeueEngagement: function () {

			var mParamsModel = this.getOwnerComponent().getModel("mimportaingParams");
			var docId = mParamsModel.getProperty("/DocId");

			var fnSuccess = jQuery.proxy(function (oData, response) {

				},
				this);

			var fnError = jQuery.proxy(function (oData, response) {

			}, this);

			var oDataModl = this.getOwnerComponent().getModel();
			oDataModl.callFunction('/engDequeue', {
				urlParameters: {
					VBELN: docId

				},
				method: "GET",
				success: fnSuccess
			});

		},
		onBTPSave: function (oEvent) {
			var jsonModel = this.getOwnerComponent().getModel("mBTPAdr");
			var oModel = this.getOwnerComponent().getModel();
			var data = jsonModel.getProperty("/AddrToBillParty");;
			var title = this.byId("oCombobox").getSelectedKey();
			//Busy Dialog
			sap.ui.core.BusyIndicator.show(0);

			var fnSuccess = jQuery.proxy(function (oData, oResponse) {
				var oResult = JSON.parse(JSON.stringify(oResponse));
				sap.ui.core.BusyIndicator.hide();
				this.ShowMessage(oResult.headers.status);
			}, this);
			var fnError = jQuery.proxy(function (oData, oResponse) {
				var oResult = JSON.parse(JSON.stringify(oResponse));
				sap.ui.core.BusyIndicator.hide();
				this.ShowMessage(oResult.headers.status);
			}, this);
			var mParams = {
				success: fnSuccess,
				error: fnError
			};

			var sFixPath = "/BtpAddrSet(VBELN='";
			var sSep = "',";
			// Create path for OData call
			var sPath = sFixPath + data.VBELN + sSep + "KUNNR='" + data.KUNNR + "')";
			//filtering data before sending
			var keys = Object.keys(data);
			var editData = {};
			for (var i = 1; i < keys.length; i++) {
				editData[keys[i]] = data[keys[i]];
			}
			editData.Title = title;
			oModel.update(sPath, editData, mParams);
		}
	});
});