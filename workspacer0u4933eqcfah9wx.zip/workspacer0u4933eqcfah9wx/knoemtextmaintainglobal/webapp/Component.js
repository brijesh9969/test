sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"kno/em/textmaint/germany/model/models"
], function(UIComponent, Device, models) {
	"use strict";

	return UIComponent.extend("kno.em.textmaint.germany.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function() {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// set the device model
			//this.setModel(models.createDeviceModel(), "device");

			// call the base component's init function and create the App view
			UIComponent.prototype.init.apply(this, arguments);
			// create the views based on the url/hash
			this.getRouter().initialize();

			var mHdrTxtID = new sap.ui.model.json.JSONModel({
				items: []
			});
			this.setModel(mHdrTxtID, "mHdrTxtID");

			var mABSTxt = new sap.ui.model.json.JSONModel({
				items: []
			});
			this.setModel(mABSTxt, "mABSTxt");

			var mBTPAdr = new sap.ui.model.json.JSONModel({
				
			});
			this.setModel(mBTPAdr, "mBTPAdr");
			
			var mTmpDate = new sap.ui.model.json.JSONModel({
				
			});
			this.setModel(mTmpDate, "mTmpDate");
			
			var mLangnew = new sap.ui.model.json.JSONModel({
 
			});
			this.setModel(mHdrTxtID, "mLangnew");
			
			var mDocStat = new sap.ui.model.json.JSONModel({
 
			});
			this.setModel(mDocStat, "mDocStat");

			var mHdrTxtParams = new sap.ui.model.json.JSONModel({
				items: undefined
			});
			this.setModel(mHdrTxtParams, "mHdrTxtParams");

			var mParamsExist = new sap.ui.model.json.JSONModel();
			this.setModel(mParamsExist, "mParamsExist");

			var mHdrTxtChg = new sap.ui.model.json.JSONModel({
				items: undefined
			});
			this.setModel(mHdrTxtChg, "mHdrTxtChg");

			var mParamValue = new sap.ui.model.json.JSONModel({
				values: undefined
			});
			this.setModel(mParamValue, "mParamValue");

			var mFuncValue = new sap.ui.model.json.JSONModel({
				values: []
			});
			this.setModel(mFuncValue, "mFuncValue");

		}
	});
});