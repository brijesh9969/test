sap.ui.define([
	"knoemprintbasketgermany/controller/BaseController",
	"sap/ui/model/json/JSONModel"
], function(BaseController, JSONModel) {
	"use strict";

	return BaseController.extend("kno.em.printmaint.germany.controller.App", {});

});