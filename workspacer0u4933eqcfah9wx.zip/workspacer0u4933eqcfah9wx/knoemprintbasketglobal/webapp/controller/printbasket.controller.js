sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/GroupHeaderListItem",
	"sap/ui/Device",
	"sap/m/MessageBox",
	"sap/m/MessageToast"
], function (Controller, JSONModel, History, Filter) {
	"use strict";

	return Controller.extend("kno.em.printmaint.germany.controller.printbasket", {

		/*		onExit: function() {
					this.dequeueEngagement();
					this.destroy();

				},*/

		onInit: function () {
			/*	var oComponentData = this.getOwnerComponent().getComponentData();
				var sImportingParamDocId;
				var sImportingParamDoctype;
				var sImportingParamEngNum;
				var sImportingParamFinalAtt;
				var sImportingParamPrintStatus;
				var sImportingParamClnt;
				var sImportingParamPrt;*/
			var sStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session),
				sNavData = sStorage.get("PrintKey");
			this.sDocTyp = sNavData.DOC_TYPE;
			var sImportingParamDocId = sNavData.VBELN,
				sImportingParamDoctype = sNavData.DOC_TYPE_TEXT,
				sImportingParamEngNum = sNavData.ENGNUM,
				sImportingParamFinalAtt = sNavData.FINALATT,
				sImportingParamPrintStatus = sNavData.PRINT,
				sImportingParamClnt = sNavData.Cname,
				sImportingParamPrt = sNavData.Ename;
			var sImportingParamDisp = sNavData.ParamDisp;
			var oTextResource = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var sYes = oTextResource.getText("Yes");
			var sNo = oTextResource.getText("No");
			if (sImportingParamFinalAtt) {
				sImportingParamFinalAtt = sYes;
			} else {
				sImportingParamFinalAtt = sNo;
			}
			/*	if (oComponentData.startupParameters && jQuery.isEmptyObject(oComponentData.startupParameters) ===
					false) {
					if (oComponentData.startupParameters.DocId) {

						sImportingParamDocId = oComponentData.startupParameters.DocId[0];
					}
					if (oComponentData.startupParameters.Doctype) {

						sImportingParamDoctype = oComponentData.startupParameters.Doctype[0];

						var specialChars = "%20";
						if (sImportingParamDoctype) {
							sImportingParamDoctype = sImportingParamDoctype.replace(new RegExp(specialChars, 'gi'), " ");

						}
					}
					if (oComponentData.startupParameters.EngNum) {

						sImportingParamEngNum = oComponentData.startupParameters.EngNum[0];
					}
					if (oComponentData.startupParameters.FinalAtt) {

						sImportingParamFinalAtt = oComponentData.startupParameters.FinalAtt[0];
						if (sImportingParamFinalAtt) {
							sImportingParamFinalAtt = "Yes";
						} else {
							sImportingParamFinalAtt = "No";
						}
					}
					if (oComponentData.startupParameters.PrintStatus) {

						sImportingParamPrintStatus = oComponentData.startupParameters.PrintStatus[0];
					}

					if (oComponentData.startupParameters.Client) {
						// Get Client from Startup parameters
						sImportingParamClnt = oComponentData.startupParameters.Client[0];
					}
					if (oComponentData.startupParameters.Partner) {
						// Get Partner from Startup parameters
						sImportingParamPrt = oComponentData.startupParameters.Partner[0];
					}

				}*/
			if (!sImportingParamDocId) {
				sImportingParamDocId = "";
			}

			if (sImportingParamDocId.length < 10) {

				for (var i = sImportingParamDocId.length; i < 10; i++) {

					sImportingParamDocId = '0' + sImportingParamDocId;
				}
			}
			//	var slink = "/sap/opu/odata/SAP/CA_OC_OUTPUT_REQUEST_SRV/Roots(ApplObjectType='BILLING_DOCUMENT',ApplObjectId='sImportingParamDocId')/Preview/$value/ -";
			var slink = "/sap/opu/odata/KNO/EM_BILL_PRINT_SRV/" + "Roots(ApplObjectType='BILLING_DOCUMENT',ApplObjectId='" +
				sImportingParamDocId + "',LOG_HANDLE='')/" + "Preview/$value/";
			$('#print').hide();

			/*	var specialChars = "%20";
				if (sImportingParamClnt) {
					sImportingParamClnt = sImportingParamClnt.replace(new RegExp(specialChars, 'gi'), " ");

				}

				if (sImportingParamPrt) {
					sImportingParamPrt = sImportingParamPrt.replace(new RegExp(specialChars, 'gi'), " ");
				}

				if (sImportingParamPrintStatus) {
					sImportingParamPrintStatus = sImportingParamPrintStatus.replace(new RegExp(specialChars, 'gi'), " ");
				}*/

			// var oDataModl = this.getOwnerComponent().getModel();
			// var fnSuccess = jQuery.proxy(function (oData, response) {

			// 	if (oData.ATT_STATUS) {
			// 		sImportingParamFinalAtt = oData.ATT_STATUS;
			// 	}
			// });

			// oDataModl.callFunction('/fnPrintPreview', {
			// 	urlParameters: {
			// 		ACTION: "GET",
			// 		VBELN: sImportingParamDocId
			// 	},
			// 	method: "GET",
			// 	success: fnSuccess
			// });
			var oModel = new JSONModel({
				DocId: sImportingParamDocId,
				Doctype: sImportingParamDoctype,
				EngNum: sImportingParamEngNum,
				FinalAtt: sImportingParamFinalAtt,
				PrintStatus: sImportingParamPrintStatus,
				link: slink,
				Clnt: sImportingParamClnt,
				Prtnr: sImportingParamPrt,
				ParamDisp: sImportingParamDisp
			});
			this.getOwnerComponent().setModel(oModel, "mimportaingParams");
			//	this._createReuseComponents();	

			var oHtml = this.getView().byId("idFrame");

			var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/KNO/EM_BILL_PRINT_SRV/");
			//  oModel.getData("/Data");
			oModel1.read("Roots(ApplObjectType='BILLING_DOCUMENT',ApplObjectId='" +
				sImportingParamDocId + "',LOG_HANDLE='')/" + "Preview/$value/", {

					success: function (oData, response) {
						//     var file = response.requestUri;
						//   window.open(file);
						oHtml.setContent("<iframe src=" + response.requestUri + " height='700' width='1000'></iframe>");
					},
					error: function (oResponse) {
						try {
							var sMessage = oResponse.response.body.split("<message>")[1].split("</message>")[0].toString();
						} catch (e) {}
						if (!sMessage) {
							sMessage = "Error Occured, print preview cannot be loaded.";
						}
						sap.m.MessageBox.error(sMessage, {
							title: "Error", // default
							textDirection: sap.ui.core.TextDirection.Inherit // default
						});
					}
				});

			//		oHtml.setContent("<iframe src=" + response + " height='700' width='1000'></iframe>");

		},

		onAfterRendering: function () {

			var mParamsModel = this.getOwnerComponent().getModel("mimportaingParams");
			var sParamDisp = mParamsModel.getProperty("/ParamDisp");
			if (sParamDisp == true) {
				try {
					var oOutBtn = this.getView().byId("__save1");
					oOutBtn.setEnabled(false);
					var oTxtBtn = this.getView().byId("__save");
					oTxtBtn.setEnabled(false);
				} catch (e) {}
			} else {
				try {
					oOutBtn = this.getView().byId("__save1");
					oOutBtn.setEnabled(true);
					oTxtBtn = this.getView().byId("__save");
					oTxtBtn.setEnabled(true);
				} catch (e) {}
			}

			if (this.sDocTyp === 'DMRT') {
				this.getView().byId("__save1").setEnabled(false);
			} else {
				this.getView().byId("__save1").setEnabled(true);
			}

		},

		onPreviewPress: function () {
			var mParamsModel = this.getOwnerComponent().getModel("mimportaingParams");
			var invoiceId = mParamsModel.getProperty("/DocId");
			sap.m.URLHelper.redirect("/sap/opu/odata/KNO/EM_BILL_PRINT_SRV/" + "Roots(ApplObjectType='BILLING_DOCUMENT',ApplObjectId='" +
				invoiceId + "')/" + "Preview/$value/", true);
		},

		_createReuseComponents: function () {

			var o = this.createId("idOutputControlComponent");
			this._oOutputControlComponent = sap.ui.getCore().createComponent({
				name: "sap.ssuite.fnd.om.outputcontrol.outputitems",
				id: o,
				settings: {
					objectType: "BILLING_DOCUMENT",
					showTableTitle: false,
					hideIssueOutputAction: false
				}
			});
			this.byId("idOutputControlContainer").setComponent(this._oOutputControlComponent);
		},

		_setReuseComponentProperties: function () {

			// Set document id, display mode and trigger a refresh of the reuse
			// components
			var mParamsModel = this.getOwnerComponent().getModel("mimportaingParams");
			var invoiceId = mParamsModel.getProperty("/DocId");
			var bSnapshot = false;
			if (this._oOutputControlComponent) {
				this._oOutputControlComponent.setEditMode(this._sMode === "display" || bSnapshot ? "D" : "C");
				this._oOutputControlComponent.setObjectId(invoiceId);
				this._oOutputControlComponent.refresh();
			}

		},
		onNavBack: function () {
			this.dequeueEngagement();
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				oCrossAppNavigator.toExternal({
					target: {
						shellHash: "#Shell-home"
					}
				});
			}

		},
		onTextPress: function (oEvent) {
			var mParamsModel = this.getOwnerComponent().getModel("mimportaingParams");
			var sInvoiceId = mParamsModel.getProperty("/DocId");
			// var sDoctype = mParamsModel.getProperty("/Doctype");
			// var sPrtnr = mParamsModel.getProperty("/Prtnr");
			// var sClnt = mParamsModel.getProperty("/Clnt");
			// var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service

			// var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
			// 	target: {
			// 		semanticObject: "ZTextMaintain",
			// 		action: "zmanage"
			// 	},
			// 	params: {
			// 		DocId: sInvoiceId,
			// 		DocType: sDoctype,
			// 		Client: sPrtnr,
			// 		Partner: sClnt
			// 	}

			// }));

			// oCrossAppNavigator.toExternal({
			// 	target: {
			// 		shellHash: hash
			// 	}
			// });

			var fnSuccess = jQuery.proxy(function (oData, response) {
					if (oData.SUCCESS) {

						var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service

						var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
							target: {
								semanticObject: "ZTextMaintain",
								action: "zmanage"
							}

						}));
						var sStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
						//to add data in the storage 
						sStorage.put("TextKey", oData);

						oCrossAppNavigator.toExternal({
							target: {
								shellHash: hash
							}
						});

					} else {

						this.displayErrorMessage(oData.MESSAGE);
					}
				},
				this);
			var oDataModl = this.getOwnerComponent().getModel();
			oDataModl.callFunction('/fnTextMaint', {
				urlParameters: {
					ACTION: "CRET",
					VBELN: sInvoiceId
				},
				method: "GET",
				success: fnSuccess
			});
		},
		displayErrorMessage: function (sMessage) {
			sap.m.MessageBox.error(sMessage, {
				title: "Error", // default
				textDirection: sap.ui.core.TextDirection.Inherit // default
			});
		},

		displayMessage: function (sMessage) {
			sap.m.MessageToast.show(sMessage, {
				duration: 5000, // default
				width: "15em", // default
				my: "center bottom",
				at: "center bottom",
				of: window, // default
				offset: "0 0", // default
				collision: "fit fit", // default
				autoClose: true, // default
				animationTimingFunction: "ease", // default
				animationDuration: 1000, // default
				closeOnBrowserNavigation: true // default
			});
		},

		onOutputPress: function (oEvent) {
			var oView = this.getView();
			var oDialog = oView.byId("selectprinter");
			// create dialog lazily
			if (!oDialog) {
				// create dialog via fragment factory
				// var oCtrl = sap.ui.controller("kno.em.billsrch.germany.ext.controller.ListReportActions");
				oDialog = this.oDialog = sap.ui.xmlfragment(oView.getId(), "kno.em.printmaint.germany.fragments.CustomPopUp",
					this);
				// connect dialog to view (models, lifecycle)
				oView.addDependent(oDialog);
			}

			var fnSuccess = jQuery.proxy(function (oData, response) {
					if ((oData.results[0]) && (!oData.results[0].SUCCESS)) {
						if (oData.results[0].ACTION == "EIN") {
							try {
								//	this.getView().byId("idComboBoxPrinter").setVisible(false);
								this.getView().byId("idMsg").setVisible(true);
								//	this.getView().byId("orderTypeLabel").setVisible(false);
								this.getView().byId("idMsg").setText(oData.results[0].MESSAGE);
								var oLocalRad = this.getView().byId("idLocal").setVisible(true);
								var oCentralRad = this.getView().byId("idCentral").setVisible(true);
								oLocalRad.setEditable(false);
								oCentralRad.setEditable(false);
								oLocalRad.setSelected(false);
								oCentralRad.setSelected(false);
								this.eInvoice = "X";
								this.oDialog.open();
							} catch (e) {}
						} else if (oData.results[0].ACTION == "OUT" && (oData.results[0].MESSAGE)) {
							this.eInvoice = "";
							this.displayErrorMessage((oData.results[0].MESSAGE));
						}
						return;
					}
					try {
						oLocalRad = this.getView().byId("idLocal").setVisible(true);
						oCentralRad = this.getView().byId("idCentral").setVisible(true);
						oLocalRad.setEditable(true);
						oCentralRad.setEditable(true);
						oLocalRad.setSelected(true);
						oCentralRad.setSelected(false);
						//	this.getView().byId("idComboBoxPrinter").setVisible(true);
						if (oData.results[0].LOCALONLY == "X") {
							this.getView().byId("idCentral").setVisible(false);
						}
						this.getView().byId("idMsg").setVisible(false);
						//	this.getView().byId("orderTypeLabel").setVisible(true);
						this.eInvoice = "";
					} catch (e) {}
					var mPrinters = new sap.ui.model.json.JSONModel({
						items: []
					});
					mPrinters.setSizeLimit(3000);

					var arrPrinters = [];

					for (var i = 0; i < oData.results.length; i++) {
						var mPrinter = {
							PRINTER: oData.results[i].PRINTER,
							PRINTER_NAME: oData.results[i].PRINTER_NAME,
						};

						arrPrinters.push(mPrinter);
					}

					mPrinters.setProperty("/items", arrPrinters);
					this.getView().setModel(mPrinters, "mPrinters");
					try {
						var oMessageStrip = this.getView().byId("PrintersMessageStrip");
						oMessageStrip.setVisible(false);
					} catch (e) {}
					this.oDialog.open();

				},
				this);

			var oDataModl = this.getOwnerComponent().getModel();
			var mParamsModel = this.getOwnerComponent().getModel("mimportaingParams");
			oDataModl.callFunction('/fnPrinters', {
				urlParameters: {
					ACTION: "OUT",
					VBELN: mParamsModel.getProperty("/DocId")
				},
				method: "GET",
				success: fnSuccess
			});

		},
		onOKPressed: function () {
			var mParamsModel = this.getOwnerComponent().getModel("mimportaingParams");
			var oHtml = this.getView().byId("idFrame");
			var oOutBtn = this.getView().byId("__save1");
			var oTxtBtn = this.getView().byId("__save");
			if (this.eInvoice == "X") {
				var oDialog = this.getView().byId("selectprinter");
				if (oDialog) {
					oDialog.close();
				}
				//return;
			}

			if (this.getView().byId("idLocal").getSelected() === true) {
				var sAction = "LOC";
				var sPrinter = "X";
			} else if (this.getView().byId("idCentral").getSelected() === true) {
				sAction = "CEN";
				sPrinter = "";
			} else if (this.eInvoice == "X") {
				sAction = "EIN";
			}

			// try {
			// 	var sPrinter = this.getView().byId("idComboBoxPrinter").getSelectedKey();
			// } catch (e) {}
			if (this.eInvoice == "X") {
				sPrinter = 'PDF';
			}

			// if (!sPrinter) {
			// 	this.displayErrorMessage("Please Select a Printer");
			// 	return;
			// }
			oDialog = this.getView().byId("selectprinter");
			if (oDialog) {
				oDialog.close();
			}
			var sMessages;
			var oDataModl = this.getOwnerComponent().getModel();
			var invoiceId = mParamsModel.getProperty("/DocId");
			var fnSuccess = jQuery.proxy(function (oData, response) {
				if (sAction != "LOC") {
					if (oData.SUCCESS) {
						sMessages = oData.MESSAGE;
						oOutBtn.setEnabled(false);
						oTxtBtn.setEnabled(false);
						sap.m.MessageToast.show(sMessages, {
							duration: 5000, // default
							width: "15em", // default
							my: "center bottom",
							at: "center bottom",
							of: window, // default
							offset: "0 0", // default
							collision: "fit fit", // default
							autoClose: true, // default
							animationTimingFunction: "ease", // default
							animationDuration: 1000, // default
							closeOnBrowserNavigation: true // default
						});
					} else {
						sMessages = oData.MESSAGE;
						oOutBtn.setEnabled(true);
						oTxtBtn.setEnabled(true);
						sap.m.MessageBox.error(sMessages, {
							title: "Error", // default
							textDirection: sap.ui.core.TextDirection.Inherit // default
						});
					}
				} else {
					try {
						oOutBtn.setEnabled(false);
						oTxtBtn.setEnabled(false);
					} catch (e) {}

					var oModel1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/KNO/EM_BILL_PRINT_SRV/");
					//  oModel.getData("/Data");
					oModel1.read("Roots(ApplObjectType='BILLING_DOCUMENT',ApplObjectId='" +
						mParamsModel.getProperty("/DocId") + "',LOG_HANDLE='')/" + "Preview/$value/", {

							success: function (oData, response) {
								//     var file = response.requestUri;
								//   window.open(file);
								var slink = "/sap/opu/odata/KNO/EM_BILL_PRINT_SRV/" + "Roots(ApplObjectType='BILLING_DOCUMENT',ApplObjectId='" +
									mParamsModel.getProperty("/DocId") + "',LOG_HANDLE='PRINT')/" + "Preview/$value/";

								oHtml.setContent("<iframe src=" + slink + " height='700' width='1000'></iframe>");
							},
							error: function (oResponse) {
								try {
									var sMessage = oResponse.response.body.split("<message>")[1].split("</message>")[0].toString();
								} catch (e) {}
								if (!sMessage) {
									sMessage = "Error Occured, print preview cannot be loaded.";
								}
								sap.m.MessageBox.error(sMessage, {
									title: "Error", // default
									textDirection: sap.ui.core.TextDirection.Inherit // default
								});
							}
						});
				}
			});
			oDataModl.callFunction('/fnPrintPreview', {
				urlParameters: {
					ACTION: sAction,
					VBELN: invoiceId,
					PRINTER: sPrinter
				},
				method: "GET",
				success: fnSuccess
			});
		},
		dequeueEngagement: function () {

			var mParamsModel = this.getOwnerComponent().getModel("mimportaingParams");
			var docId = mParamsModel.getProperty("/DocId");

			var fnSuccess = jQuery.proxy(function (oData, response) {

				},
				this);

			var fnError = jQuery.proxy(function (oData, response) {

			}, this);

			var oDataModl = this.getOwnerComponent().getModel();
			oDataModl.callFunction('/fnPrintDeq', {
				urlParameters: {
					ACTION: "OUT",
					VBELN: docId
						// MODE: sMode
				},

				method: "GET",
				success: fnSuccess,
				error: fnError
			});

		},

		onCancelPressed: function () {

			var oDialog = this.getView().byId("selectprinter");
			if (oDialog) {
				oDialog.close();
			}
		}
	});
});